# EarthDelta · Claude Code 项目说明（v9.1）

当前工作以 `plans/plan_v9_online_20260929/` 方案包为准。开始任何任务之前，先读：
@plans/plan_v9_online_20260929/00_START_HERE.md
@plans/plan_v9_online_20260929/AUTHORIZATIONS.md

## 常驻规则

1. **授权**：只执行 `AUTHORIZATIONS.md` 中已经签署的事项。T5、T6、2021 年和 2022 年的数据、安装依赖、改动 `.gitignore`，都需要对应条目的签署。不能根据对话自行推断授权。

2. **数据年份**：目前只使用 2020 年。2021 年数据需要 A7 授权，2022 年数据需要 A8 授权。

3. **因果（actor 与 scorer 分离）**
   - 发布预报的一方（actor）只能读取两类东西：起报时刻及之前的输入（索引 ≤ t），以及 `available_time ≤ cutoff(t)` 的已释放监督记录。
   - 用到 cutoff 之后真值的评分和诊断结果，永远不能进入 actor 的任何状态、选择或发布的预报。
   - 已兑现的监督经释放接口进入 actor，这是允许的。
   - 所有 actor 路径都必须通过"未来真值投毒不变性"测试，测试方法见 T2。

4. **冻结文件，只能 import，不能修改**：
   - `scripts/probe_p0.py`、`scripts/probe_p1_qc.py`、`scripts/probe_p2_engine.py`、`scripts/probe_p3_directions.py`、`scripts/probe_p4_menu.py`、`scripts/probe_smoke.py`、`scripts/probe_step2_static.py`
   - `earthdelta/probe/` 下的全部文件
   - `earthdelta/v8/` 下的全部文件
   - `earthdelta/bridge/`、`earthdelta/static_adapter.py`、`earthdelta/lowrank.py`、`earthdelta/memory.py`
   - 例外只有两个：
     - T1 可以修改 `scripts/probe_p5_estimators.py`；
     - T6 获得 A6 授权后，可以修改 `earthdelta/data/pull_wb2.py`。

5. **新代码只能放在以下位置**：`earthdelta/online/`、`scripts/online_*.py`、`configs/online_*.json`、`tests/test_online_*.py`。只支持在源码检出（source checkout）下运行：从仓库根目录执行 `PYTHONPATH=. python scripts/xxx.py`。

6. **测试**：
   - 测试命令为 `PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/ -q -m "not slow"`。原有测试不能变红。
   - CPU 测试不能加载真实的 checkpoint。
   - 依赖 zarr 的测试，如果因为缺依赖被跳过，必须在汇报里如实写明，不能算作通过。

7. **GPU**：默认本机没有 GPU。只负责写命令、配置和预算估算，由人类执行。

8. **指标**：对外报告一律使用 `earthdelta/online/metrics.py`（面积加权正确）。不得报告 `earthdelta/probe/rollout.py:area_weighted_mse` 给出的绝对值。

9. **来源记录**：每个 run 使用唯一 ID（UTC 时间加配置哈希），只写一次，不覆盖已有结果；同时保存最小来源清单。具体要求见 03 的 E 节。

10. **Git**：禁止使用 `git add .` 或 `git add -A`，只能用显式的 `git add <文件>` 添加已授权的小文件。`runs/` 下的大文件不提交。

11. **决策**：不替人做 Gate 判断，只输出各条规则的状态和建议。

12. **汇报**：每完成一个任务，按 `00_START_HERE.md` 中的格式汇报，然后停下来等待确认。
