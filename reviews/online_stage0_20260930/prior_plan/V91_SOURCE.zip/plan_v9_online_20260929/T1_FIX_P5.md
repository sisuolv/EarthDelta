# T1 基线环境检查 + 修复 P5（授权 A1）

## 第 0 步：在本机建立基线（修改任何代码之前）

1. 记录以下环境信息：`git rev-parse HEAD`、`git status --porcelain`、未提交改动的 diff 哈希、Python 与 torch 版本、CUDA 是否可用、依赖列表（`pip freeze` 的摘要）。
2. 运行全量 CPU 测试：`PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/ -q -m "not slow"`，记录通过、失败和跳过的数量。
3. 检查根目录的 `CLAUDE.md` 在合并后是否存在规则冲突。
4. 把以上结果写入 `runs/online/env_baseline_<UTC>.json`（不提交），然后汇报。**如果原有测试本来就有失败，先停下来问。**

## 目标

让 `scripts/probe_p5_estimators.py` 能正确处理 P4 输出的四维数组：`[N, A, 6, 4]`（其中 TTT 部分为 `[N, 6, 6, 4]`），并补上测试。

## 不能改动的部分

`SPEC_SHA`、决策阈值（2.0 / 1.0 / −0.5 / 0.5）、`improvement()` 的定义（先 pooled MSE，再计算 RMSE 改善）、已有输出 JSON 的字段名。**不要推断 spec 对"扩展菜单合并"的语义**：原 spec 的全文不在仓库里。

## 需要修改的部分

1. **`menu(values)`**：对每个 issue，先把 24 个格子展平取平均，再选 arm。
   ```python
   n, a = values.shape[:2]
   chosen = values.reshape(n, a, -1).mean(axis=2).argmin(axis=1)   # [N]
   selected = values[np.arange(n), chosen]                          # [N, 6, 4]
   return chosen, selected, improvement(selected, values[:, 0])
   ```
2. **`static(values)`**：`arm = int(values.reshape(n, a, -1).mean(axis=(0, 2)).argmin())`，取值范围为 0..A-1。
3. **`bootstrap(...)`**：内部缓存的形状改为 `(draws, *g.shape[2:])`。对外仍然只返回 CI 字典，每个 lo/hi 的形状为 `[6, 4]`，**不要**把整个缓存作为返回值。
4. **收据校验**：替换现在形同虚设的 `digest(path) == ""` 检查。对每个 `MENU_EVAL_SHARD_*.npz`，读取对应的 `MENU_EVAL_RECEIPT_XX.json`（文件名以 P4 实际写出的为准，先用 grep 确认），逐项校验：
   - `status == "OBSERVED"`，且不是 dry run；
   - `output_sha256` 与文件实际哈希一致；
   - `spec_sha` 一致；
   - 各 shard 的 issue 划分合在一起，恰好等于 spec 中的 E 集合，不重不漏；
   - 各 shard 的 arm 元数据一致；
   - 三个方向族中的 F0 列一致；
   - 数值全部有限，维度正确。

   任何一项不通过，就置为 BLOCKED。
5. **扩展（extension）的处理**：当 `extension["gradient"]` 或 `extension["random"]` 为真时：
   - `ORACLE_RESULTS.json` 照常写出基础菜单的诊断结果；
   - `DECISION.json` **和** `P5_RECEIPT.json` 都把 `decision` 和 `route` 设为 `null`，`status` 设为 `"EXTENSION_REQUIRED"`；
   - 进程以非零退出码结束（建议用 3），确保上游不会把它当成 GO；
   - 在汇报中说明：这是按照代码注释中"先检查扩展，再解读菜单"的意图所做的修正。扩展以后如何合并，需要另行批准的规则。
6. **明确退出码**：OBSERVED 且有最终决策时为 0；BLOCKED 时为 1；EXTENSION_REQUIRED 时为 3。
7. **`mult4` 的注释**：代码实际包含正负两个方向（9、10、19、20……）。只改注释，不改代码。

## 测试：`tests/test_online_p5_shapes.py`

参照 `tests/test_probe_p3_layout.py` 中 `_load_p3` 的写法，用 importlib 加载脚本。

- N 取 1、4、8，各用随机数组测试：`chosen` 的形状为 `[N]`，`selected` 为 `[N, 6, 4]`，`improvement` 为 `[6, 4]`，而且与显式循环写出的参考实现逐元素一致。**N=1 和 N=4 必须测**，因为原代码在这两种情况下不会报错，而是静默出错。
- TTT 形状 `[N, 6, 6, 4]` 同样要测。
- 所有 arm 数值相同时：改善为 0，`chosen` 全为 0。
- 构造一个唯一最优的 arm，检查能否选中；再构造"静态最优"和"逐 issue 最优"不同的情形。
- bootstrap 用较小的 draws（例如 50），检查每个 lo/hi 的形状都是 `[6, 4]`。
- 收据校验：构造哈希不一致、状态不对、issue 划分重叠、F0 列不一致这四种坏情况，都必须得到 BLOCKED。
- 扩展场景：检查三个输出文件都没有给出最终决策，并且退出码为 3。
- 与 `probe/estimators.per_issue_oracle` 做交叉核对，只比较选中的 arm，不比较指标数值。

## 验收

- 全部测试通过，原有测试的状态和第 0 步记录的一致；
- 只改动了 `scripts/probe_p5_estimators.py`，并新增了上述测试文件；
- 汇报中附上 diff 摘要和第 0 步的环境记录。
