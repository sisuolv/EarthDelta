# T2 `earthdelta/online/` 工具模块（授权 A1）

## 目标

为阶段 0 和阶段 1 提供一套工具，保证下面几件事：
- 因果上不会泄漏未来信息；
- 指标计算正确；
- 维度可以从模型推断，不写死；
- 所有组件都能注入替换，以便在 CPU 上测试。

**先读 T0 产出的 `REUSE_DECISIONS.md`。** 凡是其中标为 import 或 pip 的组件，都不要重新实现。

所有函数都不能写死 128×256、1024 或 6291456。模型相关的元数据一律从模型本身推断，数据的读取、滚动预报和求梯度都要能注入替换。

## 模块与接口

### `timeindex.py`
- `STEP_HOURS = 6`
- `index_of(iso, year)`：检查 6 小时对齐、负数、跨年，以及闰年的上界（1464 或 1460）。
- `iso_of(index, year)`
- `daily_issues(start, end, year, hours=(0,))`

### `clock.py`：释放时钟与监督队列
- `SupervisionRecord`：不可变记录。
  - 字段包括：`kind`（如 residual、gradient）、`issue_index`、`steps`、`valid_index_max`、`analysis_window_end`、`available_index`、`versions`（包含 model、loss、norm、denominators 四项），以及 `payload`。
  - 构造时对 payload 做 copy，并调用 `setflags(write=False)`。
- `SupervisionQueue`
  - `add_pending(record)`：只供 worker 调用。
  - `release(cutoff_index) -> tuple[SupervisionRecord, ...]`：只返回尚未释放、且 `available_index <= cutoff` 的记录，结果稳定排序并去重。
  - actor 拿不到待释放记录的任何信息，包括数量、范数、失败状态等。
- `Derived`：一个轻量的包装类，内部跟踪 `max_available_index`。提供 `assert_usable(t_index)`，EWMA、DABC、OCL 特征、中心化均值都通过它来使用。
- `available_index_for(issue_index, steps, buffer_steps)`：可用时刻 = 最后一步的有效时刻 + 缓冲。

### `stores.py`：两种 store
两者都复用 `probe/access.py` 的读取方式和 JSONL 台账格式。

- `ActorStore(store_path, year, norm_dir, ledger, run_id, expected_coords)`
  - `read_input(index, *, t_index)`：要求 `index ≤ t_index`。
  - 做 QC：z = (x − mean) / std，其中 mean 和 std 从 `normalize_mean.npz` 和 `normalize_std.npz` 读取，**不能重新估计**；要求 `max|z| ≤ 40` 且数值全部有限。
  - 坏输入要记录下来，并由调用方执行事先规定好的回退方案。
  - 首次打开时，校验通道名、time、lat、lon 与期望是否一致，同时校验数组布局。
- `ScorerStore`：可以读取任意索引，只供评分和 worker 使用。它的 QC 结果**只写入评分掩码**，不会传给 actor。
- `qc_report(indices)`：生成数据报告。**这个报告不能被 actor 使用。**

### `losses.py`
- `area_weights(lat, width)`：cos 纬度加权，广播到整个网格后再归一化，与 `v8/standard_metrics._weights` 保持一致。
- `normalized_step_mse(pred_norm, truth_raw, bridge, lat, variables, steps, denominators)`：
  - 输入可以是任意 K 步、任意 H×W，并且可以反传梯度；
  - `denominators` 要带上版本号。
- `cells(...)`：在物理单位下计算面积加权 MSE，返回形状为 `[n_var, n_step]`。

### `metrics.py`（要保持很薄：同时推断交给 `arch`，官方指标交给 `earthdelta/wbx`）
- `relative_rmse_from_mse(mse_method, mse_base)`：输入形状为 `[N, V, L]`，按 pooled MSE 开方后计算。
- `calendar_blocks(issue_times, block_days)`：按固定的日历边界分块。
- `bootstrap(mse_by_method, issue_times, *, base, block_days, draws=10000, seed)`：
  - 所有方法共用同一套抽样；
  - 输出每个格子的**边际**百分位区间；
  - 输出**同时**区间：先把逐 issue 的损失差按日历周聚合成序列，再用 `arch.bootstrap`（StationaryBootstrap 或 CircularBlockBootstrap，加上 StepM、SPA、MCS）做推断。这里只保留聚合和掩码的薄封装，不要自己实现多重比较；
  - 提供 `diff(a, b)` 用于两两比较。
- `acf_pairs(series, issue_times, lags_days)`：按日历配对，缺失的位置用掩码，不做替补；配对完成后再做分块 bootstrap。
- 必须有一致性测试：在随机场上，结果要与 `v8/standard_metrics.relative_rmse` 一致；在同一小样本上，RMSE 要与 `earthdelta/wbx/evaluate` 的官方计算一致（需要 A2a 装好 wbx 的依赖；如果因此跳过，要在汇报中如实说明）。

### `grad_utils.py`
- `load_frozen_script(name)`：用 importlib 按路径加载冻结脚本（只支持源码检出）。先校验仓库根目录，并记录 commit。
- `target_metadata(model, blocks)`：从模型推断目标参数的名称、形状、总维度，以及 block 的编号。
- `weight_gradient(model_or_loaded, x, truth, *, steps, loss_fn, rollout_fn, deltas=None)`：
  - 如果 `deltas` 不为空，**不开 checkpoint**，或者在编辑上下文里完成反传；
  - 结束后恢复所有参数的 `requires_grad`，并检查 hook 数量为 0。
- `response_effect(edited_traj, f0_traj, truth, lat, step=4)`：
  - 计算在 24h 那一步上，编辑造成的预报变化与 F0 误差之比，按变量取平均；
  - 允许传入 K ≥ 4 的短轨迹，这样校准只需要跑 4 步 rollout；
  - 定义要和 `calibration_effect` 保持一致，并在 21 步的数据上与后者做交叉核对。
- `calibrate_amplitude(effect_fn, *, target, lo, hi, iters=12)`：与 P3 的对数二分算法相同。如果给定区间括不住目标值，就报错。
- `unit(v)`：零范数时返回 `None`，由调用方回退到 F0 并计数。另外提供 `cosine`。
- `structured_sketch(vector, *, seed, rank)`：只用于压缩诊断。报告里的主结果用完整梯度；sketch 要用多个 seed 与完整梯度的余弦做校验。

### `dabc.py`
- 符号约定：`bias = forecast − truth`，订正后为 `forecast − λ·bias`。
- 按日历时间衰减：权重为 `exp(−Δdays/τ)`。τ 和 λ 在拟合期选定，内部按时间分割。
- 只使用 `release(cutoff)` 之后的记录；同一个可用时刻的多条记录按稳定顺序处理；查询不能改变状态（采用快照语义）。

### `outcorr.py`（OCL：低容量的学习型输出订正）
- **基**：对每个变量、每个时效，用拟合期的残差场计算 K 个 EOF。
- **特征**：只用已释放的记录，包括两部分：同一时效上，最近若干个已兑现残差的 EOF 系数（按日历衰减做 EWMA）；最短时效（第 1 步）上，最新已兑现残差的 EOF 系数。
- **目标**：当期残差的 EOF 系数，然后还原成订正场，订正后为 `forecast − 预测的 bias`。
- **模型**：直接用 `sklearn` 的 Ridge 或 RidgeCV，配合 TimeSeriesSplit。α 在拟合期内按时间分割选定，每个时效单独建一个模型。EOF 用 numpy SVD，按 sqrt(cos lat) 加权。**不要引入 `eofs`**，它是 GPL-3.0。
- 所有特征都通过 `Derived` 检查可用性。

## 测试（全部在 CPU 上）

- `test_online_clock.py`
  - 释放语义，待释放记录不可见；
  - 修改源数组后，记录内容不变；
  - `max_available_index` 的传递；
  - **投毒不变性测试**：用合成序列、假的 rollout 和 actor 跑一遍流程。把 cutoff 之后的真值替换成 NaN 或 1e9 后，actor 的输出、选择和状态必须逐字节相同，而离线评分允许变化。
- `test_online_stores.py`
  - QC 使用 mean 和 std（正常的温度、气压不能被误判为异常）；
  - 坐标或通道不一致时报错；
  - scorer 的 QC 不影响 actor。
  - 用到 zarr 的测试写 `pytest.importorskip("zarr")`；如果被跳过，必须在汇报中写明，不能当作通过。
- `test_online_losses_metrics.py`
  - 常数误差场的面积加权 MSE 不随网格宽度变化；
  - 与 v8 的结果一致；
  - 边际区间和同时区间的形状；
  - 同时区间在合成零效应数据上的覆盖率大致正确（抽样次数少一点，只做粗检）；
  - `acf_pairs` 对缺失位置正确使用掩码。
- `test_online_grad.py`
  - 用小模型（`blocks[i].attn.proj = Linear(8, 8)`）复现"hook 移除后再用 checkpoint 反传"：**可以接受 CheckpointError，也可以接受数值不一致，两种都记录下来**；
  - 安全路径必须与 eager 模式以及中心有限差分一致，并记录 torch 版本；
  - `target_metadata` 在小模型上推断正确；
  - 零范数时正确回退。
- `test_online_dabc.py`
  - 符号正确；同一 cutoff 下反馈与 lag1 同时可用；
  - 在"每天一条记录、衰减按天"的特例下，结果与 `memory.ewma_error_feature` 一致。
- `test_online_outcorr.py`
  - 在合成的 AR(1) 残差序列上，OCL 优于静态偏差；
  - 特征只使用了已释放的记录。

## 验收

- 所有新模块都有 docstring，写明输入形状和因果约束；
- 测试全部通过，或者如实报告跳过的项；
- 冻结文件没有被改动。
