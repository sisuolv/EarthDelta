# T0 复用审计：先找能直接用的代码，再写新代码（授权：A1 负责盘点；A2a 负责安装依赖；A2b 负责克隆 batch 5）

## 为什么要做

仓库里已经有两类可以复用的资源：

1. `reference/`：钉住版本的第三方仓库，共 46 个。`_manifest.json` 记录了每个仓库的 HEAD 和 license，克隆脚本是 `_clone_refs*.sh`。
2. `earthdelta/wbx/`：已经接入官方 WeatherBench-X 的指标，包括 RMSE、MSE、Bias、ACC、GridAreaWeighting、Regions，以及年份门控。

v9.1 的 T2 打算自己实现指标、bootstrap 和 OCL，这有重复造轮子的风险。T0 的任务是：在 T2 动手之前，先定下每个组件用什么来实现。

**时间上限：半天。** 目的是减少新代码的量，不要为此再建一套流程。

## 步骤

1. **盘点本地的 `reference/`。** 逐一核对 `_manifest.json` 中的 46 个仓库：本地是否存在，HEAD 是否一致。只读，不修改。
2. **克隆 batch 5（需要 A2b）。** 把本方案包里的 `reference_clone_batch5.sh` 复制为 `reference/_clone_refs_batch5.sh`，然后运行。克隆完成后，更新 `_manifest.json` 和 `reference/README.md`（格式与 batch 1–4 相同）。本批包含两个仓库：
   - `kimanki/TAFAS`（AAAI 2025）：用部分已观测的真值做测试时适配，并带门控校准；
   - `SJTU-DMTai/OnlineTSF`（KDD 2025 PROCEED，以及在线时间序列预测的基线）：明确讨论了标签延迟带来的时间差。
3. **提出 pip 依赖清单（需要 A2a 批准后才能安装）。** 对每个包写明版本、license 和用途。建议的清单如下：
   - `arch`（NCSA license）：block bootstrap（stationary、circular、moving），以及多重比较方法 SPA、StepM、MCS；
   - `scikit-learn`（BSD）：Ridge、RidgeCV、TimeSeriesSplit；
   - `zarr`、`xarray`、`fsspec`：读取 store；
   - `matplotlib`：画报告图；
   - `earthdelta/wbx/_vendor.py` 要求的 CPU 版 jax，按该文件的说明装进 `.pydeps_wbx`。
4. **产出 `plans/plan_v9_online_20260929/REUSE_DECISIONS.md`。** 下面预填了一版建议，请逐条核实或修改。复用方式只能从以下几种中选：
   - import：导入仓库内已有的模块；
   - pip：导入外部库；
   - vendor：带署名地拷贝（只限宽松 license）；
   - 只读参考：读代码、引用论文，但不拷贝代码；
   - 新写。
5. **如果需要修改方案文件**，写成补丁 `plans/plan_v9_online_20260929/t0_reuse.patch`，不要直接改 T2–T5。

## 预填的复用决策（待核实）

| v9.1 组件 | 复用来源 | 方式 | license 与注意事项 |
|---|---|---|---|
| Stormer 加载、rollout、编辑注入 | `earthdelta/probe/rollout.py`、`probe/edits.py`、`bridge/stormer_bridge.py`（其底层已对齐 `reference/stormer`） | import | 仓库内部代码 |
| LoRA | `static_adapter.build_fs_adapter`、`lowrank.ExpertLoRA`；语义参考 `reference/peft`、`reference/aurora/aurora/model/lora.py`（逐 rollout 步的 LoRA 模式） | import + 只读参考 | peft 为 Apache-2.0，aurora 为 MIT |
| 对外报告的主指标 | `earthdelta/wbx/evaluate.py`（官方 WBX 的 RMSE、ACC、GridAreaWeighting、Regions，自带年份门控） | import | 用于 T4 主格子的官方交叉核对；T2 的轻量指标必须与它一致 |
| 逐 issue 的格子指标 | `v8/standard_metrics.issue_mse` 的权重逻辑；T2 只新写一层很薄的封装 | import + 少量新写 | 与 v8 和 wbx 做一致性测试 |
| bootstrap 与同时推断 | `arch.bootstrap`：先把逐 issue 的损失差按周聚合成序列，再做 StationaryBootstrap 或 CircularBlockBootstrap；多重比较用 StepM、SPA、MCS | pip | 替代 T2 里自己写的"同时区间"。自己只保留按日历周聚合和掩码处理的代码 |
| OCL | `sklearn` 的 Ridge、RidgeCV，配合 TimeSeriesSplit；EOF 用 numpy SVD，按 sqrt(cos lat) 加权 | pip + 少量新写 | 不引入 `eofs`（GPL-3.0）。OCL 的外层接口参考 `reference/ORCA`（基于误差上下文的在线适配）的设计 |
| DABC | `memory.VerifiedRecord`、`eligible_records`、`ewma_error_feature` 的时间规则 | import + 少量新写 | 需要改成按日历衰减 |
| 释放队列与可用性检查 | `memory.VerifiedRecord` 的时间约束（issue < valid ≤ available）；`probe/access.py` 的台账格式 | import + 新写队列 | 投毒测试要新写 |
| 在线更新规则（T5） | `reference/OnlineTSF`（PROCEED 及在线基线的延迟标签协议）、`reference/TAFAS`（部分真值与门控）、`reference/PETSA`（低秩加门控的测试时适配） | 只读参考 | PETSA 是 CC BY-NC-SA，**不能拷贝**；另外两个仓库的 license 在克隆后核实 |
| 回路内订正对照（T5 可选） | `reference/INC`、`reference/Solver-in-the-Loop`（在自回归 rollout 中注入学习型订正） | 只读参考，或带署名 vendor | INC 为 Apache-2.0，Solver-in-the-Loop 为 MIT |
| 数据修复（T6） | `v8/data_repair.py`、`pull_wb2.py` 中的 regridder | import | 不能当作安全边界，见 T6 |

## 验收

- `REUSE_DECISIONS.md` 的每一行都经过核实：路径存在，符号存在，license 已确认；
- 列出 pip 依赖清单和 A2a 待签的内容；
- 如需修改 T2–T5，已经生成补丁；
- 估算复用之后 T2 新代码减少了多少行。
