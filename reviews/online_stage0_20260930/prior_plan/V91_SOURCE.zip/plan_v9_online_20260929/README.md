# EarthDelta 后续方案包 v9.1：延迟反馈下的在线适配（2026-09-29）

这份 README 写给人看，其余文件写给 Claude Code 执行。v9.1 按外部复查报告（`reviews/CODEX_REVIEW_PLAN_V9_20260929.md`）做了修订，每条意见的处理结果见 `CHANGELOG_v9_1.md`。

## 一、放进仓库

1. 用本目录覆盖仓库中的 `plans/plan_v9_online_20260929/`。旧的 `T3_P0_AUTOCORR.md` 已经拆分为 `T3A` 和 `T3B` 两个文件，请把旧文件删掉。
2. 把本目录里的 `CLAUDE.md` 放到仓库根目录。如果根目录已经有 `CLAUDE.md`，**不要直接追加**，先人工检查两份规则是否冲突，再合并。
   Claude Code 启动时会自动加载项目根目录的 `CLAUDE.md`，并通过其中的 `@` 引用一并载入 `00_START_HERE.md`。启动后可以用 `/context` 确认是否加载成功。
3. 新建一个分支，例如 `online-adapt-20260929`。本方案包基于 `main@d55ad70`。

## 二、启动 Claude Code

在仓库根目录启动 Claude Code，第一条消息建议写：

```
请阅读 CLAUDE.md、plans/plan_v9_online_20260929/00_START_HERE.md 和 AUTHORIZATIONS.md，
再按 00_START_HERE.md 的顺序读完 01–03。
然后从 T1 的第 0 步（在本机跑基线测试并记录环境）开始：
先复述你的理解、要改动的文件和测试计划，等我确认后再改代码。
```

## 三、需要你本人做的事

- **授权。** 在 `AUTHORIZATIONS.md` 里签署各项授权。Claude Code 只能执行已签署的事项。
- **基础信息。** 提供真实环境信息和路径：checkpoint、归一化常数目录、2020 年的 store。
- **GPU 运行。** 所有 GPU 任务都由你执行。先跑拟合期试点（pilot），再跑分析期。
- **签署协议。** 拟合期 pilot 跑完后、分析期开跑前，填写并签署 `PHASE0_PROTOCOL.md`（阈值、实用效应 δ、预算）。**必须在看到任何分析期结果之前签署。**
- **Gate 判断。** Gate 1 由你来判断。

## 四、文件清单

| 文件 | 内容 |
|---|---|
| `CLAUDE.md` | 放到仓库根目录的常驻规则 |
| `AUTHORIZATIONS.md` | 授权表，由你签署 |
| `PHASE0_PROTOCOL.md` | 阶段 0 协议，在分析期开跑前由你签署 |
| `CHANGELOG_v9_1.md` | 复查意见的逐条处理记录 |
| `00_START_HERE.md` | 任务总览、工作方式、汇报格式 |
| `T0_REUSE_AUDIT.md` | 复用审计：先找能直接用的代码 |
| `reference_clone_batch5.sh` | batch 5 克隆脚本，复制到 `reference/_clone_refs_batch5.sh` 后使用 |
| `01_BACKGROUND.md` | 已有结果、转向的依据、新的研究问题 |
| `02_CODE_REUSE_MAP.md` | 可复用的现有代码（按复查结果更正过） |
| `03_RULES_AND_PITFALLS.md` | 因果时钟、事件顺序、已知问题 |
| `T1_FIX_P5.md` | 基线环境检查 + 修复 P5 |
| `T2_ONLINE_HELPERS.md` | `earthdelta/online/` 工具模块 |
| `T3A_P0_OUTPUT_SPACE.md` | 阶段 0-A：F0 预报库 + 输出空间残差可预测性（先做，成本低） |
| `T3B_P0_PARAM_SPACE.md` | 阶段 0-B：参数空间的滞后编辑 |
| `T4_P0_REPORT_AND_GATE1.md` | 报告与 Gate 1（修订版） |
| `T5_ONLINE_REPLAY.md` | 阶段 1：在线回放（需授权） |
| `T6_DATA_2021.md` | 数据管线与 2021 年数据（需授权） |
| `LATER_PHASES.md` | 阶段 2–4 与保底方案 |
| `STOP_CONDITIONS.md` | 必须停下来问你的情况 |
