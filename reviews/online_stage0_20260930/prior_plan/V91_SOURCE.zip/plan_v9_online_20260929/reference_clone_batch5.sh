#!/usr/bin/env bash
# Fifth batch (plan v9.1 / T0): delayed-feedback online adaptation references.
# Copy this file to reference/_clone_refs_batch5.sh, then run it from the repo root (requires A2b).
# Same conventions as batch 1-4: shallow clone, proxy fallbacks, nothing is modified.
set -u
REF="${REF:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
LOG="$REF/_clone_log_batch5.txt"
: > "$LOG"
PROXIES=("" "https://gh-proxy.com/" "https://ghfast.top/" "https://ghproxy.net/")
export GIT_TERMINAL_PROMPT=0
clone_one() {
  local repo="$1" dir="$2" branch="${3:-}" depth="${4:-1}"
  local dest="$REF/$dir"
  if [ -d "$dest/.git" ] || [ -f "$dest/_FROM_ZIP" ]; then echo "[skip] $dir exists" | tee -a "$LOG"; return 0; fi
  rm -rf "$dest"
  local args=(-q --depth "$depth"); [ -n "$branch" ] && args+=(--branch "$branch")
  for p in "${PROXIES[@]}"; do
    echo "[try] $repo via '${p:-direct}'" | tee -a "$LOG"
    if timeout 900 git clone "${args[@]}" "${p}https://github.com/${repo}.git" "$dest" 2>>"$LOG"; then
      git -C "$dest" remote set-url origin "https://github.com/${repo}.git"
      echo "[ok] $repo -> $dir @ $(git -C "$dest" rev-parse --short HEAD) $(git -C "$dest" log -1 --format=%cs)" | tee -a "$LOG"; return 0
    fi
    rm -rf "$dest"
  done
  echo "[FAIL] $repo" | tee -a "$LOG"; return 1
}
clone_one kimanki/TAFAS            TAFAS       # AAAI 2025: TTA with partially-observed ground truth + gated calibration
clone_one SJTU-DMTai/OnlineTSF     OnlineTSF   # KDD 2025 PROCEED + online TSF baselines; explicit delayed-label gap
echo "[done] $(date -u)" | tee -a "$LOG"
# After cloning: append {dir, remote, head, date, license, license_hint} for each repo to reference/_manifest.json
# and add a "Batch 5" table to reference/README.md (same schema as batches 1-4).
