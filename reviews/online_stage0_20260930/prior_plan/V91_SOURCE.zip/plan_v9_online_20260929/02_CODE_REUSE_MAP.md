# 02 代码复用地图（main@d55ad70，按复查意见更正）

**原则**：能 import 就不要复制；冻结文件只能 import，不能修改。行号可能会漂移，以函数名为准；动手前先用 grep 核对一遍。

**导入方式**：
- `scripts/` 目录没有 `__init__.py`，但在仓库根目录、并且设置了 `PYTHONPATH=.` 时，它可以作为 namespace package 被导入。所以 `scripts/probe_p4_menu.py` 里的 `from scripts.probe_p3_directions import ...` 在这个条件下是能工作的。
- `pyproject.toml` 只打包了 `earthdelta*`。如果只安装了 wheel，环境里根本没有 `scripts/`。
- 因此本项目**只支持源码检出**：
  - 库代码用 importlib 按文件路径加载冻结脚本；
  - 启动时校验仓库根目录，并记录 git commit；
  - 脚本一律从仓库根目录用 `PYTHONPATH=.` 运行。

**依赖**：`pyproject.toml` 只声明了 numpy、scipy、torch 和 pytest（dev）。zarr、xarray、fsspec、gcsfs、matplotlib 都没有声明。安装任何依赖都需要 A2 授权。

## 1. 变量与时效

完整顺序见 `earthdelta/bridge/stormer_bridge.py` 中的 `DEFAULT_VARIABLES`（69 个通道）。评分用的 6 个变量如下（已按字面量核对）：

| 名称 | 通道 | channel_index |
|---|---|---|
| Z500 | geopotential_500 | 11 |
| T850 | temperature_850 | 53 |
| T2m | 2m_temperature | 0 |
| MSLP | mean_sea_level_pressure | 3 |
| U850 | u_component_of_wind_850 | 27 |
| Q700 | specific_humidity_700 | 65 |

评估时效 6/24/72/120h 分别对应第 1/4/12/20 步，第 0 步是初始场，整条轨迹共 21 个状态。主终点为 Z500 和 T850 在 24h 与 72h 的结果。

## 2. 模型与滚动预报：`earthdelta/probe/rollout.py`

- **`load_bridge(checkpoint, norm_dir, device) -> LoadedBridge`**：尺寸固定为 patch 4、hidden 1024、depth 24、heads 16，处于 eval 模式。checkpoint 和归一化目录需要由外部提供。
- **`rollout_trajectory(bridge, x_norm, *, steps, deltas=None, target_blocks=(18..23), differentiable=False, checkpoint_steps=False)`**，输出形状 `[B, steps+1, 69, 128, 256]`。
  - 输入形状必须是 (69, 128, 256)，否则报错。
  - **只有 `differentiable` 和 `checkpoint_steps` 同时为真时，才真正启用 checkpoint。**
- **`area_weighted_mse`**：返回值是真实面积平均 MSE 的 W 倍（W=256）。当分子和分母都用这个旧函数、在同一网格上计算时，L6 和效应比里的常数因子可以抵消；但只要和正确实现的分母混用，就不能抵消。**新模块一律用正确的指标，并重新计算拟合期分母，不要搬用旧 `DIRECTIONS_RECEIPT` 里的分母。**
- **`l6_per_issue` 和 `l6_cells`**：对预测和真值都要求 21 个状态。

## 3. 全矩阵梯度与编辑

- **`scripts/probe_p3_directions.py`**（冻结）：
  - `target_params(model)`：只取 blocks 18–23 的 `attn.proj.weight`。
  - `flat_delta(vector, params, device)`：维度取自 params，但 block 编号是写死的。
  - `load_issue(...)`：读取 21 个连续缓存。
  - `calibration_effect(...)`：要求 21 个状态，只读取第 4 步；它是顶层函数，可以导入。
  - `effect()` 和 `calibrate()` 是 `main()` 内部的局部函数，**不能导入**。
  - `main()` 中第 135–177 行包括参数冻结、F0 分母计算和求梯度的流程。如果要抽取这段逻辑，必须把目标函数和归一化的身份一并记录下来。
- **`scripts/probe_p4_menu.py`** 第 113–133 行：真值辅助的一步梯度试探（原来叫 TTT）。编辑后的菜单部分在 inference_mode 下运行。
- **`earthdelta/probe/edits.py`**：
  - `DirectWeightEditor(model, deltas, *, blocks)`：注册 forward hook，把 `F.linear(input, delta)` 加到输出上；退出时移除 hook，不修改原权重。它**没有**受控 rollout 那样的并发保护。
  - `pristine_state_digest(model)`：对整个 `state_dict`（包括 buffers）的名称、形状和字节做哈希。**它不涵盖** `requires_grad`、train/eval 模式、临时 hook 或 RNG 状态，这些需要另外检查。

## 4. LoRA 路线（T5）

- **`earthdelta/static_adapter.py`**：
  - `build_fs_adapter(hidden_size, target_blocks=..., *, rank_per_expert=4, scale=1.0, seed=None, init_up_std=0.0)`：A 用 kaiming 做非零随机初始化；只有在 `init_up_std=0` 时 B 才是 0，也就是说初始 ΔW = 0。
  - `fs_edit_plan(steps: int, *, plan_id: str = "fs_always_on") -> EditPlan`
- **`earthdelta/bridge/stormer_bridge.py:1115` `controlled_rollout(...)`**：
  - 可以对 LoRA 因子求导。`differentiable` 只控制系数的构造方式，并不会关闭整个 autograd。
  - **保护的范围**：对同一个 bridge 或共享 backbone 的重入和并发调用会被拒绝；带有约定 checkpoint flag 的模块会被拒绝（第 997–1050 行）。**它识别不了任意外部的 checkpoint 包装**，所以不要在外面自己加 checkpoint。独立的模型实例可以并行运行。
- **`earthdelta/lowrank.py` `ExpertLoRA`**：系数形状为 `[B, K]`，会广播到所有 token。
- **`scripts/probe_step2_static.py`**（冻结，可作参考）：
  - `make_adapter` 在第 105 行，`state_cpu` 在第 116 行，`restore_state` 在第 121 行；
  - Adam 在第 176 行，训练循环从第 182 行开始，梯度裁剪在第 198 行；
  - 正式模式的限制检查在第 164 行；
  - OBC 在第 241–278 行：用拟合集的 `mean(pred − truth)` 作偏差，在 holdout 上选 λ。
  - 这些**不能**证明已经做过超参搜索（HPO）。

## 5. 数据、时间与因果

- **`earthdelta/probe/contracts.py:101` `issue_index(issue_time, *, year=2020)`**：只校验时刻是否落在 6 小时网格上，**不检查**是否越出当年范围。新写的 `index_of` 要补上对负数、跨年和闰年上界的检查。
- **`earthdelta/probe/access.py` `ProbeAccessController`**：按 spec 的 allowlist 授权并写台账。它**没有**针对每次预报的"截至时刻"时钟。
- **`scripts/probe_p1_qc.py`** 的 QC 规则：
  - z = (x − mean) / std，mean 和 std 分别来自 `norm_dir` 下的 `normalize_mean.npz` 和 `normalize_std.npz`；
  - 数据必须全部有限，且 `max|z| ≤ 40`；
  - 同时校验 lat、lon、time 的哈希。
  - **新的 QC 必须使用训练时的 mean 和 std，不能用新年份的数据重新估计。**
- **2020 年的 store**：元数据预期为 1464 步。历史上发现过 index 712 的异常值。**是否完整，本次需要做一次全量 QC 来确认。**
- **`earthdelta/memory.py`**：
  - `VerifiedRecord`：要求 issue < valid ≤ available；key 和 value 是一维张量，并做防御性拷贝。
  - `eligible_records`：按 available 过滤；拒绝 blocked 事件；拒绝重复的 record_id；版本不一致时报错；排序稳定。
  - `ewma_error_feature(records, origin, version, decay=0.95, max_records=None, blocked_events=frozenset())`：**按记录条数衰减，不是按天数**。没有符合条件的记录时返回零向量；records 本身为空时报错。

## 6. 指标

- **`earthdelta/v8/standard_metrics.py`**：
  - `issue_mse` 和 `relative_rmse`：面积权重正确，输入是单个变量的 `[issue, lead, H, W]`，结果为正表示改善。
  - `paired_bootstrap`：给出的是单个变量、多个时效的最大偏差在 0.995 分位上的半宽，**不是**逐格子的 95% 百分位区间。
- **`earthdelta/probe/estimators.py`**：选出的 arm 是对的，但它的指标是"每个 issue 的相对 MSE 改善再取平均"，和 P5 的"pooled MSE 开方"不一致，只能用来核对选中的 arm。

## 6b. 官方 WeatherBench-X 接入：`earthdelta/wbx/`

- `evaluate.py`：调用 vendored 的官方 `weatherbenchX.metrics.deterministic`（RMSE、MSE、Bias、ACC、WindVectorRMSE），以及 `weighting.GridAreaWeighting`、`binning.Regions`、`aggregation.Aggregator`。只是把 beam 流水线换成了普通循环。自带年份门控：默认只允许 2020 年，其他年份需要 confirm-freeze 文件。
- `export.py`：导出预报；`baselines.py`：官方公开基线 store 的注册表（00Z/12Z 配对规则）；`_vendor.py`：钉住 `reference/weatherbenchX` 的版本，需要把 CPU 版 jax 装到 `.pydeps_wbx`。
- **用途**：作为 T4 主格子的官方交叉核对，也作为 T2 指标的一致性测试基准。不要再另写一套官方指标。

## 6c. 第三方参考仓库：`reference/`

共 46 个钉住版本的仓库，清单见 `reference/_manifest.json`，说明见 `reference/README.md`，均为只读。其中与 v9.1 直接相关的：stormer、weatherbenchX、peft、aurora（LoRA）、PETSA（CC BY-NC-SA，不能拷贝）、ORCA（没有 license，只能读）、INC、Solver-in-the-Loop。batch 5 会新增 TAFAS 和 OnlineTSF，见 T0。

## 7. 数据修复（T6，需授权）

- **`earthdelta/v8/data_repair.py`**：
  - `repair_zarr_year` 所说的"全部成功"只针对传入的索引，**不代表全年完整**；空列表也可能返回成功；函数本身不检查年份授权。
  - `refetch_zarr_indices` 对已有的 target 以 `r+` 模式修改；每个批次最多尝试 2 次。
  - `FailClosedRepair.record_access` 会拒绝读取 2022 年的数组，但另外两个包装函数可以绕过它。
  - **结论：这些函数不能当作安全边界。**

## 8. 其他

- **`earthdelta/heads.py` `ReferenceErrorHead(feature_dim, target_dim, latent_dim=32)`**：forward 返回 `(latent, error)`。用它做输出订正之前，还需要另外定义低维目标、训练方式、如何还原回场以及成本，它不能直接当作理想的输出订正。
- **`earthdelta/probe/budget.py` `BudgetLedger`**：没有逐行复核过，不能用它代替对全阶段算力的核算。
- **`tests/test_probe_p3_layout.py`**：`_load_p3` 支持通过 `EARTHDELTA_P3_SCRIPT` 指定脚本路径；`_IdentityBridge` 只替代了 normalize 和 denormalize，不提供 model、pad 或 rollout。
