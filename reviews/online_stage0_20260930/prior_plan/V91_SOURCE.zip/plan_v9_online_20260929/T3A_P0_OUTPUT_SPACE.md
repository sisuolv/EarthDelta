# T3A 阶段 0-A：F0 预报库 + 输出空间的残差可预测性

**授权**：写代码用 A1；拟合期的 GPU 试点用 A3；分析期的 GPU 运行用 A4。A4 的前提是 `PHASE0_PROTOCOL.md` 已经签署。

## 要回答的问题

先用最便宜的办法检验 H1：**在控制了固定偏差之后，合法的历史残差能不能预测下一期的误差？**

如果在输出空间里都预测不了，参数空间的滞后编辑大概率也没有额外价值。如果能预测，那么 DABC 和 OCL 就是参数路线必须打败的对手。

## 第 1 部分（GPU，成本低）：`scripts/online_p0a_f0bank.py`

- 覆盖拟合期、预热期和分析期全部 361 个起报（2020-01-01 至 2020-12-26，每天 00z）。每个起报用 F0 滚动 20 步，**只跑一次**。
- 保存内容：
  - 6 个评分变量在第 1、4、12、20 步的预报场，fp32，每个 issue 约 3.1MB，全部合计约 1.1GB；
  - 第 1 到 4 步的预报场，供 T3B 求梯度和计算短时效残差时复用；如果空间紧张，就只保存 6 个变量；
  - F0 的各格子 MSE。
- 读取输入时一律走 `ActorStore`（要求索引 ≤ t）。F0 不依赖任何监督信息，但仍然要走这个接口，以保证台账完整。
- 执行顺序：**先跑拟合期的 86 个起报作为试点**，记录每一步的耗时和峰值显存，并据此给出全阶段的预算。然后停下来，等人签署协议之后，再跑剩下的起报。
- 输出目录：`runs/online/<run_id>/f0bank/`，包含最小来源清单。**这个库在 T3A 和 T3B 之间共享，以后只读，不能重写。**

## 第 2 部分（CPU）：`scripts/online_p0a_outputspace.py`

在释放时钟下逐日回放。在每个时刻 t，所有臂都遵循同一个事件顺序：先释放，再更新，最后发布。

**残差记录**：`e_{s,ℓ} = F0_{s,ℓ} − truth`，它的 `available_index = s + ℓ`（再加上缓冲）。记录由 worker 用 `ScorerStore` 读取真值后生成，写入 `SupervisionQueue`。

**各臂**：

| 臂 | 定义 | 拟合期要冻结的选择 |
|---|---|---|
| `f0` | 不做订正 | — |
| `obc` | 用拟合期的平均偏差订正：`F0 − λ·mean_bias` | λ |
| `dabc` | 按日历衰减的 EWMA 偏差订正：`F0 − λ·bias_t`，只使用已释放的记录 | τ ∈ {3, 7, 15, 30} 天，λ ∈ {0.5, 1} |
| `ocl` | 低容量的学习型输出订正（见 T2 的 `outcorr.py`） | EOF 数 K、ridge 的 α |

**拟合期内部的时间分割**（写入协议）：
1. 用 1 月 1 日至 2 月 24 日的起报估计偏差、EOF 和 ridge 模型（这些起报的 120h 窗口最晚到 2 月 29 日；2 月 25 日至 29 日的起报作为隔离带，不使用）；
2. 用 3 月 1 日至 3 月 26 日的起报选超参；
3. 选定之后，用整个拟合期重新拟合；
4. 预热期只更新状态。

**诊断**（不作为门槛）：
- 对每个变量，在第 1 步和第 4 步上计算残差场的日历滞后自相关，滞后 1 到 10 天。原始版和中心化版都要算，中心化用拟合期冻结的均值。缺失位置用掩码。
- 残差可预测性：在分析期上做样本外评估，看 OCL 预测的 EOF 系数的 R²，分别与只用静态偏差、只用 DABC 相比较。

## 输出

- `cells.npz`：按 arm × issue × 6 个变量 × 4 个时效存放，另附掩码和版本信息；
- `acf.npz`；
- `config_resolved.json`：记录所有冻结的选择及选择过程，包括每个候选的拟合期分数；
- `timing.json`。

## CPU 测试：`tests/test_online_p0a.py`

- 用合成序列和假的 F0 库，端到端跑通；
- 投毒不变性测试；
- DABC 在 120h 时效上只能用到 t − 5 天及更早的起报；
- 超参选择只用到拟合期的数据；
- 一个 run_id 只能写一次，第二次写要报错。

## 需要人执行的命令（示例）

```bash
# 拟合期试点（A3）
PYTHONPATH=. python scripts/online_p0a_f0bank.py --config configs/online_p0_2020.json --phase fit --device cuda
# 签署 PHASE0_PROTOCOL.md 之后（A4）
PYTHONPATH=. python scripts/online_p0a_f0bank.py --config configs/online_p0_2020.json --phase warmup,analysis --device cuda
PYTHONPATH=. python scripts/online_p0a_outputspace.py --bank runs/online/<run_id>/f0bank --config configs/online_p0_2020.json
```
