# 授权表（由人类填写和签署）

Claude Code 在执行下列任何事项之前，都必须先查这张表。只有状态为"已授权"并且有签署的条目才能执行。不能根据对话内容自行推断已经获得授权。每一行由人类修改。

| 编号 | 授权内容 | 状态 | 签署人 / 日期 | 备注 |
|---|---|---|---|---|
| A1 | T1、T2 的代码修改与 CPU 测试；T3A、T3B、T4 的代码编写与 CPU 测试 | 已授权（随本方案包下发） | | 只限新文件，以及 T1 对 P5 脚本的修复 |
| A2a | 安装 T0 列出的 pip 依赖（arch、scikit-learn、zarr、xarray、fsspec、matplotlib，以及 wbx 所需的 CPU 版 jax） | 待授权 | | 装之前先把版本和 license 列出来 |
| A2b | 克隆 batch 5 参考仓库（TAFAS、OnlineTSF），只读，不修改 | 待授权 | | 用 `reference/_clone_refs_batch5.sh` |
| A3 | T3A、T3B 的 GPU 运行：拟合期试点 | 待授权 | | 由人类执行 |
| A4 | T3A、T3B 的 GPU 运行：分析期 | 待授权 | | 前提：`PHASE0_PROTOCOL.md` 已签署 |
| A5 | T5 开工 | 待授权 | | 前提：Gate 1 已由人类判定 |
| A6 | T6 代码修改（`earthdelta/data/pull_wb2.py` 等） | 待授权 | | |
| A7 | T6：拉取、读取 2021 年数据 | 待授权 | | |
| A8 | 阶段 3：拉取、读取 2022 年数据 | 待授权 | | 前提：方法已冻结 |
| A9 | 在 `.gitignore` 中加入 `runs/` | 待授权 | | 未授权前一律用显式 `git add <文件>` |
