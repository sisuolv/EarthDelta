# EarthDelta 独立审阅包

本包来自固定提交 `7771bb18de786724523e72df09804fe7e7debbb6`（2026-09-30 的源码、计划和公开证据）。后续 GitHub 提交只增添本 ZIP 与下载说明；科学源码未变化。

请先打开 `reviews/online_stage0_20260930/CHATGPT_NEXT_PLAN_PROMPT.md`，按其要求复查并生成下一轮 Codex 计划 ZIP。审阅入口为同目录 `README.md`。

`REVIEW_PACKAGE.json` 绑定来源提交和逐文件 SHA256；不把自身哈希递归纳入。原运行的绝对路径需要按 `SOURCE_COPY_INDEX.json` 映射。

包含源码、测试、冻结计划、收据、小型配对指标表；不含原始天气场、检查点、梯度缓存、第三方克隆或凭证。本包足以审阅实现与已有统计，不能据此声称重新运行天气模型。2021/2022 不在本包内。

当前状态是 STATISTICAL_INCONCLUSIVE，正式分析期尚未执行。重点复核 2pp 效应功效 0.2% 与 97.6% 的差异，以及经验功效模型与覆盖模拟是否相容。
