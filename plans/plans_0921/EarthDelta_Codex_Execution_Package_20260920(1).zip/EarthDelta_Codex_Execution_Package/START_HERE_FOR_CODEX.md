# START HERE FOR CODEX

目标：核实并检验 `sisuolv/EarthDelta` 的参数干预响应规划是否比最佳固定编辑、直接gain和强递归输出订正有实际价值。不添加新架构掩盖未验证假设。

把本包作为新目录放在仓库的 `plans/codex_audit_20260920/`（不覆盖已有计划）。以下命令从仓库根目录执行。审查基线为 `4fe55a7af90ea92f62a3232a571af92bfbd6114d`；HEAD变更时先审查diff和更新受影响证据，不reset用户工作。

先读：
1. `EarthDelta_Codex_Execution_Plan.md`
2. `CODEX_TASKS.md`
3. `STOP_CONDITIONS.md`
4. `research/FINAL_RESEARCH_DECISION.md`

**当前只执行 P0-01。** 第一条可立即运行的包工具是：

```bash
RUN_ID=$(date -u +%Y%m%dT%H%M%SZ)
python plans/codex_audit_20260920/validation/repo_inventory.py \
  --repo . --output artifacts/p0/P0-01/$RUN_ID/inventory.json
```

随后按P0-01实施独立S0最小修复。主计划中标为TO_IMPLEMENT的脚本不是已经存在的训练程序，应先实现CLI/测试，不能直接照抄运行失败后伪造结果。

缺GPU、数据、权重、官方参考或关键来源时写BLOCKED，完成允许的代码/CPU检查后停止。不能把跳过真实验证当PASS。

每完成任务更新decision.json、CODEX_TASKS.md、codex_tasks.json与下一允许任务，然后结束当前调用。不得在没有PASS依据时启动下一任务。失败或不确定时按停止规则处理，不擅自增加JEPA/memory/第二主干，不改变验证指标。

P0-03负责根据开发数据生成并冻结数值门槛；模板null不是允许随意猜测。P0-04必须拒绝未锁定门槛。
