# Evidence status

审查对象为 `sisuolv/EarthDelta` 的 `main@4fe55a7af90ea92f62a3232a571af92bfbd6114d`，本包不是已完成实验的发布。

时间采用 America/New_York 的 2026-09-20 命名。提交为 2026-09-21 02:44:12 UTC，即 2026-09-20 22:44:12 EDT；没有把不同日期的分支拼成一个版本。

## 已完成

- 按固定 SHA 读取主要核心源码、S0、数据切分、部分测试、v6 计划与敏感度综述。
- 打开并核对新的相关原始论文页面；详见 SOURCE_REGISTER.json。
- 本地创建工程合同、任务 DAG、实验/统计规范、回归测试规格与机器可读状态。
- 本包的结构/JSON/DAG/文件完整性验证结果见 PACKAGE_VALIDATION.json：91项结构、JSON、DAG与Python语法检查通过；不包含仓库测试或天气实验。

## 仅作者报告，不是本轮复验

README 报告 192 passed / 3 skipped；2020 年 ERA5 数组 1464×69×128×256；ps2/ps4 文件在作者环境中。未从本工具环境读取其数据/权重字节或重跑当前测试。旧 kit 的 41/50 项记录不等于当前仓库科学结果。

## BLOCKED / UNVERIFIED

- 当前仓库没有自动挂载到此运行目录，容器外网请求失败；只通过连接器完成源码读取。
- 本轮没有运行完整当前 pytest、真实 Stormer checkpoint 或 ERA5/GPU 实验。
- 作者机器上的被 gitignore 的 checkpoint、归一化、数据、GPU、S0 输出、训练后 Fs 与专家库身份均待现场核实。
- 未验证任何真实 oracle 增益、预测头效果、长期稳定性、响应迁移或参数编辑优于输出订正。
- proposed_tests/ 是给 Codex 的新增回归测试，未对完整当前仓库执行。

不允许将“包验证通过”“源码存在”或“合成测试通过”改写成真实天气方法有效。
