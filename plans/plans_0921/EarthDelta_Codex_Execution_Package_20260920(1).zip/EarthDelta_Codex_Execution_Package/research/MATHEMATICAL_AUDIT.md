# Mathematical audit and metric contract

## 1. 符号先固定

对相同预测起点、相同输入、相同随机设置与continuation，令F0为官方原模型，Fs为已训练静态参考；d_u的基准始终是Fs，不跨实验混用。

    e0 = Y − Fs(X)                   # 真值 − 参考
    du = Fu(X) − Fs(X)               # 编辑 − 参考
    eu = Y − Fu(X) = e0 − du
    gain_Q = e0ᵀQe0 − euᵀQeu = 2 e0ᵀQdu − duᵀQdu

用户材料中有一处把e0写成 forecast−truth；若使用该定义正号公式就不再一致。当前 paired.py 的计算采用 truth−forecast，主公式正确。`e0+du factorization`可作为“双分支”的口头指称，不应写成残差实际相加。

这是代数恒等式，不是新的预报理论或保证；传统影响评估与最小二乘都有先例（N02–N04）。

## 2. 统一物理/统计度量

采用固定的Q，等价实现为先用whitening后的向量再平方求和：

    q[h,v,p] = lead_weight[h] * variable_weight[v] * area_weight[p] / scale[v]²
    loss = Σ q * (prediction − target)²

area_weight按真实坐标面积归一到1；变量尺度来自固定训练/官方参考常数；lead/variable weights只在试验注册时确定。sum/mean和归一化轴是MetricSpec的一部分。样本聚合累计SSE和权重后才sqrt，不能平均逐样本RMSE。

P0主指标：72h、Z500/T850/T2m/MSLP、固定官方尺度标准化、变量等权；6/24/120h是关键副指标与退化检查。240h只有数据覆盖和长期验证通过后加入。P1轨迹目标可对24/72/120h预注册等权，再同时报告每个时效，不能用加权平均掩盖远期变差。

对未全覆盖的lead或variable，不能静默重新归一化导致各方法评价集合不同。NaN和执行失败单列；相同输入上的候选失败使用部署约定的no-edit回退计分并计入harm/failure率，禁止只删掉失败样本。

## 3. 投影中的等式与全场结论

固定线性D保证 D(eu)=D(e0)−D(du)。投影空间gain恒等式成立，并不代表等于全网格gain；D丢掉的结构可能改变候选排序。保存gain_summary和gain_full及其差异/排序冲突。

线性粗化、固定PCA、SHT复系数、固定离散涡度/散度算子可以组成D。先由真实纬度验证几何；不把每个patch FFT当球谐。对风速、动能、对数能量等非线性特征，不能假设φ(Y−F)=φ(Y)−φ(F)。这些可以定义独立的非线性评价，但必须重新计算完整两次loss；不沿用原残差恒等式。

理论上任何映射φ都可先定义 eφ=φ(Y)−φ(Fs)、dφ=φ(Fu)−φ(Fs)，再在该特征差上使用平方恒等式；这与先对残差做φ不同，也不构成物理空间的可加性。因此主线仍用固定线性D，避免偷换合同。

## 4. du 的四种含义必须进入元数据

- FINITE_EXACT：cached_responses 对实际候选完整积分之差；可用于有限库真实oracle。
- CENTRAL_JACOBIAN：central_response 的中心差分R；每列为导数近似，不是有限编辑本身。
- LINEAR_SURROGATE：R a，只在被验证的局部半径和时效内使用。
- LEARNED_FINITE / LEARNED_JACOBIAN：从合法输入学习前两者的近似；不因标签来自“确定性模型”就视为零误差。

jvp_response 当前未实现。response_kind、probe_eps、forward_precision、reference、action_window、continuation必须绑定缓存。先改变epsilon检查前向数值噪声，再用独立混合方向检查线性化；“把float32输出转float64”不能恢复已丢失的差分精度。

## 5. 多编辑：Gram交叉项不是非线性交互

若 du(a)≈Ra，则：

    b = RᵀQe0
    H = RᵀQR
    gain(a)≈2bᵀa−aᵀHa
            =Σj(2bj aj−Hjj aj²)−2Σi<j Hij ai aj

当前 geometry 与 full InteractionUtilityHead 有交叉项，并非完全忽略组合。H_ij表示线性响应方向在Q中的重叠；不等于真实联合编辑的二阶作用。

用真实 replay 检验：

    interaction_remainder(a,b) = d(a+b) − d(a) − d(b)

超出局部线性区就缩小信赖域/缩短作用窗，或回到有限非线性候选。不能靠“full H”声称已经建模这一余项。连续teacher仅是局部模型上的解，top-3 nonlinear verification不是完整字典oracle上界。

## 6. e0 不必重做整个预报

若完整合法上下文给定时du确定，最优平方损失选择只需要条件均值μe=E[e0|context]在候选响应张成空间的投影。局部模型只需b=RᵀQμe。对与全部du正交的误差，精确预测不会改变选择。因此应比较：全e0头、restricted/b头、直接gain头；不能仅凭全e0 R²低就终止项目。

反过来，若e0确实已预测得很好，就必须测试Fs+e0_hat直接订正；若du已能预测完整场，则Fs+du_hat是必须对照，不能把“既然预测了为何还执行”藏起来。

若context是有损池化，du在这个条件下也可能有残余不确定性。此时：

    E[g|c] = 2 μeᵀQ μd − μdᵀQ μd
             + 2 tr(Q Cov(d,e|c)) − tr(Q Cov(d|c)).

所以把两个均值直接代入不是普遍精确的期望效用。校准项可改善经验效果，但校准之后就应报告raw_geometry与calibrated两个分数，不再把后者称为纯恒等式收益。

## 7. 参数编辑与递归输出修正

任意单步编辑映射fu均可写成 f0(x)+c_u(x)，其中c_u(x)=fu(x)−f0(x)。若每步应用此函数，整个递归轨迹也能一致。因此没有“输出端按定义不可能改变动力学”的一般证明。

真正可测试的差异是有限参数、信息、训练量与算力下的归纳偏置、跨lead/变量一致性、可复用性。输出baseline必须是多变量、每步反馈、用同样多步loss训练，并可使用固定context或编辑code；不限制它只能最后一步补一张残差图。

## 8. 与 influence / NTK / adjoint 的区别

本项目R=∂Y/∂a沿指定低维编辑坐标，不涉及训练样本重权后的argmin变化；influence通常通过训练Hessian逆计算后一类依赖（S02）。NTK是参数梯度构成的kernel，不等于已经学得能准确预测有限干预的response surrogate。Adjoint/JVP/VJP是计算灵敏度工具，学习其低维作用只是一种摊销，必须证明成本和泛化优势；并非数学上全新对象。

## 9. 风险控制措辞

score−λuncertainty>margin只是一种选择策略。没有相应可校准样本/交换性等假设时，不叫安全保证；no-edit也不是逐样本不退化保证。候选库oracle包含zero只是事后上界，部署选择依然会错。
