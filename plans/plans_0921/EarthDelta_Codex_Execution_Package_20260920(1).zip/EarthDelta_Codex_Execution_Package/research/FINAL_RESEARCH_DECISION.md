# FINAL_RESEARCH_DECISION

decision_id: ED-2026-09-20-4fe55a7
status: CONDITIONAL_CONTINUE_P0_ONLY
source_commit: 4fe55a7af90ea92f62a3232a571af92bfbd6114d

## 保留（最多三个核心点）

1. **多时效参数干预响应预测**：用合法起报信息预测冻结天气模型对有限、可逆低秩编辑的向量轨迹响应。优先实际有限候选，局部Jacobian作为对照/后续。
2. **决策相关误差–响应分解**：分别学习reference error或其决策投影，与可无未来标签生成的du结合；identity是已知工具，贡献必须体现为真实选择、标签效率或可重新评价的收益。
3. **轨迹级选择的实证价值**：在固定信息/预算/候选库条件下，胜过最佳固定编辑、直接gain及强递归输出订正。第三项是要证明的结果，不是已经完成的结论。

工作名：EarthDelta V2 — Issue-Time Trajectory Response Planning for Frozen Weather Models。V2指本次科学收敛版，不要求重命名整个v6源码包。

## REMOVE FROM MAINLINE / DEFER

REMOVE FROM MAINLINE：首次动态LoRA、首次counterfactual effect预测、全新FSO恒等式、全新Gram教师、参数编辑天然物理一致、预算必然提速、router按构造无法迁移、已有zero-shot新专家/时效结果。

DEFER到P3：JEPA潜空间、学习式memory、动态rank控制器、频谱训练loss、Complexity Atlas、第二大型主干、真实同化、概率集合、独立干预世界模型。

保留已有代码，但P0配置关闭；EWMA只作为同信息简单对照。固定线性尺度摘要是测量工具，不另算创新。不重新构建v4四件套。

## 核心假设

H1：在强静态参考和合理训练后的编辑库上，状态相关最优编辑比验证集最佳固定编辑有可检测且值得成本的增益空间。
H2：这个空间可由合法历史预测的响应/误差信息捕获，而且分解在至少一个预注册目标（标签效率、轨迹目标重加权、组合选择）上优于同资源直接预测。
H3：实际执行参数干预相对同信息递归输出订正/响应直接回放，至少有一项真实优势，且不以不可接受的长时效退化换取一步提升。

## 排序与解锁

P0项目生存检查 → P1核心论文实现 → P2最多两条增强 → P3只记录不执行。
当前仅允许P0-01。完成任务后需存在机器可读PASS记录才解锁直接后继；BLOCKED/INCONCLUSIVE/FAIL均不能跳级。

## STOP / PIVOT

- bridge/metric/provenance/泄漏合同不通过：STOP运行科学比较，修实现，不对idea作负结论。
- 经过训练验证的有限库oracle增益上置信界仍小于预注册研究效应门槛：STOP当前库；最多一次预注册库修订，避免无休止刷库。
- oracle相对best-fixed的动态增量不足：PIVOT静态适配，不继续复杂planner。
- 分解被同资源direct-gain等效或支配：收缩/放弃分解贡献，不继续叠JEPA。
- recurrent output correction支配参数编辑：停止宣称内部编辑必要；可保留响应分析价值，但不自动另起大项目。
- 长lead有系统性劣化：缩短主张/作用窗或停止该编辑族；局部Jacobian失败只停止连续线，不否定finite线。

数值效应门槛必须由P0-03在开发数据上计算并锁定，方法见STOP_CONDITIONS.md。当前没有真实方差/成本/业务价值证据，故不填虚构2%或3%“科学门槛”。
