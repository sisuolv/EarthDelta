# Current method audit — main@4fe55a7

## 结论

这是已经从概念原型发展为统一软件模块的项目，但当前公开到连接器的快照仍缺少证明科研主张的真实实验链。不是“只有几段代码”，也不是“已有天气论文结果”。当前主线比早期 physics-state adapter 更聚焦：有限参数干预的响应、误差分解与受约束选择。

## 当前真实完成度

|层面|本轮能核实的内容|不能外推的结论|
|---|---|---|
|实现|ExpertLoRA、有限/连续规划、差分探测、Gram、教师、paired heads、bridge、data pipeline、测试文件|存在实现不等于训练有效|
|测试|作者报告192通过/3跳过；读取了小模型与合成测试片段|本轮没有完整重跑，不将旧包测试次数叠加|
|数据|下载/重网格代码与README年数据说明存在|忽略的2020数据字节和hash未访问；训练年份覆盖未知|
|checkpoint|加载函数与ps2/ps4配置存在|当前环境没有真实权重运行；配置匹配不等于内容身份|
|科学证据|v6草案明确尚未weather-trained|没有核实oracle增益、静态与动态差距、e0/du可预测性、输出订正对照|

路径和文件 blob SHA 见 `../evidence/REPOSITORY_AUDIT_MANIFEST.json`。文件 blob SHA 与仓库 commit 是不同层级，不能混写。

## 新旧方案的真实变化

旧Notion是复杂度条件化PEFT的历史依据，不是当前源码。当前代码将memory默认降为EWMA、JEPA作为可选，具有R/b/H与非线性候选验证。本次不重新把四模块组合强塞回主线。

当前的 multi-lead head 已经存在；当前 controlled_rollout 主要返回最终状态。需要补的是一次执行返回所有指定lead、目标对齐和训练流程，而不是重写一个名叫TrajectoryHead的重复类。

## 缺陷与最小修改

### A01 — 验收漏洞 (P0)

`scripts/s0_gate.py` / `verify_zero_edit_equivalence`

**源码事实：**同一 WeatherStepBridge 的 forward_validation 与 controlled_rollout 对比，expert_loras 为空。

**审查判断：**共同实现错误可同时通过；没有证明等于官方整网。

**最小修改：**同一已校验权重，独立官方 Stormer 实现→本地 architecture→controlled 三路比较；额外安装非零 B 专家但传零系数；所有时效逐点比较。

**新增测试：**`test_independent_official_parity; test_installed_zero_edit_equals_reference`。

### A02 — 验收漏洞 (P0)

`scripts/s0_gate.py` / `verify_no_state_leak / run_s0_gate`

**源码事实：**扰动未参与预测的局部未来数组；RMSE error/NaN 不纳入最终 gate。

**审查判断：**只证明重复性；坏数据或诊断异常仍可能 PASS。

**最小修改：**部署输入类不含 targets；读权限/spy-canary 测试；hook 异常恢复；required_checks 全通过且无 NaN/skip 才 PASS；环境缺失用 BLOCKED。

**新增测试：**`test_serving_rejects_targets; test_s0_fails_on_nonfinite_rmse; test_hooks_removed_on_exception`。

### A03 — 归一化待核实 (P0)

`earthdelta/bridge/stormer_bridge.py` / `NormalizationContract.from_npz_dir / denormalize_diff`

**源码事实：**加载可用 diff_mean 并参与反归一化；官方 inference 使用的增量转换零均值策略需要独立对照。

**审查判断：**不是证明所有现有常数非零，但只要非零就可能偏离官方推理；多步偏差会累积。

**最小修改：**新增 explicit diff_mean_policy 并写入哈希；replication 模式严格复现 pinned official inference，不凭文件存在自动改变策略。

**新增测试：**`test_nonzero_diff_mean_policy; test_norm_raw_increment_roundtrip`。

### A04 — 来源合同缺陷 (P0)

`earthdelta/bridge/stormer_bridge.py` / `load_stormer_checkpoint / NormalizationContract.digest`

**源码事实：**版本身份主要编码架构；norm digest 缺变量/间隔名称；grid 使用形状。

**审查判断：**同架构不同权重、通道交换、同形异网格可能不被识别。

**最小修改：**流式 SHA256 checkpoint 内容；hash 名称/shape/dtype/排序后的数据；lat/lon 实值哈希；Fs 与字典也绑定内容；拒绝 pending/placeholder。

**新增测试：**`test_same_arch_different_weights_changes_version; test_norm_interval_keys_change_digest`。

### A05 — 约束遗漏 (P0)

`earthdelta/selection.py` / `plan_from_prediction / _plan_from_finite_candidates / unified_select`

**源码事实：**finite 路径不落实 bound、max_active、max_candidates；QP 路径不使用 cost_penalty。

**审查判断：**名义受预算的选择可违反实际动作合同，比较不公平。

**最小修改：**统一候选可行性验证、代价/正则/阈值语义；非法字典直接拒绝而非悄悄夹紧；稳定 ID 并列规则。

**新增测试：**`test_finite_candidates_reject_box_violation; test_finite_support_limit; test_penalty_dispatch_parity`。

### A06 — 数学接口不一致 (P0)

`earthdelta/paired.py; earthdelta/geometry.py; earthdelta/heads.py` / `quadratic_gain / ResponseGeometry.from_error / ComposedPredictionHead.forward`

**源码事实：**分别使用最后轴权重均值、未归一化 Q、无权均值；calibration 可任意补偿。

**审查判断：**数值不在同一指标下，ridge/阈值/成本权重失去含义。

**最小修改：**单一 MetricSpec：固定变量尺度、面积、lead 权重与 reducer；显式 raw_geometric_gain 与 calibrated_gain；校准开关消融。

**新增测试：**`test_gain_matches_full_weighted_loss; test_weight_rescaling_contract; test_heads_geometry_consistency`。

### A07 — 缺失训练接口 (P0)

`earthdelta/bridge/stormer_bridge.py` / `controlled_rollout`

**源码事实：**EditPlan tuple 用 torch.tensor 重建，serving 合理但不能保留可学习 router 的系数梯度。

**审查判断：**无法用这个接口公平训练端到端条件化 baseline；不要误称所有 Adapter 梯度都断了。

**最小修改：**保留 immutable serving API，新增 controlled_rollout_train(coefficients: Tensor, ...) 与 collect_leads；禁止 detach/tensor重建；Fs 静态路径与动态路径分离。

**新增测试：**`test_router_gradient_through_frozen_rollout; test_dense_sparse_value_parity`。

### A08 — 静默错误 (P0)

`earthdelta/memory.py` / `ewma_error_feature_batched`

**源码事实：**捕获所有 ValueError，把版本错误、重复记录等转成零特征；zip 不检查长度。

**审查判断：**看似拒绝不合法记录，批量路径却静默成功。

**最小修改：**只对明确 NoEligibleRecords 做零回退；其他异常传播；检查长度、特征维度、decay 有限区间；P0 主试验默认关闭 memory。

**新增测试：**`test_batched_version_error_propagates; test_batched_duplicate_error; test_records_origins_length`。

### A09 — 时间/数据合同 (P0)

`earthdelta/data/make_splits.py` / `build_manifest / compute_guard_boundaries / from_parquet`

**源码事实：**naive datetime.timestamp 依赖主机时区；6h availability 是人为默认；边界不含 memory warmup；parquet 丢 metadata。

**审查判断：**改变机器时区会改变 UTC；理想化历史被误称实时；跨边界泄漏和来源丢失。

**最小修改：**timezone.utc；来自实际可用时间或声明 archive_assumption；所有起点完整检查 history/targets 范围；memory warmup 纳入 support；parquet sidecar；拒绝占位 hash。

**新增测试：**`test_manifest_timezone_invariance; test_full_support_inside_split; test_parquet_metadata_roundtrip`。

### A10 — 指标聚合 (P0)

`scripts/s0_gate.py` / `compute_rmse_z500`

**源码事实：**先对每个样本开平方再平均；target i+steps 对非6h步长不通用；仅首10个起点。

**审查判断：**不是统一总体 RMSE；极窄样本不能复现整年paper表。

**最小修改：**根据精确 valid timestamp 找真值，先累计加权SSE/权重再开方；原始单位与预报时效明确；移除未核实paper常数，保留 sanity非论文结果。

**新增测试：**`test_rmse_aggregate_before_sqrt; test_target_time_interval_alignment`。

### A11 — 近似边界 (P1)

`earthdelta/probe.py; earthdelta/geometry.py; earthdelta/teacher.py` / `central_response / cached_responses / box_candidates / verify_candidates`

**源码事实：**finite exact 与局部中心差分并存；Gram含交叉项；teacher只复验少量候选。

**审查判断：**局部最优/局部交叉项被叫作真实非线性 oracle 或 nonlinear interaction。

**最小修改：**response_kind 固定枚举；全候选真实 replay 做 P0 ceiling；mixed方向与epsilon误差；local teacher 只保留诊断；失败转finite-only。

**新增测试：**`test_nonlinear_joint_edit_not_equal_linear_sum; test_response_kind_mismatch`。

### A12 — 已实现而未训练 (P1)

`earthdelta/heads.py` / `ReferenceErrorHead / EditResponseHead / InteractionUtilityHead / ComposedPredictionHead`

**源码事实：**已有多lead前向与PSD H；不缺一个“multi-lead head”名称。

**审查判断：**重复造轮子；缺的是真实目标管线、训练、选择评价及同信息对照。

**最小修改：**复用现有头，接真实轨迹；比较 e0/du、直接 gain、b/H 与 restricted b；optional JEPA 默认关闭。

**新增测试：**`test_multilead_cache_matches_head_axes; test_no_future_labels_in_forward`。

### A13 — 明确占位 (P2)

`earthdelta/spectral.py; earthdelta/probe.py` / `band_energy / single_mode_energy / jvp_response`

**源码事实：**NotImplementedError，SHT只诊断已有系数。

**审查判断：**报告中误称已有谱前端或自动微分响应。

**最小修改：**P0 用固定线性粗化；只有需求成立再实现真实网格SHT或JVP；不静默替换平面FFT。

**新增测试：**`test_sht_nodes_and_single_mode; test_jvp_finite_difference_parity`。

### A14 — 科学前提 (P0)

`earthdelta/lowrank.py; README.md` / `ExpertLoRA / claimed assets`

**源码事实：**新专家 B=0；看不到已训练 Fs/专家库/真实增益日志。

**审查判断：**零初始化 oracle 无提升被误判项目失败；原模型缺少能力的提升被误认动态贡献。

**最小修改：**先训练强静态参考及非退化有限库；独立验证专家方向；no-edit=Fs；随机与弱库结果只诊断当前字典。

**新增测试：**`test_dictionary_nontrivial_and_has_identity; test_noedit_equals_Fs_not_F0`。

### A15 — 计划而非自动保证 (P1)

`plans/plans_v1_0919/v6_draft/research_spec_v6.yaml` / `context_encoder / experiments.P3 / claim`

**源码事实：**晚层参考特征写成零额外成本；预算/新专家/新lead迁移在计划中写得过强。

**审查判断：**为选从18层起的edit先跑到23层再重算，成本不免费；descriptor router同样可迁移。

**最小修改：**统一廉价历史特征，或共享到首编辑前的不可变prefix，或完整计费参考前向；迁移均列为待验证，与同descriptor对照比较。

**新增测试：**`test_serving_forward_call_ledger; test_unseen_descriptor_protocol`。

## 边界

上述为源码级发现；没有将未执行的测试标为已失败。保留已有 sparse/dense、非零fixture、try/finally移除hook、no-op、PSD约束和时间过滤的正确设计。只修其缺口，不无理由替换整个执行器。
