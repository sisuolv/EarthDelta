# Related work — primary-source audit

核查范围：截至本包审查时点可访问的原始论文摘要/HTML；2025–2026优先，但2022/2024的直接先例不能因较旧而删除。没有搜索不到相同关键词就宣称首次。来源事实与下述EarthDelta比较判断分开。未执行上游实验。

|编号/日期/状态|原始来源|已覆盖机制|对当前贡献的威胁与差异|代码证据|
|---|---|---|---|---|
|N01 · 2026-08-03 · preprint|[VI-MoLE: Uncertainty Is Not Enough](https://arxiv.org/abs/2608.02528)|专家前缀的反事实剩余风险与全局预算下边际收益路由；不是只按不确定度扩容。|覆盖预算化、执行前效用估计；区别在多变量预报响应场、向量组合与明确的起报信息合同，而非 predict-before-select 口号。|作者完整可执行仓库本轮未确认；paper-inspired baseline 不冒称官方复现。|
|N02 · 2026-09-10 · preprint|[Preemptive Ensemble Forecast Sensitivity to Observations (PEFSO)](https://arxiv.org/abs/2609.12296)|在切线性近似下估计新增观测影响；ADD-SEL-PRE 还近似更新集合预报，避免再次积分。|覆盖廉价影响预估与选择；对象是观测/同化而非参数编辑，误差评价仍依赖核验参考态。|本轮未确认作者可执行仓库。|
|N03 · 2024-03-21 · GRL peer reviewed|[Machine Learning Enables Real-Time Proactive Quality Control](https://doi.org/10.1029/2023GL107938)|从分析序列训练 ML 参考态，不使用未来观测，进行实时影响估计与观测筛选；在 Lorenz96 概念验证。|直接否定“过去影响估计都必须用未来真值”；EarthDelta 要增加参数作用的学习、场级响应及真实神经天气模型证据。|论文有 Honda 2023 数据/代码存档声明；本轮未读取或运行存档。|
|N04 · 2022-03-17 · GMD peer reviewed|[Earth system model parameter adjustment using a Green's functions approach](https://gmd.copernicus.org/articles/15/2309/2022/index.html)|通过参数扰动、模型响应和加权最小二乘进行参数校准。|当前 R→b,H→box LS 教师有直接传统先例；增加流依赖与摊销并不自动是新方法。 文中也已明确可重用响应更换目标和权重；目标重加权不是本项目独有能力。|复用 SciPy lsq_linear；原气象实验代码未移植。|
|N05 · 2026-09-10 · preprint|[CLAW: Amortized Low-Rank Adaptation for Model-Based Reinforcement Learning](https://arxiv.org/abs/2609.12278)|用少量历史 transitions 生成 LoRA；基础模型与 hypernetwork 联合预训练，测试时冻结主模型。|直接 history→adapter 对照；不等于显式预测每个编辑的向量响应。事后适配 vs 联合预训练是设定差异，不是充分贡献。|本轮未确认作者代码。|
|N06 · 2026-09-15 · preprint|[Learning Options for Compositional Motor Control with Adapter Banks](https://arxiv.org/abs/2609.17042)|共享循环核加 residual adapter 库，出现低秩结构；冻结网络后高层策略组合 options。|冻结核+编辑库+规划并不新；EarthDelta 的可守差异应是可核验响应模型，而不是架构图。|本轮未确认作者代码；其低秩为涌现结构，不应误称全程强制 LoRA。|
|N07 · 2026-04-07 (v2; first 2026-03-11) · Findings ACL 2026 (as stated on revised primary abstract)|[CLaRE-ty Amid Chaos](https://arxiv.org/abs/2603.19297)|编辑前中间层表征纠缠预测知识编辑的连带影响风险。|执行前预测编辑影响已有先例；它不是全球天气向量轨迹预测，也不等于精确预测某 edit 的完整效果。|最新版摘要明确有公开entanglement graphs/corpus链接；本轮未独立验证许可或运行，不能称代码不存在。|
|N08 · 2022 · ICML peer reviewed|[Generalizing to New Physical Systems via Context-Informed Dynamics Model](https://proceedings.mlr.press/v162/kirchmeyer22a.html)|用 context 与 hypernetwork 适配不同物理环境。|少历史条件化动力学不是新问题；需要同信息的直接 router / context-fit 强对照。|https://github.com/yuan-yin/CoDA ; 旧清单为短 SHA 17b7352，MIT 提示；复制前独立核实。|
|N09 · 2026-09-08 · preprint; submitted to AIES|[Stochastically Perturbed Weights (SPW)](https://arxiv.org/abs/2609.08412)|通过推理期扰动已有确定性天气模型权重生成集合，研究架构依赖和全场偏移失败。|权重干预已有天气实例；它不学习确定性逐候选收益选择。随机权重字典是诊断，不可替代训练专家库。|https://github.com/MeteoSwiss/ai-models-ensembles ; paper links v1.0.0；本轮未运行。|
|N10 · 2021-01-05 (v2; NeurIPS 2020) · peer reviewed|[Solver-in-the-Loop](https://arxiv.org/abs/2007.00016)|在迭代求解器中训练纠正函数，利用先前修正后的状态，多步稳定性是其直接目标。|输出/状态修正可以改变 rollout，不能用“它只改单步”建立参数编辑必要性。|https://github.com/tum-pbs/Solver-in-the-Loop ; 旧清单 f514fcf / MIT，复制前核实。|
|S01 · 2024 · ICML peer reviewed|[CoLoRA: Continuous low-rank adaptation for reduced implicit neural modeling of parameterized partial differential equations](https://proceedings.mlr.press/v235/berman24b.html)|连续低秩适配用于物理/PDE 模型。|动态低秩与物理系统的结合不是首次。|论文级比较，本轮不移植。|
|S02 · 2017 · ICML peer reviewed|[Understanding Black-box Predictions via Influence Functions](https://arxiv.org/abs/1703.04730)|通过训练最优点对数据扰动的响应分析预测变化。|涉及训练目标 Hessian 的隐式依赖；不同于固定模型沿指定参数方向的输出导数。|只用于概念边界。|
|S03 · 2022 · tutorial|[Tutorial on Amortized Optimization](https://arxiv.org/abs/2202.00665)|学习优化映射与摊销/半摊销求解。|直接预测系数、预测 b/H 后解 QP 都有一般方法背景。|https://github.com/facebookresearch/amortized-optimization-tutorial ; 清单标 CC-BY-NC；不复制教程代码。|
|S04 · 2025-09 · preprint / verify venue separately|[WeatherPEFT](https://arxiv.org/abs/2509.22020)|任务自适应提示和参数敏感性微调。|领域适配近邻，不是参数响应规划的完整替代。|https://github.com/ShileiCao/WeatherPEFT ; 清单未见许可，代码复制 BLOCKED。|
|S05 · 2024-12-02 · preprint|[Jacobian-Enforced Neural Networks (JENN)](https://arxiv.org/abs/2412.01013)|在有物理 TL/AD 标签时约束输入 Jacobian，研究同化一致性。|输入扰动响应 ∂Y/∂X 不等于参数干预响应 ∂Y/∂a。|本轮未确认作者实现；不纳入 P0。|

## Nearest-neighbor coverage matrix

以下只表示被核对工作中与EarthDelta相近的机制，不是对整篇论文“绝无某性质”的证明。T=直接；P=部分/不同对象；—=本轮核对未形成同一任务。

|工作|状态条件适配|预测干预响应/风险|干预/动作选择|预算|多编辑作用|解析效用|
|---|---|---|---|---|---|---|
|VI-MoLE|T|T（风险）|T|T|P（专家前缀）|P（风险/边际值）|
|PEFSO|P（观测）|T（近似计算，不是learned weight response）|T|P|P（观测集合）|T|
|Honda & Yamazaki|P（观测）|T（ML核验参考+影响分析）|T|—|P|T|
|Green's functions|P（参数全局校准）|T（数值灵敏度）|T（校准）|P|T（线性依赖/联合作用）|T|
|CLAW|T|P（生成适配后的world model）|P|P（适配成本）|P|—|
|Adapter Banks|T|P（动力模型，不同任务）|T|—|P（options序列）|P（控制回报）|
|CLaRE|P|T（连带影响风险）|P|—|P（表征纠缠）|—|
|CoDA|T|P（context条件动力学）|P|P|P|—|
|SPW|P|—（实际扰动/集合评价）|P（离线调参）|P|P|—|
|Solver-in-the-Loop|P（状态相关纠正）|P|—|—|T（纠正在轨迹中传播）|P（预测loss）|

## 检索覆盖与剩余不确定性

本轮按以下交叉词组定向查找，而不是只看天气综述：parameter edit response / effect prediction、low-rank counterfactual risk routing、forecast sensitivity observation and parameter、Green-function calibration、amortized optimization、Jacobian/NTK/influence、recursive residual correction、weight-space weather ensembles。仓库已有survey D的近邻被逐项对照原始页面，未照抄其“唯一空白”结论。

未找到完全同配置的研究不等于不存在。新论文/代码可能未被索引；公开仓库能访问也不等于有权重、许可和复现实验。接受状态仅按可核对页面记录，预印本不写成顶会录用。

公开实现可以借鉴机制，但本包不包含第三方全文、权重或大段代码。外部实现pin与许可确认单独见implementation/LITERATURE_TO_CODE.md。
