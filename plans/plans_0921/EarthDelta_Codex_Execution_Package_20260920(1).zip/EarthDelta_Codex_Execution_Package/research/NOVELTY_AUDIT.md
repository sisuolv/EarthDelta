# Novelty and scientific-value audit

## Verdict

当前主线的科学辨识度比最早的“物理复杂度→条件Adapter”更强，因为现在能明确提出并否证“在执行前预测编辑对整条预报的作用”。但现有证据不足以断言novelty已足够、或者可以投稿。源码/测试工作量不能替代方法效果。

最危险的不是“用了LoRA”，而是：花更多成本预测一个响应代理后，相比直接gain、直接router、递归输出纠正，到底多买到了什么？

## 最危险的 X + Y

1. **VI-MoLE + 预报误差估计器**：如果最后只是预测每个专家收益再在预算下选，技术身份相近。
2. **Green's-function校准/FSO + amortized neural predictor**：R、b、H、QP与核验均有传统来源；必须在真实起报信息、学习与复用方面提供新增证据。
3. **CLAW/CoDA + supervised error head**：如果动态程序由历史直接预测，而response只作为辅助loss，就容易被这个解释覆盖。
4. **普通recursive residual corrector + 低秩参数化**：输出空间和参数空间不是不可互相表示的两类函数；若内部参数路径没有资源/泛化优势，需要撤回必要性。

不采用“现有方法按构造无法迁移”的论据。带候选descriptor、lead、metric或budget条件的direct predictor也可迁移；是否更好必须实测。重用响应更换目标权重在Green's-function文献已有先例（N04）。

## Contribution压缩

主贡献候选：学习issue-time parameter-to-trajectory response surrogate。它是模型内部干预后果，不是地球物理反事实。只有展示实际选择价值才成立。

次贡献候选：将可无未来label获取的du和需要核验标签的e0/decision projection分开，提升特定低标签/多目标条件下的选择效果。恒等式本身不新；两分支不自动带来组合性与迁移。

实证贡献：固定信息、动作、成本的多步验证，能够区分“有hindsight提升空间”“能从历史选择”“真正需要内部编辑”。它依赖实验而不是架构名。

## 五条方向的明确判断

|方向|判断|当前优先级|
|---|---|---|
|Counterfactual intervention world model|model-internal response surrogate的命名成立；只有有限一次性选择时不必另称world model，更不必训练一个概率世界模型|作为谨慎定位，不额外加模块|
|Learned intervention Jacobian|当前central_response就是它的监督雏形；局部性/可预测性/混合编辑要先验，不能把导数对象当新数学|P2-02|
|Trajectory-level response planning|最值得新增的一个方向。现有multi-lead头可复用，重点在真实轨迹标签、计划时窗与held-out目标实证|P1实现基础，P2-01强化|
|Uncertainty-aware intervention|部署有用，但risk certificates/abstention已有VI-MoLE；没有相应校准假设不叫safe|P3，当前只保留no-edit与已预注册阈值|
|Physics-structured utility|作为固定测量空间比堆loss自然；线性算子保留恒等式，非线性能量另评价|P0/P1工具，不单列创新|

## 四类能力必须分别证实

**组合性**：有限响应不天然可加；H交叉项只表示线性重叠，必须检查真实联合replay。

**可解释性**：预测e0/du允许故障定位，这是有价值的结构，但热力图不等于物理因果解释。

**可迁移性**：预算/权重变化、lead外推、新专家/新backbone是不同任务；不能合并成一个zero-shot宣传。

**效率**：du可无核验真值生成，但仍需实际候选前向；训练探测、记忆预热、控制器和选后重算都计入成本。

## 最大scientific risks（顺序）

1. **动态headroom不足或不可预测**：hindsight赢主要利用无法从历史判断的未来噪声。
2. **不必编辑参数**：同信息recurrent output correction或Fs+预测du已经同样好且更便宜。
3. **代理目标错位**：summary gain与真实全场gain排序冲突，或calibration head取代全部所谓几何贡献。
4. **部署流程代价被低估**：晚层参考特征、候选探测、连续求解带来的成本不在账本。
5. **长时效不稳定与局部线性失效**：前24h小收益引发72/120/240h系统偏差。

## 当前最值得立刻做什么

先修P0-01的独立S0，然后在经过训练的有限库上运行P0-04。精确非线性oracle−best-fixed是最先决定planner是否值得继续的科学实验。不要在零初始化B库上做kill判断。

## 单一取舍

只能保留一个创新点：**从合法历史学习参数干预的向量轨迹响应，并用它作可验证的预报选择**。

只能新增一个真正增强：**trajectory-level planning及其目标重用/标签效率证据**，因为最接近现有实现而且直接暴露长程后果；不是再加一个“world model”名称。

## 投稿前最低证据包

独立官方checkpoint parity；真实nonzero Fs/字典；finite oracle和best-fixed差距；2×2 oracle substitution；同信息direct gain/router；多步多变量output correction及surrogate replay；72/120h稳定性并有240h审查或明确范围限制；全场与摘要一致性；完整训练/部署成本；时间块统计；至少一个响应路线特有优势对照。第二大型backbone不是替代这些证据的捷径。
