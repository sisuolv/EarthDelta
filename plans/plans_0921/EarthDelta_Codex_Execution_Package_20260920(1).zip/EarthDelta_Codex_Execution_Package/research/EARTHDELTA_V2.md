# EarthDelta V2 — Issue-Time Trajectory Response Planning

这里V2是对当前main/v6实现的科学收敛，不重写项目或丢弃已有模块。

## 1. Core problem

已有冻结天气预报器的低秩编辑何时值得执行？希望在只拥有预测起点合法信息时，预测编辑对多个未来时效的输出影响，而不是运行全部候选或读取未来核验后再挑选。

## 2. Core hypotheses

H1有限库具有超过最佳固定编辑的可学习动态空间；H2误差–响应分解在某个预注册资源/复用目标优于direct gain；H3内部编辑在强输出对照下仍有实用增量。

## 3. Formulation

Fs固定，有限编辑u∈U包括0，明确hold=4个6h步和after-hold continuation。参考误差e0=Y−Fs，finite响应du=Fu−Fs。对固定Q，g(u)=2<e0,du>Q−||du||Q²。预测头从context估计e0/du，或仅估计decision projection；预算内选u*=argmax(g_hat−λcost)。

主线使用真实finite response标签；continuous R a与b/H路径是校准信赖域内扩展。程序作用于整条轨迹，零编辑严格等于Fs而不是未适配F0。

## 4. Training objective

先训练并固定Fs与字典；建立分离的inputs/reference/response/truth partitions；对预测e0、du做同度量监督，再加实际gain/排名校准。训练truth可以用于loss，不进入forward。匹配训练预算给direct gain、b/H、context→coefficients、recursive output。

du采样额外起点必须在train/allowed-support里；不因为无需truth就把测试起点的oracle responses提前算给serving。缓存与basis/metric/normalization/continuation绑定。

## 5. Inference

legal context→预测轻量响应/误差→统一cost可行集→稳定选择（包含no-edit）→只实际执行一个候选程序→返回所有指定lead。不运行teacher、中心差分、future verification或测试期完整候选重放。晚层features若需要额外reference前向必须计费，或使用可共享prefix。

## 6. Main novelty

不是identity/QP/LoRA原语，而是可核验、可被证伪的issue-time向量轨迹响应学习，以及其相对于同信息标量/直接参数预测的具体收益。是否达到论文门槛由P0/P1证据决定。

## 7. Why parameter intervention?

没有一般必要性证明。内部编辑只是一个受限的、跨step重复作用的函数族假设；递归输出纠正同样能改变后续轨迹。必须用相同参数/输入/训练信息与成本比较，证明数据效率、长期/跨变量一致性或实际运行优势，否则放弃必要性主张。

## 8. Strongest baselines

Fs、validation best-fixed、same-context hypernetwork/direct coefficients、metric/lead-conditioned direct gain、restricted b/H、recurrent multivariate output correction、Fs+e0_hat、Fs+du_hat、known-response greedy/diagH、finite hindsight oracle（仅诊断）。

## 9. Killer experiments

先：真实有限字典oracle−best-fixed。如果不存在足够空间，不做planner。

再：2×2 e0/du oracle substitution确定瓶颈；直接gain挑战确定分解价值；recursive output与surrogate replay挑战参数执行必要性。

最后：相近72h误差下比较24–240h完整轨迹及多变量结构，检验是否只是短期投机。

## 10. Kill criteria

详见STOP_CONDITIONS.md。未测方差/成本不填虚构阈值；开发集预注册后用置信区间作PASS/FAIL/INCONCLUSIVE。所有kill仅对应被充分训练并验证的当前库/假设，不否定整个未探索参数空间。
