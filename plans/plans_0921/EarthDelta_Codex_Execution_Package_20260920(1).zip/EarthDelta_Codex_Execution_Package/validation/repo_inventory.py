#!/usr/bin/env python3
"""Read-only local inventory. Does not import the target repo, install or download.

An inventory is NOT a checkpoint parity test or a scientific PASS. Explicit
checkpoint paths are streamed for SHA-256 without deserializing their contents.
Existing output files are never overwritten. Run from the target machine.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone

PIN = "4fe55a7af90ea92f62a3232a571af92bfbd6114d"
SOURCE_FILES = (
    "README.md", "pyproject.toml", "earthdelta/paired.py", "earthdelta/probe.py",
    "earthdelta/geometry.py", "earthdelta/teacher.py", "earthdelta/selection.py",
    "earthdelta/heads.py", "earthdelta/memory.py", "earthdelta/spectral.py",
    "earthdelta/lowrank.py", "earthdelta/contracts.py",
    "earthdelta/bridge/stormer_arch.py", "earthdelta/bridge/stormer_bridge.py",
    "earthdelta/data/pull_wb2.py", "earthdelta/data/make_splits.py",
    "scripts/s0_gate.py", "tests/test_bridge.py", "tests/test_data.py",
    "tests/test_earthdelta.py", "reference/_manifest.json",
)


def digest_file(path: Path) -> dict:
    if not path.is_file():
        return {"path": str(path), "status": "MISSING_OR_NOT_FILE"}
    h = hashlib.sha256()
    try:
        before = path.stat()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                h.update(chunk)
        after = path.stat()
        unchanged = (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        return {"path": str(path), "status": "HASHED" if unchanged else "CHANGED_DURING_HASH",
                "bytes": after.st_size, "sha256": h.hexdigest() if unchanged else None}
    except OSError as exc:
        return {"path": str(path), "status": "UNREADABLE", "error": type(exc).__name__}


def git_read(repo: Path, args: list[str]) -> dict:
    if shutil.which("git") is None:
        return {"status": "UNAVAILABLE", "returncode": None}
    try:
        env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
        result = subprocess.run(["git", "-C", str(repo), *args], capture_output=True,
                                text=True, timeout=30, env=env, check=False)
        # Do not collect remotes: URLs can embed credentials. No env dump.
        return {"status": "OK" if result.returncode == 0 else "ERROR",
                "returncode": result.returncode, "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip()[:1000]}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"status": "ERROR", "error": type(exc).__name__}


def inspect(repo: Path, checkpoint: list[Path], data_manifest: Path | None) -> dict:
    if not repo.is_dir():
        raise ValueError("--repo must identify an existing directory")
    head = git_read(repo, ["rev-parse", "HEAD"])
    branch = git_read(repo, ["branch", "--show-current"])
    status = git_read(repo, ["status", "--porcelain=v1", "--untracked-files=no"])
    diff = git_read(repo, ["diff", "--name-status", f"{PIN}..HEAD"])
    metadata = {}
    for package in ("torch", "numpy", "scipy", "pytest", "timm", "xarray", "zarr", "xformers"):
        try:
            metadata[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            metadata[package] = "NOT_INSTALLED"
    sources = []
    for rel in SOURCE_FILES:
        entry = digest_file(repo / rel)
        entry["path"] = rel
        sources.append(entry)
    missing = [v["path"] for v in sources if v["status"] != "HASHED"]
    return {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "INVENTORY_ONLY_NOT_SCIENTIFIC_PASS",
        "repo": str(repo), "audit_pin": PIN,
        "git": {"head": head, "branch": branch, "tracked_changes": status,
                "changes_since_audit": diff},
        "requires_reaudit": head.get("stdout") != PIN or bool(status.get("stdout")),
        "python": sys.version, "platform": platform.platform(),
        "distribution_metadata": metadata,
        "cuda_execution": "NOT_TESTED_BY_INVENTORY",
        "source_files": sources, "missing_source_files": missing,
        "checkpoints": [digest_file(p) for p in checkpoint],
        "data_manifest": digest_file(data_manifest) if data_manifest else {"status": "NOT_SUPPLIED"},
        "real_data_read": False, "checkpoint_deserialized": False,
        "official_parity": "NOT_RUN", "repository_pytest": "NOT_RUN",
        "weather_scientific_experiments": "NOT_RUN",
        "next_action": "Execute P0-01 only; resolve assets and independent official reference; no auto-unlock.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, action="append", default=[])
    parser.add_argument("--data-manifest", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output exists; use a new run_id (overwrites are forbidden)")
    try:
        result = inspect(args.repo.resolve(), [p.resolve() for p in args.checkpoint],
                         args.data_manifest.resolve() if args.data_manifest else None)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
    except (OSError, ValueError) as exc:
        print(f"Inventory failed: {exc}", file=sys.stderr)
        return 2
    print(f"Inventory written: {args.output}. NOT a scientific PASS.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
