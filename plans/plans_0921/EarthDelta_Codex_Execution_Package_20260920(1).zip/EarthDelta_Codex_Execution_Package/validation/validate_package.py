#!/usr/bin/env python3
"""Validate delivery structure/task graph only. Does not run repository tests."""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

REQUIRED = [
    "START_HERE_FOR_CODEX.md", "EarthDelta_Codex_Execution_Plan.md", "CODEX_TASKS.md",
    "codex_tasks.json", "STOP_CONDITIONS.md", "README.md",
    "research/CURRENT_METHOD_AUDIT.md", "research/NOVELTY_AUDIT.md",
    "research/RELATED_WORK.md", "research/FINAL_RESEARCH_DECISION.md",
    "research/EARTHDELTA_V2.md", "research/MATHEMATICAL_AUDIT.md",
    "experiments/P0_SURVIVAL_EXPERIMENTS.md", "experiments/P1_CORE_EXPERIMENTS.md",
    "experiments/P2_NOVELTY_EXPERIMENTS.md", "experiments/BASELINES.md",
    "implementation/FILE_BY_FILE_PLAN.md", "implementation/TEST_PLAN.md",
    "implementation/ARTIFACT_CONTRACT.md", "implementation/REPRODUCIBILITY.md",
    "implementation/LITERATURE_TO_CODE.md", "evidence/SOURCE_REGISTER.json",
    "evidence/REPOSITORY_AUDIT_MANIFEST.json", "evidence/AUDIT_FINDINGS.json",
    "validation/repo_inventory.py", "proposed_tests/test_known_regressions.py",
]
TASK_FIELDS = ["id", "phase", "title", "priority", "status", "depends_on",
               "scientific_purpose", "files_to_inspect", "files_to_modify", "files_to_create",
               "implementation_requirements", "must_not_change", "tests_to_add", "commands",
               "artifacts", "success_criteria", "failure_criteria", "failure_action",
               "decision_after_completion", "commit_suggestion"]


def validate(root: Path) -> dict:
    checks = []
    def add(name, condition, detail=""):
        checks.append({"name": name, "passed": bool(condition), "detail": detail})
    for rel in REQUIRED:
        p = root / rel
        add(f"file:{rel}", p.is_file() and p.stat().st_size > 0)
    parsed = {}
    for p in sorted(root.rglob("*.json")):
        if p.name == "PACKAGE_VALIDATION.json":
            continue
        try:
            def invalid_constant(value):
                raise ValueError(f"Non-JSON constant {value}")
            parsed[str(p.relative_to(root))] = json.loads(p.read_text(encoding="utf-8"), parse_constant=invalid_constant)
            add(f"json:{p.relative_to(root)}", True)
        except (OSError, ValueError) as exc:
            add(f"json:{p.relative_to(root)}", False, str(exc))
    data = parsed.get("codex_tasks.json", {})
    tasks = data.get("tasks", [])
    ids = [t.get("id") for t in tasks]
    add("unique_task_ids", bool(tasks) and len(ids) == len(set(ids)))
    add("current_only_P0_01", data.get("allowed_task") == "P0-01")
    add("all_tasks_not_started", all(t.get("status") == "NOT_STARTED" for t in tasks))
    mapping = {t.get("id"): t for t in tasks}
    for task in tasks:
        tid = task.get("id", "missing")
        add(f"task_fields:{tid}", all(k in task for k in TASK_FIELDS))
        deps = task.get("depends_on", [])
        add(f"dependencies_exist:{tid}", all(d in mapping and d != tid for d in deps))
        add(f"phase_order:{tid}", all(mapping[d]["priority"] <= task["priority"] for d in deps if d in mapping))
        add(f"task_has_acceptance:{tid}", bool(task.get("success_criteria")) and bool(task.get("failure_criteria")))
        if task.get("phase") == "P3":
            add(f"P3_requires_authorization:{tid}", task.get("requires_explicit_new_authorization") is True)
    visiting, visited = set(), set()
    def walk(node):
        if node in visiting:
            raise ValueError("Cycle: " + node)
        if node in visited:
            return
        visiting.add(node)
        for dep in mapping[node].get("depends_on", []):
            if dep in mapping:
                walk(dep)
        visiting.remove(node)
        visited.add(node)
    try:
        for node in mapping:
            walk(node)
        add("acyclic_task_graph", True)
    except ValueError as exc:
        add("acyclic_task_graph", False, str(exc))
    p2 = [t for t in tasks if t.get("phase") == "P2"]
    add("P2_at_most_two", len(p2) <= 2)
    parsed_python = []
    regression_count = 0
    for path in sorted(root.rglob("*.py")):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            parsed_python.append(str(path.relative_to(root)))
            if path.parent.name == "proposed_tests":
                regression_count += sum(isinstance(n, ast.FunctionDef) and n.name.startswith("test_") for n in tree.body)
            add(f"python_ast:{path.relative_to(root)}", True)
        except (OSError, SyntaxError) as exc:
            add(f"python_ast:{path.relative_to(root)}", False, str(exc))
    return {"generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "validation_scope": "DELIVERY_STRUCTURE_JSON_DAG_AND_SYNTAX_ONLY",
            "passed": all(c["passed"] for c in checks),
            "checks_total": len(checks), "checks_passed": sum(c["passed"] for c in checks),
            "task_count": len(tasks), "python_files_syntax_checked": parsed_python,
            "proposed_regression_test_functions": regression_count,
            "regression_test_execution": "NOT_RUN",
            "repository_test_execution": "NOT_RUN",
            "real_checkpoint_parity": "NOT_RUN", "weather_experiments": "NOT_RUN",
            "checks": checks}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = validate(args.root.resolve())
    out = args.output or args.root / "evidence" / "PACKAGE_VALIDATION.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("passed", "checks_total", "checks_passed", "task_count",
                                             "proposed_regression_test_functions", "validation_scope")}, ensure_ascii=False))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
