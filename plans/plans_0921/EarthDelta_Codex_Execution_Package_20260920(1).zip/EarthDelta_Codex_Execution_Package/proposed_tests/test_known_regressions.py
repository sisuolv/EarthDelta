"""Regression specifications against audit main@4fe55a7; NOT RUN by this audit.

Run after making P0-02 repairs, from repository root:
 python -m pytest -q plans/codex_audit_20260920/proposed_tests/test_known_regressions.py

Some tests should fail against the audited code. They specify fail-closed behavior;
these are not evidence that the current code was executed in the audit environment.
"""
from __future__ import annotations
from contextlib import contextmanager
import os
import time
import pytest
import torch
from earthdelta.selection import plan_from_prediction
from earthdelta.memory import VerifiedRecord, ewma_error_feature_batched

DT = torch.float64


def test_finite_candidate_respects_coefficient_bound():
    with pytest.raises(ValueError):
        plan_from_prediction(torch.tensor([2.], dtype=DT), torch.eye(1, dtype=DT),
                             bound=.25, max_active=1, budget=1., ridge=0.,
                             candidate_offsets=torch.tensor([[.5]], dtype=DT))


def test_finite_candidate_respects_support_limit():
    with pytest.raises(ValueError):
        plan_from_prediction(torch.tensor([2.], dtype=DT), torch.eye(1, dtype=DT),
                             bound=.25, max_active=0, budget=1., ridge=0.,
                             candidate_offsets=torch.tensor([[.1]], dtype=DT))


def test_nonfinite_candidate_is_not_silently_ignored():
    with pytest.raises(ValueError):
        plan_from_prediction(torch.tensor([2.], dtype=DT), torch.eye(1, dtype=DT),
                             candidate_offsets=torch.tensor([[float('nan')]], dtype=DT),
                             max_active=1, budget=1.)


def record(record_id="a", version="expected"):
    return VerifiedRecord(record_id, 0, 6, 8, version, "old-event",
                          torch.tensor([1., 0.]), torch.tensor([3.]))


def test_memory_version_error_propagates():
    with pytest.raises(ValueError):
        ewma_error_feature_batched([[record(version="wrong")]], [10], "expected")


def test_memory_duplicate_error_propagates():
    with pytest.raises(ValueError):
        ewma_error_feature_batched([[record(), record()]], [10], "expected")


def test_memory_batch_length_mismatch_rejected():
    with pytest.raises(ValueError):
        ewma_error_feature_batched([[record()], [record("b")]], [10], "expected")


def test_memory_future_values_do_not_change_output():
    past = record()
    future = VerifiedRecord("future", 6, 12, 18, "expected", "later-event",
                            torch.tensor([1., 0.]), torch.tensor([1e6]))
    a = ewma_error_feature_batched([[past]], [10], "expected")
    b = ewma_error_feature_batched([[past, future]], [10], "expected")
    torch.testing.assert_close(a, b, rtol=0, atol=0)


@contextmanager
def timezone_env(name):
    previous = os.environ.get("TZ")
    try:
        os.environ["TZ"] = name
        time.tzset()
        yield
    finally:
        if previous is None:
            os.environ.pop("TZ", None)
        else:
            os.environ["TZ"] = previous
        time.tzset()


@pytest.mark.skipif(not hasattr(time, "tzset"), reason="Unix tzset required for this regression")
def test_manifest_utc_independent_of_host_timezone():
    from earthdelta.data.make_splits import build_manifest
    def issue_times():
        manifest = build_manifest(years=[2020], lead_hours=[6],
                                  time_step_hours=24 * 31, max_history_hours=0,
                                  normalization_hash="test-normalization")
        return [row.issue_time for row in manifest.rows]
    with timezone_env("UTC"):
        utc = issue_times()
    with timezone_env("America/New_York"):
        eastern = issue_times()
    assert utc and utc == eastern
