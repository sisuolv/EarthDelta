# EarthDelta Codex Tasks

审查基线：`main@4fe55a7af90ea92f62a3232a571af92bfbd6114d`。所有下列任务均未由本轮执行；包校验不是任务完成。


## P0

- [ ] **P0-01 — 现场证据冻结与独立官方 S0**。依赖：无；当前 `NOT_STARTED`。

- [ ] **P0-02 — 统一度量、动作约束和因果数据合同**。依赖：P0-01；当前 `NOT_STARTED`。

- [ ] **P0-03 — 非退化参考/编辑库与研究门槛预注册**。依赖：P0-02；当前 `NOT_STARTED`。

- [ ] **P0-04 — 真实有限候选 oracle 与动态空间审判**。依赖：P0-03；当前 `NOT_STARTED`。

- [ ] **P0-05 — 2×2可预测性分解与直接收益挑战**。依赖：P0-04；当前 `NOT_STARTED`。

- [ ] **P0-06 — 参数执行与递归输出订正的生存对照**。依赖：P0-05；当前 `NOT_STARTED`。

## P1

- [ ] **P1-01 — 版本化真实轨迹响应训练集**。依赖：P0-06；当前 `NOT_STARTED`。

- [ ] **P1-02 — 响应路线、直接路线和决策投影对照**。依赖：P1-01；当前 `NOT_STARTED`。

- [ ] **P1-03 — 单次选定轨迹执行与统一评测**。依赖：P1-02；当前 `NOT_STARTED`。

## P2

- [ ] **P2-01 — 轨迹目标重用与标签效率：首选增强**。依赖：P1-03；当前 `NOT_STARTED`。

- [ ] **P2-02 — 信赖域内的多编辑组合：可选第二增强**。依赖：P1-03；当前 `NOT_STARTED`。

## P3

- [ ] **P3-01 — 仅记录的后续模块与外部验证**。依赖：P1-03；当前 `NOT_STARTED`。


## Current stopping point

Do not proceed beyond: **P0-01** in the current invocation.

## Unlock condition

P0-01的decision.json必须真实通过独立官方checkpoint/数据/因果验收，且没有required skip。成功后才将P0-02标为next allowed，并更新本文件和codex_tasks.json；本次调用随即停止、报告结果，不自动串行执行所有阶段。

BLOCKED缺资源不等于FAIL，也不允许用合成结果解锁。INCONCLUSIVE仅按已经注册的样本扩展计划处理。P2在P1科学结论通过后才允许，P3不自动解锁。

## State update log

- 初始：全部NOT_STARTED；当前只允许P0-01。
- 每次更新追加：UTC timestamp / task / execution commit / run id / decision path / status / next allowed。
