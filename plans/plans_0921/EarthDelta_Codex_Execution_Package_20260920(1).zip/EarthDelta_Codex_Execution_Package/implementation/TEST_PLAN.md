# Test plan — targeted regressions, not a replacement suite

## 已有测试要保留

tests/test_earthdelta.py（合成核心）、test_bridge.py（小模型/可选真实权重）、test_data.py（合成变量/网格/切分）。README报告192 passed/3 skipped；本轮未运行，不能作为交付包验证计数。

## P0必加

|领域|具体断言|失败指向|
|---|---|---|
|独立parity|原始上游模型、本地bridge、安装非零专家零系数三路同权重输出在锁定容差内；非零edit后回零仍一致|S0自比较不能替代|
|identity|不同文件内容、通道名、lead间隔key、lat坐标、metric权重、Fs/bank版本均改变hash并被入口拒绝|旧cache不可混用|
|time|UTC/非UTC机器生成相同UTC时间；完整history/lead/memory支持不跨split；availability拒绝future|不是只改一个从未读取的future变量|
|metric|e0=Y−F；gain=loss(F)−loss(Fu)；跨variable/lead/area用同一reducer；aggregate SSE再sqrt|不能混用sum/mean|
|constraints|finite和continuous都落实box/support/cost/penalty/finite/ID；非法输入raise|不允许下游EditPlan才偶然拒绝|
|training|router系数梯度非零有限；base gradients None；dense/sparse值一致；tensor不经tuple重建|serving API不等于可微训练API|
|memory|错误version/duplicate/长度raise，只有NoEligibleRecords可零回退；预测起点后checksum不变|batched catch-all缺陷|
|trajectory|返回每个lead的结果等于相应截断rollout；hold结束从已编辑状态续跑；interval不匹配拒绝|不得拼回未编辑cache|
|oracle|完整枚举、含zero、same candidates、失败不删除；oracle≥best-fixed只在同metric成立|top3/local不是有限全oracle|
|baselines|输出修正反馈下步、所有变量可修、参数/历史/训练lead匹配|不构造稻草人对照|

proposed_tests/test_known_regressions.py提供部分具体可运行断言，要求把无效候选显式拒绝。它们预期揭露当前问题，尚未在完整仓库运行。Codex应先运行、记录失败，再最小修复；不通过改期望值掩盖问题。

## P1/P2扩展

真实paired缓存metadata/missing-case；heldout rollout；gain排名与regret；raw/calibrated分开；prefix参考前向cost计数；响应b/H的维度和PSD；epsilon/混合方向/JVP一致性；候选/metric descriptor迁移公平性。

SHT只在实施时增加真实节点、constant/singlemode/inverse/multiplicity测试。当前占位函数不应通过“跳过”转成完成状态。
