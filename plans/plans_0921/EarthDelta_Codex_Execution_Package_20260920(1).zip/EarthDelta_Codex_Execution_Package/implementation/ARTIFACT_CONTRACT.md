# Artifact contract

所有实际实验写入 `artifacts/{p0,p1,p2}/{TASK_ID}/{UTC_RUN_ID}/`；目录已存在就退出或生成新run id，不覆盖。

每次至少保存：

    config.json
    metrics.json
    summary.md
    stdout.log
    decision.json
    identity.json

需要预测时：`predictions/`；图：`figures/`；需要追踪每个起点：`per_origin_metrics.parquet`。原始权重/大数组不默认提交git；目录可提供校验清单与本地可解析路径。

identity.json包括执行commit、审查baseline commit、dirty diff hash、data manifest/normalization/grid/projection/metric/candidate/continuation SHA256、environment lock、seed、设备/精度/注意力backend。checkpoint内容hash不得以“Stormer_ps4”等架构名替代。

metrics.json使用命名字段和单位，至少：forecast_RMSE_by_variable_lead、ACC_definition、gain_metric_id、raw_geometric_gain、calibrated_gain、actual_gain、oracle_kind、regret、negative_gain_rate、failed_forecasts、latency_scope、peak_memory、probe_training_cost。未测值用null并给reason，不用0。

decision.json至少：task_id、status、required_checks、blocking_reasons、protocol_hash、input_run_ids、contrast、estimate、confidence_interval、threshold、next_allowed_task。PASS仅在全部required checks为PASS且所需真实验证没有skip时允许。INCONCLUSIVE与BLOCKED不解锁。

null/NaN区分：未知用null+reason；数值NaN/Inf是失败事件，不能用JSON的非标准NaN编码消失。最终PNG/CSV不能取代可再计算的per-origin结果。论文表按相同有效起点表join；执行失败按预注册回退计分并计数。

推理轨迹规范：变量名、压力层、lat/lon数值、init_time、lead_time、valid_time、units、model/plan/version。不能只存一个缺坐标的npy并靠文件名猜轴。
