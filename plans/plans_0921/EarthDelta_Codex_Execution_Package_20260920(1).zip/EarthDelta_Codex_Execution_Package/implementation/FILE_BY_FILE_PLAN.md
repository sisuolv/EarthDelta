# File-by-file implementation plan

所有修改都相对审查commit；先复核当前HEAD是否变化。表中为要做的patch，不代表已经实现。

|当前文件/函数|现在实现|问题|怎么改|对应实验/任务|优先级|
|---|---|---|---|---|---|
|`scripts/s0_gate.py` / `verify_zero_edit_equivalence`|同一 WeatherStepBridge 的 forward_validation 与 controlled_rollout 对比，expert_loras 为空。|共同实现错误可同时通过；没有证明等于官方整网。|同一已校验权重，独立官方 Stormer 实现→本地 architecture→controlled 三路比较；额外安装非零 B 专家但传零系数；所有时效逐点比较。|S0 / P0-01|P0|
|`scripts/s0_gate.py` / `verify_no_state_leak / run_s0_gate`|扰动未参与预测的局部未来数组；RMSE error/NaN 不纳入最终 gate。|只证明重复性；坏数据或诊断异常仍可能 PASS。|部署输入类不含 targets；读权限/spy-canary 测试；hook 异常恢复；required_checks 全通过且无 NaN/skip 才 PASS；环境缺失用 BLOCKED。|S0 / P0-01|P0|
|`earthdelta/bridge/stormer_bridge.py` / `NormalizationContract.from_npz_dir / denormalize_diff`|加载可用 diff_mean 并参与反归一化；官方 inference 使用的增量转换零均值策略需要独立对照。|不是证明所有现有常数非零，但只要非零就可能偏离官方推理；多步偏差会累积。|新增 explicit diff_mean_policy 并写入哈希；replication 模式严格复现 pinned official inference，不凭文件存在自动改变策略。|S0 / P0-01|P0|
|`earthdelta/bridge/stormer_bridge.py` / `load_stormer_checkpoint / NormalizationContract.digest`|版本身份主要编码架构；norm digest 缺变量/间隔名称；grid 使用形状。|同架构不同权重、通道交换、同形异网格可能不被识别。|流式 SHA256 checkpoint 内容；hash 名称/shape/dtype/排序后的数据；lat/lon 实值哈希；Fs 与字典也绑定内容；拒绝 pending/placeholder。|S0 / P0-01|P0|
|`earthdelta/selection.py` / `plan_from_prediction / _plan_from_finite_candidates / unified_select`|finite 路径不落实 bound、max_active、max_candidates；QP 路径不使用 cost_penalty。|名义受预算的选择可违反实际动作合同，比较不公平。|统一候选可行性验证、代价/正则/阈值语义；非法字典直接拒绝而非悄悄夹紧；稳定 ID 并列规则。|约束 / P0-02|P0|
|`earthdelta/paired.py; earthdelta/geometry.py; earthdelta/heads.py` / `quadratic_gain / ResponseGeometry.from_error / ComposedPredictionHead.forward`|分别使用最后轴权重均值、未归一化 Q、无权均值；calibration 可任意补偿。|数值不在同一指标下，ridge/阈值/成本权重失去含义。|单一 MetricSpec：固定变量尺度、面积、lead 权重与 reducer；显式 raw_geometric_gain 与 calibrated_gain；校准开关消融。|全部 / P0-02|P0|
|`earthdelta/bridge/stormer_bridge.py` / `controlled_rollout`|EditPlan tuple 用 torch.tensor 重建，serving 合理但不能保留可学习 router 的系数梯度。|无法用这个接口公平训练端到端条件化 baseline；不要误称所有 Adapter 梯度都断了。|保留 immutable serving API，新增 controlled_rollout_train(coefficients: Tensor, ...) 与 collect_leads；禁止 detach/tensor重建；Fs 静态路径与动态路径分离。|direct router / P0-02|P0|
|`earthdelta/memory.py` / `ewma_error_feature_batched`|捕获所有 ValueError，把版本错误、重复记录等转成零特征；zip 不检查长度。|看似拒绝不合法记录，批量路径却静默成功。|只对明确 NoEligibleRecords 做零回退；其他异常传播；检查长度、特征维度、decay 有限区间；P0 主试验默认关闭 memory。|同信息 / P0-02|P0|
|`earthdelta/data/make_splits.py` / `build_manifest / compute_guard_boundaries / from_parquet`|naive datetime.timestamp 依赖主机时区；6h availability 是人为默认；边界不含 memory warmup；parquet 丢 metadata。|改变机器时区会改变 UTC；理想化历史被误称实时；跨边界泄漏和来源丢失。|timezone.utc；来自实际可用时间或声明 archive_assumption；所有起点完整检查 history/targets 范围；memory warmup 纳入 support；parquet sidecar；拒绝占位 hash。|全部 / P0-02|P0|
|`scripts/s0_gate.py` / `compute_rmse_z500`|先对每个样本开平方再平均；target i+steps 对非6h步长不通用；仅首10个起点。|不是统一总体 RMSE；极窄样本不能复现整年paper表。|根据精确 valid timestamp 找真值，先累计加权SSE/权重再开方；原始单位与预报时效明确；移除未核实paper常数，保留 sanity非论文结果。|S0 / P0-01|P0|
|`earthdelta/probe.py; earthdelta/geometry.py; earthdelta/teacher.py` / `central_response / cached_responses / box_candidates / verify_candidates`|finite exact 与局部中心差分并存；Gram含交叉项；teacher只复验少量候选。|局部最优/局部交叉项被叫作真实非线性 oracle 或 nonlinear interaction。|response_kind 固定枚举；全候选真实 replay 做 P0 ceiling；mixed方向与epsilon误差；local teacher 只保留诊断；失败转finite-only。|A,C,F / P0-04,P2-02|P1|
|`earthdelta/heads.py` / `ReferenceErrorHead / EditResponseHead / InteractionUtilityHead / ComposedPredictionHead`|已有多lead前向与PSD H；不缺一个“multi-lead head”名称。|重复造轮子；缺的是真实目标管线、训练、选择评价及同信息对照。|复用现有头，接真实轨迹；比较 e0/du、直接 gain、b/H 与 restricted b；optional JEPA 默认关闭。|C,D,F / P0-05,P1-02|P1|
|`earthdelta/spectral.py; earthdelta/probe.py` / `band_energy / single_mode_energy / jvp_response`|NotImplementedError，SHT只诊断已有系数。|报告中误称已有谱前端或自动微分响应。|P0 用固定线性粗化；只有需求成立再实现真实网格SHT或JVP；不静默替换平面FFT。|物理诊断 / P2/P3|P2|
|`earthdelta/lowrank.py; README.md` / `ExpertLoRA / claimed assets`|新专家 B=0；看不到已训练 Fs/专家库/真实增益日志。|零初始化 oracle 无提升被误判项目失败；原模型缺少能力的提升被误认动态贡献。|先训练强静态参考及非退化有限库；独立验证专家方向；no-edit=Fs；随机与弱库结果只诊断当前字典。|A,B / P0-03|P0|
|`plans/plans_v1_0919/v6_draft/research_spec_v6.yaml` / `context_encoder / experiments.P3 / claim`|晚层参考特征写成零额外成本；预算/新专家/新lead迁移在计划中写得过强。|为选从18层起的edit先跑到23层再重算，成本不免费；descriptor router同样可迁移。|统一廉价历史特征，或共享到首编辑前的不可变prefix，或完整计费参考前向；迁移均列为待验证，与同descriptor对照比较。|效率/transfer / P1-03,P2-01|P1|

## 现有正确组件不要重写

保留central_response/cached_responses分工、ResponseGeometry的Gram构造、teacher的真实非线性复验接口、ExpertLoRA稠密/稀疏数值路径、测试中的非零fixture、hook的try/finally恢复、ComposedPredictionHead的lead轴与零编辑mask。需要的是连接、统一合同和补强测试。

## 训练路径的隐藏正则

当前ComposedPredictionHead.training_loss在JEPA关闭时仍计算variance项。P0比较应明确loss_weights，选择不使用latent时将其显式置0或用简单heads独立loss；不能只看use_jepa_latent=False就宣称两条训练完全相同。

## 新增I/O边界

ServingContext仅包括history、起点、合法metadata、可审计memory feature、版本；不含targets。
OfflineEpisodeTargets包括Y、exact du和truth-derived e0，仅dataset训练/评测组件可见。
MetricSpec与CandidateSet不可变；ResponseKind区分finite exact/central derivative/learned；TrajectoryResult包含ordered lead_hours和同序predictions。

旧方法参数保持向后兼容，过期cache必须显式失效；不为新方法改写历史结果文件。
