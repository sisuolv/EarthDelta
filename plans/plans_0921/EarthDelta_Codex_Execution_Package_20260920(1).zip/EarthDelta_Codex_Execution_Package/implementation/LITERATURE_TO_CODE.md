# Literature-to-code and licensing

|External repo|Pinned commit|License status|Reused idea/code|EarthDelta destination|Modification/limits|
|---|---|---|---|---|---|
|tung-nd/stormer|58dfee5a6037399a40fefd492bc00421e0c885a8|本轮读取该pin LICENSE：MIT，版权Tung Nguyen|独立官方参考、标准网络/归一化|bridge/official_reference.py、s0_gate.py|保留版权；不要把本地重实现当独立official；核对权重另有来源|
|google-research/weatherbenchX|964a35e8fea2c644a3a1dd056289146cc67a4741|本轮确认完整commit；README此前读取Apache-2.0，实际vendoring前再读pin LICENSE|xarray loader/metric/aggregation|evaluation/weatherbench_adapter.py|以依赖封装为主，锁版本与坐标，native loss交叉核对|
|huggingface/peft|50a277e（作者manifest，完整pin尚未独立解析）|作者manifest Apache-2.0；使用前核实|standard LoRA baseline|baselines/standard_lora.py（仅确有需要时）|当前ExpertLoRA K=1更省事；不把AdaLoRA等同测试期动态rank|
|tum-pbs/Solver-in-the-Loop|f514fcf（作者manifest）|作者manifest MIT；复制前核实|递归纠正训练思想|baselines/recurrent_output.py|可用PyTorch独立实现最小强对照，无需迁入完整PDE环境|
|yuan-yin/CoDA|17b7352（作者manifest）|作者manifest MIT；复制前核实|context fitting / direct adaptation|baselines/past_context.py（P1可选）|观测支持窗口不得超过起点；不把future teacher叫online|
|NVIDIA/torch-harmonics|4ac8ed3（作者manifest）|license头已见，pin全文尚未独立复验|SHT诊断及球面响应工具|spectral.py（P2/P3）|先验证grid节点；不依shape套默认SHT；P0不依赖|
|DCDmllm/CoMoL|011306a（作者manifest）|manifest未发现license，UNVERIFIED|动态低秩/core-mixture近邻|仅文献/独立重实现对照|复制源码BLOCKED直到许可清楚|
|ShileiCao/WeatherPEFT|b2cdc25（作者manifest）|manifest未发现license，UNVERIFIED|任务PEFT近邻|暂缓主线|不得把公开可读等同有权复制|
|SciPy optimize|通过环境锁生成package版本与hash|随项目依赖核查，当前已使用|lsq_linear、minimize小问题求解|teacher.py、selection.py|无需引入Gurobi/可微QP框架；在有限库对照成立后才扩展|

完整外部pin缺失时，Codex需在使用前执行 `git rev-parse <recorded-prefix>^{commit}`、读取同commit的LICENSE并写入artifact。无法解析或license缺失：BLOCKED_COPY，不得取main最新代替且仍声称相同实验。

来源：`https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/reference/_manifest.json` 为作者的本地记录，不表示本轮已验证每个clone。Stormer LICENSE： https://github.com/tung-nd/stormer/blob/58dfee5a6037399a40fefd492bc00421e0c885a8/LICENSE 。本包没有拷贝外部模型权重、论文全文或原始repo。
