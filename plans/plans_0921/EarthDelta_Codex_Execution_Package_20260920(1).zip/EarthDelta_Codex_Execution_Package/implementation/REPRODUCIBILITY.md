# Reproducibility and integrity

1. 审查基线为main@4fe55a7af90ea92f62a3232a571af92bfbd6114d。现场HEAD不同先diff-review并记录，不能reset覆盖用户工作；修改使用新分支或用户指定工作区。
2. 每次实验锁定seed、候选顺序与稳定ID、训练/验证/确认数据、明确作用窗和续跑策略。重复性试验要保存attention backend、TF32/AMP、dtype以及确定性设置。
3. 权重、字典、数据、归一化与metric使用内容身份；摘要/PCA只用训练集拟合。缓存的有效性需要由入口检查，不只是提供一个从未调用的check_version_match函数。
4. training features/labels与serving features分离；未来真值只能在offline loss/evaluation/teacher中；不能在推理中隐式调用oracle、重播全部test候选后挑。
5. 同一个预测起点后的verified memory只读；新周期允许已到期记录的chronological协议单列；随机batch不可共享未重置的历史状态。
6. 所有方法相同完整历史、同样的teacher/response额外监督、同等调参预算、多步训练、同指标与样本。额外监督可能是方法的一部分，但必须单列成本和matched-data对照。
7. 库/epoch/rho/阈值/metric由开发集选，最终确认集不作反馈优化；计划外选择需要新协议和独立确认数据。
8. probe response epsilon、dtype和repeatability写入版本；未来时效超出训练覆盖不叫支持内迁移；新专家新校准不叫零样本。
9. 不以易复制的README summary替代logs/checksums。作者报告与本轮重跑分两栏；skip不能标PASS，资料缺失标BLOCKED。
10. 第三方许可在固定commit核查，保留notice；不复制无许可代码。不要把仓库读权限或公开下载当再分发许可，也不分发任何凭证。
11. 不引入后台持续下载/重复重试无限循环。资源上限、取消/断点逻辑明确；缺数据先可验证小批，然后申请/记录扩展，不自动拉几十年。
12. 本包的validation只证明文件/任务结构，不证明EarthDelta实现或实验正确；proposed_tests需在真实工作区由Codex执行并报告。
