# EarthDelta — research audit and gated Codex execution package

审查对象：`sisuolv/EarthDelta`，`main@4fe55a7af90ea92f62a3232a571af92bfbd6114d`。
日期标签按 America/New_York：2026-09-20；仓库提交UTC时间为2026-09-21T02:44:12Z（当地2026-09-20 22:44:12）。

## 入口

先阅读 `START_HERE_FOR_CODEX.md`。当前只允许执行 **P0-01**。完整任务合同在 `EarthDelta_Codex_Execution_Plan.md`；可勾选清单在 `CODEX_TASKS.md`；机器任务图在 `codex_tasks.json`。

研究结论：**CONDITIONAL CONTINUE / P0 ONLY**。保留起报时的轨迹响应预测、明确度量下的e0/du分解和真实选择价值；暂缓模块扩展。既不认定方法已达到投稿标准，也不因目前缺少真实结果而宣判整条路线失败。

## 本包交付什么

- 当前源码审查与15项风险发现，区分已实现、作者报告、未核验和纯proposal。
- 10个重点近邻与补充文献，原始来源和复用边界。
- 12项带依赖、测试、命令、产物、验收与停止条件的Codex任务。
- 固定研究决策、数学审计、强基线、P0/P1/P2/P3分阶段实验。
- 只读现场库存工具、交付结构校验工具、8个针对已读代码风险的回归测试草案。

## 验证边界

本轮实际进行了GitHub授权只读审查、原始文献查阅、文档/JSON/ZIP生成与交付结构校验。**未克隆并执行当前EarthDelta仓库的pytest，未运行当前checkpoint、ERA5训练、GPU预报或科学实验。** README中的192通过/3跳过属于作者报告，不是本轮复跑。

`proposed_tests/test_known_regressions.py` 仅做语法校验，**未执行**；部分测试按预期应在审查版本上失败，必须在现场确认并修复，不得把“已写测试”报成“测试通过”。

`validation/repo_inventory.py --help` 和 `validation/validate_package.py` 是现有可运行工具；主计划里标为TO_IMPLEMENT的训练/评测CLI是待Codex创建的接口合同，不是已完成的天气实验程序。

## 在现场校验本包

```bash
python validation/validate_package.py
```

这一命令只验证结构、JSON、任务DAG及Python语法，不会下载数据、安装依赖、导入EarthDelta或执行科学实验。

`MANIFEST.sha256`记录打包时文件内容身份。重新运行校验会更新其报告时间，因此本地变更后应生成新manifest，不要误称旧hash仍然有效。

## 安全与复用

不覆盖旧计划、不自动修改仓库、不上传Notion或提交GitHub。原始引用代码与模型的许可分别核查；本包没有重新分发外部模型权重或数据。不要把仓库中的许可声明自动推广到所有引用资产。
