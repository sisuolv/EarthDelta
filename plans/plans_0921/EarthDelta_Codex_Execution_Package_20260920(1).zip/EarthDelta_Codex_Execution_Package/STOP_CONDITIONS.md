# STOP_CONDITIONS — evidence before expansion

## 0. 四种状态不能混淆

- **BLOCKED**：没有资产、GPU/内存、独立官方参考、完整开发数据或必要许可；不作科学否定，不解锁下一任务。
- **FAIL / STOP**：工程合同明确违反，或充分验证后的统计上界仍小于锁定目标；指出停止的是哪个字典、方法分支或科学主张。
- **INCONCLUSIVE**：区间仍跨过门槛/功效不足；仅按预先批准样本计划扩充，不增加模块、换数据切分或改评价目标。
- **PASS**：相关下界/非劣条件及全部合同满足，不是单个p值小，也不是“没显著变差”。

## 1. 不能现在臆造统一的2%/3%

本轮没有真实baseline variance、候选增益分布、运行成本或业务最低收益。因而本包中的配置是模板，numeric阈值由P0-03从独立development数据生成，P0-04必须拒绝阈值缺失的注册文件。这是可执行校准任务，不是让agent任意猜一个数字。

### P0-03的具体生成规则

1. 固定primary contrast与metric：72h、Z500/T850/T2m/MSLP，训练/官方尺度标准化的面积加权MSE。固定作用窗4×6h。确认集尚未打开。
2. 测量同一参考重复运行得到的gain差异，令η_num为其绝对差异的99%分位；以10×η_num作为保守的数值噪声隔离底线。10是工程安全倍数，不是科研效应定律；必须同时报告原始η_num。
3. 在development块上估计每个paired contrast的块均值标准差s_block。块长度不小于最大验证lead引起的重叠长度，并结合development自相关诊断；敏感性检查两种更长块长。
4. 由实际每起点全候选成本、允许的资源上限及未用数据覆盖得到最大有效块数 B_max，不把像素/候选数当独立样本数。资源预算必须显式，不因机器有空闲就任意扩展。
5. 计算资源可分辨效应 MDE=(z_(1−α/(2L))+z_0.8)*s_block/sqrt(B_max)，L为预先计划的查看次数（默认1，至多2次时作Bonferroni调整）。这是一项近似功效规划；用development block resampling复核近似，不能把正态近似当最终显著性检验。
6. **研究可行性筛选门槛** δ_research=max(10η_num,MDE)。分别生成delta_headroom（oracle−Fs）与delta_dynamic（oracle−best-fixed）。它衡量现有资源下值得展开的最小可分辨改进，不等于真实业务最低有价值收益。
7. 若有可引用的业务收益/成本标准，再填写δ_domain并使用max(δ_research,δ_domain)；没有时保留null并禁止写operationally useful结论。equivalence_margin和long_harm_margin也必须由同单位的数值噪声、可分辨量及清晰容忍理由冻结，不用测试结果反推。
8. 保存全部数值、输入development IDs、单位、成本、资源预算、计算命令、阈值理由及SHA。更改候选/metric/hold/阈值必须新protocol和新的确认数据；不得只复用同一确认集不断尝试。

这不是允许低功效试验宣布项目失败：如果上界仍大且区间宽，只能INCONCLUSIVE。若合理字典尚未收敛，也不能进入scientific STOP。

## 2. 决策规则

对于“增益必须超过δ”的量Δ，计算预注册paired block置信区间[L,U]：

    L > δ  → PASS
    U <= δ → 当前假设/字典 FAIL（按下表STOP/PIVOT）
    其他   → INCONCLUSIVE

对非劣指标（如长时效loss增加），使用预注册伤害margin：上置信界低于margin才通过；下界高于margin为伤害；跨越则不确定。多个变量/lead的guardrail使用同时区间或预注册Holm处理，不能测试后只展示最好的一个。

若采用两次查看，只能使用锁定的样本数与α分配；不按结果随时加一点数据直到显著。

## 3. STOP条款

|ID|触发条件|动作|禁止的绕过|
|---|---|---|---|
|STOP-0|独立S0、metric identity、来源、future-read或梯度合同失败|停止所有科学比较并修复|把合成/同bridge测试PASS当真实S0|
|STOP-1|经过训练与留出校验的有限库oracle−Fs的U≤δ_headroom|停止当前库；最多一次预注册修订|在零B/未训练库上否定想法；无限刷库|
|STOP-2|oracle−best-fixed的U≤δ_dynamic|PIVOT静态适配；取消复杂planner|用oracle总增益掩盖动态增量不足|
|STOP-3|经过轻量合理调参，合法e/du或decision projection捕获不到可分辨动态增益|针对2×2瓶颈停止/收窄；必要时归为不可预测hindsight空间|靠扩JEPA/memory继续堆模块|
|STOP-4|factorized与direct gain等效且更贵，且锁定的标签/目标复用检验也无优势|删除分解方法贡献或PIVOT direct controller|只看latent loss/图形掩盖decision劣势|
|STOP-5|同信息recurrent output或surrogate replay在主指标、长程伤害与成本上支配parameter execution|停止参数编辑必要性主张|把输出baseline限制为一步或不给同样历史|
|STOP-6|短时效赢、72/120/240h系统损伤超过margin|缩小作用窗/主张或停该编辑族；重新注册|只报告6h/24h最优结果|
|STOP-7|Ra对混合编辑的真实误差超信赖域，fullH组合收益不成立|停止连续Jacobian分支，退回finite-exact|把Gram overlap称非线性交互并继续扩大a|
|STOP-8|总体开销超过预算、控制器比节省的adapter成本更高而无精度优势|撤回加速/预算优势，重新评价Pareto|忽略reference额外前向、warmup和probe成本|

## 4. 明确分母与字典范围

不用“静态解释了oracle的90%”作为唯一门槛，因为oracle接近0时比率不稳定。用同单位paired oracle−best_fixed及区间。

有限库oracle只上界当前列出的可行编辑，不上界全部可能参数修改；solver没找到更优也不构成不存在性证明。主动缩字典、删困难变量、增测试期探测都会改变问题，必须新protocol。
