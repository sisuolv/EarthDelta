# EarthDelta Codex Execution Plan

审查日期（America/New_York）：2026-09-20。对象：`sisuolv/EarthDelta`，`main@4fe55a7af90ea92f62a3232a571af92bfbd6114d`。
本文件是实施合同；除明确existing脚本外，新CLI/classes/tests均为TO_IMPLEMENT，不能称已经完成。

## 0. Mission

在冻结天气模型和严格起报信息限制下，评估可逆低秩参数编辑的向量轨迹响应是否能被预测，并是否值得用于选择。当前阶段是基础库+合成测试+数据/桥接建设，尚无本轮核实的真实trained-head/字典收益结果。

本轮只允许执行P0-01。暂不加入JEPA、复杂memory、动态rank、谱loss、第二主干或大规模训练。任务需要提出可证伪结果，而非确保EarthDelta获胜。

## 1. Repository Ground Truth

- 分支main；commit `4fe55a7af90ea92f62a3232a571af92bfbd6114d`；提交UTC 2026-09-21 02:44:12，对应纽约9月20日22:44:12。
- 当前目录：earthdelta核心/bridge/data，scripts/s0_gate.py，tests三组，plans/plans_v1_0919，reference/_manifest.json。
- 当前实现：e0/du paired、finite/central probes、RᵀQR几何、teacher、finite/continuous selector、ExpertLoRA、b/H和multi-lead heads、EWMA、SDPA bridge、数据下载/切分。
- tests作者报告192 pass/3 skip，本轮未复跑；不能拿旧kit日志当本commit验收。
- README报告2020年1464×69×128×256数据与ps2/ps4本地checkpoint；其字节、hash与现场资源 **UNVERIFIED**。
- Fs、trained expert bank、learned e0/du/gain heads、真实oracle、长期增益 **UNVERIFIED**；不要从类名或plan内容推断已训练。
- `jvp_response`、`band_energy`、`single_mode_energy`未实现；现有head已支持lead轴，缺的是训练与真实轨迹数据链。
- 当前编辑在`attn.proj` blocks18–23，不是旧starter的post-block20/23。不要使用旧版路径覆盖当前实现。

## 2. Scientific Contract

Must preserve:

1. F0=官方冻结原模型；Fs=明确加载的已训练静态参考；zero additional edit=Fs。不能混用两个no-edit。
2. e0=Y−Fs，du=Fu−Fs，eu=e0−du；同一MetricSpec下gain=2<e0,du>−||du||²。
3. Q的变量尺度、面积、时效、reducer、投影均固定且入hash。summary正确不意味着full-field正确。
4. Finite真实响应与Jacobian/linear surrogate分开；Gram cross terms不是nonlinear interaction。
5. 真值、teacher、probe仅离线分析/训练；serving forward无targets，不在test起点枚举所有候选后选最优。
6. 编辑窗口、continuation、输入历史、memory snapshot和候选cost一致。结束后从edited state继续Fs，不拼回原轨迹。
7. Frozen weight不等于no_grad整段；router训练需保留Tensor梯度；serving immutable plan与training tensor API分开。
8. 时间全部UTC，available_time<=origin，memory支持/目标不能跨split；archive假设不得改写成真实在线可用性。
9. 正/零/负效果全部保存；候选失败按锁定回退计分并计数；不同方法同起点。
10. 保留正确旧模块和历史结果；不无理由重写，不自动提交/推送，不分发凭证或无许可代码。

## 3. Non-goals

本轮不做JEPA/TTT复杂memory/dynamic rank优化/谱训练loss/Complexity Atlas/第二模型/同化/概率预测/全参数Jacobian。旧实现保留关闭。P3仅backlog。

## 4. Current Blocking Questions

Q1独立官方checkpoint bridge正确吗？Q2训练后的finite字典是否有真实oracle空间？Q3该空间是否超过最佳固定编辑？Q4合法e0或其decision projection、du是否可预测？Q5分解是否好过同信息direct gain？Q6内部编辑为何好过recursive output或Fs+predicteddu？Q7实际成本与长lead伤害是否值得？

当前已发现的前置问题：S0同bridge自比较；不参与计算的future数组测试；RMSE未进pass；norm均值策略；身份hash缺内容/名称；finite候选遗漏约束；sum/mean不统一；tuple梯度接口；batched memory吞异常；UTC/availability/guard不足。详见每个任务的定位，不因这些问题直接否定科学idea。

## 5. Execution DAG

```text
P0-01 Independent S0
   BLOCKED/FAIL -> stop current invocation, fix evidence/integration
   PASS
    v
P0-02 Metric / action / time / gradient contracts
    v
P0-03 Trained Fs + finite dictionary + development-only preregistration
    v
P0-04 Exact finite oracle vs Fs and validation best-fixed
   FAIL -> STOP current bank OR PIVOT static (at most one preregistered repair)
   INCONCLUSIVE -> only predeclared sample extension
   PASS
    v
P0-05 Oracle e0/du 2x2 + direct-gain + projection predictability
    v
P0-06 Recurrent output / surrogate replay / long-rollout challenge
   DOMINATED -> STOP parameter-necessity claim
   CONTINUE
    v
P1-01 Real trajectory response dataset
    v
P1-02 Response / direct / bH / coefficient models
    v
P1-03 Serving + common evaluation + complete costs
   SCIENTIFIC CONTINUE
    +--> P2-01 trajectory objective reuse / label efficiency (preferred)
    +--> P2-02 trust-region multi-edit composition (optional)

P3-01 future work: explicit new authorization, never auto-run
```

每阶段的prerequisites=input_run_ids中前置PASS；input/output/metric/pass/fail/next-action见下列独立任务。单次Codex调用只执行allowed_task，不把DAG当无人监管的无限运行脚本。

## 6. Detailed Codex Tasks

共同命令前置：包位于`plans/codex_audit_20260920/`，从repo root执行，设置新的`RUN_ID=$(date -u +%Y%m%dT%H%M%SZ)`。`LOCKED_RUN`必须由前置成功decision.json给出的run_id显式替换，不按文件夹排序猜“最新”。输入配置中的null资产由现场验证后填入副本；template不直接成为科学注册。


### TASK P0-01 — 现场证据冻结与独立官方 S0

**Phase / prerequisites:** P0 / none

#### Scientific purpose
确认真实权重、数据和bridge可信；修复A01–A04/A10中S0直接阻断项，先于任何科学增益计算。

#### Files to inspect
- `README.md`
- `pyproject.toml`
- `scripts/s0_gate.py`
- `earthdelta/bridge/stormer_arch.py`
- `earthdelta/bridge/stormer_bridge.py`
- `tests/test_bridge.py`
- `reference/_manifest.json`

#### Files to modify
- `scripts/s0_gate.py`
- `earthdelta/bridge/stormer_bridge.py`
- `tests/test_bridge.py`

#### Files to create
- `earthdelta/bridge/official_reference.py`
- `tests/test_s0_independent.py`

#### Implementation requirements
- 先运行包内repo_inventory.py；若HEAD不等于审查SHA，输出差异并重新核对受影响发现，不reset、不stash、不覆盖dirty tree。只可工作在用户授权的副本/新分支。
- S0增加--config/--out-dir/--checkpoint/--data-dir/--norm-dir/--device参数，删除import时pip install与硬编码本地环境替换；只加载选定patch4。资源缺失输出BLOCKED和缺失清单。
- 官方reference必须从pin的原始Stormer包构造（可在独立进程），不得调用EarthDelta的architecture/bridge；加载同一内容哈希的权重。若官方依赖不可运行，整网parity=BLOCKED，不能降级成同实现自比较。
- 分离官方F0、本地F0、安装非零专家但系数全零的F0三路；fp32关键归一化状态误差起始门槛atol=rtol=1e-5，另报绝对/相对max与逐lead误差。容差变更必须有重复性/精度证据，不按结果随意放宽。
- 明确diff_mean_policy，严格按pinned官方推理路径；保存模型内容SHA256、变量顺序、pressure levels、norm命名字段、网格坐标哈希。禁止placeholder标记进入PASS。
- 测试no-edit、非零edit后恢复、异常后hook移除、A→B→A不串状态；部署输入对象无future truth，并使用真正连接数据读取端的canary。
- RMSE以真实valid_time索引、先聚合SSE再sqrt；出现NaN、必需诊断异常、required-check skip都不能PASS。移除无独立来源的paper RMSE倍率阈值。S0少样本只验pipeline，不作paper replication。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_official_and_local_checkpoint_parity`
- `test_installed_nonzero_bank_zero_coeff_parity`
- `test_diff_mean_policy_matches_reference`
- `test_hook_restored_after_exception`
- `test_s0_nonfinite_or_skipped_required_check_not_pass`
- `test_s0_target_time_and_rmse_reducer`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python plans/codex_audit_20260920/validation/repo_inventory.py --repo . --output artifacts/p0/P0-01/$RUN_ID/inventory.json
python -m pytest -q tests -m "not slow"
python scripts/s0_gate.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --out-dir artifacts/p0/P0-01/$RUN_ID/s0
```

#### Expected artifact
共同目录 `artifacts/p0/P0-01/$RUN_ID/`。

- `inventory.json`
- `environment.json`
- `checkpoint_identity.json`
- `data_identity.json`
- `pytest.log`
- `s0/report.json`
- `parity_by_lead.csv`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 独立官方整网+相同权重+真实网格输入三路parity通过；所有required checks=PASS；所有误差有限
- 192/3只是此前作者报告；本轮现场的实际pytest计数/skip原因写入日志
- 无future读取，无权重污染；资产身份完整；不存在阻断性环境缺失

#### Failure criteria
- 官方reference未运行/只有同bridge对照
- 缺checkpoint/数据/GPU资源/官方依赖时为BLOCKED，不是科学FAIL
- 非有限预测、norm差异、身份冲突、状态污染均STOP修复

#### Decision after completion
仅全部required checks通过后解锁P0-02；BLOCKED保留已完成代码和日志，停止扩大任务范围。

#### Commit suggestion
`fix(p0): establish independent checkpoint parity and evidence gate`

---


### TASK P0-02 — 统一度量、动作约束和因果数据合同

**Phase / prerequisites:** P0 / P0-01

#### Scientific purpose
消除A05–A09，并为强直接router baseline提供可微执行；避免用不一致metric获得虚假增益。

#### Files to inspect
- `earthdelta/paired.py`
- `earthdelta/geometry.py`
- `earthdelta/heads.py`
- `earthdelta/selection.py`
- `earthdelta/contracts.py`
- `earthdelta/memory.py`
- `earthdelta/data/make_splits.py`
- `earthdelta/bridge/stormer_bridge.py`

#### Files to modify
- `earthdelta/paired.py`
- `earthdelta/geometry.py`
- `earthdelta/heads.py`
- `earthdelta/selection.py`
- `earthdelta/contracts.py`
- `earthdelta/memory.py`
- `earthdelta/data/make_splits.py`
- `earthdelta/bridge/stormer_bridge.py`

#### Files to create
- `earthdelta/metrics.py`
- `earthdelta/data/episode_contract.py`
- `scripts/p0_contract_gate.py`
- `tests/test_metric_contract.py`
- `tests/test_audit_regressions.py`
- `tests/test_serving_isolation.py`

#### Implementation requirements
- MetricSpec为不可变结构，包含variable names/scales、lead/area weights、mask规则、reducer、projection identity；encode_residual不再次减气候均值。平方utility的所有路径使用同一对象或明确whitened约定。
- finite候选校验box、support、dtype/finite、候选上限、ID唯一与预算；拒绝非法而不是悄悄clamp；统一cost_penalty和ridge含义；区分support cap与实测耗时预算。
- ewma_error_feature_batched只对专门NoEligibleRecords回退零；版本、重复ID、长度错误继续raise；P0主评测memory disabled，EWMA baseline使用相同合法支持。
- build_manifest全部UTC aware；检验每个样本完整支持时间区间与数据存在性；支持memory_warmup和maxlead；availability声明为真实时间或明确archive assumption，不把6h当ERA5发布事实；parquet保留metadata sidecar。
- 新增controlled_rollout_train(x, coefficients[B,K]或显式step轴, hold_steps, ...)保留autograd；serving EditPlan仍不可变。不得将requires_grad Tensor转换为tuple、detach或torch.tensor。
- controlled_rollout增加return_trajectory/collect_leads而保留旧final-only调用；hold结束从编辑状态继续Fs；版本校验接到入口；强制interval与plan一致。
- ProgramSpec暂不接主线，明确UNINTEGRATED；不引入step×layer×region新动作空间。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_gain_identity_same_metric_all_paths`
- `test_scale_and_projection_hash_mismatch`
- `test_finite_box_support_penalty_limits`
- `test_batched_memory_invalid_records_raise`
- `test_timezone_independent_manifest`
- `test_parquet_provenance_roundtrip`
- `test_coefficient_grad_through_frozen_backbone`
- `test_returned_trajectory_equals_final_legacy`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python -m pytest -q tests/test_metric_contract.py tests/test_audit_regressions.py tests/test_serving_isolation.py
python scripts/p0_contract_gate.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --out-dir artifacts/p0/P0-02/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p0/P0-02/$RUN_ID/`。

- `metric_spec.json`
- `contract_tests.json`
- `time_manifest.json`
- `cache_rejection_report.json`
- `gradient_report.json`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 平方恒等式在float64 toy的绝对/相对误差≤1e-10，fp32实际投影≤1e-5或预注册误差界
- 非法约束与来源冲突测试100%拒绝；同输入不受未来canary和TZ影响
- router系数存在非零有限梯度；主干参数梯度均None/零且哈希不变

#### Failure criteria
- 几何路径与直接配对loss不一致
- 任何版本错误被吞掉或future读取改变输出
- 可微baseline无法训练或dense/sparse结果不等价

#### Decision after completion
工程合同全部PASS才允许P0-03；这里只能修实现，不能调整科学hypothesis来绕过错误。

#### Commit suggestion
`fix(contracts): unify utility weighting causal manifests and edit feasibility`

---


### TASK P0-03 — 非退化参考/编辑库与研究门槛预注册

**Phase / prerequisites:** P0 / P0-02

#### Scientific purpose
先保证评测对象是一组经过训练、合理调参的候选，避免零初始化/欠训练造成假性kill。用独立开发数据确定效应与成本门槛。

#### Files to inspect
- `earthdelta/lowrank.py`
- `earthdelta/bridge/stormer_bridge.py`
- `earthdelta/data/pull_wb2.py`
- `earthdelta/data/make_splits.py`
- `plans/plans_v1_0919/v6_draft/research_spec_v6.yaml`

#### Files to modify
- `earthdelta/lowrank.py`

#### Files to create
- `scripts/train_static_reference.py`
- `scripts/train_edit_dictionary.py`
- `scripts/preregister_p0.py`
- `earthdelta/data/forecast_dataset.py`
- `tests/test_dictionary_and_training.py`

#### Implementation requirements
- 先现场核实2015–18训练数据与2019验证数据，不把README的2020数据当训练集；不存在则BLOCKED acquisition，不默默重划2020 train/test。下载复用pull_wb2但按现场RAM使用安全顺序模式。
- Fs采用当前v6的attn.proj blocks18–23 rank16、多步4步loss；保存可独立加载的静态adapter与内容hash。原F0仍作为比较。
- 编辑库以当前ExpertLoRA接口训练K=8非零方向（资源不足可预注册较小试验，但失败仅否定该有限库）；train-only流型/误差族构造，same-rank方向对照，报告每个专家留出表现/范数/成本/训练曲线。
- 初始有限集合：no-edit、K单专家、4个在开发集预先确定的不同pair；rho=0.25只作起点，若变更在测试前锁定；全部作用前4步。不要在测试label上挑pair或调rho。
- 训练和验证阶段检查欠拟合：相同预算全局LoRA、训练loss下降、非零response、不同seed稳定性；上界无收益时先排除损坏/未训库。
- preregister_p0从独立development blocks读取重复性噪声、paired gain方差、有效块数、实测成本，产生具体numeric delta_headroom/delta_dynamic/equivalence_margin/long_harm_margin和sample budget；使用STOP_CONDITIONS规则。
- 如果没有业务最低收益依据，明确research-feasibility gate而非operational viability；所有阈值冻结到preregistered.json及SHA，P0 oracle gate拒绝空阈值。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_static_zeroedit_reference_identity`
- `test_expert_bank_nonzero_response`
- `test_dictionary_uses_train_only_clusters`
- `test_training_assets_exclude_test_year`
- `test_preregistration_requires_finite_thresholds`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/train_static_reference.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --out-dir artifacts/p0/P0-03/$RUN_ID/static
python scripts/train_edit_dictionary.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --static-dir artifacts/p0/P0-03/$RUN_ID/static --out-dir artifacts/p0/P0-03/$RUN_ID/dictionary
python scripts/preregister_p0.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --development-dir artifacts/p0/P0-03/$RUN_ID --out artifacts/p0/P0-03/$RUN_ID/preregistered.json
```

#### Expected artifact
共同目录 `artifacts/p0/P0-03/$RUN_ID/`。

- `static/adapter.pt`
- `dictionary/bank.pt`
- `dictionary/candidates.json`
- `training_curves.csv`
- `expert_dev_metrics.csv`
- `cost_table.json`
- `preregistered.json`
- `preregistered.sha256`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- Fs和bank真实训练并通过identity/nonzero/heldout完整性测试
- 测试标签未用于字典、阈值、聚类、epoch/rho或primary metric选择
- numeric预注册文件有效；未来任务能复用固定候选与cost表

#### Failure criteria
- 没有训练年份数据、GPU或可用static权重：BLOCKED
- 零B、所有候选实际相同、专家从未收敛：工程/训练失败，不能宣布scientific kill
- 无方差成本证据却填2%/3%门槛：拒绝注册

#### Decision after completion
通过后解锁P0-04；允许的额外库修订次数预设为1，并使用新protocol和新留出集，不无期限刷字典。

#### Commit suggestion
`feat(p0): establish trained dictionary and preregister survival criteria`

---


### TASK P0-04 — 真实有限候选 oracle 与动态空间审判

**Phase / prerequisites:** P0 / P0-03

#### Scientific purpose
最快确认是否有必要做planner：不是仅超过F0，而是超过Fs和验证集选定的最佳固定编辑。

#### Files to inspect
- `earthdelta/probe.py`
- `earthdelta/paired.py`
- `earthdelta/teacher.py`
- `earthdelta/bridge/stormer_bridge.py`

#### Files to modify
- `earthdelta/probe.py`

#### Files to create
- `scripts/eval_oracle_ceiling.py`
- `earthdelta/evaluation/paired_statistics.py`
- `tests/test_oracle_ceiling.py`

#### Implementation requirements
- 对锁定候选集每个可行候选完整非线性积分到6/24/72/120h；same origin、same initial history、same memory snapshot、same trained library、same cost contract。每个candidate失败计入，不删。
- 调用cached_responses获取FINITE_EXACT；P0 oracle不得用Ra、teacher top3或未执行候选替代。候选有限时可枚举，对当前库构成hindsight upper envelope；不叫全参数理论天花板。
- 比较F0、Fs、seeded random、best-fixed chosen on validation、train-defined regime-fixed、hindsight per-origin best；两种oracle（最大forecast gain与cost-penalized utility）分开。
- 主对比为oracle−best_fixed、以及oracle−Fs，在预注册72h/4变量norm下计算；同时输出absolute RMSE与其他lead/variable guardrails。
- 按天气过程/时间块paired bootstrap，不把像素或重叠6h起点当独立样本。读取preregistered.json并核对hash；没有numeric margin不能PASS。
- 小子集保留epsilon与mixed-linearity诊断，但连续线失败不影响有限nonlinear事实；缓存固定响应与full-field gain便于后续复用。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_finite_oracle_contains_reference`
- `test_oracle_loss_not_greater_than_best_fixed`
- `test_static_selected_on_validation_only`
- `test_candidate_failures_counted`
- `test_fullfield_gain_summary_disagreement_reported`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/eval_oracle_ceiling.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --preregister artifacts/p0/P0-03/LOCKED_RUN/preregistered.json --out-dir artifacts/p0/P0-04/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p0/P0-04/$RUN_ID/`。

- `candidate_metrics.csv`
- `per_origin_gain.parquet`
- `responses/`
- `oracle_vs_static.json`
- `bootstrap_intervals.json`
- `linearity_diagnostic.json`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- oracle−Fs下置信界>delta_headroom且oracle−best_fixed下置信界>delta_dynamic
- 相关长时效上伤害不超过预注册上限；结论不依赖删除失败起点
- 所有实测候选与部署信息/成本合同一致

#### Failure criteria
- 上置信界≤门槛：STOP当前候选库或dynamic-planner主张
- 区间跨门槛：INCONCLUSIVE，执行预先批准的下一批，不能加模块或改指标
- 候选执行失败/metric错误：工程STOP，先修复再重跑所有方法

#### Decision after completion
PASS才解锁P0-05；oracle有收益但动态空间很小则PIVOT static edit；允许一次预注册字典修订，不自动扩展JEPA。

#### Commit suggestion
`feat(p0): measure exact intervention ceiling against best fixed edit`

---


### TASK P0-05 — 2×2可预测性分解与直接收益挑战

**Phase / prerequisites:** P0 / P0-04

#### Scientific purpose
定位e0、du或选择器谁是真瓶颈；检验分解而非简单direct gain的价值。

#### Files to inspect
- `earthdelta/heads.py`
- `earthdelta/geometry.py`
- `earthdelta/selection.py`
- `earthdelta/paired.py`

#### Files to modify
- `earthdelta/heads.py`

#### Files to create
- `scripts/p0_predictability.py`
- `earthdelta/baselines/direct_gain.py`
- `earthdelta/baselines/simple_error.py`
- `tests/test_prediction_information_sets.py`

#### Implementation requirements
- 只使用train/development中对齐缓存训练轻量头；test/确认集不参与训练。可在training block内部交叉拟合并保留guard；不要把oracle gate确认集当优化训练集。
- 复用ReferenceErrorHead/EditResponseHead/InteractionUtilityHead，JEPA=False，memory disabled或相同EWMA；同一features/candidate/label预算比较direct scalar gain、b/H、paired e0/du、zero/mean du、climatology/EWMA e0。
- 完成 exact e0+exact du、exact e0+pred du、pred e0+exact du、pred e0+pred du；前3项显式ORACLE_DIAGNOSTIC，不计serving排行榜。
- 使用相同MetricSpec，报告raw_geometry与calibrated；不能只让paired头用额外收益监督而不给direct_gain相同训练预算。
- e0全场R²差不自动kill，增加候选响应span上的projection/b预测；du报告非零样本与小范数样本分开，零响应基线不能靠相对范数放大。
- 评价真正选中的forecast gain和regret而不只头MSE；oracle substitution帮助定位哪个预测任务值得改善。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_oracle_arrays_never_enter_serving_context`
- `test_prediction_candidate_permutation`
- `test_noedit_score_structural_zero`
- `test_zero_response_metrics_finite`
- `test_four_way_ablation_has_identical_candidate_set`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/p0_predictability.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --preregister artifacts/p0/P0-03/LOCKED_RUN/preregistered.json --cache artifacts/p0/P0-04/LOCKED_RUN --out-dir artifacts/p0/P0-05/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p0/P0-05/$RUN_ID/`。

- `ablation_2x2.csv`
- `response_metrics.csv`
- `gain_predictions.parquet`
- `selection_regret.json`
- `direct_gain_comparison.json`
- `heads/`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 合法预测选择相对best-fixed的下置信界>预注册可学习增益门槛
- paired与direct-gain差异/等效区间报告完整；至少能识别哪一路具有潜在增量
- 未出现teacher标签进入forward、test用于调参或候选集合不一致

#### Failure criteria
- oracle e0仍无法挽救pred du：先定位响应/线性化/表示问题
- oracle du仍无法挽救pred e0或decision projection：e0是主要障碍，不盲目扩rank
- direct-gain在等效区间内且更便宜：PIVOT simple controller，缩减factorization贡献

#### Decision after completion
只有存在真实可学习动态增益才进入P0-06；若paired未赢，允许P1仅围绕预注册label-efficiency/trajectory目标检验，不预先宣布分解胜出。

#### Commit suggestion
`feat(p0): add oracle substitution and direct gain falsification`

---


### TASK P0-06 — 参数执行与递归输出订正的生存对照

**Phase / prerequisites:** P0 / P0-05

#### Scientific purpose
证明有限资源下内部编辑确有用途，或及时停止不必要的parameter-edit主张。

#### Files to inspect
- `earthdelta/bridge/stormer_bridge.py`
- `earthdelta/heads.py`
- `earthdelta/lowrank.py`

#### Files to modify
- `earthdelta/bridge/stormer_bridge.py`

#### Files to create
- `earthdelta/baselines/recurrent_output.py`
- `scripts/p0_output_challenge.py`
- `scripts/p0_final_decision.py`
- `tests/test_output_correction_rollout.py`

#### Implementation requirements
- 实现多变量recurrent output corrector C_phi：x_next=Fs(x)+C_phi(history,Fs(x),context)，纠正后的状态进入下一步；同样4步训练、同历史、同变量、同留出集、相近参数/调参/实测成本。
- 加入Fs+e0_hat直接订正、Fs+du_hat候选响应回放与最终时效后处理；如果只能解码summary，需训练同监督full-field decoder并计成本，不把summary-only弱对照当完整替代。
- 参数编辑持续24h vs输出context持续24h与每步更新分别注明；输出方法也可跨变量、跨lead、固定code复用。不能人为只允许它修一步。
- 最小长rollout6/24/72/120h，240h数据不足标BLOCKED；对超过计划结束仍保留的下游效果独立分析。
- 报告Pareto：forecast loss、harm、latency、训练/探测成本；用paired等效/非劣检验而非只看p>0.05；汇总所有P0门状态，输出明确CONTINUE/STOP/PIVOT/INCONCLUSIVE。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_corrected_state_enters_next_step`
- `test_multivariate_corrector_not_terminal_only`
- `test_synthetic_exact_corrector_reproduces_parameter_edit`
- `test_response_replay_and_execution_use_same_reference`
- `test_long_rollout_does_not_rejoin_unedited_cache`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/p0_output_challenge.py --config plans/codex_audit_20260920/configs/p0_protocol.template.json --preregister artifacts/p0/P0-03/LOCKED_RUN/preregistered.json --out-dir artifacts/p0/P0-06/$RUN_ID
python scripts/p0_final_decision.py --artifacts-root artifacts/p0 --out artifacts/p0/P0-06/$RUN_ID/decision.json
```

#### Expected artifact
共同目录 `artifacts/p0/P0-06/$RUN_ID/`。

- `baseline_fit_log.csv`
- `forecast_by_lead.csv`
- `cost_pareto.csv`
- `harmful_edit_rates.json`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 参数编辑有至少一项预注册优势且其他关键维度非劣，或明确保留的标签效率/轨迹一致性待P1验证
- 所有P0证据齐全且无方法学阻断；没有用弱输出baseline制造优势

#### Failure criteria
- 递归输出订正在关键预报/长期伤害/成本上支配编辑：STOP parameter necessity主张
- 只有短期收益而长期退化超过margin：缩作用窗/收窄lead，不继续高阶模块
- 证据不足：INCONCLUSIVE，不以“无显著差异”当等效

#### Decision after completion
P0完整CONTINUE后才解锁P1；若PIVOT，必须更新FINAL_RESEARCH_DECISION后由用户确认新研究方向，不静默另做项目。

#### Commit suggestion
`feat(p0): challenge parameter editing with recurrent output correction`

---


### TASK P1-01 — 版本化真实轨迹响应训练集

**Phase / prerequisites:** P1 / P0-06

#### Scientific purpose
把P0缓存扩展成可审计、可复用的标签分离数据集，保持现有数学模块。

#### Files to inspect
- `earthdelta/probe.py`
- `earthdelta/data/pull_wb2.py`
- `earthdelta/data/make_splits.py`

#### Files to modify
- `earthdelta/probe.py`
- `earthdelta/data/make_splits.py`

#### Files to create
- `earthdelta/data/response_dataset.py`
- `scripts/build_response_dataset.py`
- `tests/test_response_dataset.py`

#### Implementation requirements
- 将state/history、reference trajectory、finite edit response、truth-derived reference error分区存储；serving loader只读前者合法字段；不缓存过期target latent。
- 每个样本含origin/valid/available、candidate descriptor、hold/continuation、SHA和split；du标签不需要future truth，但在测试期预先生成du仍算test-time probes，不能混进主协议。
- 新增候选/权重/规范需新cache；正负零gain都保留；统一失败处理；数据压缩不得改变Q中有用的相位与幅值。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_response_cache_rejects_stale_dictionary`
- `test_truth_partition_unreadable_by_serving`
- `test_multilead_axis_and_units`
- `test_cache_preserves_negative_gain`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/build_response_dataset.py --config plans/codex_audit_20260920/configs/p1_protocol.template.json --out-dir artifacts/p1/P1-01/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p1/P1-01/$RUN_ID/`。

- `dataset_manifest.json`
- `reference/`
- `responses/`
- `offline_targets/`
- `split_hashes.json`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 所有训练样本完整合法；多lead identity与fullfield check通过
- 同一cache可被paired和direct baseline使用，额外数据/label成本分别记录

#### Failure criteria
- 版本失配、未来真值混入features、改权重后沿用旧response

#### Decision after completion
PASS后进入P1-02；失败重建受影响cache，不只删除坏样本。

#### Commit suggestion
`feat(data): add versioned finite trajectory response dataset`

---


### TASK P1-02 — 响应路线、直接路线和决策投影对照

**Phase / prerequisites:** P1 / P1-01

#### Scientific purpose
检验方法学收益而非模块存在；复用已有多lead和PSD头。

#### Files to inspect
- `earthdelta/heads.py`
- `earthdelta/paired.py`
- `earthdelta/geometry.py`

#### Files to modify
- `earthdelta/heads.py`

#### Files to create
- `scripts/train_controllers.py`
- `earthdelta/training/controller_training.py`
- `tests/test_controller_training.py`

#### Implementation requirements
- 同时训练paired e0/du、direct gain、history→coefficients+multistep loss、b/H、restricted b；必须相同上下文与预算，并给direct baseline同等paired标签访问。
- 损失先用physical response regression和gain ranking/regret目标；JEPA关闭。pair标量calibration可选并单列结果。
- 上下文用输入历史统计或首次可编辑block之前的共享prefix；若用18–23参考特征计入实际额外参考/重算成本，不声称免费。
- 纯e0/du并不天然预测期望gain：验证偏差与不确定性，必要时校准；共享已有heads接口不重写全套模型。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_controller_context_information_equality`
- `test_baseline_router_receives_gradient`
- `test_calibration_off_matches_metric_identity`
- `test_model_config_has_no_deferred_modules`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/train_controllers.py --config plans/codex_audit_20260920/configs/p1_protocol.template.json --dataset artifacts/p1/P1-01/LOCKED_RUN --out-dir artifacts/p1/P1-02/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p1/P1-02/$RUN_ID/`。

- `controllers/`
- `training_budget.csv`
- `head_metrics.csv`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 训练/验证完整且best epoch由validation选；无test tuning；强baseline达到可复现收敛
- paired优势或失败均保留，score误差与实际regret关联报告

#### Failure criteria
- 只有latent/response MSE改善而选择不改善
- baseline少训练/少信息；head数据泄漏

#### Decision after completion
PASS是流程验收不是预设方法胜出；没有任何可守优势时更新为PIVOT，不自动解锁P2。

#### Commit suggestion
`feat(train): compare response and direct decision models fairly`

---


### TASK P1-03 — 单次选定轨迹执行与统一评测

**Phase / prerequisites:** P1 / P1-02

#### Scientific purpose
端到端验证legal-serving决策、forecast收益和总成本。

#### Files to inspect
- `earthdelta/selection.py`
- `earthdelta/bridge/stormer_bridge.py`
- `earthdelta/heads.py`

#### Files to modify
- `earthdelta/selection.py`
- `earthdelta/bridge/stormer_bridge.py`

#### Files to create
- `earthdelta/controller.py`
- `earthdelta/evaluation/weatherbench_adapter.py`
- `scripts/evaluate_controllers.py`
- `tests/test_end_to_end_protocol.py`

#### Implementation requirements
- finite serving只运行轻量头和选中的实际轨迹；记录所有backbone调用次数、prefix缓存、memory warmup、planner和adapter成本。模型推理绝不调用teacher/probe/truth。
- 导出init_time/lead_time/latitude/longitude/level与单位明确的xarray，复用pinned WeatherBench-X；RMSE/ACC climatology固定训练/官方定义，聚合前不sqrt。
- 强静态、随机、regime、direct gain/router、递归输出、surrogate replay与EarthDelta全部相同起点；oracle独立表只诊断。
- 实际cost表不允许仅按rank估FLOPs宣传加速；所有结果生成config/metrics/log/summary/identity/decision。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_serving_never_invokes_probe_teacher_or_targets`
- `test_noedit_and_candidate_permutation`
- `test_wbx_local_metric_agreement`
- `test_complete_cost_ledger`
- `test_same_origins_all_baselines`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/evaluate_controllers.py --config plans/codex_audit_20260920/configs/p1_protocol.template.json --out-dir artifacts/p1/P1-03/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p1/P1-03/$RUN_ID/`。

- `predictions/`
- `tables/main.csv`
- `tables/cost.csv`
- `tables/oracle_only.csv`
- `figures/`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- P0关键结论在新独立确认集复现；关键统计与cost均完整
- 存在至少一项预注册科学优势，不靠缺失baseline或图像美化

#### Failure criteria
- 重复P0检查失败；不能重现动态增益；输出baseline支配；长lead违规

#### Decision after completion
核心结果通过才考虑P2；论文可先停在有限候选trajectory response，不需要强上连续world model。

#### Commit suggestion
`feat(eval): enforce serving isolation and matched trajectory evaluation`

---


### TASK P2-01 — 轨迹目标重用与标签效率：首选增强

**Phase / prerequisites:** P2 / P1-03

#### Scientific purpose
证明向量轨迹响应比单个scalar gain更可复用，这是仅新增一个科学想法时的选择。

#### Files to inspect
- `earthdelta/heads.py`
- `earthdelta/evaluation/paired_statistics.py`
- `earthdelta/data/response_dataset.py`

#### Files to modify
- `earthdelta/heads.py`

#### Files to create
- `scripts/eval_trajectory_transfer.py`
- `tests/test_transfer_protocol.py`

#### Implementation requirements
- 在训练覆盖的lead上改变预注册Q/任务权重与成本约束，重用预测响应重算utility；对照得到Q、lead、budget descriptor的direct-gain模型，不能按构造宣布其做不到。
- 区分三种任务：支持内目标重加权、真正held-out lead外推、new expert few-shot响应校准；只有第一类可直接宣称重用，后二者额外数据/训练必须单列。
- label scarcity仅减少e0/gain的truth labels，du使用的历史origin仍在train；same scalar baseline可使用相同无标签response监督。
- 最大240h时效用于确认，不靠6h胜利外推；report regression error、decision regret、harm与总成本。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_metric_descriptor_baseline_has_equal_information`
- `test_new_expert_calibration_cost_not_zero_shot`
- `test_heldout_horizon_never_trained`
- `test_truth_label_fraction_accounting`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/eval_trajectory_transfer.py --config plans/codex_audit_20260920/configs/p2_protocol.template.json --out-dir artifacts/p2/P2-01/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p2/P2-01/$RUN_ID/`。

- `transfer_protocol.json`
- `label_efficiency.csv`
- `metric_reweighting.csv`
- `heldout_horizon.csv`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 相对可条件化direct baseline在至少一个锁定场景超过预注册margin
- 额外监督/校准全部计入，不把few-shot叫zero-shot

#### Failure criteria
- 直接gain同等好且更省；收益仅来自额外数据；长期伤害显著

#### Decision after completion
不成立则删除transfer贡献，不扩架构；成立可作为核心论文第二项证据。

#### Commit suggestion
`feat(p2): evaluate reusable trajectory objectives and label efficiency`

---


### TASK P2-02 — 信赖域内的多编辑组合：可选第二增强

**Phase / prerequisites:** P2 / P1-03

#### Scientific purpose
只有有限响应成立且组合实际有用时，检验学习局部J及off-diagonal H。

#### Files to inspect
- `earthdelta/probe.py`
- `earthdelta/geometry.py`
- `earthdelta/teacher.py`
- `earthdelta/selection.py`
- `earthdelta/heads.py`

#### Files to modify
- `earthdelta/probe.py`
- `earthdelta/selection.py`
- `earthdelta/heads.py`

#### Files to create
- `scripts/eval_local_composition.py`
- `tests/test_local_composition.py`

#### Implementation requirements
- 中心差分epsilon sweep、不同dtype repeatability、混合方向/不同幅值holdout，按state/lead报告local remainder。JVP只有算子兼容时实现，否则保留finite difference。
- 完整H与diagH同基比较；真实pair response独立执行，分开报告Gram overlap与nonlinear remainder。continuous solver只在校准信赖域内，超域回finite或no-edit。
- 以同lead、同参数范数/支持/cost约束比较predict_J、predict_bH、direct coefficient、direct candidate；非线性复验只离线，serving不能据future真值再筛。
- 禁止把teacher top3称为oracle；不假定zeroB下J有意义；所有basis规范/标度固定。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `test_centered_jacobian_epsilon_convergence`
- `test_mixed_response_remainder`
- `test_offdiag_and_nonlinear_interaction_are_separate`
- `test_trust_region_rejects_unsupported_action`
- `test_continuous_solver_constraints`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
python scripts/eval_local_composition.py --config plans/codex_audit_20260920/configs/p2_protocol.template.json --out-dir artifacts/p2/P2-02/$RUN_ID
```

#### Expected artifact
共同目录 `artifacts/p2/P2-02/$RUN_ID/`。

- `epsilon_sweep.csv`
- `linearity_by_lead.csv`
- `interaction_vs_remainder.csv`
- `full_vs_diag_H.csv`
- `config.json`
- `metrics.json`
- `summary.md`
- `stdout.log`
- `decision.json`

#### Success criteria
- 混合方向真实误差在预注册信赖域内可接受，且fullH组合带来真实选择优势
- 实际全场增益与summary选择一致性已报告

#### Failure criteria
- 线性化不成立或fullH≈diagH；QP推荐由非线性误差主导

#### Decision after completion
FAIL仅停止continuous/Jacobian增强，保留成功finite主线；P2最多以上两条，不再堆JEPA/memory。

#### Commit suggestion
`feat(p2): validate trust-region composition against nonlinear replay`

---


### TASK P3-01 — 仅记录的后续模块与外部验证

**Phase / prerequisites:** P3 / P1-03

#### Scientific purpose
防止当前阶段scope creep；不是自动授权的执行任务。

#### Files to inspect
- `plans/plans_v1_0919/v6_draft/research_spec_v6.yaml`

#### Files to modify
无

#### Files to create
- `plans/future_work_evidence_gates.md`

#### Implementation requirements
- 只维护backlog：JEPA在普通response预测是确认瓶颈时；memory在误差有可重复历史结构时；动态rank在实测budget曲线支持时；谱loss在固定linear summary无法支持目标时。
- 第二backbone、概率集合、数据同化、物理Jacobian只在独立范围和资源授权后启动；不修改本包的自动解锁规则。

#### Must NOT change
- 不改冻结主干/起报信息边界；离线oracle与serving路径分开
- 不以合成或跳过测试冒充真实天气验收；不覆盖历史结果
- 不更换评价集合、变量、时效、候选或阈值以提高测试结果；任何变更新建protocol版本

#### Tests to add
- `手工审查backlog每项都有瓶颈证据与最小对照，不运行大实验`

#### Command
以下新脚本先实现再运行；P3不是执行命令。

```bash
NO_EXECUTION: maintain backlog only; explicit future authorization required
```

#### Expected artifact
共同目录 `artifacts/p3/P3-01/$RUN_ID/`。

- `future_work_evidence_gates.md`

#### Success criteria
- 仅文档，没有安装/训练新组件

#### Failure criteria
- P0/P1未过就运行P3；无授权大规模下载/训练

#### Decision after completion
DEFER；不自动执行。

#### Commit suggestion
`docs: record evidence-gated future work`

---



## 7. P0 — Project Survival Tests

只有P0-01/02工程PASS后才讨论idea。P0-03保证库不是零初始化。P0-04测finite真oracle而非局部teacher。P0-05识别可学习瓶颈和direct-gain价值。P0-06直接挑战参数必要性。失败按以下STOP算法处理，不继续花哨模块。

## 8. P1 — Core Paper Implementation

使用已有多lead heads接真实轨迹dataset和training/evaluation。主线仍finite，按同数据同输入训练所有强baseline。P1输出可复核paper表，不自动声称方法赢。

## 9. P2 — Novelty Enhancement

最多两条：轨迹目标重用/标签效率，以及校准信赖域内多编辑组合。后一条失败不伤害finite结论。不要增加第三条JEPA/memory重新堆叠。

## 10. P3 — Optional / Future Work

仅backlog；需要确认当前瓶颈、明确对照及新的资源授权。不会因P1通过就自动执行。

## 11. Baseline Implementation Plan


# Baseline implementation and fairness

|ID|方法|当前可复用|训练/输入|来源/封装|输出|公平合同|
|---|---|---|---|---|---|---|
|B0|Frozen F0|官方Stormer pinned权重|无训练；明确69通道/真实坐标/归一化|官方forward、推理增量和WB-X|原始物理预报轨迹|与Fs分开，不将zero-edit基准混淆|
|B1|Static Fs / higher-capacity static LoRA|现有ExpertLoRA K=1或标准PEFT|与动态库同数据；多步训练；额外高容量静态模型匹配总可训练参数|earthdelta/lowrank.py；标准LoRA需另pin|全部规定lead轨迹|验证集挑epoch，禁止测试选reference|
|B2|Random / best-fixed / regime-fixed|同一候选库|随机seed固定；best-fixed只在validation选；regime由train规则|现有select_plan+新增baseline配置|选定候选及轨迹|no-edit也在同一可行集；同cost/hold|
|B3|History→coefficients direct router|现有BoundedProgramHead +新增可微rollout|端到端同样多步loss；完整上下文与预算descriptor|复用heads.py；CLAW/CoDA机制参考|可行coefficients和轨迹|不是把不可微tuple API接过去再宣布效果差|
|B4|Direct scalar gain|新增direct_gain.py，小MLP/GRU|与paired路线相同context、edit、lead、Q/budget输入与训练label；可用同response辅助监督|纯PyTorch；VI-MoLE-inspired value baseline标明非官方复现|[B,K,H] gain或预注册aggregate|调参次数与额外数据相同；改变metric给相同descriptor|
|B5|Paired e0/du & restricted projection|现有ReferenceErrorHead/EditResponseHead/InteractionUtilityHead|平方metric统一；raw vs calibrated；e0+true du等仅diagnostic|当前本项目代码|响应场/摘要、b/H与选择|投影gain不冒充全fieldgain|
|B6|Recursive multivariate output correction|新增recurrent_output.py|输入和变量与编辑相同；校正反馈下一step；相同4步训练及后续长rollout|Solver-in-the-Loop作为机制来源；不需搬其全部PDE框架|Fs(x)+C_phi的完整轨迹|可使用context/code固定多步；匹配参数、时间、历史|
|B7|Fs+predicted e0 / Fs+predicted du|复用相同预测头+公平fullfielddecoder|需要完整场时decoder同等训练并计成本；不是只回放低维摘要|当前heads.py+新增输出bridge|直接订正轨迹或单lead输出分别报告|检验为何还实际执行edit；信息/成本相同|
|B8|Full/diag H, past context fit|现有geometry/teacher/selection|past-fit只用已揭示targets；diag/full共用R/训练信息|SciPy已有依赖；CoDA/Green方法参考|coefficients、预测/实际gain|未来核验优化只离线oracle；支持/rho/cost一致|
|O0|Finite oracle / e0 oracle / du oracle|现有cached_responses+完整实际枚举|明确标签/真实响应知情，绝不进入serving主排名|probe.py / paired.py|hindsight best及2×2诊断|有限库天花板；候选失败不剔除；不以top3充全oracle|
|B9|WeatherPEFT / Aurora-specific adapters|仅后续可比任务|需要相同任务/信息/数据并独立许可核验|WeatherPEFT暂无已核许可；Aurora非第一阶段backbone|按适配任务定义|不能把下尺度任务成绩直接挪到Stormer全球预测比较|

## 实施合同

最少包括B0–B8/O0，B9仅在任务与许可匹配后做。P0用小而合理训练的版本，P1扩展同样协议，不改变比较定义。共同report字段：history span、observations available、extra offline labels、trainable params、trained dictionary cost、candidate evaluation calls、measured inference/warmup latency、seeds/optimization budget、actual forecast failure count。

output端不能只用t2m单变量对比多变量编辑；不能只训练一步对比多步loss。参数编辑不能读取reference晚层features而不让对照使用/不计这次前向。direct gain也可输入新metric/budget/lead，因此“它无法迁移”不能当预设。

论文/代码/license分别核查。下面外部源码不在本包中分发，所有缺许可项目的复制操作BLOCKED。依赖优先复用本项目已实现基础层，降低迁移成本。



## 12. Evaluation Contract

Forecast：固定真实物理单位RMSE、固定climatology的ACC、每个变量每个lead及预注册aggregate。primary72h，secondary6/24/120，240h确认；平方gain不是RMSE差，分开命名。

Intervention：actual gain、exact finite oracle gain、best-fixed gap、selection regret、top-k best-edit recall、ranking correlation、negative-gain rate、candidate failures。exact e/du消融和oracle选择单列，不进入部署方法榜。

Response：非零response cosine、R²、absolute与relative norm error；零/近零响应独立分桶，避免除零和随机意义的cosine。

Efficiency：主干/适配/控制器可训练总参数；实测固定设备batch和精度的p50/p95 latency、warmup、峰值显存；显式记录所有reference/selected/probe调用；预算包括feature encoder、memory、planner和执行，不只rank计数。

Rollout：corrected state进入下一步、hold后从该状态继续。相同context、变量、lead与失败策略下比较recurrent output、Fs+e0_hat和Fs+du_hat。不能用输出只能改单步的错误论据。

统计：paired时间块/天气过程为单位，预先定块长/查看次数/primary contrast；bootstrap对相同起点联合重采样，ratio指标重算分母；依赖单位不得是像素数。guardrail采用同时区间/预注册多重校正。

## 13. Artifact Contract


# Artifact contract

所有实际实验写入 `artifacts/{p0,p1,p2}/{TASK_ID}/{UTC_RUN_ID}/`；目录已存在就退出或生成新run id，不覆盖。

每次至少保存：

    config.json
    metrics.json
    summary.md
    stdout.log
    decision.json
    identity.json

需要预测时：`predictions/`；图：`figures/`；需要追踪每个起点：`per_origin_metrics.parquet`。原始权重/大数组不默认提交git；目录可提供校验清单与本地可解析路径。

identity.json包括执行commit、审查baseline commit、dirty diff hash、data manifest/normalization/grid/projection/metric/candidate/continuation SHA256、environment lock、seed、设备/精度/注意力backend。checkpoint内容hash不得以“Stormer_ps4”等架构名替代。

metrics.json使用命名字段和单位，至少：forecast_RMSE_by_variable_lead、ACC_definition、gain_metric_id、raw_geometric_gain、calibrated_gain、actual_gain、oracle_kind、regret、negative_gain_rate、failed_forecasts、latency_scope、peak_memory、probe_training_cost。未测值用null并给reason，不用0。

decision.json至少：task_id、status、required_checks、blocking_reasons、protocol_hash、input_run_ids、contrast、estimate、confidence_interval、threshold、next_allowed_task。PASS仅在全部required checks为PASS且所需真实验证没有skip时允许。INCONCLUSIVE与BLOCKED不解锁。

null/NaN区分：未知用null+reason；数值NaN/Inf是失败事件，不能用JSON的非标准NaN编码消失。最终PNG/CSV不能取代可再计算的per-origin结果。论文表按相同有效起点表join；执行失败按预注册回退计分并计数。

推理轨迹规范：变量名、压力层、lat/lon数值、init_time、lead_time、valid_time、units、model/plan/version。不能只存一个缺坐标的npy并靠文件名猜轴。



## 14. Reproducibility Contract
# Reproducibility and integrity

1. 审查基线为main@4fe55a7af90ea92f62a3232a571af92bfbd6114d。现场HEAD不同先diff-review并记录，不能reset覆盖用户工作；修改使用新分支或用户指定工作区。
2. 每次实验锁定seed、候选顺序与稳定ID、训练/验证/确认数据、明确作用窗和续跑策略。重复性试验要保存attention backend、TF32/AMP、dtype以及确定性设置。
3. 权重、字典、数据、归一化与metric使用内容身份；摘要/PCA只用训练集拟合。缓存的有效性需要由入口检查，不只是提供一个从未调用的check_version_match函数。
4. training features/labels与serving features分离；未来真值只能在offline loss/evaluation/teacher中；不能在推理中隐式调用oracle、重播全部test候选后挑。
5. 同一个预测起点后的verified memory只读；新周期允许已到期记录的chronological协议单列；随机batch不可共享未重置的历史状态。
6. 所有方法相同完整历史、同样的teacher/response额外监督、同等调参预算、多步训练、同指标与样本。额外监督可能是方法的一部分，但必须单列成本和matched-data对照。
7. 库/epoch/rho/阈值/metric由开发集选，最终确认集不作反馈优化；计划外选择需要新协议和独立确认数据。
8. probe response epsilon、dtype和repeatability写入版本；未来时效超出训练覆盖不叫支持内迁移；新专家新校准不叫零样本。
9. 不以易复制的README summary替代logs/checksums。作者报告与本轮重跑分两栏；skip不能标PASS，资料缺失标BLOCKED。
10. 第三方许可在固定commit核查，保留notice；不复制无许可代码。不要把仓库读权限或公开下载当再分发许可，也不分发任何凭证。
11. 不引入后台持续下载/重复重试无限循环。资源上限、取消/断点逻辑明确；缺数据先可验证小批，然后申请/记录扩展，不自动拉几十年。
12. 本包的validation只证明文件/任务结构，不证明EarthDelta实现或实验正确；proposed_tests需在真实工作区由Codex执行并报告。



## 15. Literature-to-Code Mapping
# Literature-to-code and licensing

|External repo|Pinned commit|License status|Reused idea/code|EarthDelta destination|Modification/limits|
|---|---|---|---|---|---|
|tung-nd/stormer|58dfee5a6037399a40fefd492bc00421e0c885a8|本轮读取该pin LICENSE：MIT，版权Tung Nguyen|独立官方参考、标准网络/归一化|bridge/official_reference.py、s0_gate.py|保留版权；不要把本地重实现当独立official；核对权重另有来源|
|google-research/weatherbenchX|964a35e8fea2c644a3a1dd056289146cc67a4741|本轮确认完整commit；README此前读取Apache-2.0，实际vendoring前再读pin LICENSE|xarray loader/metric/aggregation|evaluation/weatherbench_adapter.py|以依赖封装为主，锁版本与坐标，native loss交叉核对|
|huggingface/peft|50a277e（作者manifest，完整pin尚未独立解析）|作者manifest Apache-2.0；使用前核实|standard LoRA baseline|baselines/standard_lora.py（仅确有需要时）|当前ExpertLoRA K=1更省事；不把AdaLoRA等同测试期动态rank|
|tum-pbs/Solver-in-the-Loop|f514fcf（作者manifest）|作者manifest MIT；复制前核实|递归纠正训练思想|baselines/recurrent_output.py|可用PyTorch独立实现最小强对照，无需迁入完整PDE环境|
|yuan-yin/CoDA|17b7352（作者manifest）|作者manifest MIT；复制前核实|context fitting / direct adaptation|baselines/past_context.py（P1可选）|观测支持窗口不得超过起点；不把future teacher叫online|
|NVIDIA/torch-harmonics|4ac8ed3（作者manifest）|license头已见，pin全文尚未独立复验|SHT诊断及球面响应工具|spectral.py（P2/P3）|先验证grid节点；不依shape套默认SHT；P0不依赖|
|DCDmllm/CoMoL|011306a（作者manifest）|manifest未发现license，UNVERIFIED|动态低秩/core-mixture近邻|仅文献/独立重实现对照|复制源码BLOCKED直到许可清楚|
|ShileiCao/WeatherPEFT|b2cdc25（作者manifest）|manifest未发现license，UNVERIFIED|任务PEFT近邻|暂缓主线|不得把公开可读等同有权复制|
|SciPy optimize|通过环境锁生成package版本与hash|随项目依赖核查，当前已使用|lsq_linear、minimize小问题求解|teacher.py、selection.py|无需引入Gurobi/可微QP框架；在有限库对照成立后才扩展|

完整外部pin缺失时，Codex需在使用前执行 `git rev-parse <recorded-prefix>^{commit}`、读取同commit的LICENSE并写入artifact。无法解析或license缺失：BLOCKED_COPY，不得取main最新代替且仍声称相同实验。

来源：`https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/reference/_manifest.json` 为作者的本地记录，不表示本轮已验证每个clone。Stormer LICENSE： https://github.com/tung-nd/stormer/blob/58dfee5a6037399a40fefd492bc00421e0c885a8/LICENSE 。本包没有拷贝外部模型权重、论文全文或原始repo。



## 16. Expected Paper Artifacts

Figure1：finite oracle−Fs和oracle−best-fixed分布/区间；Figure2：预测响应与真实响应及zero/mean基线；Figure3：e0/du四格oracle substitution；Figure4：EarthDelta/directgain/recursiveoutput/surrogate replay的skill–cost；Figure5：全lead轨迹与harm；Figure6（P2可选）：目标重用/label效率或fullH与真实非线性余项。

Table1：完整预测和共同起点；Table2：信息/数据/损失/候选公平性及消融；Table3：训练探测、控制器、执行和显存成本。图表必须可由artifact重建，不手工改数。

## 17. STOP Conditions and threshold generation


# STOP_CONDITIONS — evidence before expansion

## 0. 四种状态不能混淆

- **BLOCKED**：没有资产、GPU/内存、独立官方参考、完整开发数据或必要许可；不作科学否定，不解锁下一任务。
- **FAIL / STOP**：工程合同明确违反，或充分验证后的统计上界仍小于锁定目标；指出停止的是哪个字典、方法分支或科学主张。
- **INCONCLUSIVE**：区间仍跨过门槛/功效不足；仅按预先批准样本计划扩充，不增加模块、换数据切分或改评价目标。
- **PASS**：相关下界/非劣条件及全部合同满足，不是单个p值小，也不是“没显著变差”。

## 1. 不能现在臆造统一的2%/3%

本轮没有真实baseline variance、候选增益分布、运行成本或业务最低收益。因而本包中的配置是模板，numeric阈值由P0-03从独立development数据生成，P0-04必须拒绝阈值缺失的注册文件。这是可执行校准任务，不是让agent任意猜一个数字。

### P0-03的具体生成规则

1. 固定primary contrast与metric：72h、Z500/T850/T2m/MSLP，训练/官方尺度标准化的面积加权MSE。固定作用窗4×6h。确认集尚未打开。
2. 测量同一参考重复运行得到的gain差异，令η_num为其绝对差异的99%分位；以10×η_num作为保守的数值噪声隔离底线。10是工程安全倍数，不是科研效应定律；必须同时报告原始η_num。
3. 在development块上估计每个paired contrast的块均值标准差s_block。块长度不小于最大验证lead引起的重叠长度，并结合development自相关诊断；敏感性检查两种更长块长。
4. 由实际每起点全候选成本、允许的资源上限及未用数据覆盖得到最大有效块数 B_max，不把像素/候选数当独立样本数。资源预算必须显式，不因机器有空闲就任意扩展。
5. 计算资源可分辨效应 MDE=(z_(1−α/(2L))+z_0.8)*s_block/sqrt(B_max)，L为预先计划的查看次数（默认1，至多2次时作Bonferroni调整）。这是一项近似功效规划；用development block resampling复核近似，不能把正态近似当最终显著性检验。
6. **研究可行性筛选门槛** δ_research=max(10η_num,MDE)。分别生成delta_headroom（oracle−Fs）与delta_dynamic（oracle−best-fixed）。它衡量现有资源下值得展开的最小可分辨改进，不等于真实业务最低有价值收益。
7. 若有可引用的业务收益/成本标准，再填写δ_domain并使用max(δ_research,δ_domain)；没有时保留null并禁止写operationally useful结论。equivalence_margin和long_harm_margin也必须由同单位的数值噪声、可分辨量及清晰容忍理由冻结，不用测试结果反推。
8. 保存全部数值、输入development IDs、单位、成本、资源预算、计算命令、阈值理由及SHA。更改候选/metric/hold/阈值必须新protocol和新的确认数据；不得只复用同一确认集不断尝试。

这不是允许低功效试验宣布项目失败：如果上界仍大且区间宽，只能INCONCLUSIVE。若合理字典尚未收敛，也不能进入scientific STOP。

## 2. 决策规则

对于“增益必须超过δ”的量Δ，计算预注册paired block置信区间[L,U]：

    L > δ  → PASS
    U <= δ → 当前假设/字典 FAIL（按下表STOP/PIVOT）
    其他   → INCONCLUSIVE

对非劣指标（如长时效loss增加），使用预注册伤害margin：上置信界低于margin才通过；下界高于margin为伤害；跨越则不确定。多个变量/lead的guardrail使用同时区间或预注册Holm处理，不能测试后只展示最好的一个。

若采用两次查看，只能使用锁定的样本数与α分配；不按结果随时加一点数据直到显著。

## 3. STOP条款

|ID|触发条件|动作|禁止的绕过|
|---|---|---|---|
|STOP-0|独立S0、metric identity、来源、future-read或梯度合同失败|停止所有科学比较并修复|把合成/同bridge测试PASS当真实S0|
|STOP-1|经过训练与留出校验的有限库oracle−Fs的U≤δ_headroom|停止当前库；最多一次预注册修订|在零B/未训练库上否定想法；无限刷库|
|STOP-2|oracle−best-fixed的U≤δ_dynamic|PIVOT静态适配；取消复杂planner|用oracle总增益掩盖动态增量不足|
|STOP-3|经过轻量合理调参，合法e/du或decision projection捕获不到可分辨动态增益|针对2×2瓶颈停止/收窄；必要时归为不可预测hindsight空间|靠扩JEPA/memory继续堆模块|
|STOP-4|factorized与direct gain等效且更贵，且锁定的标签/目标复用检验也无优势|删除分解方法贡献或PIVOT direct controller|只看latent loss/图形掩盖decision劣势|
|STOP-5|同信息recurrent output或surrogate replay在主指标、长程伤害与成本上支配parameter execution|停止参数编辑必要性主张|把输出baseline限制为一步或不给同样历史|
|STOP-6|短时效赢、72/120/240h系统损伤超过margin|缩小作用窗/主张或停该编辑族；重新注册|只报告6h/24h最优结果|
|STOP-7|Ra对混合编辑的真实误差超信赖域，fullH组合收益不成立|停止连续Jacobian分支，退回finite-exact|把Gram overlap称非线性交互并继续扩大a|
|STOP-8|总体开销超过预算、控制器比节省的adapter成本更高而无精度优势|撤回加速/预算优势，重新评价Pareto|忽略reference额外前向、warmup和probe成本|

## 4. 明确分母与字典范围

不用“静态解释了oracle的90%”作为唯一门槛，因为oracle接近0时比率不稳定。用同单位paired oracle−best_fixed及区间。

有限库oracle只上界当前列出的可行编辑，不上界全部可能参数修改；solver没找到更优也不构成不存在性证明。主动缩字典、删困难变量、增测试期探测都会改变问题，必须新protocol。
