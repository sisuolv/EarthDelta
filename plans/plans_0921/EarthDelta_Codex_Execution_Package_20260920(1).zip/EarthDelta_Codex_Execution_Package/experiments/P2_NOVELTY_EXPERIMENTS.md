# P2 — at most two enhancements

## P2-01（首选）：轨迹目标重用与低标签决策

冻结同一个响应模型，在训练支持内改变量/lead权重、成本预算；与获得相同目标descriptor的direct-gain做比较。评估不同未来truth标签比例时实际选择质量；给对照相同额外du数据。分别标识支持内重加权、新时效外推、新专家少样本校准，不统称zero-shot。

## P2-02（可选）：验证后的多编辑局部组合

从有限库扩到低维连续系数。比较真实joint response、中心差分Ra、learnedR a；分开Gram cross terms和nonlinear remainder。fullH/diagH、directcoeff、continuous optimizer共享rho/support/cost。响应可近似的信赖域由开发集固定；域外回finite/noedit。

P2-02失败不推翻P1的finite路线；P2-01失败不自动扩更多模块。JEPA、复杂记忆、rank控制器、全谱loss、第二大主干和真实同化留P3。
