# P0 — project survival, not leaderboard polishing

顺序：P0-01独立S0 → P0-02统一合同 → P0-03训练参考/库与注册 → P0-04精确oracle → P0-05可预测性分解 → P0-06输出挑战。

核心试验对应用户A–F：A/B在P0-04；C/D在P0-05；E/F在P0-06。真实A必须等待一个非退化库，不能在零初始化模块上做“最高上界无提升”。

先用少量跨季节连续片段验证缓存，再按preregister采样；首10个一月起点只算sanity。对每个起点所有可行候选都是真实有限预报；frozen和Fs同时报告，但主要动态空间相对validation best-fixed。

2×2：oracle e/du，oracle e+pred du，pred e+oracle du，pred both。oracle只用于诊断；预测路径的所有变量来自同一合法context。统计同样预算下的regret、positive/negative gain、best action recall与替换后的增益变化，定位真正瓶颈。

必要简单对照：e0全场均值/气候态、合法EWMA、du=0、训练平均du、直接gain、restricted response projection/b。全e0 R²低不代表相关投影不能预测。若du头很准，必须挑战“为什么不用预测du直接加回输出”。

输出baseline要多变量、递归、相同历史与多步训练。名义cost和实测wall-clock都记录，控制器调用reference backbone时不能藏账。

本阶段最终产出是CONTINUE/STOP/PIVOT/INCONCLUSIVE，而不是一个预设的新方法胜出表。阈值算法、置信规则和最大一次库修订见STOP_CONDITIONS.md。
