# Baseline implementation and fairness

|ID|方法|当前可复用|训练/输入|来源/封装|输出|公平合同|
|---|---|---|---|---|---|---|
|B0|Frozen F0|官方Stormer pinned权重|无训练；明确69通道/真实坐标/归一化|官方forward、推理增量和WB-X|原始物理预报轨迹|与Fs分开，不将zero-edit基准混淆|
|B1|Static Fs / higher-capacity static LoRA|现有ExpertLoRA K=1或标准PEFT|与动态库同数据；多步训练；额外高容量静态模型匹配总可训练参数|earthdelta/lowrank.py；标准LoRA需另pin|全部规定lead轨迹|验证集挑epoch，禁止测试选reference|
|B2|Random / best-fixed / regime-fixed|同一候选库|随机seed固定；best-fixed只在validation选；regime由train规则|现有select_plan+新增baseline配置|选定候选及轨迹|no-edit也在同一可行集；同cost/hold|
|B3|History→coefficients direct router|现有BoundedProgramHead +新增可微rollout|端到端同样多步loss；完整上下文与预算descriptor|复用heads.py；CLAW/CoDA机制参考|可行coefficients和轨迹|不是把不可微tuple API接过去再宣布效果差|
|B4|Direct scalar gain|新增direct_gain.py，小MLP/GRU|与paired路线相同context、edit、lead、Q/budget输入与训练label；可用同response辅助监督|纯PyTorch；VI-MoLE-inspired value baseline标明非官方复现|[B,K,H] gain或预注册aggregate|调参次数与额外数据相同；改变metric给相同descriptor|
|B5|Paired e0/du & restricted projection|现有ReferenceErrorHead/EditResponseHead/InteractionUtilityHead|平方metric统一；raw vs calibrated；e0+true du等仅diagnostic|当前本项目代码|响应场/摘要、b/H与选择|投影gain不冒充全fieldgain|
|B6|Recursive multivariate output correction|新增recurrent_output.py|输入和变量与编辑相同；校正反馈下一step；相同4步训练及后续长rollout|Solver-in-the-Loop作为机制来源；不需搬其全部PDE框架|Fs(x)+C_phi的完整轨迹|可使用context/code固定多步；匹配参数、时间、历史|
|B7|Fs+predicted e0 / Fs+predicted du|复用相同预测头+公平fullfielddecoder|需要完整场时decoder同等训练并计成本；不是只回放低维摘要|当前heads.py+新增输出bridge|直接订正轨迹或单lead输出分别报告|检验为何还实际执行edit；信息/成本相同|
|B8|Full/diag H, past context fit|现有geometry/teacher/selection|past-fit只用已揭示targets；diag/full共用R/训练信息|SciPy已有依赖；CoDA/Green方法参考|coefficients、预测/实际gain|未来核验优化只离线oracle；支持/rho/cost一致|
|O0|Finite oracle / e0 oracle / du oracle|现有cached_responses+完整实际枚举|明确标签/真实响应知情，绝不进入serving主排名|probe.py / paired.py|hindsight best及2×2诊断|有限库天花板；候选失败不剔除；不以top3充全oracle|
|B9|WeatherPEFT / Aurora-specific adapters|仅后续可比任务|需要相同任务/信息/数据并独立许可核验|WeatherPEFT暂无已核许可；Aurora非第一阶段backbone|按适配任务定义|不能把下尺度任务成绩直接挪到Stormer全球预测比较|

## 实施合同

最少包括B0–B8/O0，B9仅在任务与许可匹配后做。P0用小而合理训练的版本，P1扩展同样协议，不改变比较定义。共同report字段：history span、observations available、extra offline labels、trainable params、trained dictionary cost、candidate evaluation calls、measured inference/warmup latency、seeds/optimization budget、actual forecast failure count。

output端不能只用t2m单变量对比多变量编辑；不能只训练一步对比多步loss。参数编辑不能读取reference晚层features而不让对照使用/不计这次前向。direct gain也可输入新metric/budget/lead，因此“它无法迁移”不能当预设。

论文/代码/license分别核查。下面外部源码不在本包中分发，所有缺许可项目的复制操作BLOCKED。依赖优先复用本项目已实现基础层，降低迁移成本。
