# P1 — core paper evidence

Prerequisite：P0完整CONTINUE。不允许在P0失败时用新增架构绕过。

固定Fs、字典与hold；建立版本化向量轨迹response dataset，训练同信息的paired/direct/b-H/router，保持JEPA关闭、memory只做相同简单baseline。分别报告参考误差预测、响应预测和gain校准的贡献。

核心表：F0/Fs/high-cap static/best-fixed/regime/directgain/directrouter/recursiveoutput/surrogate replay/EarthDelta；oracle另表。每项同valid_time、same failure policy。

指标：全场RMSE/ACC、多lead、平方gain、regret、编辑harm率、response cosine/norm/R²、训练和test-time所有调用成本。不要把训练响应MSE变小当paper完成。

必须增加：summary vs fullfield gain排序、zero-response基线、same-rank differentdirection库、固定计划continuation、reference features计算账本、压缩投影丢掉的实际收益分析。

若paired只达到directgain同水平，需要P2预注册某个真正复用场景证明额外价值；否则贡献退回简单controller，不能把数学恒等式当创新补位。
