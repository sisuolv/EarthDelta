# File-by-file minimal-patch plan

所有create项目前为提议路径，不是已存在模块。禁止重写整个repository。

| File/module | Modification | Purpose | Experiment | Expected artifact |
|---|---|---|---|---|
| `scripts/s0_gate.py` | MODIFY，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `earthdelta/bridge/stormer_bridge.py` | MODIFY，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `earthdelta/data/make_splits.py` | MODIFY，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `earthdelta/contracts.py` | MODIFY，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `earthdelta/metrics.py` | CREATE，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `earthdelta/provenance.py` | CREATE，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `earthdelta/data/validation.py` | CREATE，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `configs/p0/s0.json` | CREATE，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `tests/test_s0_official.py` | CREATE，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `tests/test_metric_contract.py` | CREATE，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `tests/test_data_integrity.py` | CREATE，具体符号与I/O见P0-01 requirements | 防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。 | P0-01 | status.json, provenance.json, metrics.json |
| `earthdelta/selection.py` | MODIFY，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `earthdelta/contracts.py` | MODIFY，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `earthdelta/lowrank.py` | MODIFY，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `earthdelta/intervention_bank.py` | CREATE，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `scripts/build_edit_bank.py` | CREATE，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `scripts/oracle_ceiling.py` | CREATE，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `configs/p0/oracle.json` | CREATE，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `tests/test_finite_feasibility.py` | CREATE，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `tests/test_bank_response.py` | CREATE，具体符号与I/O见P0-02 requirements | 首先判断编辑动作本身是否有价值；不训练复杂 predictor。 | P0-02 | bank_manifest.json, bank_checkpoint.pt, decision_policy.json |
| `earthdelta/paired.py` | MODIFY，具体符号与I/O见P0-03 requirements | 避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。 | P0-03 | static_choice.json, crossfit_splits.json, four_quadrants.parquet |
| `earthdelta/analysis/headroom.py` | CREATE，具体符号与I/O见P0-03 requirements | 避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。 | P0-03 | static_choice.json, crossfit_splits.json, four_quadrants.parquet |
| `earthdelta/context.py` | CREATE，具体符号与I/O见P0-03 requirements | 避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。 | P0-03 | static_choice.json, crossfit_splits.json, four_quadrants.parquet |
| `scripts/headroom_decomposition.py` | CREATE，具体符号与I/O见P0-03 requirements | 避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。 | P0-03 | static_choice.json, crossfit_splits.json, four_quadrants.parquet |
| `configs/p0/headroom.json` | CREATE，具体符号与I/O见P0-03 requirements | 避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。 | P0-03 | static_choice.json, crossfit_splits.json, four_quadrants.parquet |
| `tests/test_headroom.py` | CREATE，具体符号与I/O见P0-03 requirements | 避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。 | P0-03 | static_choice.json, crossfit_splits.json, four_quadrants.parquet |
| `tests/test_paired_summary.py` | CREATE，具体符号与I/O见P0-03 requirements | 避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。 | P0-03 | static_choice.json, crossfit_splits.json, four_quadrants.parquet |
| `earthdelta/baselines/simple.py` | CREATE，具体符号与I/O见P0-04 requirements | 在投入复杂系统前，检查更简单的输出订正或标量 gain 是否已解释全部收益。 | P0-04 | baseline_results.parquet, fairness_ledger.json, p0_decision.md |
| `scripts/p0_baseline_challenge.py` | CREATE，具体符号与I/O见P0-04 requirements | 在投入复杂系统前，检查更简单的输出订正或标量 gain 是否已解释全部收益。 | P0-04 | baseline_results.parquet, fairness_ledger.json, p0_decision.md |
| `configs/p0/baselines.json` | CREATE，具体符号与I/O见P0-04 requirements | 在投入复杂系统前，检查更简单的输出订正或标量 gain 是否已解释全部收益。 | P0-04 | baseline_results.parquet, fairness_ledger.json, p0_decision.md |
| `tests/test_baseline_fairness.py` | CREATE，具体符号与I/O见P0-04 requirements | 在投入复杂系统前，检查更简单的输出订正或标量 gain 是否已解释全部收益。 | P0-04 | baseline_results.parquet, fairness_ledger.json, p0_decision.md |
| `earthdelta/context.py` | MODIFY，具体符号与I/O见P1-01 requirements | 将无标签响应模拟与延迟真值监督分离，建立可复用训练证据。 | P1-01 | paired_manifest.parquet, context_features/, du_labels/ |
| `earthdelta/data/paired_dataset.py` | CREATE，具体符号与I/O见P1-01 requirements | 将无标签响应模拟与延迟真值监督分离，建立可复用训练证据。 | P1-01 | paired_manifest.parquet, context_features/, du_labels/ |
| `scripts/build_response_dataset.py` | CREATE，具体符号与I/O见P1-01 requirements | 将无标签响应模拟与延迟真值监督分离，建立可复用训练证据。 | P1-01 | paired_manifest.parquet, context_features/, du_labels/ |
| `configs/p1/dataset.json` | CREATE，具体符号与I/O见P1-01 requirements | 将无标签响应模拟与延迟真值监督分离，建立可复用训练证据。 | P1-01 | paired_manifest.parquet, context_features/, du_labels/ |
| `tests/test_paired_dataset.py` | CREATE，具体符号与I/O见P1-01 requirements | 将无标签响应模拟与延迟真值监督分离，建立可复用训练证据。 | P1-01 | paired_manifest.parquet, context_features/, du_labels/ |
| `earthdelta/heads.py` | MODIFY，具体符号与I/O见P1-02 requirements | 以匹配条件实证 factorization 是否比直接 scalar gain 值得。 | P1-02 | head_checkpoints/, training_history.json, per_origin_predictions.parquet |
| `earthdelta/paired.py` | MODIFY，具体符号与I/O见P1-02 requirements | 以匹配条件实证 factorization 是否比直接 scalar gain 值得。 | P1-02 | head_checkpoints/, training_history.json, per_origin_predictions.parquet |
| `earthdelta/training/response.py` | CREATE，具体符号与I/O见P1-02 requirements | 以匹配条件实证 factorization 是否比直接 scalar gain 值得。 | P1-02 | head_checkpoints/, training_history.json, per_origin_predictions.parquet |
| `scripts/train_response_heads.py` | CREATE，具体符号与I/O见P1-02 requirements | 以匹配条件实证 factorization 是否比直接 scalar gain 值得。 | P1-02 | head_checkpoints/, training_history.json, per_origin_predictions.parquet |
| `configs/p1/heads.json` | CREATE，具体符号与I/O见P1-02 requirements | 以匹配条件实证 factorization 是否比直接 scalar gain 值得。 | P1-02 | head_checkpoints/, training_history.json, per_origin_predictions.parquet |
| `tests/test_head_losses.py` | CREATE，具体符号与I/O见P1-02 requirements | 以匹配条件实证 factorization 是否比直接 scalar gain 值得。 | P1-02 | head_checkpoints/, training_history.json, per_origin_predictions.parquet |
| `earthdelta/bridge/stormer_bridge.py` | MODIFY，具体符号与I/O见P1-03 requirements | 支持公平的端到端 router 和 recurrent correction 基线，消除 tuple 脱梯度与批共享限制。 | P1-03 | pytest.log, gradient_audit.json, parity_report.md |
| `earthdelta/bridge/controlled_projection.py` | CREATE，具体符号与I/O见P1-03 requirements | 支持公平的端到端 router 和 recurrent correction 基线，消除 tuple 脱梯度与批共享限制。 | P1-03 | pytest.log, gradient_audit.json, parity_report.md |
| `tests/test_differentiable_rollout.py` | CREATE，具体符号与I/O见P1-03 requirements | 支持公平的端到端 router 和 recurrent correction 基线，消除 tuple 脱梯度与批共享限制。 | P1-03 | pytest.log, gradient_audit.json, parity_report.md |
| `earthdelta/baselines/neural.py` | CREATE，具体符号与I/O见P1-04 requirements | 直接攻击参数编辑与响应分解的存在价值。 | P1-04 | baseline_checkpoints/, training_costs.json, fairness_ledger.json |
| `earthdelta/baselines/peft.py` | CREATE，具体符号与I/O见P1-04 requirements | 直接攻击参数编辑与响应分解的存在价值。 | P1-04 | baseline_checkpoints/, training_costs.json, fairness_ledger.json |
| `scripts/train_baselines.py` | CREATE，具体符号与I/O见P1-04 requirements | 直接攻击参数编辑与响应分解的存在价值。 | P1-04 | baseline_checkpoints/, training_costs.json, fairness_ledger.json |
| `configs/p1/baselines.json` | CREATE，具体符号与I/O见P1-04 requirements | 直接攻击参数编辑与响应分解的存在价值。 | P1-04 | baseline_checkpoints/, training_costs.json, fairness_ledger.json |
| `tests/test_neural_baselines.py` | CREATE，具体符号与I/O见P1-04 requirements | 直接攻击参数编辑与响应分解的存在价值。 | P1-04 | baseline_checkpoints/, training_costs.json, fairness_ledger.json |
| `earthdelta/selection.py` | MODIFY，具体符号与I/O见P1-05 requirements | 把分数变成真实一次编辑预报，再由后到真值验证，而不是只评估预测分数。 | P1-05 | serving_predictions/, decisions.parquet, offline_metrics/ |
| `earthdelta/planner.py` | CREATE，具体符号与I/O见P1-05 requirements | 把分数变成真实一次编辑预报，再由后到真值验证，而不是只评估预测分数。 | P1-05 | serving_predictions/, decisions.parquet, offline_metrics/ |
| `scripts/evaluate_planner.py` | CREATE，具体符号与I/O见P1-05 requirements | 把分数变成真实一次编辑预报，再由后到真值验证，而不是只评估预测分数。 | P1-05 | serving_predictions/, decisions.parquet, offline_metrics/ |
| `configs/p1/planner.json` | CREATE，具体符号与I/O见P1-05 requirements | 把分数变成真实一次编辑预报，再由后到真值验证，而不是只评估预测分数。 | P1-05 | serving_predictions/, decisions.parquet, offline_metrics/ |
| `tests/test_serving_boundary.py` | CREATE，具体符号与I/O见P1-05 requirements | 把分数变成真实一次编辑预报，再由后到真值验证，而不是只评估预测分数。 | P1-05 | serving_predictions/, decisions.parquet, offline_metrics/ |
| `earthdelta/evaluation.py` | CREATE，具体符号与I/O见P1-06 requirements | 检验短期收益是否保留、跨年是否有效，并形成真实论文证据。 | P1-06 | overall_results.csv, ablations.csv, efficiency.csv |
| `scripts/evaluate_publication.py` | CREATE，具体符号与I/O见P1-06 requirements | 检验短期收益是否保留、跨年是否有效，并形成真实论文证据。 | P1-06 | overall_results.csv, ablations.csv, efficiency.csv |
| `scripts/make_paper_tables.py` | CREATE，具体符号与I/O见P1-06 requirements | 检验短期收益是否保留、跨年是否有效，并形成真实论文证据。 | P1-06 | overall_results.csv, ablations.csv, efficiency.csv |
| `configs/p1/publication.json` | CREATE，具体符号与I/O见P1-06 requirements | 检验短期收益是否保留、跨年是否有效，并形成真实论文证据。 | P1-06 | overall_results.csv, ablations.csv, efficiency.csv |
| `tests/test_aggregation.py` | CREATE，具体符号与I/O见P1-06 requirements | 检验短期收益是否保留、跨年是否有效，并形成真实论文证据。 | P1-06 | overall_results.csv, ablations.csv, efficiency.csv |
| `earthdelta/decision_space.py` | CREATE，具体符号与I/O见P2-01 requirements | 验证比完整误差预测更弱的信息是否足够决策，并证明响应分解的具体额外价值。 | P2-01 | decision_space.json, label_efficiency.csv, metric_budget_transfer.csv |
| `scripts/decision_transfer.py` | CREATE，具体符号与I/O见P2-01 requirements | 验证比完整误差预测更弱的信息是否足够决策，并证明响应分解的具体额外价值。 | P2-01 | decision_space.json, label_efficiency.csv, metric_budget_transfer.csv |
| `configs/p2/transfer.json` | CREATE，具体符号与I/O见P2-01 requirements | 验证比完整误差预测更弱的信息是否足够决策，并证明响应分解的具体额外价值。 | P2-01 | decision_space.json, label_efficiency.csv, metric_budget_transfer.csv |
| `tests/test_decision_space.py` | CREATE，具体符号与I/O见P2-01 requirements | 验证比完整误差预测更弱的信息是否足够决策，并证明响应分解的具体额外价值。 | P2-01 | decision_space.json, label_efficiency.csv, metric_budget_transfer.csv |
| `earthdelta/calibration.py` | CREATE，具体符号与I/O见P2-02 requirements | 不借助虚假独立性或上界作差，直接控制候选收益被高估的风险。 | P2-02 | calibration_state.json, coverage.csv, selective_gain.csv |
| `scripts/calibrate_intervention_risk.py` | CREATE，具体符号与I/O见P2-02 requirements | 不借助虚假独立性或上界作差，直接控制候选收益被高估的风险。 | P2-02 | calibration_state.json, coverage.csv, selective_gain.csv |
| `configs/p2/calibration.json` | CREATE，具体符号与I/O见P2-02 requirements | 不借助虚假独立性或上界作差，直接控制候选收益被高估的风险。 | P2-02 | calibration_state.json, coverage.csv, selective_gain.csv |
| `tests/test_gain_calibration.py` | CREATE，具体符号与I/O见P2-02 requirements | 不借助虚假独立性或上界作差，直接控制候选收益被高估的风险。 | P2-02 | calibration_state.json, coverage.csv, selective_gain.csv |
| `configs/p3/generalization.json` | CREATE，具体符号与I/O见P3-01 requirements | 在主线已成立后检验结论的可迁移范围，不作为掩盖单主干失败的方法。 | P3-01 | second_backbone_gate.json, generalization_results.csv, limitations.md |
| `scripts/evaluate_backbone_transfer.py` | CREATE，具体符号与I/O见P3-01 requirements | 在主线已成立后检验结论的可迁移范围，不作为掩盖单主干失败的方法。 | P3-01 | second_backbone_gate.json, generalization_results.csv, limitations.md |
| `tests/test_backbone_contract.py` | CREATE，具体符号与I/O见P3-01 requirements | 在主线已成立后检验结论的可迁移范围，不作为掩盖单主干失败的方法。 | P3-01 | second_backbone_gate.json, generalization_results.csv, limitations.md |
| `configs/p3/diagnostics.json` | CREATE，具体符号与I/O见P3-02 requirements | 仅在具体失败模式被主线结果识别后扩展分析，而非为novelty叠模块。 | P3-02 | event_results.csv, physical_diagnostics.csv, failure_modes.md |
| `scripts/analyze_extreme_regimes.py` | CREATE，具体符号与I/O见P3-02 requirements | 仅在具体失败模式被主线结果识别后扩展分析，而非为novelty叠模块。 | P3-02 | event_results.csv, physical_diagnostics.csv, failure_modes.md |
| `tests/test_physical_diagnostics.py` | CREATE，具体符号与I/O见P3-02 requirements | 仅在具体失败模式被主线结果识别后扩展分析，而非为novelty叠模块。 | P3-02 | event_results.csv, physical_diagnostics.csv, failure_modes.md |
