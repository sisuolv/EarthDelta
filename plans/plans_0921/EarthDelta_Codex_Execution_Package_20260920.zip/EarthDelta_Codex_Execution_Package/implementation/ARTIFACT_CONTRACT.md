# Artifact Contract

每次实验使用不可覆盖目录 `artifacts/p{0,1,2,3}/<TASK_ID>/<UTC timestamp>_<git-short>_<nonce>/`。目录已存在就退出，不自动 overwrite。Failed/blocked run 同样保存记录；不清理失败数据来改善结果。

最少文件：`config.json`、`metrics.json`、`summary.md`、`stdout.log`、`provenance.json`、`status.json`、`command.txt`。有逐样本结果时增加 `predictions/` 与 `per_origin.parquet`；图表放 `figures/`。`metrics.json` 未运行的值为 null 并标原因，禁止 0、NaN 或随机占位值冒充结果；JSON allow_nan=false。

`status.json` 包含 task_id、status、prerequisite_runs、blocking_reasons、decision、next_allowed_task；`provenance.json` 包含完整 git commit/dirty diff hash、checkpoint SHA256、bank SHA256、normalization/key order/array digests、grid actual coordinate digest、summary/metric digest、split manifest digest、seeds、硬件/软件/精度、数据版本与可用时间语义。

`per_origin.parquet` 至少：origin_id、issue_time_utc、split_id、event_block_id、method、candidate_id、lead_hours、variable、weighted_sse、weight_sum、reference_sse、predicted_gain、actual_gain（offline evaluator 才写）、declared_cost、measured_latency、status、failure_reason。

预测输出和后到的 oracle 评估分别保存：服务结果文件中不写 future truth，不把 oracle_gain 回灌 serving features。候选缓存必须记录 reference forecast、finite response 或 local R 的类型，不准两者混用。

图：oracle/headroom 分布；response norm/cosine/decision error；四象限瓶颈；static/router/gain/residual 的比较；label efficiency；metric/budget transfer；6–240h 保护变量；skill–cost Pareto。没有真实数据不得生成“示意实验曲线”当结果。
