# Reproducibility and fairness

1. 用实际 git SHA 作为依据。当前基线为 4fe55a7af90ea92f62a3232a571af92bfbd6114d。发现 main 已前进，先记录差异并重新核查受影响文件；不要 force-reset 用户修改或覆盖工作区。
2. P0 固定官方 Stormer revision 与实际 checkpoint。源码许可、权重许可、数据许可三者独立。代理/镜像下载仍核对上游 identity；不把明文密钥写日志。
3. 时间始终 timezone-aware UTC；数据 manifest 需要实际起止时间、缺口、重复、通道/层、网格、单位、常量变量、warmup history 与最大 240h 终点 coverage。只验证 timestamp 大小关系不够。
4. 按初始时间/天气事件块分割，不随机拆网格或重叠轨迹；拟合 bank、normalizer、basis、regime prototypes 只用 train。2019 可拆 dev/calibration 的不重叠连续块；2020 和 2021–22 保持最终评测，任何曾参与选择的片段明确移出 final test。
5. ERA5 reanalysis 是回顾数据，不是在 valid_time 当时可获得的实时观测。对研究回放明确 `availability_policy=retrospective_assumed`；对业务声明使用真实产品 release/retrieval 时间。不可把 6h 默认 delay 叫验证过的 ERA5 发布延迟。
6. deterministic backbone.eval()/frozen 参数；多次试验保持相同初态、RNG、数值精度。测 finite du 先验证重复性。所有非零/零编辑恢复测试要使用 B 非零的 bank。
7. 同信息条件下对照：额外无标签响应模拟可用量、真值标签数、选择预算、训练更新次数、trainable params/总 params、硬件、feature pass 必须公开；不能不给 baseline 相同训练机会。
8. online GPU latency 测 batch=1 且 CUDA synchronize，报告 warm/cold、median/P95、peak memory、前向次数；offline 数据生成与训练耗时分列。SDPA/xformers 的重复噪声和 tolerance 实测，不能随意放宽到通过。
9. 运行当前 unit tests 并保存真实 collect / passed / skipped / failed。缺 checkpoint 的 real tests 记 skipped，不能转通过。各新增 CLI `--help` 测试；外部库必须固定版本，不在 import 时自动 pip 安装。
10. 最终论文表由保存的 per-origin 结果脚本生成，含所有失败/回退，不手工删样本。整体显著性与分项探索标明；不把 69 个相关变量、多个 lead 当作几十个独立复现。
