# Literature-to-code mapping / dependency lock

| External repo | Pinned commit / status | License status | 实际核查/可借鉴 | EarthDelta file | 修改原则 |
|---|---|---|---|---|---|
| https://github.com/tung-nd/stormer | 58dfee5a6037399a40fefd492bc00421e0c885a8 | MIT，已读 LICENSE | 已读 inference.py；零增量均值、固定步长与路径平均协议 | bridge/stormer_bridge.py, scripts/s0_gate.py | 独立 oracle，不mock本地类；保留版权；权重许可另查 |
| https://github.com/microsoft/aurora | 4765abc724c607a18f93df0302dbd0afcaca17fa | MIT code header；权重另查 | 已读 aurora/model/lora.py 的 LoRA/LoRARollout | lowrank.py / baselines/peft.py | 主要作先例与步号调度参考，不复制整个backbone |
| https://github.com/ShileiCao/WeatherPEFT | commit UNVERIFIED；已读 tree b2cdc25cbbb78de272a6f6e0d532c2fe2006a15c 与 fish.py blob 99afcd973bada082a670f1d83ba563bbb57996f7 | top-level许可未核实；禁止默认MIT | 已核查梯度重要性与随机mask实现 | baselines/peft.py | 当前只作论文机制对照；resolve许可/commit后再决定是否复用 |
| https://github.com/eric-mitchell/mend | UNVERIFIED pin | 官方仓库展示MIT，复用前读固定版本 | learned low-rank edit作为prior，不是天气drop-in | RELATED_WORK / optional baseline | 不能用当前futurelabel驱动MEND然后当合法服务 |
| https://github.com/sail-sg/lorahub | UNVERIFIED pin/license | BLOCKED_COPY | 官方代码链接由论文确认；未逐行审核 | baselines/peft.py 可选 | coefficient-free-gradient search思路；无梯度不等于无标签 |
| https://github.com/EnnengYang/AdaMerging | project manifest报告 cea1165；本次未独立解析完整SHA | manifest报告MIT，不能替代独立核验 | 只用于合并/熵适应背景 | baselines optional | 不把分类entropy变天气loss |
| https://github.com/tum-pbs/Solver-in-the-Loop | UNVERIFIED pin/license | BLOCKED_COPY | 论文多步状态订正动机；本次未跑源码 | baselines/neural.py | 最小独立实现天气recurrent corrector，标清非官方复现 |
| https://github.com/google-research/weatherbench2 | UNVERIFIED pin/license | resolve before import/copy | 希望复用latitude RMSE/ACC聚合定义 | metrics.py/evaluation.py | 首先锁定实际版本并对固定例子交叉验证；不是凭名称保证一致 |
| https://github.com/NVIDIA/torch-harmonics | UNVERIFIED pin/license | resolve before import/copy | P3球面变换节点/归一化 | spectral.py | 不加入P0依赖 |

UNVERIFIED 不允许用“main”冒充 fixed commit。Codex 在本地可读 reference/ 镜像时对每个实际使用依赖执行 git rev-parse HEAD、读取LICENSE并计算hash，保存 dependency_lock.json。代码、checkpoint、dataset许可证分开记录。EarthDelta根目录未见完整当前LICENSE时，应先整理已有上游版权/许可边界；旧kit的MIT不能自动授权所有新增文件。
