# Test Plan

既有测试仍应运行；下述测试是新增要求。本文不声称这些测试当前已存在/已通过。

## P0-01

- `test_independent_upstream_class`
- `test_zero_coeff_nonzero_bank`
- `test_diff_mean_official_zero`
- `test_timezone_invariance_utc`
- `test_reject_placeholder_hash`
- `test_rmse_failure_blocks_gate`
- `test_future_columns_rejected`
- `test_artifact_version_mismatch`

## P0-02

- `test_finite_rejects_outside_box`
- `test_finite_rejects_max_active_zero`
- `test_finite_nan_rejected`
- `test_zero_bank_not_scientific_ceiling`
- `test_oracle_includes_noedit`
- `test_no_test_label_bank_training`
- `test_gain_actual_not_linear_teacher`

## P0-03

- `test_static_selection_disjoint`
- `test_four_oracle_quadrants`
- `test_large_orthogonal_error_irrelevant`
- `test_nonlinear_summary_identity`
- `test_summary_fullfield_disagreement`
- `test_context_no_truth`

## P0-04

- `test_same_context_and_split`
- `test_ewma_available_time`
- `test_oracle_never_serving`
- `test_residual_shared_multilead_metric`

## P1-01

- `test_cache_rejects_changed_weights`
- `test_future_label_mask`
- `test_block_overlap_forbidden`
- `test_summary_fit_train_only`
- `test_lead240_coverage`

## P1-02

- `test_zero_edit_structural_zero`
- `test_weighted_gain_matches_metrics`
- `test_memory_none_supported`
- `test_score_calibration_separate`
- `test_action_permutation_equivariance`
- `test_losses_respect_label_mask`

## P1-03

- `test_coeff_gradient_nonzero`
- `test_batch_distinct_plans`
- `test_reference_params_frozen`
- `test_dense_sparse_parity`
- `test_trajectory_final_matches_legacy`
- `test_no_cross_call_plan_state`

## P1-04

- `test_router_same_information`
- `test_recurrent_correction_feedback`
- `test_baseline_metric_budget_condition`
- `test_adapter_training_not_zero_product`
- `test_total_label_budget_logged`

## P1-05

- `test_teacher_not_reachable_from_serving`
- `test_noop_when_no_positive_score`
- `test_tie_break_stable_id`
- `test_changed_bank_rejected`
- `test_selected_forecast_actually_run`

## P1-06

- `test_rmse_aggregate_before_sqrt`
- `test_acc_fixed_climatology`
- `test_failure_samples_retained`
- `test_block_bootstrap_no_pixel_independence`
- `test_extreme_threshold_train_only`

## P2-01

- `test_projection_decision_sufficiency`
- `test_metric_reweight_within_basis`
- `test_new_bank_protocol_labeled`
- `test_pair_interaction_not_gram_overlap`

## P2-02

- `test_max_over_candidate_calibration`
- `test_noop_exact_zero`
- `test_risk_upper_difference_not_lcb`
- `test_changed_metric_invalidates_calibration`
- `test_calibration_test_split_disjoint`

## P3-01

- `test_backbone_specific_version`
- `test_no_cross_arch_cache_reuse`

## P3-02

- `test_event_definition_no_test_tuning`
- `test_spherical_nodes_and_normalization`
- `test_energy_phase_distinction`

## 必须保留的层级

数学/CPU fixture、真实checkpoint单模块、完整真实rollout、统计评估、泄漏/版本负例五层分开。真实层缺资源时skip/BLOCKED且不得让总gate通过；CPU pass无法替代真实层。
