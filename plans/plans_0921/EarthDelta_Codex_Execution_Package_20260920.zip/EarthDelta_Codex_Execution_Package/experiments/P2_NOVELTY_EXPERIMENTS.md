# P2 实验合同

先读STOP_CONDITIONS.md与主执行计划；以下是实验数据/输入/输出/判据索引。

## P2-01 — 决策子空间与目标/预算重用

目的：验证比完整误差预测更弱的信息是否足够决策，并证明响应分解的具体额外价值。

Prerequisites：P1-06

Inputs/implementation：
- train-only固定basis U和response-span投影；比较full e0、projected e0、direct b、direct gain，报告保留响应能量与实际regret，不能只报告压缩率。
- 冻结head后改变预登记MetricSpec权重/预算；权重变化限定在保留空间内；direct-gain/router也接收目标与预算或等量再校准。
- 新专家测试分成已有bank未见组合、未见bank零probe、未见bank少量无标签probe；当前descriptor无权重表征，最后两者不能冒充按构造zero-shot。
- 有限pair response直接缓存用于组合holdout，分析gamma_ij；若采用Jacobian只作局部对照并测linearity radius；不新增第三条主创新。

Outputs：`decision_space.json`, `label_efficiency.csv`, `metric_budget_transfer.csv`, `combination_holdout.csv`, `claim_decision.md`

Pass：相对条件化强baseline，在预登记label/transfer场景有可辨提升且成本计入。

Fail：无额外优势 -> STOP-6，撤回factorization更强方法claim。

Next：只保留被实验支持的label-efficiency/metric-transfer贡献；失败不回收模块堆叠。

## P2-02 — 候选集级收益校准与不编辑策略

目的：不借助虚假独立性或上界作差，直接控制候选收益被高估的风险。

Prerequisites：P1-06

Inputs/implementation：
- 使用单独2019calibration连续块计算r_t=max_a(ghat_ta−g_ta)，固定高分位数q；LCB=ghat−q；noedit按真实零收益特殊处理；校准及保护规则在final前冻结。
- 固定candidate集合/metric/version分组；不同K与新bank必须重新说明校准适用性；不得把两个剩余风险上界相减当gain LCB。
- 报告coverage-vs-edit-rate、actual gain、harm frequency、no-edit rate、shift coverage；时间依赖只给经验结果/显式假设，不宣称distribution-free operational guarantee。
- 与uncertainty-only gating、scalar-gain校准、pointplanner比较；联合概率e0/du模型仅在资源许可且协方差可估计时作额外消融，不进入默认。

Outputs：`calibration_state.json`, `coverage.csv`, `selective_gain.csv`, `shift_calibration.md`, `figures/risk_coverage.png`

Pass：校准后可编辑覆盖率下actual risk/gain优于强gating且保护量满足声明；覆盖假设清楚。

Fail：校准外推崩溃/无价值/noop几乎全退但无有效gain -> 缩窄安全声明或STOP-7。

Next：只在被测分布和候选条件下保留selective-planning主张；超出条件默认noedit/需再校准。
