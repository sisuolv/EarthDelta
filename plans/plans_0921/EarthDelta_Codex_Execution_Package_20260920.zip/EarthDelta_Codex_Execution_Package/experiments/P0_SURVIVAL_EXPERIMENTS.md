# P0 实验合同

先读STOP_CONDITIONS.md与主执行计划；以下是实验数据/输入/输出/判据索引。

## P0-01 — 独立官方 S0 与可追溯数据合同

目的：防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。

Prerequisites：baseline inventory

Inputs/implementation：
- 新增 MetricSpec：variables/units/scales/latitude weights/lead weights/reduction；weighted_sse(pred,truth,spec)->(sse,weight_sum)，gain_from_pair 使用同一度量；消除 per-origin RMSE 平均的混淆。
- S0 CLI 使用 --config；输入 checkpoint_path、normalization_dir、era5_path、official_repo_dir、precision、origins。无默认硬编码个人路径；空值返回 BLOCKED 和具体缺失项，退出码2；不在 import 时安装依赖。
- 独立 import 官方 GlobalForecastIterativeModule 与官方 Stormer，固定 58dfee5...；禁止 sys.modules/mock 将官方类替换成本地类。读取官方 inference.py 的零增量均值与 fixed-interval rollout；官方多路径平均另标 protocol。
- 同一实际 checkpoint/69变量/网格/真实输入比较 official fixed6h 与 local fixed6h 的6/24/72h；先单模块 fp32 parity，再实际完整轨迹。容差来自同精度重复运行与事先记录的逐元素/metric envelope，不得观察结果后调大。
- 创建 B 非零的低秩 bank；coeff=0 与无 bank/官方等价；coeff≠0 有响应；计划结束后参数贡献归零但状态不重置；异常/重复调用无残留。
- NormalizationContract 严格 official 模式 diff_mean=0，增加非零 diff_mean fixture 检出误配；checkpoint SHA256 与 architecture ID 分开；rollout 自动核对 bank/model/normalization/interval。
- UTC-aware manifest；norm/grid hash 必须实际生成，拒绝 placeholder；validate actual time/channel/grid/finite/units；按当前 history/lead 检查实际 coverage，后续 240h 任务必须重新核查边界，不能沿用 168h guard；ERA5 availability 标为 retrospective 或真实 release_time。
- S0 overall gate 必须显式包含所有必要条件，包括 metric finite 与匹配官方同配置 RMSE；近似论文数值仅背景，不用于通过判定。先只检查一种与资源匹配的 checkpoint；ps2/ps4 不要求为不相关原因双下载。
- 记录环境/现有测试执行；若官方 xformers/真实权重/数据缺失，保存 BLOCKED；不能仅内部两路径一致就解除此门。

Outputs：`status.json`, `provenance.json`, `metrics.json`, `official_local_per_origin.parquet`, `parity_report.md`, `normalization_audit.json`, `data_inventory.json`

Pass：所有必需 pytest 条目通过；真实 checkpoint 官方/本地同协议满足预登记误差 envelope；所有 critical gate true。；实际 bytes/hash/coverage 可追溯；没有未说明的 missing/skipped 必需 real test。

Fail：任一独立 parity/数据/zero-edit/metric/版本失败 -> INVALID。；缺官方依赖、真实数据/权重、足够资源 -> BLOCKED。

Next：PASS 后只更新 P0-01；记录允许下一轮解锁 P0-02，本次停止。BLOCKED/INVALID 禁止任何 P0-02+ 科学运行。

## P0-02 — 非退化编辑库与真实 oracle 上限

目的：首先判断编辑动作本身是否有价值；不训练复杂 predictor。

Prerequisites：P0-01

Inputs/implementation：
- 统一 validate_candidate(offset, bound, max_active, costs,budget,max_candidates)；finite/continuous 入口均检查 finite、维度、support、幅度、成本，含精确零编辑和稳定 id tie-break。
- FrozenEditBank(manifest, adapters) 记录每个候选的实际权重 hash/rank/layer/系数/作用窗。默认单编辑候选，K 小且固定；不要先展开所有成对组合。
- 先做 B 非零、BA 范数、实际 du 超数值噪声、±幅度响应、恢复与重复性检查。随机非零 bank 仅作注入 sanity；scientific ceiling 必须对已训练/结构化且 freeze 的 bank 单独报告。
- 支持 train-only 小规模专家构造（不同 train regime/训练随机种子），固定非零训练系数后学习 A/B；禁止零 router×零 B 联合冷启动。无训练集 -> BLOCKED，不用 test truth 构造 bank。
- 预登记 bank A 与最多一次 bank B fallback，max trials；不能依据 oracle test 挑专家、窗长、幅度。reference 默认 F0，训练 Fs 必须另作独立基线。
- 只在 development origins 运行 frozen reference 与每个有限实际编辑，含6/24/72h及保护变量，cached_responses 保存实际 finite du；oracle 由真实加权损失枚举，不用局部 QP 拟合数值冒充。
- 脚本先做资源 pilot；在不看正式收益前锁定 N、block length、统计政策与 δ_survival；遵循 STOP_CONDITIONS 的区间决策。失败分支/NaN 不得丢弃。

Outputs：`bank_manifest.json`, `bank_checkpoint.pt`, `decision_policy.json`, `reference_predictions/`, `candidate_responses/`, `per_origin.parquet`, `oracle_ceiling.json`, `figures/oracle_ceiling.png`

Pass：非零响应与回退通过；固定字典实际 oracle gain 的区间下界超过冻结 screen threshold。；训练/开发构造与最终 test 严格分开；成本和失败率保存。

Fail：全零/退化 bank -> INVALID_DICTIONARY，不是证明科学无效。；oracle gain 区间上界低于阈值且预登记 fallback 已失败 -> STOP 当前主线。

Next：PASS_SCREEN 才允许 P0-03；INCONCLUSIVE 只允许预登记样本扩展；STOP 不得进入 predictor 大训练。

## P0-03 — 静态之外的动态空间与瓶颈四象限

目的：避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。

Prerequisites：P0-02

Inputs/implementation：
- 修正 paired 文档符号/非线性 summary 断言；测试共同非线性 S 仍精确、S(error) 与 S(y)−S(f) 不可混用。
- best-static 只在独立训练/开发选择集固定；在独立 headroom 集比较 no-edit、static、origin oracle；不能同一集合同时选 static 并把无偏外推当事实。
- 新增 IssueContext 仅含 history/current/issue_time/version；初版 context 为 fixed low-dimensional spatial statistics 或冻结主干特征；如用 reference forward，计入在线成本，不称免费。
- 训练简单 ridge/linear e0、du、direct gain pilot，time-block crossfit，不引入 JEPA/memory；用4象限（true/true、true/pred、pred/true、pred/pred）计算 actual chosen gain/regret。
- 同时输出全 e0 R²、response-subspace 误差、gain-ranking；对无 oracle headroom 样本不滥用 top-k/cosine。zero response 有效性按明确分母约定标 NA。
- 比较 summary/full-field 选出的 oracle，测 summary-driven 选择导致的保护量损害；交互指示为真实 pair-minus-singles，不用 H 非对角代替。

Outputs：`static_choice.json`, `crossfit_splits.json`, `four_quadrants.parquet`, `dynamic_headroom.json`, `summary_guard.json`, `figures/bottleneck_quadrants.png`

Pass：动态 oracle 超 static 的增量区间下界大于预登记 δ_dynamic。；至少一个 pilot predictor 具有超 naive 的决策信号，或明确定位单一可攻克瓶颈；不给大模型无条件放行。

Fail：U_dynamic<δ_dynamic -> PIVOT static。；summary 提升而 full-field/保护量劣化 -> INVALID summary 主目标。

Next：通过动态空间且存在可检验信号才 P0-04；预测证据不足时保持 INCONCLUSIVE，不把完整 e0 低 R²单独定死刑。

## P0-04 — 最小残差订正与直接收益挑战

目的：在投入复杂系统前，检查更简单的输出订正或标量 gain 是否已解释全部收益。

Prerequisites：P0-03

Inputs/implementation：
- 实现同 context 的 climatological bias、EWMA（仅合法历史，或明确禁用）、ridge joint-trajectory residual、action-conditioned scalar gain 和 regime lookup；所有 feature/label/time split 同等。
- 最小 baseline 是 survival screen，不作为最终强 neural residual 论文对照。若已有简单方法全面支配，需要先说明新的可证伪优势而不是继续堆模块。
- 记录训练标签条数、无标签响应生成次数、训练开销、推理 context cost；上界 oracle 不参与 serving。
- 比较预测编辑、best-static、output correction 的 paired gain、成本和保护量，冻结下一阶段 baseline 清单和定量统计政策。

Outputs：`baseline_results.parquet`, `fairness_ledger.json`, `p0_decision.md`, `frozen_p1_protocol.json`

Pass：P0-01~03 均通过且预测路线未被所有更简单方法全面支配；明确剩余可检验优势。

Fail：简单输出订正/直接 gain 在收益、成本、保护量全面支配且无标签/目标转移假设证据 -> STOP 或 PIVOT。

Next：只有在 p0_decision.md 写明 CONTINUE、证据路径齐全时解锁 P1；结果不明维持 INCONCLUSIVE。
