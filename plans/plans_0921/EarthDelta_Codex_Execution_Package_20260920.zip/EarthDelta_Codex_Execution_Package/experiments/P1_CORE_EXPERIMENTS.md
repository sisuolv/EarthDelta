# P1 实验合同

先读STOP_CONDITIONS.md与主执行计划；以下是实验数据/输入/输出/判据索引。

## P1-01 — 真实成对轨迹数据集与可用信息接口

目的：将无标签响应模拟与延迟真值监督分离，建立可复用训练证据。

Prerequisites：P0-04

Inputs/implementation：
- PairedTrajectoryDataset 返回 IssueContext、action descriptors、du labels、verification_mask；TruthBatch 只在训练损失/evaluator 参数中出现。
- train2015–18，2019按连续块分dev/calibration，final2020和shift2021–22，缺少任何范围明确 BLOCKED；用实际 coverage而非年份循环生成记录。
- fixed linear area-weighted summary S，必要时训练集拟合 basis；原场预测可另存低频样本供保护评价。保存6/24/72/120/240h，作用窗不随 lead 偷改。
- 缓存键包含 input content、checkpoint、bank、normalizer、grid、summary、interval、window；响应 finite 与 local R 带不同 schema。
- 标签效率实验分别 subsample 核验 origin 和保持合法无标签 d 数据量；base/银行训练用过的标签也记录总账。

Outputs：`paired_manifest.parquet`, `context_features/`, `du_labels/`, `verified_labels/`, `dataset_card.md`, `provenance.json`

Pass：实际样本/所有hash/coverage通过；不存在跨split重叠核验或不可达标签。

Fail：版本冲突、未来标签路径泄漏 -> INVALID；数据缺口 -> BLOCKED。

Next：只在真实 dataset audit PASS 后允许P1-02。

## P1-02 — e0/du、bH、直接收益预测头训练

目的：以匹配条件实证 factorization 是否比直接 scalar gain 值得。

Prerequisites：P1-01

Inputs/implementation：
- 复用 ReferenceErrorHead/EditResponseHead；让 memory可选且默认禁用，gain calibration 默认关闭；输出 raw e0、du、analytic_gain，learned_score独立字段。
- 加入 DirectGainHead(context,action,metric_descriptor,budget_descriptor)->scalar，及 EditedForecastHead / predicted bH 比较；预算不影响真实候选gain但可影响选择，禁止混淆。
- 训练同一固定 Q 下weighted losses；zero edit du=0/gain=0做结构约束；正确处理lead和action permutation。
- 先3个固定训练seed（只是初始重复设计，不代表足够 statistical power）；保持超参搜索预算相同；label fractions在protocol预登记，no futuretruth at validation serving。
- 报告cosine/R²/norm calibration、4象限actual regret、lead degradation；禁止只用训练loss宣布预测成功。

Outputs：`head_checkpoints/`, `training_history.json`, `per_origin_predictions.parquet`, `oracle_quadrants.json`, `label_efficiency.csv`

Pass：predicted both相对static/naive有真实heldout gain；head差异的决策影响可解释。

Fail：固定训练预算后decision signal≈naive且无projection空间信号 -> STOP-3。

Next：通过后进入实际planner；du/e0某一瓶颈失败则仅执行预登记对应消融，不加入未授权模块。

## P1-03 — 可微逐样本计划与显式低秩注入

目的：支持公平的端到端 router 和 recurrent correction 基线，消除 tuple 脱梯度与批共享限制。

Prerequisites：P0-04

Inputs/implementation：
- 新增 controlled_trajectory(bridge,x_norm,variables,interval,coefficients[B,K],bank,hold_steps,requested_leads)->tensor[B,H,V,lat,lon]。系数tensor保持梯度；不要 torch.tensor(existing_tensor) 重建。
- 保留旧 EditPlan serving wrapper，由其转换进入新的显式路径；旧单plan API不破坏。冻结主干/银行时仍允许梯度对coeff传播。
- 在可控 projection 包装中显式传递系数/步号，避免共享 mutable hooks；若暂留hook则显式串行限制并禁止并发，不能声称已线程安全。
- 验证dense/sparse、batched/unbatched、zero/nonzero、window-end、异常恢复与官方 parity；不可重写注意力/归一化等无关层。

Outputs：`pytest.log`, `gradient_audit.json`, `parity_report.md`

Pass：coefficients梯度正确且主干不更新；所有兼容/恢复/官方测试通过。

Fail：grad断开/批间计划污染/zero-edit偏移 -> INVALID。

Next：PASS解锁强router/recurrent baseline；不要在无可微路径时用较弱替身声称公平。

## P1-04 — 强 router、LoRA 和输出订正基线

目的：直接攻击参数编辑与响应分解的存在价值。

Prerequisites：P1-01, P1-03

Inputs/implementation：
- ConditionalRouter(context,action bank,metric,budget)->bounded coeff；用相同多步损失端到端训练；best-static/higher-rank static LoRA使用相同允许训练标签。
- TrajectoryResidualCorrector(context,Fref)->multi-lead physical correction；RecurrentResidualCorrector(current_state,context,step)->state correction并反馈到冻结主干。terminal-only作弱诊断，不能唯一residual baseline。
- Black-box edited forecast predictor共享训练样本，单列预测整场成本；regime lookup与EWMA保留。
- 表格同时匹配标签、上下文与训练预算；再报告参数匹配和cost-matched两种比较，不强迫无法同时相等的所有资源假装完全匹配。
- WeatherPEFT/Aurora学习思路可对照；直接复制外部实现先验证license和commit；天气回归不无理由使用分类熵TTA；任何历史监督适应使用合法已核验样本。

Outputs：`baseline_checkpoints/`, `training_costs.json`, `fairness_ledger.json`, `baseline_predictions/`

Pass：关键强baseline训练与evaluation可重复，fairness ledger无未说明的不等条件。

Fail：输出订正全面支配且无可复用优势 -> STOP-4；baseline未调通 -> BLOCKED claim，不跳过。

Next：进入P1-05/06前保持所有baseline冻结；后续不得只删除更强的baseline。

## P1-05 — 有限响应规划的实际执行闭环

目的：把分数变成真实一次编辑预报，再由后到真值验证，而不是只评估预测分数。

Prerequisites：P1-02, P1-03, P1-04

Inputs/implementation：
- plan_issue(IssueContext,prediction,MetricSpec,CostProfile)->EditPlan，强制feasible/noedit/immutableversion；未来truth不在依赖可达图。
- finite du analyticgain为主；bH-QP保留独立ablation，明确local surrogate标签。服务不运行teacher.verify_candidates来偷看真实收益。
- 首次原始point-gain策略只称pointplanner；selective empirical calibration只有独立校准可用才启用，校准策略冻结。
- 分别保存issue-time预测/选择和offlineactualevaluation；所有选择后的forecast真实运行且包含失败率，缓存命中必须权重hash匹配。
- costprofile计入上下文referencepass、head、selection和editedrollout；bank稀疏成本与总latency分列。

Outputs：`serving_predictions/`, `decisions.parquet`, `offline_metrics/`, `latency.json`, `selection_audit.md`

Pass：predicted选择的真实gain而非estimatedgain胜过预登记对照，且protected/latency符合政策。

Fail：真实gain不提升、oracle混入、成本预算不实 -> STOP/INVALID按对应规则。

Next：结果成立才P1-06；没有正收益自动noedit，不强制选最大负收益候选。

## P1-06 — 长轨迹、独立年份和论文主表

目的：检验短期收益是否保留、跨年是否有效，并形成真实论文证据。

Prerequisites：P1-05

Inputs/implementation：
- 按冻结协议打开final2020/shift2021–22；6/24/72/120/240h逐变量RMSE、ACC和预登记多变量目标；ACC climatology只用训练/固定公开参考，不拟合测试。
- time-block/bootstrap paireddifference，先确定块长敏感性；损坏/发散预测保留失效率与保守损失政策，不能自动dropna。
- 直接报告同一候选集的oracle regret、static gap、ranking、risk coverage、成本，及海陆/季节/训练期阈值定义的极端子集。
- 谱诊断没有真实SHT验证前不提供KE-spectrum绝对物理结论；普通wind/pressure/temperature drift保护指标先做。
- 图表全由artifact生成；不承诺跨backbone generality，未做第二主干明确限制。

Outputs：`overall_results.csv`, `ablations.csv`, `efficiency.csv`, `confidence_intervals.json`, `figures/`, `paper_evidence.md`

Pass：真实heldout增益、保护量非劣和长lead结果符合预登记区间要求；所有对照完整。

Fail：长轨迹系统性损害 -> STOP-5；跨年优势消失 -> 缩窄或STOP主张而非重新选年份。

Next：P1充分成立才可执行P2；主表失败不靠JEPA/memory救场。
