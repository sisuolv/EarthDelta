# Baseline implementation plan

| Baseline | 复用位置 / 外部参考 | 输入→输出 | 标签/推理条件与公平性 | 实施阶段 |
|---|---|---|---|---|
| F0 frozen | pinned official Stormer + bridge | current state→trajectory | 相同 checkpoint/normalization/rollout | P0-01 |
| Fs static LoRA | ExpertLoRA；Aurora LoRA 参考 | state→trajectory | 训练标签计入总账，独立freeze版本；不得假定存在 | P0-02/P1-04 |
| best-fixed / random edit | 当前 bank + actual finite evaluator | 固定id/固定seed→trajectory | static仅dev选；random含noedit协议；不看test truth | P0-03 |
| regime lookup | 新 simple baseline | legal context→bank id | train-only regime聚类，等量核验标签 | P0-04 |
| direct scalar gain | 新 DirectGainHead | context,action,metric→gain | 同bank/标签/teacher access；目标转移也接收metric | P0-04/P1-02 |
| b/H utility | InteractionUtilityHead | context→b,H | local surrogate明示；不冒充真实响应泛化 | P1-02 |
| conditional router/hypernetwork | BoundedProgramHead扩展+可微bridge | context,metric,budget→coeff | 多步actual loss端到端；同训练机会 | P1-04 |
| terminal residual | simple/neural residual | context,F0→末步订正 | 只弱诊断，不能唯一输出baseline | P0-04 |
| trajectory residual | joint multi-lead corrector | context,F0→多lead订正 | 同时训练多变量/多lead | P1-04 |
| recurrent residual | solver-in-loop思路，自有最小实现 | current state,step→状态订正 | 订正后反馈；成本和梯度预算公开 | P1-04 |
| bias/EWMA calibration | memory原语修复后 | 已available误差历史→bias | 不调用本次futuretruth；empty-history合法零回退 | P0-04 |
| black-box edited forecast | 新 EditedForecastHead | context,action→edited fields | 与响应头等资料和训练预算，模型容量公开 | P1-02 |
| oracle edit / e0 / du | paired/teacher/evaluator | truth仅offline→上限 | 不列成可部署方法，full finite oracle与local teacher分开 | P0-02/03 |
| SPW/ensemble | R07原文；代码重现需另核验 | 权重扰动→forecast ensemble | 概率指标与多轨迹成本另列，不能混淆单轨迹RMSE | P3可选 |
| WeatherPEFT / Aurora step LoRA | 官方实现参考 | 任务条件/步号→适配 | 不同任务/主干是背景先例；迁移版须重新实现/公平训练 | P1/P3按scope |
| 监督历史适应 TTA | 自有simple历史loss优化 | 已核验过去样本→coeff | no current futuretruth；分类entropy不能直接搬天气 | P1可选强对照 |

外部源码许可见 implementation/LITERATURE_TO_CODE.md。若无许可证，不复制源码；可独立实现论文公开思想并引用，且不宣称复现官方结果。
