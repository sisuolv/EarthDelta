#!/usr/bin/env python3
"""Validate this delivery package, not the EarthDelta implementation or results.

Uses only the Python standard library. A PASS does not unlock any scientific
stage and does not mean that a referenced/proposed repository file exists.
"""
from __future__ import annotations
import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote

REQUIRED = [
    'README.md','START_HERE_FOR_CODEX.md','EarthDelta_Research_Audit_CN.md',
    'EarthDelta_Codex_Execution_Plan.md','CODEX_TASKS.md','codex_tasks.json','STOP_CONDITIONS.md',
    'research/CURRENT_METHOD_AUDIT.md','research/NOVELTY_AUDIT.md','research/RELATED_WORK.md',
    'research/FINAL_RESEARCH_DECISION.md','research/EARTHDELTA_V2.md','research/literature_sources.json',
    'experiments/P0_SURVIVAL_EXPERIMENTS.md','experiments/P1_CORE_EXPERIMENTS.md',
    'experiments/P2_NOVELTY_EXPERIMENTS.md','experiments/BASELINES.md',
    'implementation/FILE_BY_FILE_PLAN.md','implementation/TEST_PLAN.md',
    'implementation/ARTIFACT_CONTRACT.md','implementation/REPRODUCIBILITY.md',
    'implementation/LITERATURE_TO_CODE.md','implementation/decision_policy_template.json',
    'evidence/repository_findings.json','evidence/source_ledger.json',
    'tools/audit_math.py','tools/validate_package.py'
]
TASK_FIELDS = ['id','title','priority','status','execution_allowed','depends_on',
               'scientific_purpose','files_to_inspect','files_to_modify','files_to_create',
               'implementation_requirements','must_not_change','tests_to_add','commands',
               'commands_status','artifacts','success_criteria','failure_criteria',
               'failure_action','decision_after_completion','commit_suggestion']


def validate(root: Path) -> dict:
    errors: list[str]=[]
    missing=[p for p in REQUIRED if not (root/p).is_file() or (root/p).stat().st_size==0]
    errors.extend('missing/empty: '+p for p in missing)
    parsed={}
    for p in root.rglob('*.json'):
        try:
            parsed[str(p.relative_to(root))]=json.loads(p.read_text(encoding='utf-8'))
        except (UnicodeError,json.JSONDecodeError) as e:
            errors.append(f'invalid JSON {p.relative_to(root)}: {e}')
    d=parsed.get('codex_tasks.json',{})
    tasks=d.get('tasks',[])
    ids=[t.get('id') for t in tasks]
    if len(ids)!=len(set(ids)) or any(not isinstance(x,str) for x in ids):
        errors.append('task IDs missing or duplicated')
    lookup={t.get('id'):t for t in tasks}
    for t in tasks:
        for field in TASK_FIELDS:
            if field not in t:
                errors.append(f"{t.get('id')}: missing field {field}")
        for dep in t.get('depends_on',[]):
            if dep not in lookup:
                errors.append(f"{t.get('id')}: unknown dependency {dep}")
        for field in ['commands','artifacts','success_criteria','failure_criteria','tests_to_add']:
            if not t.get(field):
                errors.append(f"{t.get('id')}: empty {field}")
        if t.get('status')!='TODO':
            errors.append(f"initial delivered task state is not TODO: {t.get('id')}")
    active=set(); visited=set(); topological=[]
    def visit(x: str) -> None:
        if x in active:
            raise ValueError('cyclic task graph: '+x)
        if x in visited or x not in lookup:
            return
        active.add(x)
        for dep in lookup[x].get('depends_on',[]):
            visit(dep)
        active.remove(x);visited.add(x);topological.append(x)
    try:
        for x in ids:
            if isinstance(x,str):visit(x)
    except ValueError as e:
        errors.append(str(e))
    allowed=[t['id'] for t in tasks if t.get('execution_allowed')]
    if allowed!=['P0-01']:
        errors.append('only P0-01 may initially be execution_allowed')
    if d.get('current_allowed_task')!='P0-01' or d.get('stop_after')!='P0-01' or d.get('auto_advance') is not False:
        errors.append('initial stop/authorization contract mismatch')
    if d.get('scientific_results_executed') is not False:
        errors.append('scientific-results flag must be false in the delivered package')
    report=(root/'EarthDelta_Research_Audit_CN.md').read_text(encoding='utf-8') if (root/'EarthDelta_Research_Audit_CN.md').exists() else ''
    expected=['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII','XIV']
    actual=re.findall(r'^## Part ([IVX]+) —',report,re.M)
    if actual!=expected:errors.append('full report does not contain ordered Parts I–XIV')
    papers=parsed.get('research/literature_sources.json',[])
    if not (10<=len(papers)<=20):errors.append('nearest-neighbor count outside requested 10–20')
    # Validate actual Markdown links only, not backticked proposed repo paths.
    relative_links=0
    for p in root.rglob('*.md'):
        text=p.read_text(encoding='utf-8')
        if text.count('```')%2:
            errors.append(f'unbalanced fenced blocks: {p.relative_to(root)}')
        for target in re.findall(r'(?<!!)\[[^\]\n]+\]\(([^\s)]+)\)',text):
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',target) or target.startswith('#'):
                continue
            dest=unquote(target.split('#',1)[0])
            if not dest:continue
            relative_links+=1
            if not (p.parent/dest).exists():
                errors.append(f'broken relative link in {p.relative_to(root)}: {target}')
    ledger=parsed.get('evidence/source_ledger.json',{})
    if not ledger.get('not_executed'):
        errors.append('missing execution limitations in evidence ledger')
    policy=parsed.get('implementation/decision_policy_template.json',{})
    if policy.get('status')!='UNFROZEN' or policy.get('policy_frozen_before_evaluation') is not False:
        errors.append('template must not pretend experimental thresholds were frozen')
    if policy.get('delta_noise') is not None or policy.get('delta_mde') is not None:
        errors.append('template must not contain fabricated measured effect thresholds')
    return {'scope':'delivery_package_structure_and_contract_only','weather_or_repository_validation':False,
            'generated_at_utc':datetime.now(timezone.utc).isoformat(),
            'status':'PASS' if not errors else 'FAIL','errors':errors,
            'required_files_count':len(REQUIRED),'task_count':len(tasks),'nearest_neighbor_count':len(papers),
            'task_graph_acyclic':not any('cyclic' in x for x in errors),'topological_order':topological,
            'initially_allowed_tasks':allowed,'report_parts':actual,'relative_links_checked':relative_links}


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    result=validate(args.root.resolve())
    out=args.output or args.root/'evidence'/'package_validation.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"{result['status']}: {result['task_count']} tasks, {result['nearest_neighbor_count']} neighbors, {len(result['report_parts'])} report parts.")
    print('Package check only; not scientific validation; does not unlock P0-02.')
    for error in result['errors']:print('ERROR:',error)
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
