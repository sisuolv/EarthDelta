#!/usr/bin/env python3
"""Standalone algebra checks, NOT EarthDelta tests or weather experiments.

Python standard library only. All examples are deliberately constructed; none
of the numerical values is a measured forecast score or a repository test result.
"""
from __future__ import annotations

import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

Vector = Sequence[float]


def sub(a: Vector, b: Vector) -> list[float]:
    if len(a) != len(b):
        raise ValueError('dimension mismatch')
    return [x - y for x, y in zip(a, b)]


def dot(a: Vector, b: Vector, q: Vector | None = None) -> float:
    if len(a) != len(b) or (q is not None and len(q) != len(a)):
        raise ValueError('dimension mismatch')
    if q is None:
        q = [1.0] * len(a)
    if any(w < 0 or not math.isfinite(w) for w in q):
        raise ValueError('nonnegative finite weights required')
    return sum(w * x * y for w, x, y in zip(q, a, b))


def gain(e: Vector, d: Vector, q: Vector | None = None) -> float:
    return 2.0 * dot(e, d, q) - dot(d, d, q)


def close(a: float, b: float, tol: float = 1e-10) -> bool:
    return math.isclose(a, b, rel_tol=tol, abs_tol=tol)


def run_checks() -> list[dict]:
    checks: list[dict] = []

    def record(name: str, passed: bool, detail: dict) -> None:
        checks.append({'name': name, 'passed': bool(passed), 'illustration': detail})

    y, f0, fa = [2.0, -1.5], [0.4, 0.8], [1.2, -0.2]
    s = lambda v: [x*x + math.sin(x) for x in v]
    e, d = sub(s(y), s(f0)), sub(s(fa), s(f0))
    q = [0.3, 1.7]
    direct = dot(e, e, q) - dot(sub(e, d), sub(e, d), q)
    record('same_nonlinear_summary_telescopes', close(gain(e,d,q), direct),
           {'expanded_gain': gain(e,d,q), 'direct_loss_difference': direct})
    lhs, rhs = s(sub(y, f0)), sub(s(y), s(f0))
    record('nonlinear_summary_does_not_commute_with_difference',
           any(not close(a,b) for a,b in zip(lhs,rhs)), {'S_y_minus_f': lhs, 'S_y_minus_S_f': rhs})

    e, eh, d = [1., 1000.], [1., 0.], [1., 0.]
    record('large_full_error_can_preserve_gain', close(gain(e,d), gain(eh,d)),
           {'e_prediction_squared_error': dot(sub(e,eh),sub(e,eh)), 'true_gain': gain(e,d), 'proxy_gain': gain(eh,d)})

    e, eh = [0.01,1000.], [-0.01,1000.]
    ds = [[0.01,0.],[-0.01,0.]]
    gs, ghs = [gain(e,d) for d in ds], [gain(eh,d) for d in ds]
    relative_error = dot(sub(e,eh),sub(e,eh))/dot(e,e)
    record('tiny_full_relative_error_can_reverse_ranking',
           gs[0] > gs[1] and ghs[0] < ghs[1] and relative_error < 1e-8,
           {'relative_squared_error': relative_error, 'actual_gains': gs, 'proxy_gains': ghs})

    e = [1.]
    separate, combined = gain(e,[1.]), gain(e,[2.])
    record('gram_overlap_is_required', close(separate,1.) and close(combined,0.),
           {'single_gain': separate, 'combined_gain': combined, 'incorrect_sum_of_singles': 2*separate})

    f = lambda a,b: a+b+20*a*b
    gamma = f(.5,.5)-f(.5,0)-f(0,.5)
    record('mixed_nonlinear_response_is_not_gram_overlap', close(gamma,5.),
           {'axis_jacobian': [1.,1.], 'linear_prediction':1., 'actual_combined_response':f(.5,.5), 'mixed_response':gamma})

    e,d,eta,xi,q=[1.2,-.3],[.4,.2],[.1,-.2],[-.05,.08],[2.,.7]
    eh,dh=[a+b for a,b in zip(e,eta)],[a+b for a,b in zip(d,xi)]
    actual = gain(eh,dh,q)-gain(e,d,q)
    decomposed = 2*dot(eta,d,q)+2*dot(sub(e,d),xi,q)+2*dot(eta,xi,q)-dot(xi,xi,q)
    record('gain_prediction_error_decomposition', close(actual,decomposed),
           {'gain_error':actual,'decomposed_error':decomposed})

    samples = [([1.,2.],[.2,.5]),([3.,1.],[.6,-.2]),([2.,4.],[-.1,.8]),([4.,3.],[.4,.1])]
    q=[.4,1.6]; n=len(samples)
    me=[sum(e[j] for e,d in samples)/n for j in range(2)]
    md=[sum(d[j] for e,d in samples)/n for j in range(2)]
    covariance = sum(dot(sub(d,md),sub(e,me),q) for e,d in samples)/n
    variance = sum(dot(sub(d,md),sub(d,md),q) for e,d in samples)/n
    lhs = sum(gain(e,d,q) for e,d in samples)/n
    rhs = gain(me,md,q)+2*covariance-variance
    record('expected_gain_includes_cross_covariance', close(lhs,rhs),
           {'expected_gain':lhs,'mean_only_gain':gain(me,md,q),'covariance_corrected':rhs})

    true_r0,true_ra,upper_r0,upper_ra=8.,8.9,10.,9.
    record('difference_of_risk_upper_bounds_is_not_gain_lower_bound',
           upper_r0>=true_r0 and upper_ra>=true_ra and upper_r0-upper_ra>true_r0-true_ra,
           {'actual_gain':true_r0-true_ra,'difference_of_valid_upper_bounds':upper_r0-upper_ra})

    actual,proxy=[0.,.4,.35],[0.,.3,.45]
    chosen=max(range(len(proxy)), key=proxy.__getitem__)
    epsilon=max(abs(a-b) for a,b in zip(actual,proxy))
    regret=max(actual)-actual[chosen]
    record('finite_argmax_regret_bound', regret<=2*epsilon+1e-12,
           {'selected':chosen,'regret':regret,'two_epsilon':2*epsilon})

    e,d=[1.,1000.],[1.,-.01]
    full,projected = gain(e,d),gain([e[0]],[d[0]])
    discarded=2*e[1]*d[1]-d[1]**2
    record('small_response_tail_can_change_benefit_sign', full<0<projected and close(full-projected,discarded),
           {'full_gain':full,'projected_gain':projected,'discarded_response_energy_fraction':d[1]**2/dot(d,d)})

    e,d,scales=[2.,-3.],[.4,-.2],[2.,5.]
    ez,dz=[a/s for a,s in zip(e,scales)],[a/s for a,s in zip(d,scales)]
    record('fixed_affine_scaling_changes_metric',close(gain(ez,dz),gain(e,d,[1/s**2 for s in scales])),
           {'scaled_space_gain':gain(ez,dz),'equivalent_original_weighted_gain':gain(e,d,[1/s**2 for s in scales])})
    return checks


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'evidence'/'math_sanity.json')
    args=ap.parse_args()
    checks=run_checks()
    result={'scope':'standalone_constructed_algebra_examples_only',
            'repository_tests_executed':False,'weather_experiments_executed':False,
            'generated_at_utc':datetime.now(timezone.utc).isoformat(),
            'status':'PASS' if all(x['passed'] for x in checks) else 'FAIL',
            'checks_count':len(checks),'checks':checks}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"{result['status']}: {len(checks)} standalone algebra checks. NOT weather or repository tests.")
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
