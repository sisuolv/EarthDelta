# STOP_CONDITIONS — scientific decision contract

## 状态不是二值

- `BLOCKED`：checkpoint / 数据 / 独立官方依赖 / 许可 / 配置 / 资源缺失。不得当科学失败，也不得用合成数据顶替。
- `INVALID`：泄漏、度量错、版本错、官方 parity 错、实际未来数据可达。停止这次实验，修复后新 run；历史结果作废但保留。
- `INCONCLUSIVE`：置信区间跨过决策阈值或样本不足。只按预登记规则增加样本，不得直接换指标/年份。
- `PASS_SCREEN`：通过开发集的继续投入门，不等于发表证据。
- `PASS`：对应任务全部工程条件与预先指定的科学条件满足；必须附 artifact/hash。
- `STOP` / `PIVOT`：当前主张失败或被更简单方案解释。不得通过加模块绕过。

## 固定度量

主损失 L_t(a)=Σ_h β_h Σ_v α_v Σ_i w_i[(F_a−Y)_{hvi}/s_v]^2，所有权重预先固定且各自归一化，s_v 来自训练期，不随候选或测试结果改变。主 screen 先用 72h 的同一固定多变量目标；Z500/T850/T2m/U10/V10/MSLP 分项和 24/120/240h 是保护/扩展，不准只选赢家。

主收益差异为 paired origin loss，不把网格点当独立样本。forecast 表逐变量使用 sqrt(聚合加权 MSE)，不是先开根号再平均。Z500 默认 geopotential m²/s²，若转 geopotential height 要明确除以固定 g0 并改单位。

## 阈值如何得到（不是随意指定 2%）

P0-01 在固定精度/硬件上重复无编辑参考推理，计算数值引起的 paired loss 差异，并冻结 δ_noise（相应绝对差的高分位数及置信上界）。这是数值可分辨阈值，不是业务意义阈值。

在独立开发 pilot 上估计 paired-loss 的时间块方差 σ_block、相关长度和可承担的最大独立块数 n_eff,max。样本量规划采用正态近似 δ_MDE=(z_0.975+z_0.8) σ_block/sqrt(n_eff,max)≈2.80 σ_block/sqrt(n_eff,max)，实际区间由 time-block bootstrap 给出。MDE 只表示该设计对效应的探测能力，不等于应用价值。

`decision_policy.json` 在后续 oracle/主比较前冻结：主指标、开发/校准/测试范围、block length、最大样本/最大 GPU-hours、δ_noise、δ_MDE、δ_practical（若有业务最低收益依据）、protected_harm_margin、alpha、最终单次检验方案。没有 operational relevance 依据时，`delta_practical=null` 并标记 `claim_scope=research_screen_only`；允许用 max(δ_noise,δ_MDE) 做资源投入 screen，但禁止称为业务收益已达标。不能把 δ_MDE 当事实上的 operational threshold。

如需要中途反复看结果，先指定 look 数与 alpha spending；默认只做一次固定样本量正式 gate。模型/字典/超参数试验预算同样登记。开发集选方案，测试集仅最后打开一次；统计结论以测试集为准。

## STOP-0 — Integrity

任何独立官方 parity、零系数+非零 bank、缓存指纹、未来标签隔离、UTC/coverage、finite constraints、metric identity 测试失败 → `INVALID`，不得训练主系统。官方不可运行 → `BLOCKED` 而不是“内部一致所以 PASS”。

## STOP-1 — No real edit / no oracle ceiling

首先检查 bank 存在非零 BA、非零 rollout response 且作用窗正确；全零银行是 `INVALID_DICTIONARY`，不是科学反证。

对冻结字典含 no-edit 的真实最优 a*_t 计算 I_oracle=E[L_t(0)−L_t(a*_t)]。若区间上界 U_oracle<δ_survival → STOP 当前字典。最多允许一次在方案中事先列明的 trained/structured bank fallback（只用 train/dev，不看最终 test）；仍失败则 STOP 参数编辑主线。若 L_oracle>δ_survival → PASS_SCREEN；否则 INCONCLUSIVE。

Oracle 是可用候选上的事后上限，不是服务结果；有限近似 QP teacher 不得标为 full oracle。

## STOP-2 — No dynamic headroom

从 train/dev 选 best-fixed 编辑 a_static 并锁定；不得用每个测试 origin 的 truth 选 static。计算 I_dynamic=E[L_t(a_static)−L_t(a*_t)]，以及相对不编辑的绝对收益，含成本。U_dynamic<δ_dynamic → PIVOT 静态校准并停止动态 planner 主张。不得使用“static 解释 80%”这类近零分母不稳定比率作为唯一条件。

## STOP-3 — No decision-relevant predictability

先分离 oracle-e+oracle-d、oracle-e+pred-d、pred-e+oracle-d、pred-both 四象限。与零响应、常数/平均响应、时间/季节均值和简单线性回归比较。以真实 gain、regret 与有 headroom 样本上的 ranking 为主，cosine/R² 只辅助。

在固定训练/调参预算内，若 predicted-both 相比 best-static 和强 direct gain 的改进上界不超过 δ_predict，且标签效率/目标转移也无可辨优势 → STOP factorized-planning 主张。完整 e0 R² 低不能单独触发停止；方向投影和 ranking 必须失败才有力。

## STOP-4 — Output correction dominates

匹配 context、标签、trainable parameters（同时报告总参数）、训练预算、候选响应 teacher access 与实测在线成本。比较 terminal、joint-trajectory、recurrent residual；后二者是强基线。

若参数编辑的收益不高于最强输出订正（改进区间上界≤0），成本不更低、保护变量/long rollout 不更好，且无预登记标签效率/目标转移优势 → STOP 参数编辑主线或 PIVOT 输出订正。成本不能只用 adapter rank 或 declared token cost 表示。

## STOP-5 — Unsafe trajectory / projection gaming

若 summary gain>0 而完整场/保护变量持续劣化，或 120/240h 的损害超过预登记 non-inferiority margin → STOP 该 summary/window/方法 claim。一次真实发散/NaN 立即触发工程停止并保存失败率，不能在统计表中删除该样本。

## STOP-6 — No reusable factorization advantage

在同信息、接收相同 metric/budget 输入的 direct-gain/router 下，响应路线在新权重/预算与核验标签受限设定均无改进 → 撤回“可复用”创新。不能把“不喂新目标给 baseline”造成的失效当作优势。

## STOP-7 — Calibration invalid

候选集合、metric、bank、backbone 或输入分布变化后不复核校准即声称安全 → INVALID claim。区间实际覆盖显著低于名义目标且无法通过预登记校准恢复 → no-edit 或放弃安全保证；不得把两项风险上界的差当作收益下界。

## 项目级决策

正确性门失败：修复，不宣称科学失败。资源门失败：BLOCKED。H1 失败：不投资主 head。H2 失败但 H3 成功：只可保留经证实的系统/经验贡献。H3 失败且 H2 无独立实证价值：STOP。第二主干未做不会抹去第一主干结果，但必须缩窄 generality claim。
