# EarthDelta Codex Execution Plan

## 0. Mission

在冻结天气模型与冻结编辑空间上，检验合法起报信息能否预测编辑的轨迹效应并产生可核验收益。当前为原语实现阶段，不是已验证天气方法。本轮**只执行 P0-01**，成功后写状态并停止。不要训练完整系统、申请额外服务或修改远端仓库；提交由用户既有工作流执行。

## 1. Repository Ground Truth

Repository: `sisuolv/EarthDelta`；branch `main`；审核 SHA `4fe55a7af90ea92f62a3232a571af92bfbd6114d`。重要目录 `earthdelta/`、`earthdelta/bridge/`、`earthdelta/data/`、`scripts/`、`tests/`、`plans/plans_v1_0919/`。

已读源码包含成对目标、finite/central响应、Gram几何、离线teacher、有限/连续规划、heads、LoRA、memory/spectral原语、bridge和split pipeline；只核查了部分测试与数据下载/架构范围，不能说全仓逐行证明。

README报告195项测试规模、192 passed/3 skipped、2020 ERA51464×69×128×256与本地Stormer权重；这些大文件和真实执行结果本轮未独立核验。当前真训练head、oracle ceiling、选择后weather skill **UNVERIFIED / 尚无本轮可验证artifact**；不把代码存在等同科学结果。实际state需要P0-01 inventory。

## 2. Scientific Contract

冻结 F_ref；零编辑必须复现同一个参考协议。F_ref=F0默认；Fs只有独立训练冻结后才可作为另一个参考，F0仍报告。Action bank不可在测试期依据truth改动。

未来truth只进offline训练标签/teacher/evaluator。Serving只接IssueContext与冻结artifact；公共函数的参数签名无truth还不够，需检查数据路径和缓存。No-edit必须精确零收益并总可选。

Finite response d(a)=S(F_a(X))−S(F_ref(X))；e=S(Y)−S(F_ref(X))；actual gain=2e^TQd−d^TQd；proxy gain用预测e/d，不能称未知真实收益的exact值。局部R的QP是另一个近似协议。保持同一metric、通道、单位、纬度、尺度、lead权重。

默认编辑前4个6h步，随后reference参数继续作用于已改变状态。不能重置状态来改善长期误差。程序默认只有一个bank；未见bank迁移需单独协议。

## 3. Non-goals

不为novelty添加JEPA/神经memory/dynamicrank/spectral loss；不扩展第二backbone；不做大规模训练；不重写无关主干；不将失败/NaN样本删除；不修改测试协议挑选更好年份；不运行未获许可外部代码；不把BLOCKED替换成synthetic PASS。

## 4. Current Blocking Questions

Q1：真实checkpoint是否与独立官方同协议等价？Q2：实际非零bank是否存在oracle收益？Q3：其收益超出best-static吗？Q4：对排序有用的du/e0投影是否可预测？Q5：factorization相对direct gain/router是否有标签效率/目标重用优势？Q6：参数编辑是否比trajectory/recurrent residual correction更值得？

## 5. Execution DAG

```text

P0-01 independent official/data/metric gate
  ├─ BLOCKED / INVALID → STOP this run; no scientific conclusion
  └─ PASS → P0-02 real nonzero bank + exact oracle ceiling
                ├─ STOP → one preregistered bank fallback, then STOP if still fails
                └─ PASS_SCREEN → P0-03 dynamic-vs-static + four quadrants
                                      ├─ no dynamic headroom → PIVOT static
                                      └─ PASS_SCREEN → P0-04 simple residual/direct-gain attack
                                                            ├─ dominated → STOP/PIVOT
                                                            └─ CONTINUE
                                                                ├─ P1-01 data → P1-02 heads
                                                                └─ P1-03 differentiable bridge
                                                                     ↓
                                                               P1-04 strong baselines
                                                                     ↓
                                                               P1-05 actual planner
                                                                     ↓
                                                               P1-06 heldout 6–240h
                                                                     ├─ P2-01 decision space/reuse
                                                                     ├─ P2-02 calibration/no-edit
                                                                     └─ P3 optional generality/diagnostics

```

## 6. Detailed Codex Tasks

所有新文件/CLI均是本计划要求实现的接口，**不声称当前仓库已存在**。先实现并做`--help`/unit测试，再运行相应命令。任务结果目录遵守不可覆盖合同。

### TASK P0-01 — 独立官方 S0 与可追溯数据合同

#### Scientific purpose

防止在错误归一化/错误参考实现/假零编辑等价上构建整条论文；这是本轮唯一可执行任务。

#### Prerequisites

无；首先确认当前仓库和必要资源。

#### Files to inspect

- README.md
- scripts/s0_gate.py
- earthdelta/bridge/stormer_arch.py
- earthdelta/bridge/stormer_bridge.py
- earthdelta/data/make_splits.py
- earthdelta/contracts.py
- tests/test_bridge.py
- tests/test_data.py

#### Files to modify

- scripts/s0_gate.py
- earthdelta/bridge/stormer_bridge.py
- earthdelta/data/make_splits.py
- earthdelta/contracts.py

#### Files to create

- earthdelta/metrics.py
- earthdelta/provenance.py
- earthdelta/data/validation.py
- configs/p0/s0.json
- tests/test_s0_official.py
- tests/test_metric_contract.py
- tests/test_data_integrity.py

#### Implementation requirements

- 新增 MetricSpec：variables/units/scales/latitude weights/lead weights/reduction；weighted_sse(pred,truth,spec)->(sse,weight_sum)，gain_from_pair 使用同一度量；消除 per-origin RMSE 平均的混淆。
- S0 CLI 使用 --config；输入 checkpoint_path、normalization_dir、era5_path、official_repo_dir、precision、origins。无默认硬编码个人路径；空值返回 BLOCKED 和具体缺失项，退出码2；不在 import 时安装依赖。
- 独立 import 官方 GlobalForecastIterativeModule 与官方 Stormer，固定 58dfee5...；禁止 sys.modules/mock 将官方类替换成本地类。读取官方 inference.py 的零增量均值与 fixed-interval rollout；官方多路径平均另标 protocol。
- 同一实际 checkpoint/69变量/网格/真实输入比较 official fixed6h 与 local fixed6h 的6/24/72h；先单模块 fp32 parity，再实际完整轨迹。容差来自同精度重复运行与事先记录的逐元素/metric envelope，不得观察结果后调大。
- 创建 B 非零的低秩 bank；coeff=0 与无 bank/官方等价；coeff≠0 有响应；计划结束后参数贡献归零但状态不重置；异常/重复调用无残留。
- NormalizationContract 严格 official 模式 diff_mean=0，增加非零 diff_mean fixture 检出误配；checkpoint SHA256 与 architecture ID 分开；rollout 自动核对 bank/model/normalization/interval。
- UTC-aware manifest；norm/grid hash 必须实际生成，拒绝 placeholder；validate actual time/channel/grid/finite/units；按当前 history/lead 检查实际 coverage，后续 240h 任务必须重新核查边界，不能沿用 168h guard；ERA5 availability 标为 retrospective 或真实 release_time。
- S0 overall gate 必须显式包含所有必要条件，包括 metric finite 与匹配官方同配置 RMSE；近似论文数值仅背景，不用于通过判定。先只检查一种与资源匹配的 checkpoint；ps2/ps4 不要求为不相关原因双下载。
- 记录环境/现有测试执行；若官方 xformers/真实权重/数据缺失，保存 BLOCKED；不能仅内部两路径一致就解除此门。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_independent_upstream_class
- test_zero_coeff_nonzero_bank
- test_diff_mean_official_zero
- test_timezone_invariance_utc
- test_reject_placeholder_hash
- test_rmse_failure_blocks_gate
- test_future_columns_rejected
- test_artifact_version_mismatch

#### Expected artifact

- status.json
- provenance.json
- metrics.json
- official_local_per_origin.parquet
- parity_report.md
- normalization_audit.json
- data_inventory.json

#### Success criteria

- 所有必需 pytest 条目通过；真实 checkpoint 官方/本地同协议满足预登记误差 envelope；所有 critical gate true。
- 实际 bytes/hash/coverage 可追溯；没有未说明的 missing/skipped 必需 real test。

#### Failure criteria

- 任一独立 parity/数据/zero-edit/metric/版本失败 -> INVALID。
- 缺官方依赖、真实数据/权重、足够资源 -> BLOCKED。

#### Decision after completion

PASS 后只更新 P0-01；记录允许下一轮解锁 P0-02，本次停止。BLOCKED/INVALID 禁止任何 P0-02+ 科学运行。

#### Commit suggestion

`fix(p0): establish independent Stormer parity and verified data contract`

#### Command（完成本任务实现后运行）

```bash
python scripts/s0_gate.py --config configs/p0/s0.json --output-root artifacts/p0/P0-01
```

### TASK P0-02 — 非退化编辑库与真实 oracle 上限

#### Scientific purpose

首先判断编辑动作本身是否有价值；不训练复杂 predictor。

#### Prerequisites

P0-01

#### Files to inspect

- earthdelta/lowrank.py
- earthdelta/contracts.py
- earthdelta/probe.py
- earthdelta/teacher.py
- earthdelta/selection.py

#### Files to modify

- earthdelta/selection.py
- earthdelta/contracts.py
- earthdelta/lowrank.py

#### Files to create

- earthdelta/intervention_bank.py
- scripts/build_edit_bank.py
- scripts/oracle_ceiling.py
- configs/p0/oracle.json
- tests/test_finite_feasibility.py
- tests/test_bank_response.py

#### Implementation requirements

- 统一 validate_candidate(offset, bound, max_active, costs,budget,max_candidates)；finite/continuous 入口均检查 finite、维度、support、幅度、成本，含精确零编辑和稳定 id tie-break。
- FrozenEditBank(manifest, adapters) 记录每个候选的实际权重 hash/rank/layer/系数/作用窗。默认单编辑候选，K 小且固定；不要先展开所有成对组合。
- 先做 B 非零、BA 范数、实际 du 超数值噪声、±幅度响应、恢复与重复性检查。随机非零 bank 仅作注入 sanity；scientific ceiling 必须对已训练/结构化且 freeze 的 bank 单独报告。
- 支持 train-only 小规模专家构造（不同 train regime/训练随机种子），固定非零训练系数后学习 A/B；禁止零 router×零 B 联合冷启动。无训练集 -> BLOCKED，不用 test truth 构造 bank。
- 预登记 bank A 与最多一次 bank B fallback，max trials；不能依据 oracle test 挑专家、窗长、幅度。reference 默认 F0，训练 Fs 必须另作独立基线。
- 只在 development origins 运行 frozen reference 与每个有限实际编辑，含6/24/72h及保护变量，cached_responses 保存实际 finite du；oracle 由真实加权损失枚举，不用局部 QP 拟合数值冒充。
- 脚本先做资源 pilot；在不看正式收益前锁定 N、block length、统计政策与 δ_survival；遵循 STOP_CONDITIONS 的区间决策。失败分支/NaN 不得丢弃。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_finite_rejects_outside_box
- test_finite_rejects_max_active_zero
- test_finite_nan_rejected
- test_zero_bank_not_scientific_ceiling
- test_oracle_includes_noedit
- test_no_test_label_bank_training
- test_gain_actual_not_linear_teacher

#### Expected artifact

- bank_manifest.json
- bank_checkpoint.pt
- decision_policy.json
- reference_predictions/
- candidate_responses/
- per_origin.parquet
- oracle_ceiling.json
- figures/oracle_ceiling.png

#### Success criteria

- 非零响应与回退通过；固定字典实际 oracle gain 的区间下界超过冻结 screen threshold。
- 训练/开发构造与最终 test 严格分开；成本和失败率保存。

#### Failure criteria

- 全零/退化 bank -> INVALID_DICTIONARY，不是证明科学无效。
- oracle gain 区间上界低于阈值且预登记 fallback 已失败 -> STOP 当前主线。

#### Decision after completion

PASS_SCREEN 才允许 P0-03；INCONCLUSIVE 只允许预登记样本扩展；STOP 不得进入 predictor 大训练。

#### Commit suggestion

`feat(p0): measure finite intervention oracle ceiling with fail-closed feasibility`

#### Command（完成本任务实现后运行）

```bash
python scripts/oracle_ceiling.py --config configs/p0/oracle.json --output-root artifacts/p0/P0-02
```

### TASK P0-03 — 静态之外的动态空间与瓶颈四象限

#### Scientific purpose

避免用静态适配即可解释的收益包装动态规划；区分响应误差与未来误差。

#### Prerequisites

P0-02

#### Files to inspect

- earthdelta/paired.py
- earthdelta/geometry.py
- earthdelta/heads.py
- earthdelta/teacher.py
- tests/test_earthdelta.py

#### Files to modify

- earthdelta/paired.py

#### Files to create

- earthdelta/analysis/headroom.py
- earthdelta/context.py
- scripts/headroom_decomposition.py
- configs/p0/headroom.json
- tests/test_headroom.py
- tests/test_paired_summary.py

#### Implementation requirements

- 修正 paired 文档符号/非线性 summary 断言；测试共同非线性 S 仍精确、S(error) 与 S(y)−S(f) 不可混用。
- best-static 只在独立训练/开发选择集固定；在独立 headroom 集比较 no-edit、static、origin oracle；不能同一集合同时选 static 并把无偏外推当事实。
- 新增 IssueContext 仅含 history/current/issue_time/version；初版 context 为 fixed low-dimensional spatial statistics 或冻结主干特征；如用 reference forward，计入在线成本，不称免费。
- 训练简单 ridge/linear e0、du、direct gain pilot，time-block crossfit，不引入 JEPA/memory；用4象限（true/true、true/pred、pred/true、pred/pred）计算 actual chosen gain/regret。
- 同时输出全 e0 R²、response-subspace 误差、gain-ranking；对无 oracle headroom 样本不滥用 top-k/cosine。zero response 有效性按明确分母约定标 NA。
- 比较 summary/full-field 选出的 oracle，测 summary-driven 选择导致的保护量损害；交互指示为真实 pair-minus-singles，不用 H 非对角代替。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_static_selection_disjoint
- test_four_oracle_quadrants
- test_large_orthogonal_error_irrelevant
- test_nonlinear_summary_identity
- test_summary_fullfield_disagreement
- test_context_no_truth

#### Expected artifact

- static_choice.json
- crossfit_splits.json
- four_quadrants.parquet
- dynamic_headroom.json
- summary_guard.json
- figures/bottleneck_quadrants.png

#### Success criteria

- 动态 oracle 超 static 的增量区间下界大于预登记 δ_dynamic。
- 至少一个 pilot predictor 具有超 naive 的决策信号，或明确定位单一可攻克瓶颈；不给大模型无条件放行。

#### Failure criteria

- U_dynamic<δ_dynamic -> PIVOT static。
- summary 提升而 full-field/保护量劣化 -> INVALID summary 主目标。

#### Decision after completion

通过动态空间且存在可检验信号才 P0-04；预测证据不足时保持 INCONCLUSIVE，不把完整 e0 低 R²单独定死刑。

#### Commit suggestion

`feat(p0): separate static headroom and decision-relevant prediction bottlenecks`

#### Command（完成本任务实现后运行）

```bash
python scripts/headroom_decomposition.py --config configs/p0/headroom.json --output-root artifacts/p0/P0-03
```

### TASK P0-04 — 最小残差订正与直接收益挑战

#### Scientific purpose

在投入复杂系统前，检查更简单的输出订正或标量 gain 是否已解释全部收益。

#### Prerequisites

P0-03

#### Files to inspect

- earthdelta/context.py
- earthdelta/heads.py
- earthdelta/metrics.py

#### Files to modify

- 无；本任务以新增模块为主。

#### Files to create

- earthdelta/baselines/simple.py
- scripts/p0_baseline_challenge.py
- configs/p0/baselines.json
- tests/test_baseline_fairness.py

#### Implementation requirements

- 实现同 context 的 climatological bias、EWMA（仅合法历史，或明确禁用）、ridge joint-trajectory residual、action-conditioned scalar gain 和 regime lookup；所有 feature/label/time split 同等。
- 最小 baseline 是 survival screen，不作为最终强 neural residual 论文对照。若已有简单方法全面支配，需要先说明新的可证伪优势而不是继续堆模块。
- 记录训练标签条数、无标签响应生成次数、训练开销、推理 context cost；上界 oracle 不参与 serving。
- 比较预测编辑、best-static、output correction 的 paired gain、成本和保护量，冻结下一阶段 baseline 清单和定量统计政策。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_same_context_and_split
- test_ewma_available_time
- test_oracle_never_serving
- test_residual_shared_multilead_metric

#### Expected artifact

- baseline_results.parquet
- fairness_ledger.json
- p0_decision.md
- frozen_p1_protocol.json

#### Success criteria

- P0-01~03 均通过且预测路线未被所有更简单方法全面支配；明确剩余可检验优势。

#### Failure criteria

- 简单输出订正/直接 gain 在收益、成本、保护量全面支配且无标签/目标转移假设证据 -> STOP 或 PIVOT。

#### Decision after completion

只有在 p0_decision.md 写明 CONTINUE、证据路径齐全时解锁 P1；结果不明维持 INCONCLUSIVE。

#### Commit suggestion

`feat(p0): add matched residual and direct-gain survival baselines`

#### Command（完成本任务实现后运行）

```bash
python scripts/p0_baseline_challenge.py --config configs/p0/baselines.json --output-root artifacts/p0/P0-04
```

### TASK P1-01 — 真实成对轨迹数据集与可用信息接口

#### Scientific purpose

将无标签响应模拟与延迟真值监督分离，建立可复用训练证据。

#### Prerequisites

P0-04

#### Files to inspect

- earthdelta/data/pull_wb2.py
- earthdelta/data/make_splits.py
- earthdelta/context.py
- earthdelta/probe.py

#### Files to modify

- earthdelta/context.py

#### Files to create

- earthdelta/data/paired_dataset.py
- scripts/build_response_dataset.py
- configs/p1/dataset.json
- tests/test_paired_dataset.py

#### Implementation requirements

- PairedTrajectoryDataset 返回 IssueContext、action descriptors、du labels、verification_mask；TruthBatch 只在训练损失/evaluator 参数中出现。
- train2015–18，2019按连续块分dev/calibration，final2020和shift2021–22，缺少任何范围明确 BLOCKED；用实际 coverage而非年份循环生成记录。
- fixed linear area-weighted summary S，必要时训练集拟合 basis；原场预测可另存低频样本供保护评价。保存6/24/72/120/240h，作用窗不随 lead 偷改。
- 缓存键包含 input content、checkpoint、bank、normalizer、grid、summary、interval、window；响应 finite 与 local R 带不同 schema。
- 标签效率实验分别 subsample 核验 origin 和保持合法无标签 d 数据量；base/银行训练用过的标签也记录总账。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_cache_rejects_changed_weights
- test_future_label_mask
- test_block_overlap_forbidden
- test_summary_fit_train_only
- test_lead240_coverage

#### Expected artifact

- paired_manifest.parquet
- context_features/
- du_labels/
- verified_labels/
- dataset_card.md
- provenance.json

#### Success criteria

- 实际样本/所有hash/coverage通过；不存在跨split重叠核验或不可达标签。

#### Failure criteria

- 版本冲突、未来标签路径泄漏 -> INVALID；数据缺口 -> BLOCKED。

#### Decision after completion

只在真实 dataset audit PASS 后允许P1-02。

#### Commit suggestion

`feat(data): add versioned issue-time paired trajectory dataset`

#### Command（完成本任务实现后运行）

```bash
python scripts/build_response_dataset.py --config configs/p1/dataset.json --output-root artifacts/p1/P1-01
```

### TASK P1-02 — e0/du、bH、直接收益预测头训练

#### Scientific purpose

以匹配条件实证 factorization 是否比直接 scalar gain 值得。

#### Prerequisites

P1-01

#### Files to inspect

- earthdelta/heads.py
- earthdelta/geometry.py
- earthdelta/paired.py

#### Files to modify

- earthdelta/heads.py
- earthdelta/paired.py

#### Files to create

- earthdelta/training/response.py
- scripts/train_response_heads.py
- configs/p1/heads.json
- tests/test_head_losses.py

#### Implementation requirements

- 复用 ReferenceErrorHead/EditResponseHead；让 memory可选且默认禁用，gain calibration 默认关闭；输出 raw e0、du、analytic_gain，learned_score独立字段。
- 加入 DirectGainHead(context,action,metric_descriptor,budget_descriptor)->scalar，及 EditedForecastHead / predicted bH 比较；预算不影响真实候选gain但可影响选择，禁止混淆。
- 训练同一固定 Q 下weighted losses；zero edit du=0/gain=0做结构约束；正确处理lead和action permutation。
- 先3个固定训练seed（只是初始重复设计，不代表足够 statistical power）；保持超参搜索预算相同；label fractions在protocol预登记，no futuretruth at validation serving。
- 报告cosine/R²/norm calibration、4象限actual regret、lead degradation；禁止只用训练loss宣布预测成功。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_zero_edit_structural_zero
- test_weighted_gain_matches_metrics
- test_memory_none_supported
- test_score_calibration_separate
- test_action_permutation_equivariance
- test_losses_respect_label_mask

#### Expected artifact

- head_checkpoints/
- training_history.json
- per_origin_predictions.parquet
- oracle_quadrants.json
- label_efficiency.csv

#### Success criteria

- predicted both相对static/naive有真实heldout gain；head差异的决策影响可解释。

#### Failure criteria

- 固定训练预算后decision signal≈naive且无projection空间信号 -> STOP-3。

#### Decision after completion

通过后进入实际planner；du/e0某一瓶颈失败则仅执行预登记对应消融，不加入未授权模块。

#### Commit suggestion

`feat(model): train metric-consistent response and direct-gain heads`

#### Command（完成本任务实现后运行）

```bash
python scripts/train_response_heads.py --config configs/p1/heads.json --output-root artifacts/p1/P1-02
```

### TASK P1-03 — 可微逐样本计划与显式低秩注入

#### Scientific purpose

支持公平的端到端 router 和 recurrent correction 基线，消除 tuple 脱梯度与批共享限制。

#### Prerequisites

P0-04

#### Files to inspect

- earthdelta/bridge/stormer_bridge.py
- earthdelta/bridge/stormer_arch.py
- earthdelta/lowrank.py

#### Files to modify

- earthdelta/bridge/stormer_bridge.py

#### Files to create

- earthdelta/bridge/controlled_projection.py
- tests/test_differentiable_rollout.py

#### Implementation requirements

- 新增 controlled_trajectory(bridge,x_norm,variables,interval,coefficients[B,K],bank,hold_steps,requested_leads)->tensor[B,H,V,lat,lon]。系数tensor保持梯度；不要 torch.tensor(existing_tensor) 重建。
- 保留旧 EditPlan serving wrapper，由其转换进入新的显式路径；旧单plan API不破坏。冻结主干/银行时仍允许梯度对coeff传播。
- 在可控 projection 包装中显式传递系数/步号，避免共享 mutable hooks；若暂留hook则显式串行限制并禁止并发，不能声称已线程安全。
- 验证dense/sparse、batched/unbatched、zero/nonzero、window-end、异常恢复与官方 parity；不可重写注意力/归一化等无关层。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_coeff_gradient_nonzero
- test_batch_distinct_plans
- test_reference_params_frozen
- test_dense_sparse_parity
- test_trajectory_final_matches_legacy
- test_no_cross_call_plan_state

#### Expected artifact

- pytest.log
- gradient_audit.json
- parity_report.md

#### Success criteria

- coefficients梯度正确且主干不更新；所有兼容/恢复/官方测试通过。

#### Failure criteria

- grad断开/批间计划污染/zero-edit偏移 -> INVALID。

#### Decision after completion

PASS解锁强router/recurrent baseline；不要在无可微路径时用较弱替身声称公平。

#### Commit suggestion

`feat(bridge): add differentiable batched intervention trajectories`

#### Command（完成本任务实现后运行）

```bash
python -m pytest tests/test_differentiable_rollout.py tests/test_s0_official.py -q
```

### TASK P1-04 — 强 router、LoRA 和输出订正基线

#### Scientific purpose

直接攻击参数编辑与响应分解的存在价值。

#### Prerequisites

P1-01, P1-03

#### Files to inspect

- earthdelta/heads.py
- earthdelta/bridge/stormer_bridge.py
- earthdelta/lowrank.py

#### Files to modify

- 无；本任务以新增模块为主。

#### Files to create

- earthdelta/baselines/neural.py
- earthdelta/baselines/peft.py
- scripts/train_baselines.py
- configs/p1/baselines.json
- tests/test_neural_baselines.py

#### Implementation requirements

- ConditionalRouter(context,action bank,metric,budget)->bounded coeff；用相同多步损失端到端训练；best-static/higher-rank static LoRA使用相同允许训练标签。
- TrajectoryResidualCorrector(context,Fref)->multi-lead physical correction；RecurrentResidualCorrector(current_state,context,step)->state correction并反馈到冻结主干。terminal-only作弱诊断，不能唯一residual baseline。
- Black-box edited forecast predictor共享训练样本，单列预测整场成本；regime lookup与EWMA保留。
- 表格同时匹配标签、上下文与训练预算；再报告参数匹配和cost-matched两种比较，不强迫无法同时相等的所有资源假装完全匹配。
- WeatherPEFT/Aurora学习思路可对照；直接复制外部实现先验证license和commit；天气回归不无理由使用分类熵TTA；任何历史监督适应使用合法已核验样本。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_router_same_information
- test_recurrent_correction_feedback
- test_baseline_metric_budget_condition
- test_adapter_training_not_zero_product
- test_total_label_budget_logged

#### Expected artifact

- baseline_checkpoints/
- training_costs.json
- fairness_ledger.json
- baseline_predictions/

#### Success criteria

- 关键强baseline训练与evaluation可重复，fairness ledger无未说明的不等条件。

#### Failure criteria

- 输出订正全面支配且无可复用优势 -> STOP-4；baseline未调通 -> BLOCKED claim，不跳过。

#### Decision after completion

进入P1-05/06前保持所有baseline冻结；后续不得只删除更强的baseline。

#### Commit suggestion

`feat(baselines): add matched router and trajectory residual challengers`

#### Command（完成本任务实现后运行）

```bash
python scripts/train_baselines.py --config configs/p1/baselines.json --output-root artifacts/p1/P1-04
```

### TASK P1-05 — 有限响应规划的实际执行闭环

#### Scientific purpose

把分数变成真实一次编辑预报，再由后到真值验证，而不是只评估预测分数。

#### Prerequisites

P1-02, P1-03, P1-04

#### Files to inspect

- earthdelta/selection.py
- earthdelta/contracts.py
- earthdelta/metrics.py

#### Files to modify

- earthdelta/selection.py

#### Files to create

- earthdelta/planner.py
- scripts/evaluate_planner.py
- configs/p1/planner.json
- tests/test_serving_boundary.py

#### Implementation requirements

- plan_issue(IssueContext,prediction,MetricSpec,CostProfile)->EditPlan，强制feasible/noedit/immutableversion；未来truth不在依赖可达图。
- finite du analyticgain为主；bH-QP保留独立ablation，明确local surrogate标签。服务不运行teacher.verify_candidates来偷看真实收益。
- 首次原始point-gain策略只称pointplanner；selective empirical calibration只有独立校准可用才启用，校准策略冻结。
- 分别保存issue-time预测/选择和offlineactualevaluation；所有选择后的forecast真实运行且包含失败率，缓存命中必须权重hash匹配。
- costprofile计入上下文referencepass、head、selection和editedrollout；bank稀疏成本与总latency分列。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_teacher_not_reachable_from_serving
- test_noop_when_no_positive_score
- test_tie_break_stable_id
- test_changed_bank_rejected
- test_selected_forecast_actually_run

#### Expected artifact

- serving_predictions/
- decisions.parquet
- offline_metrics/
- latency.json
- selection_audit.md

#### Success criteria

- predicted选择的真实gain而非estimatedgain胜过预登记对照，且protected/latency符合政策。

#### Failure criteria

- 真实gain不提升、oracle混入、成本预算不实 -> STOP/INVALID按对应规则。

#### Decision after completion

结果成立才P1-06；没有正收益自动noedit，不强制选最大负收益候选。

#### Commit suggestion

`feat(planner): execute finite response plans with audited information boundaries`

#### Command（完成本任务实现后运行）

```bash
python scripts/evaluate_planner.py --config configs/p1/planner.json --output-root artifacts/p1/P1-05
```

### TASK P1-06 — 长轨迹、独立年份和论文主表

#### Scientific purpose

检验短期收益是否保留、跨年是否有效，并形成真实论文证据。

#### Prerequisites

P1-05

#### Files to inspect

- earthdelta/metrics.py
- earthdelta/data/make_splits.py
- earthdelta/spectral.py

#### Files to modify

- 无；本任务以新增模块为主。

#### Files to create

- earthdelta/evaluation.py
- scripts/evaluate_publication.py
- scripts/make_paper_tables.py
- configs/p1/publication.json
- tests/test_aggregation.py

#### Implementation requirements

- 按冻结协议打开final2020/shift2021–22；6/24/72/120/240h逐变量RMSE、ACC和预登记多变量目标；ACC climatology只用训练/固定公开参考，不拟合测试。
- time-block/bootstrap paireddifference，先确定块长敏感性；损坏/发散预测保留失效率与保守损失政策，不能自动dropna。
- 直接报告同一候选集的oracle regret、static gap、ranking、risk coverage、成本，及海陆/季节/训练期阈值定义的极端子集。
- 谱诊断没有真实SHT验证前不提供KE-spectrum绝对物理结论；普通wind/pressure/temperature drift保护指标先做。
- 图表全由artifact生成；不承诺跨backbone generality，未做第二主干明确限制。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_rmse_aggregate_before_sqrt
- test_acc_fixed_climatology
- test_failure_samples_retained
- test_block_bootstrap_no_pixel_independence
- test_extreme_threshold_train_only

#### Expected artifact

- overall_results.csv
- ablations.csv
- efficiency.csv
- confidence_intervals.json
- figures/
- paper_evidence.md

#### Success criteria

- 真实heldout增益、保护量非劣和长lead结果符合预登记区间要求；所有对照完整。

#### Failure criteria

- 长轨迹系统性损害 -> STOP-5；跨年优势消失 -> 缩窄或STOP主张而非重新选年份。

#### Decision after completion

P1充分成立才可执行P2；主表失败不靠JEPA/memory救场。

#### Commit suggestion

`feat(eval): publish traceable heldout trajectory and efficiency evidence`

#### Command（完成本任务实现后运行）

```bash
python scripts/evaluate_publication.py --config configs/p1/publication.json --output-root artifacts/p1/P1-06
```

### TASK P2-01 — 决策子空间与目标/预算重用

#### Scientific purpose

验证比完整误差预测更弱的信息是否足够决策，并证明响应分解的具体额外价值。

#### Prerequisites

P1-06

#### Files to inspect

- earthdelta/heads.py
- earthdelta/geometry.py
- earthdelta/context.py

#### Files to modify

- 无；本任务以新增模块为主。

#### Files to create

- earthdelta/decision_space.py
- scripts/decision_transfer.py
- configs/p2/transfer.json
- tests/test_decision_space.py

#### Implementation requirements

- train-only固定basis U和response-span投影；比较full e0、projected e0、direct b、direct gain，报告保留响应能量与实际regret，不能只报告压缩率。
- 冻结head后改变预登记MetricSpec权重/预算；权重变化限定在保留空间内；direct-gain/router也接收目标与预算或等量再校准。
- 新专家测试分成已有bank未见组合、未见bank零probe、未见bank少量无标签probe；当前descriptor无权重表征，最后两者不能冒充按构造zero-shot。
- 有限pair response直接缓存用于组合holdout，分析gamma_ij；若采用Jacobian只作局部对照并测linearity radius；不新增第三条主创新。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_projection_decision_sufficiency
- test_metric_reweight_within_basis
- test_new_bank_protocol_labeled
- test_pair_interaction_not_gram_overlap

#### Expected artifact

- decision_space.json
- label_efficiency.csv
- metric_budget_transfer.csv
- combination_holdout.csv
- claim_decision.md

#### Success criteria

- 相对条件化强baseline，在预登记label/transfer场景有可辨提升且成本计入。

#### Failure criteria

- 无额外优势 -> STOP-6，撤回factorization更强方法claim。

#### Decision after completion

只保留被实验支持的label-efficiency/metric-transfer贡献；失败不回收模块堆叠。

#### Commit suggestion

`feat(p2): test decision-sufficient response representations and reuse`

#### Command（完成本任务实现后运行）

```bash
python scripts/decision_transfer.py --config configs/p2/transfer.json --output-root artifacts/p2/P2-01
```

### TASK P2-02 — 候选集级收益校准与不编辑策略

#### Scientific purpose

不借助虚假独立性或上界作差，直接控制候选收益被高估的风险。

#### Prerequisites

P1-06

#### Files to inspect

- earthdelta/planner.py
- earthdelta/selection.py

#### Files to modify

- 无；本任务以新增模块为主。

#### Files to create

- earthdelta/calibration.py
- scripts/calibrate_intervention_risk.py
- configs/p2/calibration.json
- tests/test_gain_calibration.py

#### Implementation requirements

- 使用单独2019calibration连续块计算r_t=max_a(ghat_ta−g_ta)，固定高分位数q；LCB=ghat−q；noedit按真实零收益特殊处理；校准及保护规则在final前冻结。
- 固定candidate集合/metric/version分组；不同K与新bank必须重新说明校准适用性；不得把两个剩余风险上界相减当gain LCB。
- 报告coverage-vs-edit-rate、actual gain、harm frequency、no-edit rate、shift coverage；时间依赖只给经验结果/显式假设，不宣称distribution-free operational guarantee。
- 与uncertainty-only gating、scalar-gain校准、pointplanner比较；联合概率e0/du模型仅在资源许可且协方差可估计时作额外消融，不进入默认。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_max_over_candidate_calibration
- test_noop_exact_zero
- test_risk_upper_difference_not_lcb
- test_changed_metric_invalidates_calibration
- test_calibration_test_split_disjoint

#### Expected artifact

- calibration_state.json
- coverage.csv
- selective_gain.csv
- shift_calibration.md
- figures/risk_coverage.png

#### Success criteria

- 校准后可编辑覆盖率下actual risk/gain优于强gating且保护量满足声明；覆盖假设清楚。

#### Failure criteria

- 校准外推崩溃/无价值/noop几乎全退但无有效gain -> 缩窄安全声明或STOP-7。

#### Decision after completion

只在被测分布和候选条件下保留selective-planning主张；超出条件默认noedit/需再校准。

#### Commit suggestion

`feat(p2): calibrate candidate-set gain overestimation and abstention`

#### Command（完成本任务实现后运行）

```bash
python scripts/calibrate_intervention_risk.py --config configs/p2/calibration.json --output-root artifacts/p2/P2-02
```

### TASK P3-01 — 第二 checkpoint / 第二 backbone

#### Scientific purpose

在主线已成立后检验结论的可迁移范围，不作为掩盖单主干失败的方法。

#### Prerequisites

P1-06

#### Files to inspect

- earthdelta/bridge/
- reference/_manifest.json

#### Files to modify

- 无；本任务以新增模块为主。

#### Files to create

- configs/p3/generalization.json
- scripts/evaluate_backbone_transfer.py
- tests/test_backbone_contract.py

#### Implementation requirements

- 先同架构另一Stormer checkpoint并重新做S0/cache；再按资源选第二backbone；数据/权重/源码许可分别核验。
- 每个backbone重新构建/固定bank，不把跨参数坐标缓存复用当迁移；报告方法迁移与权重zero-shot是不同命题。
- 可以使用Aurora官方LoRA作为先例/对照；它不是自动适配Stormer的drop-in baseline。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_backbone_specific_version
- test_no_cross_arch_cache_reuse

#### Expected artifact

- second_backbone_gate.json
- generalization_results.csv
- limitations.md

#### Success criteria

- 独立gate通过并复现核心现象；否则如实限定Stormer。

#### Failure criteria

- 第二主干失败 -> 缩窄generality，不否认已验证第一主干结果。

#### Decision after completion

只有资源与P1结果允许时执行；当前不得创建大规模下载任务。

#### Commit suggestion

`feat(p3): evaluate independently gated backbone generalization`

#### Command（完成本任务实现后运行）

```bash
python scripts/evaluate_backbone_transfer.py --config configs/p3/generalization.json --output-root artifacts/p3/P3-01
```

### TASK P3-02 — 极端事件与物理诊断的定向扩展

#### Scientific purpose

仅在具体失败模式被主线结果识别后扩展分析，而非为novelty叠模块。

#### Prerequisites

P1-06

#### Files to inspect

- earthdelta/spectral.py
- earthdelta/memory.py

#### Files to modify

- 无；本任务以新增模块为主。

#### Files to create

- configs/p3/diagnostics.json
- scripts/analyze_extreme_regimes.py
- tests/test_physical_diagnostics.py

#### Implementation requirements

- 训练期阈值/外部事件目录预定义极端，报告事件级bootstrap和全部事件，而非只展示个案。
- 使用球面节点/归一化已验证的SHT才增加KE/anisotropy；谱能量与相位/原风场并列。
- JEPA/memory/dynamicrank默认仍关闭；任何加入必须新增单独研究决策，写明哪项failure和如何消融；不能由本任务自动解锁所有模块。

#### Must NOT change

- 冻结参考主干与 bank 的版本；训练参考 Fs 时另建版本且保留 F0。
- 本次未来 truth 只能进入 offline evaluator / teacher，不进入 serving predictor。
- 固定 split、MetricSpec、no-edit、作用窗和成本协议；不根据结果更改。
- 保留既有正确 API 和 tests，禁止无关重写/删除失败结果。

#### Tests to add

- test_event_definition_no_test_tuning
- test_spherical_nodes_and_normalization
- test_energy_phase_distinction

#### Expected artifact

- event_results.csv
- physical_diagnostics.csv
- failure_modes.md

#### Success criteria

- 新的分析结论可重复且不改变原主表协议。

#### Failure criteria

- 指标/事件泄漏 -> INVALID；缺SHT正确性 -> BLOCKED该指标。

#### Decision after completion

保持为Optional分析；失败不追加未经授权的大模型模块。

#### Commit suggestion

`feat(p3): add preregistered regime and physical diagnostics`

#### Command（完成本任务实现后运行）

```bash
python scripts/analyze_extreme_regimes.py --config configs/p3/diagnostics.json --output-root artifacts/p3/P3-02
```

## 7. P0 — Project Survival Tests

依次P0-01~04；任何科学强训练之前完成。P0-01本次唯一解锁，P0-02不能以全零bank测oracle；P0-03的dynamic margin不能被static总提升替代；P0-04不是最终弱baseline许可证。

## 8. P1 — Core Paper Implementation

P0书面CONTINUE后，先成对数据与可微接口，再头/强baseline，最后actualplanner与final heldout。P1-03可与数据准备并行，但当前没有授权执行。

## 9. P2 — Novelty Enhancement

最多两条：P2-01决策充分表示与目标/预算重用；P2-02候选集级收益校准。局部Jacobian/组合响应仅是P2-01的受控消融，非第三主线。

## 10. P3 — Optional / Future Work

第二主干和极端/物理诊断只有P1完成后执行。JEPA/memory/dynamicrank没有自动解锁任务，需新的失败模式证据及研究决策。

## 11. Baseline Implementation Plan


| Baseline | 复用位置 / 外部参考 | 输入→输出 | 标签/推理条件与公平性 | 实施阶段 |
|---|---|---|---|---|
| F0 frozen | pinned official Stormer + bridge | current state→trajectory | 相同 checkpoint/normalization/rollout | P0-01 |
| Fs static LoRA | ExpertLoRA；Aurora LoRA 参考 | state→trajectory | 训练标签计入总账，独立freeze版本；不得假定存在 | P0-02/P1-04 |
| best-fixed / random edit | 当前 bank + actual finite evaluator | 固定id/固定seed→trajectory | static仅dev选；random含noedit协议；不看test truth | P0-03 |
| regime lookup | 新 simple baseline | legal context→bank id | train-only regime聚类，等量核验标签 | P0-04 |
| direct scalar gain | 新 DirectGainHead | context,action,metric→gain | 同bank/标签/teacher access；目标转移也接收metric | P0-04/P1-02 |
| b/H utility | InteractionUtilityHead | context→b,H | local surrogate明示；不冒充真实响应泛化 | P1-02 |
| conditional router/hypernetwork | BoundedProgramHead扩展+可微bridge | context,metric,budget→coeff | 多步actual loss端到端；同训练机会 | P1-04 |
| terminal residual | simple/neural residual | context,F0→末步订正 | 只弱诊断，不能唯一输出baseline | P0-04 |
| trajectory residual | joint multi-lead corrector | context,F0→多lead订正 | 同时训练多变量/多lead | P1-04 |
| recurrent residual | solver-in-loop思路，自有最小实现 | current state,step→状态订正 | 订正后反馈；成本和梯度预算公开 | P1-04 |
| bias/EWMA calibration | memory原语修复后 | 已available误差历史→bias | 不调用本次futuretruth；empty-history合法零回退 | P0-04 |
| black-box edited forecast | 新 EditedForecastHead | context,action→edited fields | 与响应头等资料和训练预算，模型容量公开 | P1-02 |
| oracle edit / e0 / du | paired/teacher/evaluator | truth仅offline→上限 | 不列成可部署方法，full finite oracle与local teacher分开 | P0-02/03 |
| SPW/ensemble | R07原文；代码重现需另核验 | 权重扰动→forecast ensemble | 概率指标与多轨迹成本另列，不能混淆单轨迹RMSE | P3可选 |
| WeatherPEFT / Aurora step LoRA | 官方实现参考 | 任务条件/步号→适配 | 不同任务/主干是背景先例；迁移版须重新实现/公平训练 | P1/P3按scope |
| 监督历史适应 TTA | 自有simple历史loss优化 | 已核验过去样本→coeff | no current futuretruth；分类entropy不能直接搬天气 | P1可选强对照 |

外部源码许可见 implementation/LITERATURE_TO_CODE.md。若无许可证，不复制源码；可独立实现论文公开思想并引用，且不宣称复现官方结果。

## 12. Evaluation Contract

Forecast：统一weighted MSE及逐变量RMSE、ACC，lead6/24/72/120/240h。Intervention：actual/oracle/predicted gain分列、regret、top-k recall（只对defined/nontrivial样本）、Spearman/Kendall及负收益触发率。Response：Q-cosine、R²与norm error，零范数记NA。Efficiency：总/可训练参数、offlinecalls/训练成本、online额外referencepass/前向次数/medianP95 latency/peakmemory。Rollout：主变量/保护量/failed trajectory rate，不把spectrum当fullfield替代。最终推断按起报time-block；见下文冻结阈值政策。

## 13. Artifact Contract


每次实验使用不可覆盖目录 `artifacts/p{0,1,2,3}/<TASK_ID>/<UTC timestamp>_<git-short>_<nonce>/`。目录已存在就退出，不自动 overwrite。Failed/blocked run 同样保存记录；不清理失败数据来改善结果。

最少文件：`config.json`、`metrics.json`、`summary.md`、`stdout.log`、`provenance.json`、`status.json`、`command.txt`。有逐样本结果时增加 `predictions/` 与 `per_origin.parquet`；图表放 `figures/`。`metrics.json` 未运行的值为 null 并标原因，禁止 0、NaN 或随机占位值冒充结果；JSON allow_nan=false。

`status.json` 包含 task_id、status、prerequisite_runs、blocking_reasons、decision、next_allowed_task；`provenance.json` 包含完整 git commit/dirty diff hash、checkpoint SHA256、bank SHA256、normalization/key order/array digests、grid actual coordinate digest、summary/metric digest、split manifest digest、seeds、硬件/软件/精度、数据版本与可用时间语义。

`per_origin.parquet` 至少：origin_id、issue_time_utc、split_id、event_block_id、method、candidate_id、lead_hours、variable、weighted_sse、weight_sum、reference_sse、predicted_gain、actual_gain（offline evaluator 才写）、declared_cost、measured_latency、status、failure_reason。

预测输出和后到的 oracle 评估分别保存：服务结果文件中不写 future truth，不把 oracle_gain 回灌 serving features。候选缓存必须记录 reference forecast、finite response 或 local R 的类型，不准两者混用。

图：oracle/headroom 分布；response norm/cosine/decision error；四象限瓶颈；static/router/gain/residual 的比较；label efficiency；metric/budget transfer；6–240h 保护变量；skill–cost Pareto。没有真实数据不得生成“示意实验曲线”当结果。

## 14. Reproducibility Contract


1. 用实际 git SHA 作为依据。当前基线为 4fe55a7af90ea92f62a3232a571af92bfbd6114d。发现 main 已前进，先记录差异并重新核查受影响文件；不要 force-reset 用户修改或覆盖工作区。
2. P0 固定官方 Stormer revision 与实际 checkpoint。源码许可、权重许可、数据许可三者独立。代理/镜像下载仍核对上游 identity；不把明文密钥写日志。
3. 时间始终 timezone-aware UTC；数据 manifest 需要实际起止时间、缺口、重复、通道/层、网格、单位、常量变量、warmup history 与最大 240h 终点 coverage。只验证 timestamp 大小关系不够。
4. 按初始时间/天气事件块分割，不随机拆网格或重叠轨迹；拟合 bank、normalizer、basis、regime prototypes 只用 train。2019 可拆 dev/calibration 的不重叠连续块；2020 和 2021–22 保持最终评测，任何曾参与选择的片段明确移出 final test。
5. ERA5 reanalysis 是回顾数据，不是在 valid_time 当时可获得的实时观测。对研究回放明确 `availability_policy=retrospective_assumed`；对业务声明使用真实产品 release/retrieval 时间。不可把 6h 默认 delay 叫验证过的 ERA5 发布延迟。
6. deterministic backbone.eval()/frozen 参数；多次试验保持相同初态、RNG、数值精度。测 finite du 先验证重复性。所有非零/零编辑恢复测试要使用 B 非零的 bank。
7. 同信息条件下对照：额外无标签响应模拟可用量、真值标签数、选择预算、训练更新次数、trainable params/总 params、硬件、feature pass 必须公开；不能不给 baseline 相同训练机会。
8. online GPU latency 测 batch=1 且 CUDA synchronize，报告 warm/cold、median/P95、peak memory、前向次数；offline 数据生成与训练耗时分列。SDPA/xformers 的重复噪声和 tolerance 实测，不能随意放宽到通过。
9. 运行当前 unit tests 并保存真实 collect / passed / skipped / failed。缺 checkpoint 的 real tests 记 skipped，不能转通过。各新增 CLI `--help` 测试；外部库必须固定版本，不在 import 时自动 pip 安装。
10. 最终论文表由保存的 per-origin 结果脚本生成，含所有失败/回退，不手工删样本。整体显著性与分项探索标明；不把 69 个相关变量、多个 lead 当作几十个独立复现。

## 15. Literature-to-Code Mapping


| External repo | Pinned commit / status | License status | 实际核查/可借鉴 | EarthDelta file | 修改原则 |
|---|---|---|---|---|---|
| https://github.com/tung-nd/stormer | 58dfee5a6037399a40fefd492bc00421e0c885a8 | MIT，已读 LICENSE | 已读 inference.py；零增量均值、固定步长与路径平均协议 | bridge/stormer_bridge.py, scripts/s0_gate.py | 独立 oracle，不mock本地类；保留版权；权重许可另查 |
| https://github.com/microsoft/aurora | 4765abc724c607a18f93df0302dbd0afcaca17fa | MIT code header；权重另查 | 已读 aurora/model/lora.py 的 LoRA/LoRARollout | lowrank.py / baselines/peft.py | 主要作先例与步号调度参考，不复制整个backbone |
| https://github.com/ShileiCao/WeatherPEFT | commit UNVERIFIED；已读 tree b2cdc25cbbb78de272a6f6e0d532c2fe2006a15c 与 fish.py blob 99afcd973bada082a670f1d83ba563bbb57996f7 | top-level许可未核实；禁止默认MIT | 已核查梯度重要性与随机mask实现 | baselines/peft.py | 当前只作论文机制对照；resolve许可/commit后再决定是否复用 |
| https://github.com/eric-mitchell/mend | UNVERIFIED pin | 官方仓库展示MIT，复用前读固定版本 | learned low-rank edit作为prior，不是天气drop-in | RELATED_WORK / optional baseline | 不能用当前futurelabel驱动MEND然后当合法服务 |
| https://github.com/sail-sg/lorahub | UNVERIFIED pin/license | BLOCKED_COPY | 官方代码链接由论文确认；未逐行审核 | baselines/peft.py 可选 | coefficient-free-gradient search思路；无梯度不等于无标签 |
| https://github.com/EnnengYang/AdaMerging | project manifest报告 cea1165；本次未独立解析完整SHA | manifest报告MIT，不能替代独立核验 | 只用于合并/熵适应背景 | baselines optional | 不把分类entropy变天气loss |
| https://github.com/tum-pbs/Solver-in-the-Loop | UNVERIFIED pin/license | BLOCKED_COPY | 论文多步状态订正动机；本次未跑源码 | baselines/neural.py | 最小独立实现天气recurrent corrector，标清非官方复现 |
| https://github.com/google-research/weatherbench2 | UNVERIFIED pin/license | resolve before import/copy | 希望复用latitude RMSE/ACC聚合定义 | metrics.py/evaluation.py | 首先锁定实际版本并对固定例子交叉验证；不是凭名称保证一致 |
| https://github.com/NVIDIA/torch-harmonics | UNVERIFIED pin/license | resolve before import/copy | P3球面变换节点/归一化 | spectral.py | 不加入P0依赖 |

UNVERIFIED 不允许用“main”冒充 fixed commit。Codex 在本地可读 reference/ 镜像时对每个实际使用依赖执行 git rev-parse HEAD、读取LICENSE并计算hash，保存 dependency_lock.json。代码、checkpoint、dataset许可证分开记录。EarthDelta根目录未见完整当前LICENSE时，应先整理已有上游版权/许可边界；旧kit的MIT不能自动授权所有新增文件。

## 16. Expected Paper Artifacts

Figure1 oracle/static headroom；Figure2真实vs预测响应及4象限；Figure3label efficiency；Figure4参数编辑vs强输出订正；Figure5多lead保护变量；Figure6冻结head目标/预算转移；Figure7coverage/gain/no-edit。Table1整体skill含失败；Table2最小核心消融；Table3真实效率。没有真实结果时只生成EMPTY/BLOCKED说明，不画虚构结果。

## 17. STOP Conditions and Statistical Policy


## 状态不是二值

- `BLOCKED`：checkpoint / 数据 / 独立官方依赖 / 许可 / 配置 / 资源缺失。不得当科学失败，也不得用合成数据顶替。
- `INVALID`：泄漏、度量错、版本错、官方 parity 错、实际未来数据可达。停止这次实验，修复后新 run；历史结果作废但保留。
- `INCONCLUSIVE`：置信区间跨过决策阈值或样本不足。只按预登记规则增加样本，不得直接换指标/年份。
- `PASS_SCREEN`：通过开发集的继续投入门，不等于发表证据。
- `PASS`：对应任务全部工程条件与预先指定的科学条件满足；必须附 artifact/hash。
- `STOP` / `PIVOT`：当前主张失败或被更简单方案解释。不得通过加模块绕过。

## 固定度量

主损失 L_t(a)=Σ_h β_h Σ_v α_v Σ_i w_i[(F_a−Y)_{hvi}/s_v]^2，所有权重预先固定且各自归一化，s_v 来自训练期，不随候选或测试结果改变。主 screen 先用 72h 的同一固定多变量目标；Z500/T850/T2m/U10/V10/MSLP 分项和 24/120/240h 是保护/扩展，不准只选赢家。

主收益差异为 paired origin loss，不把网格点当独立样本。forecast 表逐变量使用 sqrt(聚合加权 MSE)，不是先开根号再平均。Z500 默认 geopotential m²/s²，若转 geopotential height 要明确除以固定 g0 并改单位。

## 阈值如何得到（不是随意指定 2%）

P0-01 在固定精度/硬件上重复无编辑参考推理，计算数值引起的 paired loss 差异，并冻结 δ_noise（相应绝对差的高分位数及置信上界）。这是数值可分辨阈值，不是业务意义阈值。

在独立开发 pilot 上估计 paired-loss 的时间块方差 σ_block、相关长度和可承担的最大独立块数 n_eff,max。样本量规划采用正态近似 δ_MDE=(z_0.975+z_0.8) σ_block/sqrt(n_eff,max)≈2.80 σ_block/sqrt(n_eff,max)，实际区间由 time-block bootstrap 给出。MDE 只表示该设计对效应的探测能力，不等于应用价值。

`decision_policy.json` 在后续 oracle/主比较前冻结：主指标、开发/校准/测试范围、block length、最大样本/最大 GPU-hours、δ_noise、δ_MDE、δ_practical（若有业务最低收益依据）、protected_harm_margin、alpha、最终单次检验方案。没有 operational relevance 依据时，`delta_practical=null` 并标记 `claim_scope=research_screen_only`；允许用 max(δ_noise,δ_MDE) 做资源投入 screen，但禁止称为业务收益已达标。不能把 δ_MDE 当事实上的 operational threshold。

如需要中途反复看结果，先指定 look 数与 alpha spending；默认只做一次固定样本量正式 gate。模型/字典/超参数试验预算同样登记。开发集选方案，测试集仅最后打开一次；统计结论以测试集为准。

## STOP-0 — Integrity

任何独立官方 parity、零系数+非零 bank、缓存指纹、未来标签隔离、UTC/coverage、finite constraints、metric identity 测试失败 → `INVALID`，不得训练主系统。官方不可运行 → `BLOCKED` 而不是“内部一致所以 PASS”。

## STOP-1 — No real edit / no oracle ceiling

首先检查 bank 存在非零 BA、非零 rollout response 且作用窗正确；全零银行是 `INVALID_DICTIONARY`，不是科学反证。

对冻结字典含 no-edit 的真实最优 a*_t 计算 I_oracle=E[L_t(0)−L_t(a*_t)]。若区间上界 U_oracle<δ_survival → STOP 当前字典。最多允许一次在方案中事先列明的 trained/structured bank fallback（只用 train/dev，不看最终 test）；仍失败则 STOP 参数编辑主线。若 L_oracle>δ_survival → PASS_SCREEN；否则 INCONCLUSIVE。

Oracle 是可用候选上的事后上限，不是服务结果；有限近似 QP teacher 不得标为 full oracle。

## STOP-2 — No dynamic headroom

从 train/dev 选 best-fixed 编辑 a_static 并锁定；不得用每个测试 origin 的 truth 选 static。计算 I_dynamic=E[L_t(a_static)−L_t(a*_t)]，以及相对不编辑的绝对收益，含成本。U_dynamic<δ_dynamic → PIVOT 静态校准并停止动态 planner 主张。不得使用“static 解释 80%”这类近零分母不稳定比率作为唯一条件。

## STOP-3 — No decision-relevant predictability

先分离 oracle-e+oracle-d、oracle-e+pred-d、pred-e+oracle-d、pred-both 四象限。与零响应、常数/平均响应、时间/季节均值和简单线性回归比较。以真实 gain、regret 与有 headroom 样本上的 ranking 为主，cosine/R² 只辅助。

在固定训练/调参预算内，若 predicted-both 相比 best-static 和强 direct gain 的改进上界不超过 δ_predict，且标签效率/目标转移也无可辨优势 → STOP factorized-planning 主张。完整 e0 R² 低不能单独触发停止；方向投影和 ranking 必须失败才有力。

## STOP-4 — Output correction dominates

匹配 context、标签、trainable parameters（同时报告总参数）、训练预算、候选响应 teacher access 与实测在线成本。比较 terminal、joint-trajectory、recurrent residual；后二者是强基线。

若参数编辑的收益不高于最强输出订正（改进区间上界≤0），成本不更低、保护变量/long rollout 不更好，且无预登记标签效率/目标转移优势 → STOP 参数编辑主线或 PIVOT 输出订正。成本不能只用 adapter rank 或 declared token cost 表示。

## STOP-5 — Unsafe trajectory / projection gaming

若 summary gain>0 而完整场/保护变量持续劣化，或 120/240h 的损害超过预登记 non-inferiority margin → STOP 该 summary/window/方法 claim。一次真实发散/NaN 立即触发工程停止并保存失败率，不能在统计表中删除该样本。

## STOP-6 — No reusable factorization advantage

在同信息、接收相同 metric/budget 输入的 direct-gain/router 下，响应路线在新权重/预算与核验标签受限设定均无改进 → 撤回“可复用”创新。不能把“不喂新目标给 baseline”造成的失效当作优势。

## STOP-7 — Calibration invalid

候选集合、metric、bank、backbone 或输入分布变化后不复核校准即声称安全 → INVALID claim。区间实际覆盖显著低于名义目标且无法通过预登记校准恢复 → no-edit 或放弃安全保证；不得把两项风险上界的差当作收益下界。

## 项目级决策

正确性门失败：修复，不宣称科学失败。资源门失败：BLOCKED。H1 失败：不投资主 head。H2 失败但 H3 成功：只可保留经证实的系统/经验贡献。H3 失败且 H2 无独立实证价值：STOP。第二主干未做不会抹去第一主干结果，但必须缩窄 generality claim。

## 18. 完成记录与下一轮入口

每完成任务同步status.json、codex_tasks.json中的status、CODEX_TASKS.md checkbox与Current stopping point。只有所有success criteria和artifact实际存在才勾选。当前授权不自动扩展：完成P0-01后停下，输出状态、证据、commit建议与P0-02是否可解锁；不擅自执行P0-02。

## 19. 决策子空间补充合同（仅 P2-01 解锁后）

以下为建议实现，而非当前代码已经具有的能力。先将每个变量/lead 的格点场按固定训练期尺度与纬度面积权重白化。只在 train-only 的真实编辑响应上拟合固定正交基 U；不得用测试 truth，也不得在 serving 中先计算实际候选响应后把它当作免费的“预测”输入。

对同一白化空间，写 e=Ue_z+e_perp、d=Ud_z+d_perp，则

    G_full − G_projected = 2 e_perp^T d_perp − ||d_perp||².

因此低响应重建误差或高解释方差**不充分**：小 d_perp 仍可能与很大的 e_perp 对齐，改变收益和排序。基维数的选择应同时看开发集的实际 gain distortion、top-edit agreement、regret、完整场保护量，并把最终 basis 锁定后再测试。

为了有清晰的目标复用保证，首版使用按 variable×lead 分块的 U，并只允许对这些块施加非负标量权重。该类权重保持块内基空间不变。新空间区域掩码、任意非对角物理度量或新变量不自动满足这一条件；必须保留完整场预测，或重新定义/校准读出并计入成本。不能仅改变一个 Q 矩阵就声称可迁移到所有天气目标。

主实验至少比较：full-e/full-d；projected-e/projected-d；直接 b；action-conditioned direct gain。相同 metric/budget 输入必须给 direct-gain/router。对未见 bank 成员，现有专家 ID 和系数描述符不够；默认不宣称 zero-shot，新专家需独立权重描述或无标签 probe adaptation 协议。

运行时的保护条件只能依赖当前可用信息、模型预测或确定性有效性约束。真实未来保护变量损失只可由离线 evaluator 计算，不能暗中用其决定应用/撤销编辑。

## 20. 成本与收益的单位

首版优先把实测延迟/调用预算作为可行性约束。若采用软目标 G−λc，λ 必须在开发阶段按应用权衡预先固定并进入配置，使成本惩罚与归一化预报损失同单位。不得把毫秒、rank 或 token 数直接与 MSE 相减；代理成本和实测成本分列。
