# START HERE FOR CODEX

目标：验证起报时的参数编辑是否确实值得，而不是先堆模块。

Read in order:
1. `EarthDelta_Codex_Execution_Plan.md`
2. `research/FINAL_RESEARCH_DECISION.md`
3. `CODEX_TASKS.md`
4. `STOP_CONDITIONS.md`

然后检查当前仓库的git状态。审计基线main=`4fe55a7af90ea92f62a3232a571af92bfbd6114d`。如代码已更新，记录diff并核查相关结论，不覆盖用户修改，不force reset。

**Execute ONLY P0-01.** 这要求真实、独立的官方Stormer gate和数据/版本合同。文档中新增CLI尚需实现，不能假定现成可运行。

没有checkpoint/data/官方依赖/资源时保存`BLOCKED`，附已完成代码与具体缺项；不要用synthetic代替真实gate。不向日志写密钥。不下载/复制许可不清晰代码。

P0-01成功后更新`CODEX_TASKS.md`和`codex_tasks.json`，附真实run和hash，停止。不要自动进入P0-02，不启动大训练，不添加JEPA/memory/dynamicrank。

可先运行 `python tools/validate_package.py` 检查本工程合同包；这不是weather科学验证。`tools/audit_math.py`仅独立代数例子，不能用于S0或oracle gate。
