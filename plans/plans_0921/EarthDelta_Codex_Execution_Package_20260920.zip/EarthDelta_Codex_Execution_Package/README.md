# EarthDelta Research Audit & Codex Execution Package

审计快照：`main` / `4fe55a7af90ea92f62a3232a571af92bfbd6114d`；日期 2026-09-20 America/New_York。

阅读完整研究报告：[EarthDelta_Research_Audit_CN.md](EarthDelta_Research_Audit_CN.md)。

交给 Codex 的入口：[START_HERE_FOR_CODEX.md](START_HERE_FOR_CODEX.md)。完整工程合同：[EarthDelta_Codex_Execution_Plan.md](EarthDelta_Codex_Execution_Plan.md)。

任务状态：[CODEX_TASKS.md](CODEX_TASKS.md)；机器任务图：[codex_tasks.json](codex_tasks.json)；停止条件：[STOP_CONDITIONS.md](STOP_CONDITIONS.md)。

默认只允许执行 P0-01，成功后停止。本包未执行任何真实天气科学实验，也未修改远端仓库。新增实验 CLI 是待实现合同；`tools/` 中的脚本仅作交付包和独立数学检查。

所有文件以 UTF-8 编码。参考论文/代码保持原始链接；未将未经许可的外部源代码打入包。
