# FINAL_RESEARCH_DECISION

状态：**有条件继续；只解锁 P0-01。当前不能按已验证方法论文写强贡献。**

## 保留

以冻结参考模型为起点，建立**有限、可逆、版本固定的参数编辑集合**；分别利用无需未来标签的轨迹响应监督与需要核验的误差监督；以共享物理指标评估候选价值；始终允许不编辑。先保留 finite-response 路线，局部 Jacobian/QP 作为后续受检验替代，而非同时维护三个论文主线。

参考 F_ref 明确为 F0 或已有训练完成且冻结的 Fs。默认 P0 使用官方 F0；Fs 只能在单独训练、记录权重后引入，并同时报告 F0、Fs。不得把已训练适配器当作已存在。

## 删除 / 暂缓

主线 DEFER：JEPA、神经长期 memory、dynamic rank、spectral loss、完整 Complexity Atlas、第二主干、大规模全系统训练。

REMOVE FROM MAINLINE CLAIMS：新发现平方误差恒等式；新发明小 QP；“H 包含全部非线性交互”；按构造支持未见 bank；LoRA rank 小所以实测效率高；ERA5 六小时核验即业务可用；“可逆即物理安全”。这些是叙述删除，不是无条件删代码。

## 三个待证伪假设

H1：冻结的合法编辑集合，在未用于构造 bank 的起报样本上，存在超过最小实用效应的真实 oracle 收益，且显著超出验证集选择的最佳固定编辑。

H2：分离的 e0/du 学习，在低核验标签或改变评估指标/预算时，比同信息的直接 gain 与 end-to-end router 更有效；所有方法拥有公平的计算/teacher access。

H3：在 6–240h 轨迹与保护变量上，选择性参数编辑优于或形成有意义 Pareto 优势于同信息的 trajectory/recurrent residual correction，不只是单一时效投影改善。

## 两条核心候选贡献

C1：**Decision-sufficient trajectory response modeling**——不把完整未来误差可预测性作为唯一目标，研究响应子空间中足以决定编辑排序的信息能否在有限核验标签下学习。

C2：**Reusable, selective intervention planning**——冻结响应代理后重用多时效/变量指标与成本条件，并通过候选集合级收益高估校准决定何时回退 no-edit。

两者均是待验证研究假设；不声称这些概念本身首次出现。最有价值的可能是首个扎实的受控实证组合，而不是算法原语。

## P0 → P1 → P2 → P3

P0-01：修正必要协议并独立复现官方；无数据/权重/GPU条件时 BLOCKED，不转合成 PASS。
P0-02：先验证 bank 非退化，然后真实 finite oracle ceiling。
P0-03：验证 best-static 之外的 dynamic headroom；同时建立 projector/full-field、oracle/error/response 分解合同。
P0-04：小规模直接 residual 与 direct-gain 生存挑战，建立不能被轻易击败的基线。
P1：成对响应数据、预测头、同信息 router、选择性闭环执行、长轨迹与独立年份。
P2：最多两条：decision-sufficient 子空间/目标转移；集合级校准/有条件的 pair response 或局部 QP。
P3：第二主干/极端事件扩展及确有 failure mode 的可选表示模块。

## 停止逻辑

协议不正确 → STOP 本次实验，先修正确性。
没有资源 → BLOCKED（不是科学失败）。
oracle 的区间上界仍低于实际意义阈值 → STOP 当前字典；仅允许一次预先登记的结构化/训练 bank 替代，不无限选设定。
static 已解释所有可用 headroom → PIVOT 到静态校准，停止动态 planner 的强主张。
响应/误差信息无决策价值，或强输出订正全面支配且无标签效率/目标转移优势 → STOP 当前主线。
证据区间跨阈值 → INCONCLUSIVE，执行预登记追加样本计划，不把不显著当“证明无效”。
