# EarthDelta — 独立最近邻调查

检索截止：2026-09-20 America/New_York（连接器时间可为 2026-09-21 UTC）。采用原论文、期刊/会议页面与官方代码。未声称穷尽所有文献，也未将检索未发现当作“首个”的证明。

| Work | Year / venue | Core mechanism | Predicts intervention effect? | Parameter intervention? | State conditioned? | Online selection? | Analytical utility | Weather? | 真正重叠 | 剩余候选贡献（尚未证明） |
|---|---|---|---|---|---|---|---|---|---|---|
| [R01](https://arxiv.org/abs/2608.02528) Uncertainty Is Not Enough: Value-of-Information Routing for Mixtures of LoRA Experts (VI-MoLE) | 2026-08-03 · arXiv | 预测专家前缀的剩余风险，按边际价值分配预算 | 标量风险，不是天气响应场 | 是，LoRA 库 | 输入 | 是 | 风险代理；不能当真实收益恒等式 | 否 | 最直接威胁“反事实价值驱动的预算 LoRA 路由” | 有符号多时效响应、延迟核验、可重加权目标的实证价值 |
| [R02](https://agupubs.onlinelibrary.wiley.com/doi/full/10.1029/2023GL107938) Machine Learning Enables Real-Time Proactive Quality Control: A Proof-of-Concept Study | 2024 · GRL | 用机器学习参考分析支持实时主动观测质控 | EFSO 观测影响 | 否，观测/同化 | 分析历史 | 是 | 预报误差影响量；参考态是估计 | Lorenz-96 概念验证 | 未来真值不可得时仍做预报影响决策已有先例 | 参数编辑的响应学习与全球天气轨迹验证 |
| [R03](https://journals.ametsoc.org/abstract/journals/mwre/133/5/mwr2912.1.xml) Using Green’s Functions to Calibrate an Ocean General Circulation Model | 2005 · Monthly Weather Review | 参数扰动建立响应核，联合校准参数 | 是，响应核 | 物理模式参数 | 校准资料/模式 | 离线 | 加权最小二乘 | 海洋 | 有限差分—响应矩阵—加权拟合不是新算法 | 把流依赖响应摊销为逐起报预测，而非一次全局校准 |
| [R04](https://gmd.copernicus.org/articles/15/2309/2022/) Earth system model parameter adjustment using a Green’s functions approach | 2022 · GMD | ESM 多参数敏感度与多观测目标加权优化 | 是，敏感度实验 | 20 个物理控制参数 | 目标与权重 | 离线 | 加权最小二乘 | Earth system | 联合影响、目标权重与参数依赖均有先例 | 神经参数编辑的输入条件化响应预测及核验标签效率 |
| [R05](https://arxiv.org/abs/2605.14546) Discovering Physical Directions in Weight Space: Composing Neural PDE Experts (CCM) | 2026-05-14 · arXiv | 同锚点端点专家分解，物理坐标/观测前缀选择权重组合 | 权重方向，不等同输出 Jacobian | 是，权重合并 | 物理元数据/前缀 | 选定后部署 | 坐标读出/前缀校准 | PDE，非全球天气 | 物理条件化权重干预与长轨迹收益不独占 | 未知未来误差下对响应场进行选择，不依赖已知物理坐标 |
| [R06](https://arxiv.org/abs/2609.17042) Learning Options for Compositional Motor Control with Adapter Banks (CABRA) | 2026-09-15 · arXiv | 共享循环网络、适配器库、组合运动控制 | 不是先预测逐编辑天气响应 | 适配器；低秩为学习后结构 | 任务/轨迹 | 优化控制策略 | 任务轨迹目标 | 否 | 共享主干+适配器库+控制已存在 | 未知天气未来真值、响应代理与核验延迟；不能声称首个适配器控制 |
| [R07](https://arxiv.org/abs/2609.08412) Stochastically Perturbed Weights: Ensembles from Deterministic Machine-Learning Weather Models (SPW) | 2026-09-08 · arXiv；AIES 投稿非录用 | 已有确定性天气模型推理时权重扰动生成集合 | 通过实际采样，不是收益预测 | 是，原始权重张量 | 架构/注入位置 | 扰动推理 | 概率预报评价 | 是，四种主干 | 冻结天气模型上的推理期参数扰动已有直接先例 | 逐状态定向改善的可预测性，而不是生成不确定性集合 |
| [R08](https://www.nature.com/articles/s41586-025-09005-y) A foundation model for the Earth system (Aurora; LoRARollout implementation) | 2025 · Nature；公开代码核查至 2026-09-14 | Earth-system foundation model；实现含逐 rollout 步 LoRA | 不独立预测 edit effect | 是，LoRA | 步号/任务 | 预定步号调度 | 训练预报损失 | 是 | “改变多步天气动力学的 LoRA”不是新概念 | 逐起报有符号响应评估和主动不编辑 |
| [R09](https://proceedings.iclr.cc/paper_files/paper/2026/hash/4e6219cc3913fd508dbd7f3f6d90cd4e-Abstract-Conference.html) Task-Adaptive Parameter-Efficient Fine-Tuning for Weather Foundation Models (WeatherPEFT) | 2025 arXiv / ICLR 2026 | 任务动态提示与随机 Fisher 引导参数选择 | 否 | 是，选参数/提示 | 任务/输入模式 | 前向条件化，非候选收益规划 | 训练目标 | 是 | 天气特定 PEFT 与动态条件化已被覆盖 | 效果建模、选择性干预；不能只比较普通 LoRA |
| [R10](https://arxiv.org/abs/2608.21652) GeoQ: Geometry-Aware Conditional Quantile Error Estimation for Scientific Surrogate Models | 2026-08-21 · arXiv | 锚点校准误差+几何条件分位数增量 | 预测误差而非编辑效果 | 否 | 查询/支持度 | 误差估计 | 条件分位数，非有符号二次收益 | 含天气实验 | 逐输入科学代理误差预测已有直接先例 | 误差方向与编辑响应对齐；误差幅值不够规划 |
| [R11](https://arxiv.org/abs/2606.02663) AdaWeather: Adaptively Mixing Probabilistic Weather Forecasts with Logarithmic Regret | 2026-06-01 · arXiv；NeurIPS 投稿非录用 | 监督学习+在线专家建议组合概率天气预报 | 不是参数效果预测 | 否，输出混合 | 上下文/反馈 | 是 | 预报混合损失与 regret | 温度预报 | 天气中的适应性选择、相对静态混合的价值需对照 | 参数干预而非输出融合，必须用实验证明必要性 |
| [R12](https://openreview.net/forum?id=0DcZxeWfOPt) Fast Model Editing at Scale (MEND) | 2022 · ICLR | 学习转换低秩分解梯度来快速编辑 | 不独立预测所有候选效果 | 是 | 给定输入—目标输出 | 是 | 编辑目标/局部性损失 | 否 | 学习参数编辑、低秩编辑、局部性不是新贡献 | 起报时没有目标未来答案，不可调用 edit-label 梯度 |
| [R13](https://proceedings.mlr.press/v70/koh17a.html) Understanding Black-box Predictions via Influence Functions | 2017 · ICML | 梯度/Hessian-vector 近似训练数据扰动影响 | 是，局部影响 | 由重加权训练诱导 | 训练点/测试点 | 诊断 | 局部影响近似 | 否 | 执行昂贵改动前估计输出/损失变化并非全新范式 | 有限神经编辑轨迹响应，不等同训练样本影响函数 |
| [R14](https://arxiv.org/abs/2307.13269) LoraHub: Efficient Cross-Task Generalization via Dynamic LoRA Composition | 2023 · arXiv | 用少量目标任务示例无梯度搜索 LoRA 组合 | 实际评估，不是响应代理 | 是 | 目标任务示例 | 适应后推理 | 示例损失 | 否 | 组合库+搜索已知；无梯度不代表无标签 | 不用未来真值，离线响应监督与合法历史核验分离 |
| [R15](https://arxiv.org/abs/2310.02575) AdaMerging: Adaptive Model Merging for Multi-Task Learning | 2023 arXiv / 2024 版本 | 无标签测试样本熵最小化调节合并系数 | 不独立建模响应场 | 是 | 测试分布 | 测试时适应 | 熵代理 | 否 | 无测试标签的权重组合已有先例 | 天气回归不能直接把分类熵当可靠误差代理 |
| [R16](https://arxiv.org/abs/2408.01415) Conditional LoRA Parameter Generation (COND P-DIFF) | 2024-08-02 · arXiv | 参数自编码器+任务条件潜空间扩散生成 LoRA | 否，生成参数 | 是 | 任务条件，非自动等同逐天气状态 | 参数生成 | 生成/适应训练目标 | 否 | 条件生成 LoRA 不构成 EarthDelta 独占创新 | 先评估响应再选择与直接生成的受控比较 |
| [R17](https://arxiv.org/abs/1805.12114) Deep Reinforcement Learning in a Handful of Trials using Probabilistic Dynamics Models (PETS) | 2018 · arXiv/NeurIPS | 概率动力学模型+轨迹采样规划 | 状态—动作效果 | 动作非网络权重 | 当前状态/动作 | 是 | 已知奖励下预期轨迹回报 | 否 | 学习响应再规划、风险传播来自模型预测控制谱系 | 模型自身参数为动作，天气真值和可核验标签的特殊信息结构 |
| [R18](https://arxiv.org/abs/2608.29998) The Intervention Gap in Latent World Models | 2026-08-30 · arXiv | 匹配真实干预，审计规划时的效果保真度 | 直接审计干预效果 | 环境动作，非参数编辑 | 任务/状态/候选 | 评测 | operator-error 与任务方向 | 否 | 预测准确/奖励准确不等于干预准确的区分已被明确提出 | 把该审计应用于天气参数干预并展示新的可重复经验规律 |
| [R19](https://arxiv.org/abs/1710.08005) Smart “Predict, then Optimize” (SPO) | 2017 · arXiv；后续正式发表 | 让预测损失关注下游优化决策误差 | 预测决策参数 | 不特指网络编辑 | 决策上下文 | 预测后求解 | 优化结构/决策损失 | 否 | 预测 b/H 再 QP、用 regret 训练有成熟谱系 | 天气响应监督与结构化信息分离必须提供额外价值 |
| [R20](https://arxiv.org/abs/2007.00016) Solver-in-the-Loop: Learning from Differentiable Physics to Interact with Iterative PDE-Solvers | 2020 · arXiv；2021 修订 | 把订正器放入可微分迭代求解器训练 | 学习订正，不独立逐候选响应 | 输出/状态订正 | 当前迭代状态 | 循环订正 | 多步物理求解损失 | PDE | 输出订正也能形成稳定、连贯多步反馈；不能弱化这类基线 | 参数通道是否比同信息循环输出订正更有价值需实测 |
## 最接近的五项：10 维逐项比较

以下比较是从原论文与当前代码推导的审计判断，不是外部方法的新实验结果。对方的优点不因为不在天气领域而被抹去。

| 维度 | VI-MoLE [R01] | ML-PQC [R02] | Green’s-function [R03/R04] | CCM [R05] | CABRA [R06] | EarthDelta 当前/目标 |
|---|---|---|---|---|---|---|
| Scientific question | 哪个专家值得追加 | 哪个观测值得保留 | 哪些参数联合降低模式偏差 | 专家权重是否包含物理方向 | 适配器能否复用组合运动技能 | 未知未来误差时是否能选择有效参数编辑 |
| Formulation | 条件剩余风险与增量价值 | ML 参考分析支持 EFSO | 参数响应核与加权最小二乘 | 同锚点共享更新+有符号端点方向 | 共享循环动力学+适配器代码 | e0、有限 du 或局部 R；二次几何 |
| Supervision | 委员会/任务风险 | 历史分析训练参考预测 | 历史观测目标及扰动模拟 | 端点训练资料/物理坐标/前缀 | 运动示范与轨迹目标 | du 无未来标签；e0/收益须核验 |
| Inference | 风险预测后预算分配 | 估计影响后质控 | 调参后部署 | 读出坐标后单一合并模型 | 优化/执行适配器策略 | 合法历史→预测→预先承诺编辑窗 |
| Intervention | LoRA 专家前缀/组合 | 观测/同化 | 物理参数 | 神经网络权重组合 | 残差适配器 | 注意力投影的低秩权重等价改动 |
| Objective | 单位成本风险下降 | 预报误差下降 | 多目标加权误差 | 物理族 OOD 轨迹精度 | 已知目标运动轨迹 | 固定物理指标的预报误差下降 |
| Optimization | 有条件的贪心分配/校准 | 质控决策 | 联合线性拟合 | 坐标校准/选择 | 可微目标下控制 | 有限选择或支持枚举+盒约束 QP |
| Serving info | 输入/专家状态 | 当前分析与过去资料 | 校准完成后的模型 | 已知元数据或已观察前缀 | 给定任务目标 | 不含本次 forecast 的未来验证真值 |
| Budget | 专家计算预算 | 同化/预报影响 | 离线模拟数量 | 单个部署模型 | 控制优化成本 | 目前多为声明的专家成本；须测真实开销 |
| Experiments | LoRA 路由任务 | Lorenz-96 概念验证 | 海洋/耦合 ESM | 三类 PDE | 运动控制 | 目前核心真实天气选择结果未证实 |

严格区别：CCM 的“有限差分探针”是端点**权重**的差，不自动等于 EarthDelta 在每个输入上测得的**输出**响应 Jacobian。CABRA 的适配器低秩结构不应擅自改写成固定 LoRA 参数化；其共享网络训练协议也不能简化为从头到尾冻结预训练主干。ML-PQC 是有力先例，但不能写成已在全球神经天气模型上完成相同参数编辑。

### Reviewer 最可能的 X + Y

最有力的说法不是“LoRA + weather”，而是 **Green’s-function 参数校准 / forecast-impact analysis + VI-MoLE 式价值路由**；从系统架构看还可以说 **条件适配器库 + model-based planning**。该批评对算法原语基本成立。合理回应必须是新的受控发现：有限轨迹响应是否可预测、是否在少核验标签下产生优势、是否能复用同一代理更换指标/预算，以及是否比直接标量风险预测和循环输出订正更好。单靠换名为“counterfactual world model”不能回应。


## 论文与代码证据分开

“没有定位到官方代码”不等于作者没有代码，也不使先行论文失去 prior-art 意义。除下述明确说明外，本次未运行外部实现。预印本不能写成顶会录用。

- **R01** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R02** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R03** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R04** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R05** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R06** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R07** — 见原文官方 Code 链接；本次未审计其实现/许可
- **R08** — https://github.com/microsoft/aurora
- **R09** — https://github.com/ShileiCao/WeatherPEFT
- **R10** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R11** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R12** — https://github.com/eric-mitchell/mend
- **R13** — https://github.com/kohpangwei/influence-release
- **R14** — https://github.com/sail-sg/lorahub
- **R15** — https://github.com/EnnengYang/AdaMerging
- **R16** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R17** — https://github.com/kchua/handful-of-trials
- **R18** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R19** — 本次未核实可复用官方代码、固定提交和许可；仅用原文作方法比较。
- **R20** — https://github.com/tum-pbs/Solver-in-the-Loop
