# EarthDelta V2 — Decision-Sufficient Trajectory Intervention Planning

这是建议的下一阶段研究设计，不是对已经完成方法的重新命名。

## Problem statement / scientific question

给定冻结天气预报器、合法起报信息 X、冻结编辑集合 A 和有限核验标签，能否在不运行每条候选 forecast、不看未来真值的条件下，预测足以比较编辑收益的轨迹响应结构，并选择比 no-edit、最佳静态编辑及同信息输出订正更有价值的计划？

核心不应是“更复杂的 LoRA”，而应是：**真实天气中是否存在一个比完整未来误差更容易学习、又足够支持干预决策的响应子空间？**

## 两个核心贡献与可证伪结果

**C1：决策充分的轨迹响应学习。** 在 train-only 数据上定义固定 summary / basis U，保持度量可解释。输出 ê_h、d̂_h(a)，必要时投影到 span{d_h(a)}；比较 full-e、projected-e、直接 b、直接 gain。不是宣称投影公式新，而是检验哪些可预测信息真正驱动天气干预收益。

**C2：可重用、选择性的规划。** 一个预测器服务多个已声明变量/lead 权重和预算；校准候选集级收益高估，保留 no-edit。必须证明迁移无需重新训练 head 或说明少量再校准成本，并与 action/metric/budget-conditioned direct-gain/router 对照，不能用不接收新目标的弱 router。

## 输入输出和训练

首版 action descriptor 使用固定 bank 内身份/系数/作用窗，**不声称未见专家外推**。输入为过去 L 帧的冻结空间特征及可用时间元数据；memory 允许空，默认禁用。首版固定原场变量/纬度加权 summary；U 只能在训练分割拟合。只在 basis 覆盖的空间宣称目标重加权。

离线对同一 X 运行 reference 与所有候选，产生 d 标签；未来 Y 到达才产生 e/g 标签。损失采用

    L = λd ||d̂−d||_Q² + λe ||ê−e||_Q²
        + λg |ĝ−g|² + λr regret_surrogate,

其中 λg、λr 的项只能作用于有核验的训练样本；λr 为可选，先做朴素回归对照。所有 λ、basis 尺寸、K、rank、作用窗只能在训练/开发集选择。禁止利用测试 oracle 反向选 bank。主线中解析 ĝ=2ê^TQd̂−||d̂||_Q²；任意 learned score correction 必须单列 baseline。

## Inference

1. 校验模型、bank、normalization、grid、split、summary、cost profile 指纹。
2. 构建不含 TruthBatch 的 IssueContext；提取上下文特征，记录额外前向成本。
3. 同时预测候选完整多时效响应与参考误差；根据 MetricSpec 重加权。
4. 应用 feasible set（box/support/cost）及集合级收益高估校准；没有可信正收益则 no-edit。
5. 执行一次被选中的编辑 rollout；前 4 步编辑、随后回到 reference 参数，状态不重置。
6. 保存预测分数/决策/成本；真值之后到达时，在独立 evaluator 计算实际收益。

## 既有工作不能“自动覆盖”的部分

不是因为前人没有写相同模块名，而是因为需要验证联合能力：同一合法信息条件下的 signed trajectory response、有限核验标签下的决策充分性、重加权目标的可复用性与保护变量上的实际收益。每一项都可能被直接 gain 或条件 router 同样做到；因此目前仅是待检验差异，不是 exclusivity claim。

## Strongest baselines / decisive experiments

同一 bank 的 best-static、regime lookup、action-conditioned direct gain、b/H predictor、端到端条件 router；直接 trajectory residual correction 和 recurrent state correction；frozen / trained static LoRA / rank-matched larger static LoRA；known e0/du 的四象限 oracle。补充 SPW/ensemble 为不同成本的对照，不把概率集合与确定性单轨迹只比较 RMSE 而忽略 CRPS/预算。

决定性主图是“标签比例—真实增益”“固定 head 改目标/预算”“参数编辑 vs 输出订正的 skill—latency Pareto”“5–10 日收益保持及保护变量损失”，不是模块消融越多越好。

## Kill criteria

采用 STOP_CONDITIONS.md。若 oracle dynamic headroom 不足，不执行 V2；若 direct-gain/router 在公平数据成本下同样好且响应路线没有复用/标签效率优势，撤回 factorization 的方法贡献；若循环输出订正全面支配，停止参数编辑主张；若只有 summary 改善而完整场恶化，停止该 summary 作为主要目标。

## 必须做 vs 有结果后再做

必须做：P0 真实 gate；有限非零 bank；统一 metric；actual/oracle/static；4 象限分解；强 direct gain/router/residual；time-block uncertainty；6/24/72/120/240h。

有结果后再做：P2 决策子空间及目标转移；经验风险控制；若 pair composition 确有收益且线性误差小才恢复 QP。第二主干、神经 memory、JEPA、dynamic rank 不属于当前主线前置任务。

## 五个升级方向的选择

| 方向 | 实质增量 | 风险 | 决定 |
|---|---|---|---|
| Counterfactual intervention world model | 明确 state×edit→trajectory response | 只换名，MPC 早已有该范式 | 保留问题描述，不单列贡献 |
| Learned intervention Jacobian/basis | 从逐候选泛化到组合，降低 probe 成本 | 非线性和未见方向外推 | P2；先 finite exact 验证 |
| Trajectory-level intervention | 多变量/多时效收益与连贯性 | 输出循环订正也可做到 | 主实验设计必须包含 |
| Uncertainty-aware planning | 允许 no-edit，检验错误激活风险 | 校准漂移/假保证 | 集合级经验校准，小规模实现 |
| Physics-structured response space | 可解释尺度/风场方向与保护量 | 谱能量丢相位、投影掩盖损害 | 固定物理度量+诊断优先，spectral loss 暂缓 |


## 数学合同：什么精确，什么不精确

令 F_a(X) 为同一冻结参考模型在编辑计划 a 下的**完整有限 rollout**，Y 为仅离线可见的未来验证资料。对同一个固定 summary S 定义

    e = S(Y) − S(F_0(X))
    d(a) = S(F_a(X)) − S(F_0(X))
    L(a) = (e − d(a))^T Q (e − d(a)),  Q ⪰ 0
    G(a) = L(0) − L(a) = 2 e^T Q d(a) − d(a)^T Q d(a).

G>0 表示改善。这里有限 rollout 可以任意非线性，S 也可以非线性：只要始终先用同一个 S 再相减，`e−d=S(Y)−S(F_a(X))` 恒成立。线性 S 的必要性来自不同命题：`S(Y−F0)=S(Y)−S(F0)`、对原场固定二次范数的解释、局部响应叠加，不能混为一谈。若 S 取 kinetic-energy spectrum，则得到谱空间的损失恒等式，不是原始风场 MSE 的等价优化，方向/相位可能丢失。

固定仿射标准化的平移在差分中抵消，尺度会改变 Q。必须固定通道顺序、训练期尺度、纬度/lead/变量权重。候选相关的标准差、自适应归一化或不同 summary 会改变比较对象。代码里 `paired` 的归一化加权平均、`geometry` 的加权和、head 的 feature mean 不能混用；统一约定后再计算成本惩罚。首版优先将实测成本作为可行性约束；若用软惩罚 G−λc，λ 必须预登记并把成本换算到相同收益单位，不可直接把毫秒、rank 或 token 数与 MSE 相减。

### 局部 QP

若 d(a)≈Ra，b=R^T Qe，H=R^T QR，则 surrogate gain=2b^T a−a^T Ha。
固定支持集时，H PSD 对应凸最小化 `a^T(H+λI)a−2b^Ta`，盒约束 |a_j|≤ρ。再加 support 数量、激活成本时，整个问题包含组合约束；当前支持枚举加数值盒优化，不是一个无条件的全局连续凸 QP。

H_ij 表示响应列在度量下的重叠。它不代表真实二阶动力学项。定义

    γ_ij = d(a_i+a_j) − d(a_i) − d(a_j).

即使 H=R^TQR 计算完全正确，γ_ij 仍可很大。应该实际缓存 pair intervention，或者使用局部可信域与非线性误差诊断。**有限候选数组输入到 b/H 分支，也不会自动把线性近似变成真实 finite-response 评估。**

`(a−a*)^T H(a−a*) = ||R(a−a*)||_Q²` 是输出响应度量下的系数模仿；有用但不应命名成新的蒸馏几何原理。

### 真正需要预测多少 e0？

在固定线性响应空间中，决策只需要 b=R^TQe，而不是完美重建 e 的所有方向。设 Q=I、响应只有第一坐标 e1，则第二坐标的误差再大也不影响编辑排序。因此：完整 e0 的 R² 低**不能单独作为 kill criterion**；必须测 response-subspace error、b 误差、gain ranking 与实际 regret。反过来，完整 e0 的平均 R² 高也可能漏掉极小但关键的响应方向。

若 ê=e+η，d̂=d+ξ，则

    Ĝ−G = 2η^TQd + 2(e−d)^TQξ + 2η^TQξ − ξ^TQξ.

这给出明确分解，而不是笼统说两个 head 都要好。对同一有限可行集合，若所有候选 |Ĝ−G|≤ε，精确 argmax 选择的 regret≤2ε；近似求解器再加优化误差。该界是直接代数性质，不作为独立新定理贡献。

### 不确定性不能只用 mean gain 减一个任意方差

给定 issue-time 信息 I，令 e、d 的条件均值为 μe、μd，则

    E[G|I] = 2μe^TQμd − μd^TQμd
             + 2 tr(Q Cov(d,e|I)) − tr(Q Cov(d|I)).

相关项不可默认忽略。固定确定性 backbone 的真实 d(X,a) 对完整 X 是确定的；代理模型/压缩 context 的不确定性不能自动称“大气随机性”。

首版不必训练复杂联合概率模型。可在独立校准块上直接计算每次起报的最大收益高估 `r_t=max_a(ĝ_t(a)−g_t(a))`，用固定分位数 q 得到 `LCB_t(a)=ĝ_t(a)−q`；只有 LCB 超过成本且保护条件满足才编辑。No-edit 的真实收益恒为 0，应特殊处理为精确零。

在 iid/exchangeable calibration 条件下可以讨论集合级覆盖；天气时间依赖、候选改变和分布漂移会破坏直接套用的保证。本项目默认报告时间块上的经验覆盖和 shift degradation，不声称无条件 finite-sample operational safety。两项风险上界之差也**不是**收益下界；不能不加证明地照搬“certified marginal gain”的措辞。


## 决策子空间与目标复用：必须遵守的附加合同

以下为建议实现，而非当前代码已经具有的能力。先将每个变量/lead 的格点场按固定训练期尺度与纬度面积权重白化。只在 train-only 的真实编辑响应上拟合固定正交基 U；不得用测试 truth，也不得在 serving 中先计算实际候选响应后把它当作免费的“预测”输入。

对同一白化空间，写 e=Ue_z+e_perp、d=Ud_z+d_perp，则

    G_full − G_projected = 2 e_perp^T d_perp − ||d_perp||².

因此低响应重建误差或高解释方差**不充分**：小 d_perp 仍可能与很大的 e_perp 对齐，改变收益和排序。基维数的选择应同时看开发集的实际 gain distortion、top-edit agreement、regret、完整场保护量，并把最终 basis 锁定后再测试。

为了有清晰的目标复用保证，首版使用按 variable×lead 分块的 U，并只允许对这些块施加非负标量权重。该类权重保持块内基空间不变。新空间区域掩码、任意非对角物理度量或新变量不自动满足这一条件；必须保留完整场预测，或重新定义/校准读出并计入成本。不能仅改变一个 Q 矩阵就声称可迁移到所有天气目标。

主实验至少比较：full-e/full-d；projected-e/projected-d；直接 b；action-conditioned direct gain。相同 metric/budget 输入必须给 direct-gain/router。对未见 bank 成员，现有专家 ID 和系数描述符不够；默认不宣称 zero-shot，新专家需独立权重描述或无标签 probe adaptation 协议。

运行时的保护条件只能依赖当前可用信息、模型预测或确定性有效性约束。真实未来保护变量损失只可由离线 evaluator 计算，不能暗中用其决定应用/撤销编辑。
