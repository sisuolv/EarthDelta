# Novelty Audit

结论：**当前创新强度不足以单凭方法结构支撑强顶会 claim；但保留一个值得低成本否证的交叉科学问题。** 尚未检索到与全部设置完全同构的公开方法，不能据此证明“first”。最近邻不是 GraphCast/Pangu，而是 VI-MoLE、ML-PQC、Green’s-function 校准、CCM 与 CABRA；参见 RELATED_WORK.md 的原文链接。

| 层面 | 最强可尝试的主张 | 审稿人反驳 | 必须证据 | 当前判断 |
|---|---|---|---|---|
| Problem | 起报时预测参数编辑对未知未来误差的价值 | ML-PQC 已处理不可见未来参考；VI-MoLE 已做价值路由 | 全球天气/延迟核验/真实 finite response 的统一受控结果 | 窄交叉空白有潜力，不是泛范式首创 |
| Formulation | e0/du 分离利用两类监督 | 平方误差展开与 response calibration 是旧方法 | 低标签/跨指标比 direct gain 更好 | 公式 novelty 低，信息结构值得验证 |
| Algorithm | 交互感知预算选择 | Gram 最小二乘/支持枚举/QP 已成熟 | composition holdout、非线性误差及真实收益 | 当前算法 novelty 低 |
| Weather | 流依赖多时效物理编辑 | Aurora/WeatherPEFT/SPW 已做天气适配/扰动 | 跨变量、极端、长时效，不依赖单一投影 | 目前 weather-specific 方法证据不足 |
| Systems | 可逆、可审计 issue-time edits | 工程纪律不是科学贡献 | 真实成本、安全回退、无泄漏、重放 | 工程有价值；不能替代科学发现 |
| Empirical | 发现可预测的干预子空间/其边界 | 只是挑选容易改善的模型/年份 | 预登记失败边界、强基线、独立年与负结果 | 最值得押注，但当前未有真实证据 |

## 为什么必须问参数编辑的必要性

e0 本身就是残差监督。如果能预测 e0，直接修正 forecast 是一个自然且强的对手。参数编辑可能限制输出在模型动力学允许的轨迹族中，降低多步订正的样本复杂度，并让同一低维动作影响多个变量/lead；但这些只是可检验归纳偏置。模型本身不是严格保守的物理积分器，编辑也不自动保持守恒或平衡。

“输出订正只会修一个点，参数编辑才有连贯 rollout”是假对照：循环 residual corrector 可以把订正状态反馈，trajectory corrector 也能共同预测多变量/时效。应当同时比较 terminal、trajectory 和 recurrent 三类输出订正；后两类进入强主表。只有参数编辑展示匹配资源下的 skill/稳定性/标签效率/可复用性优势，才有独立存在价值。

相比 ensemble/更大模型/全量重训，本项目的合理动机是重用既有资产、控制适应成本、检测何时不应调整；不是声称所有情形都更好。对 ensemble 比较真实调用次数与概率指标；对 full fine-tuning 比较总训练成本；对 retrieval/memory 比较同一可用资料；对 calibration 保留简单偏差订正。

## 旧 Notion 模块处置

| 模块 | 对应明确 failure mode | 不加入缺什么 | prior-work / novelty 判断 | 决定 |
|---|---|---|---|---|
| ERA5 Complexity Atlas | 不知道 headroom 集中在哪些 regime | 缺细分误差分析，不妨碍主模型 | 数据分层/诊断不自动是方法创新 | Analysis only |
| Physics-state encoder | 简单上下文看不出 flow-dependent gain | 可能预测不足 | 条件适配已广泛存在；先冻结主干特征 | Minimal core input；新 encoder 后置 |
| Memory | 近期有合法核验误差却未利用 | 缺在线偏差反馈 | ML-PQC/校准已有相近思路 | EWMA baseline；神经 memory DEFER |
| JEPA / latent state | 输入表示限制响应预测 | 未确认前不能假设必须 | 潜预测不保证干预保真 [R18] | DEFER |
| Dynamic rank | 真正算力瓶颈和容量不匹配 | 仅固定容量，未必造成损失 | Conditional PEFT/库路由已有先例 | P3 |
| Spectral features | 小尺度误差/相位被普通特征漏掉 | 缺多尺度诊断 | 物理特征不等于新问题 | Analysis only，必要时 Optional |
| Spectral loss | 训练过度平滑且能证实 | 可能仍有高频损失 | 不能以新损失掩盖 oracle 不足 | DEFER |
| Anisotropy diagnostics | 编辑破坏方向结构 | 缺方向安全检查 | 属评测结构而非核心算法 | Analysis only |
| Kinetic-energy spectrum | 编辑破坏尺度能量分配 | 缺谱安全检查 | 能量不能替代相位/风场验证 | Analysis only |
| Weather-regime prototypes | 银行缺异质性 | oracle 可能不足 | CCM/条件专家已有谱系 | 可用于唯一预登记 bank fallback |
| Long-term memory | 长期漂移且短历史不足 | 当前未发现该 failure | 没有证据前是模块堆叠 | Future work |
| Hierarchical edit dictionary | 已证实大 bank 搜索/训练成本过高 | 小 bank 不受影响 | 层级检索是实现选择 | Future work |
| Gated incremental capacity | 容量过写/长期上下文瓶颈 | 当前主线没有该需求 | Notion Proteus 阅读笔记不是天气实验 | Remove from mainline |

这里的 DEFER 不要求删除已通过测试的通用模块；只是禁止把它们作为新一轮 P0 的前置或默认训练项。
