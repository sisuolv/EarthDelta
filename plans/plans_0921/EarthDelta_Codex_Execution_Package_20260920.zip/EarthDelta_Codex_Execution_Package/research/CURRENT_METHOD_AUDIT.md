# Current Method Audit — pinned main `4fe55a7af90ea92f62a3232a571af92bfbd6114d`

## 范围和可信度

源树与主路径通过 GitHub connector 读取，Notion 主页面及其容量阅读链接通过 Notion connector 读取。审核使用固定提交；不把 main 之后可能新增的工作包含在内。没有在远程 CCI 上执行命令；本地克隆/工作区连接不可用，因此没有声称复跑完整测试、加载真实权重或测出天气 skill。`README_REPORTED`、`CODE_VERIFIED`、`UNVERIFIED` 必须区分。

## 当前不是一个已经训练完成的单一计算图

现有代码是一组可组合原语，并存至少三条路线：

1. `cached_responses` 得到有限候选的真实非线性响应；`paired_targets` 产生 e0/du/gain 标签；未来可用 `ComposedPredictionHead` 预测 e0/du，再由 `select_plan` 选择。
2. `central_response` 测局部 R；`ResponseGeometry.from_error` 计算 b、H；`box_candidates` 提供离线教师；`BoundedProgramHead` 学系数。
3. `InteractionUtilityHead` 预测 b/H，再调用 `plan_from_prediction` 做支持枚举与盒约束优化。

路线 2/3 不能冒充路线 1 的有限非线性响应评估。`ComposedPredictionHead` 还包含 memory 接口和 score calibration，与“纯解析收益”的叙述不同。没有发现主线的真实 weather-head 训练脚本/训练权重/闭环选择结果。

### 参数干预的实际语义

在 attention projection 的输入 z 上，输出增量是 sum_k a_k B_k A_k z。a 在该次执行内与 token 无关时，它等价于 W_eff=W+sum_k a_k B_k A_k；无需永久改写 checkpoint。默认作用前 4 个 6h 步，之后 a=0，但**从已经被改变的气象状态继续 rollout**，并非跳回未编辑轨迹。桥接默认返回末步。若使用旧 ProgramSpec 的 token/region 条件系数，则是局部条件适配，不能笼统称全局权重矩阵编辑。

### 信息与组件边界

| 类别 | 现有原语 | 合法用途 |
|---|---|---|
| Offline，不用未来标签 | frozen forecast、编辑 forecast、cached_responses、central_response | 收集确定性模型响应；但耗计算并非免费 |
| Offline，用未来标签 | paired_targets、ResponseGeometry.from_error、teacher.verify_candidates | e0/收益标签与 oracle 分析 |
| Learned | ReferenceErrorHead、EditResponseHead、InteractionUtilityHead、BoundedProgramHead、组合头 | 类定义存在不代表已训练 |
| Analytic | gain、Gram geometry、盒约束/支持枚举 | 代理空间解析；不是未知真实收益的精确计算 |
| Runtime | controlled_rollout + 未来计划连接的 predictor/selector | issue-time 输入不含本次未来 truth |
| Memory | VerifiedRecord、eligible_records、EWMA/gated delta 原语 | 只能使用已经 available 的核验记录；P0 暂缓 |
| Physics | 系数谱诊断和节点检查；regridding | 不是已完成的 KE/anisotropy/SHT loss pipeline |

## 最准确的范式

**以 PEFT 作为动作空间、以 forecast sensitivity / response surrogate 作为模型、以 decision-time planning 作为推理规则的摊销控制原型。**

它不是通常意义的 test-time gradient adaptation，因为主线服务时不做梯度更新；不是传统 model editing，因为本次正确目标未来未知；可以视为 model-based planning，但“world model”只是描述，不自动带来新贡献；模型内干预不等于对真实大气的因果干预。直接 b/H 头接近 decision-focused prediction；直接系数头接近 conditional router/hypernetwork。

## 审计发现

| ID | 优先级 | 位置/符号 | 观察 | 最小处理 | 证据边界 |
|---|---|---|---|---|---|
| A01 | P0/blocker | [scripts/s0_gate.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/scripts/s0_gate.py): `verify_zero_edit_equivalence / run_s0_gate` | “官方”比较实际是本地 bridge 的两条路径，传空 expert_loras；RMSE 写报告但不进入总体 gate。 | 重新独立调用 pinned upstream，非零 B 的零系数测试；RMSE/NaN/通道/网格条件全部列入 gate。 | 代码事实，不表示已观测到真实预报错误。 |
| A02 | P0/blocker | [earthdelta/bridge/stormer_bridge.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/bridge/stormer_bridge.py): `NormalizationContract.denormalize_diff` | 本地支持增量均值；官方 inference.py 构造增量变换时均值为零。 | 严格 official 模式使用零增量均值；输入非零 diff_mean 时拒绝或明确独立协议。 | 是否影响现有 checkpoint 的实际输入，取决于本地 npz；当前 UNVERIFIED。 |
| A03 | P0/blocker | [earthdelta/lowrank.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/lowrank.py): `ExpertLoRA.__init__` | B 初始化全零；未训练银行可能所有编辑都为零。 | 把专家构造与非退化检查置于 oracle 前；训练专家时系数须非零。 | 初始化为零本身是合理 LoRA 设计，不是代码错误；错误是拿它测 scientific ceiling。 |
| A04 | P0/correctness | [earthdelta/selection.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/selection.py): `plan_from_prediction finite candidate branch` | 有限候选分支没有继承 bound/max_active/max_candidates 的过滤。 | 所有分支共用 feasibility 检查，包括 finite/shape/box/support/cost/noop/稳定 tie-break。 | 静态代码审计发现；本次未运行完整项目测试。 |
| A05 | P0/metric | [earthdelta/paired.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/paired.py): `_assert_linear_operator_assumption / paired_targets` | 文档对 gain 的符号有误；把非线性 summary 一概视作破坏恒等式不正确；断言体为空。 | 统一正收益符号；解释任意共同 summary 的恒等式和原空间 metric 的区别。 | 代数结论可以独立验证，不依赖天气数据。 |
| A06 | P0/metric | [earthdelta/heads.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/heads.py): `ComposedPredictionHead.forward` | gain 默认包含可学习 calibration，且 mean-feature 归约；paired/geometry 权重归约并不一致。 | 输出 analytic_gain 与 corrected_score 两个不同字段；统一 MetricSpec；主线关闭任意校准偏置。 | 不能把可学习修正后的分数叫 exact analytical gain。 |
| A07 | P0/data | [earthdelta/data/make_splits.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/data/make_splits.py): `build_manifest / compute_guard_boundaries` | naive datetime.timestamp 受系统时区影响；归一化 hash 有 placeholder 默认值；默认核验延迟 6h。 | UTC aware；真实 hash 必填；实际资料 coverage；ERA5 回放与 operational availability 分开。 | 6h 不是已核验 ERA5 可用时延；retrospective 协议必须标注。 |
| A08 | P0/provenance | [earthdelta/contracts.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/contracts.py); [earthdelta/bridge/stormer_bridge.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/bridge/stormer_bridge.py): `ArtifactVersion / load_stormer_checkpoint / controlled_rollout` | 非空字符串即可；结构版本不等于 checkpoint 内容身份；版本检查工具未在 rollout 自动执行。 | 完整 checkpoint / bank / norm / metric / grid / split 内容指纹，公共入口 fail closed。 | 严格 state_dict load 只验证结构映射，不证明预测 parity。 |
| A09 | P1/training | [earthdelta/bridge/stormer_bridge.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/bridge/stormer_bridge.py): `controlled_rollout` | tuple→torch.tensor 切断系数梯度；一个 EditPlan 共用于 batch；默认只返回最终步。 | 保留旧 API；加 differentiable coefficient tensor path 与 trajectory return，逐样本计划。 | 梯度断开不影响离线枚举，但阻塞同信息 end-to-end router 强基线。 |
| A10 | P1/system | [earthdelta/bridge/stormer_bridge.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/bridge/stormer_bridge.py): `controlled_rollout hooks` | try/finally 清理合理，但 forward hooks 修改模块临时状态，不是并发安全的纯函数。 | 早期单进程显式限制；P1 新建显式低秩投影接口，保留旧路径 parity。 | 可逆不等于无运行时共享状态；不要无理由重写整个主干。 |
| A11 | P1/math | [earthdelta/geometry.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/geometry.py); [earthdelta/probe.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/probe.py): `ResponseGeometry / local_linearity_error` | RᵀQR 是线性响应重叠，不包含真实 mixed nonlinear interaction。已有测试明确展示失败例。 | 用实际 pair response 检验 gamma_ij；超出局部可信域转 finite exact response。 | 不将正确的一阶几何改成错误“全非线性交互”。 |
| A12 | optional/fail-closed | [earthdelta/memory.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/memory.py): `ewma_error_feature_batched` | 广泛捕获 ValueError 返回零可能掩盖版本/重复记录问题；zip 长度不一致可截断。 | 只允许明确 empty-history 回退；其他异常抛出；batch lengths 校验。 | memory 不进入 P0 主线，使用该分支前必须修复。 |
| A13 | status | [earthdelta/probe.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/probe.py); [earthdelta/spectral.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/spectral.py): `jvp_response / band_energy / single_mode_energy` | 存在 NotImplementedError；频谱诊断是系数级工具，不是完整天气球面谱流程。 | 如实标记未实现；JVP 与 SHT 暂缓，不作为 P0 前置任务。 | 已有 coefficient_diagnostics 可以保留但不可夸大。 |
| A14 | status | [README.md](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/README.md); [scripts/s0_gate_inputs/channels.json](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/scripts/s0_gate_inputs/channels.json): `README evidence vs tracked tree` | README 报告 2020 ERA5 和 checkpoint，本次能访问的树没有对应真实大文件或 S1+ 实验结果。 | 本地 inventory 核验后才能升级为 VERIFIED；报告不把“未见”写成“根本不存在”。 | 报告型证据≠本轮独立数据校验；本轮未跑 195 项测试。 |
| A15 | P1/claim | [earthdelta/contracts.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/contracts.py); [earthdelta/heads.py](https://github.com/sisuolv/EarthDelta/blob/4fe55a7af90ea92f62a3232a571af92bfbd6114d/earthdelta/heads.py): `EditPlan.descriptor / EditResponseHead` | 描述符包含激活标记、系数、窗长，不包含新专家权重本身的可泛化表征。 | 新 bank 是新版本；未见专家实验需明示 descriptors 或无标签 probe adaptation。 | 不能声称当前按构造支持新专家 zero-shot。 |


## 完成度

- CODE_VERIFIED：低秩专家、成对目标、有限/局部探测、Gram 几何、离线教师、规划器和头类；桥接/归一化/数据下载/划分实现；相关合成测试。
- README_REPORTED：195 项总测试规模，192 passed / 3 skipped 的记录；2020 ERA5 `1464×69×128×256`；本地两种 Stormer checkpoint。
- UNVERIFIED：以上数据/权重的实际 bytes、SHA256、可读性、训练年覆盖、GPU 可用性、完整测试当前执行结果。
- 尚无本轮可核验的论文级 evidence：独立官方真实 parity，非零 bank oracle ceiling，du/e0 预测效果，动态 edit skill，跨年/长轨迹/成本收益。

不能从“GitHub 没有大文件”推断“本地没有数据”。但也不能把 README 的下载完成记录升级成已完成科学验证。
