# EarthDelta Codex Tasks

审核基线：`4fe55a7af90ea92f62a3232a571af92bfbd6114d`。以下均未执行；这不是完成列表。

## P0

- [ ] P0-01 — 独立官方 S0 与可追溯数据合同（depends: none）
- [ ] P0-02 — 非退化编辑库与真实 oracle 上限（depends: P0-01）
- [ ] P0-03 — 静态之外的动态空间与瓶颈四象限（depends: P0-02）
- [ ] P0-04 — 最小残差订正与直接收益挑战（depends: P0-03）

## P1

- [ ] P1-01 — 真实成对轨迹数据集与可用信息接口（depends: P0-04）
- [ ] P1-02 — e0/du、bH、直接收益预测头训练（depends: P1-01）
- [ ] P1-03 — 可微逐样本计划与显式低秩注入（depends: P0-04）
- [ ] P1-04 — 强 router、LoRA 和输出订正基线（depends: P1-01, P1-03）
- [ ] P1-05 — 有限响应规划的实际执行闭环（depends: P1-02, P1-03, P1-04）
- [ ] P1-06 — 长轨迹、独立年份和论文主表（depends: P1-05）

## P2

- [ ] P2-01 — 决策子空间与目标/预算重用（depends: P1-06）
- [ ] P2-02 — 候选集级收益校准与不编辑策略（depends: P1-06）

## P3

- [ ] P3-01 — 第二 checkpoint / 第二 backbone（depends: P1-06）
- [ ] P3-02 — 极端事件与物理诊断的定向扩展（depends: P1-06）

## Current stopping point

Do not proceed beyond: **P0-01**. 当前只允许P0-01；成功后停止并汇报，不能自动启动P0-02。

## Unlock condition

P0-01真实独立官方gate PASS且artifact齐全，记录后由下一轮执行授权解锁P0-02。BLOCKED/INVALID不算通过。P1只有P0明确CONTINUE后可开启；P2/P3仅在P1论文级证据支持时。

## Updates

暂时没有任何weather训练、官方checkpoint运行或真实skill结果来自本执行包。每次更新填写run_id/status/evidence_path/full_commit，未通过不得勾选。
