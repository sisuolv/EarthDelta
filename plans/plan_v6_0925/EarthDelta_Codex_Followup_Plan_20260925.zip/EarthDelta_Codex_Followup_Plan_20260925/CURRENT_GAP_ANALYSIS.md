# 当前缺口与处置

所有源码/产物定位在commit `45edd51b563a626e01b31af24e0d95afa6d56d7b`。审查基准为extracted_v2，历史DONE限定证据层。

## 阶段对照
| 阶段 | 已完成 | 仍缺/本包处置 |
|---|---|---|
| FP00–04 | 指定S0、唯一Fs、共同bank机制证据保留 | 不重训；FP02残留消费漏洞由FP06b解决 |
| FP05a | 曝光台账纠正2020H2，17pins前后不变、旧receipt重建 | 状态读取与独立外部原件证明区分 |
| FP05b | 当前N112 cache/OOF/score产物、917tests日志、CP3原/毒化blob同一 | 新receipt缺，逐leadF0错误、source/bg/subset guards缺；原主BELOW/STRADDLE保留 |
| WBX TierA | 官方依赖封装/指标/regrid/CPU tests代码 | 本次未取得原执行日志，不能整体升级execution PASS |
| WBX TierB | 真rollout/导出/原panel对账代码 | summary/GPU原receipt缺；官方metric1e-6relative非bitwise；真实入口年份guard遗漏 |
| FP06 | 规则已存在 | 正式decision尚未做；语义真值表/独立复算后再做 |
| FP07/08/WBX02 | 草案 | 诊断隔离、2022早并行、WBX可选、策略框架提前，均TO_BE_RUN |


## R25-01 — 6h/72h 的 F0 背景换算错误
**STATIC_CONFIRMED / P0**

`scripts/r4_policy_oof.py: stage_score (读取范围40–225)`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/dev_results.csv`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/paired_block_bootstrap.json`

stage_score 对所有baseline=M0比较减同一个H_Fs_24h。非24h的G_F0_point错误；24h主结果与72h相对Fs guard不因此失效。现有independent_recompute未覆盖这个逐lead代数合同。

最小行动：旧产物只读封存；新增errata按各lead同一配对样本重算H和G_F0及CI，禁止覆盖或改判原24h BELOW/STRADDLE。

## R25-02 — CPU评分与merge的证据消费链仍有缺口
**STATIC_CONFIRMED / P0**

`scripts/r4_policy_oof.py: bind、stage_score (40–225)`；`scripts/r4_candidate_cache.py: stage_merge (390–end)`；`tests/test_fp05_consumption_chain.py`

F0背景JSON未在score重hash；policy入口没有调用check_sources/bind_dev_protocol，manifest passed标记加授权子集并非精确冻结N的证明。GPU路径有更强前置检查；没有证据证明本次真的被篡改或泄漏。

最小行动：新版本CPU wrapper核验根授权、完整allowlist、dev protocol、源码、background_F0、预测冻结、完整矩阵与read-set；用真实入口故障注入测试。

## R25-03 — WBX年份helper未覆盖通用evaluate实际入口
**STATIC_CONFIRMED / P0**

`earthdelta/wbx/evaluate.py: evaluate、evaluate_single_chunk、assert_years_authorized`；`tests/test_wbx_evaluate.py:52–86`；`scripts/r4_wbx_tierb.py: build_selection`

TierB选择与truth_from_store有H1/year guard；通用evaluate直接建loader并读取指定时间，未消费年份许可。helper单测不能证明所有公开入口无绕过。caller自己生成的permit+hash也不是外部授权。

最小行动：在实际loader/evaluate之前绑定人工批准的能力文件、精确issue/support及valid times；不能仅以2020全年默认允许代替曝光台账。

## R25-04 — C-J1/C-J2与WBX完成回执及TierB原表未齐
**MISSING / P1**

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/jobs/`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/analysis/cj1_independent_verify.json`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/analysis/cj2_independent_verify_noloss.json`；`artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/job_result.json`；`artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/job_result.json`；`artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json`

新GPU计算有丰富产物与H100 worker记录，但读取到的jobs只含argv/dry-run，未取得新job_id+原始returncode+elapsed完整联结。TierB路径404。FP05a补回旧20作业不能替代新作业。

最小行动：只读复制原receipt/invocation/source/shard日志、TierB summary及其gpu_record；不因GitHub缺附件而重跑训练。

## R25-05 — 结果语言应区分零效应、效用门与动态增量
**STATIC_CONFIRMED / P1**

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/paired_block_bootstrap.json`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/dev_results.csv`；`README.md: Status & roadmap`；`FOLLOWUP_PLAN_20260924_ROUND2(1).md:13–21`

M3vsFs点+0.261143%，CI全正但未达0.34%；M3vsM1跨0。未达门槛/无增量路由支持成立；没有任何样本外正效应不成立。M3vsF0点+0.0697956%仍需配对CI。

最小行动：分别报告以上三层和未确认的泛化范围；保持原BELOW/STRADDLE，不能说无效应或把正点估计升级成业务价值。

## R25-06 — N=112是有记录的事前准入修订，不是全部规则不变
**STATIC_CONFIRMED / P1**

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/admission/policy_dev_selection_STOP.json`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/admission/policy_dev_selection_coordinator_resolution.json`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/PREREGISTRATION.md`

原8-drop cap在16drops时触发，选择算法没换，接受门确被豁免；在DEV outcomes前冻结可接受为修订设计。独立重建确认10drops来自全空16/19层，另6不是全空层原因。结论只覆盖23/25层的可用数据条件分布。

最小行动：登记AMENDMENT，明确cap8→接受16、N112、空层与其余drops；不重选、不补样、不称完整2019H2代表样本。

## R25-07 — CP3有字节级同一性证据，但mutation不是完整保证
**EXECUTION_CONFIRMED / P1**

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/policies/cp3/`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/logs/cp3_poison_check.log`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/tests/mutation_checks.json`；`scripts/r4_policy_oof.py:stage_fit_predict`

Git tree核对四个原始fold预测与各自nan/1e9重跑blob同一。mutation JSON实际13条，不是12条，声称KILLED；未取得每个patch/原始pytest trace，不能独立确认每条是预期断言杀死。CP3代码毒化eval，不含purged；原标签访问器另有限制。

最小行动：补归档mutant patch/exit/失败断言；追加purged标签、F0哈希、source drift、subset N、真实WBX evaluate未授权年份反例。

## R25-08 — FP06当前分支清楚，但规则尚需全域覆盖测试
**STATIC_CONFIRMED / P1**

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/PREREGISTRATION.md:FP06-RULES-v1`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/cache_protocol_v1.json`；`FOLLOWUP_PLAN_20260924_ROUND2(1).md:37–44`

原协议明确In order，因此当前数据应先到规则3 PIVOT_STATIC，不应让后续STRADDLE全局否决。规则并非对所有状态完备：例如所有收益ABOVE但72h guard失败，没有明确终态。当前分支不代表M1达到门槛，更不是新GPU/confirm许可。

最小行动：按原In order实现first-match并写真值表；保留原规则与数值，未覆盖状态fail-closed为INCONCLUSIVE_RULE_COVERAGE并升级协调者。当前明确分支无需重开科学选择或新增审批。

## R25-09 — 2022 verification_failed 原始原因与可用性未核实
**MISSING / P1**

`checkpoints/pull_2022.log`；`FOLLOWUP_PLAN_20260924_ROUND2(1).md:24–26,77–83`

草案报告finalize_year失败；GitHub原log未取得。不能确认全年度不可用或某个具体变量坏，也不能沿用2022更干净/优先confirm的假设。2019全store完整措辞与FP05空层记录冲突，可能后来修过但无新证据。

最小行动：立即并行只读log/schema/完成标志排查；禁止下载/覆盖修复/模型评价。新完整性读取需独立授权与INTEGRITY_ONLY台账。

## R25-10 — TierB PASS不等于官方指标全部逐位相等
**STATIC_CONFIRMED / P1**

`scripts/r4_wbx_tierb.py: RTOL、phase_evaluate (640–end)`；`earthdelta/wbx/_vendor.py`；`earthdelta/wbx/evaluate.py`；`earthdelta/wbx/regrid.py`

实际复用官方WBX metrics/aggregation与WB2 ConservativeRegridder，不是只换标签重写RMSE。TierB official metric比较阈值1e-6 relative；in_job↔old panel和export/truth字节匹配另列。312对应104个family×issue的3leads，而非104个独立天气样本。

最小行动：恢复原表、验证全部预定family/issue/lead；至少两行独立原panel配对，分开报告exact与toleranced三条链；不得凭TierB_PASS判官方标准benchmark或全部bitwise。

## R25-11 — 正式benchmark runner及可部署拟合器尚未交付
**STATIC_CONFIRMED / P1**

`scripts/r4_wbx_benchmark.py:GitHub404`；`earthdelta/policy_oof.py:310–355`；`FOLLOWUP_PLAN_20260924_ROUND2(1).md:85–94`

草案脚本不存在；OOF文件只存parameter digests而不是所有可重载scaler/PCA/ridge数组。不能把112条OOF动作当2020部署策略，也不能按validation最好折选模型。

最小行动：先F0/Fs公共背景设计；只有预先固定训练集与序列化策略、公共baseline共同输入/变量/时间/网格定义后才增加dynamic栏。先实现CLI、再测成本，不把未知工作估为一次聚合。

## R25-12 — 更像共同修正占主导、当前bank差异空间小，而非仅路由太弱
**PLAUSIBLE_UNVERIFIED / P1**

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/dev_results.csv`；`earthdelta/candidate_cache.py:legal_features_np (420–515)`；`Notion:3dcff220ec6980e69babfbdc2fb62d11 §3–4`

M1取得oracle点收益82.997%；oracle-M1仅0.05356个百分点。候选差异、季节、短训练、Fs补偿和粗feature均可解释；没有对照实验区分唯一因果。当前5动作不能否定Notion连续组合/learned predictive state方法。

最小行动：FP07优先centered advantages/top2margin/regret/conditioned responses，再诊断PCA/regularization/season；拟新实验先匹配static vsstateconditioned PEFT，不叠加所有模块。

## R25-12补充：动作不同不等于产生有效增量
`evaluation/failures.json`（45edd51，FP05b）显示M3为expert0/1=73/39，而M1为112/0；oracle为62/41/2/7。M3≈M1不是“实际没路由”。FP07必须将39个切换的正负增量逐项分解，并以loss差/代价加权；不能用动作熵或oracle准确率单独推断价值。当前0.34%的冻结门既用于vsFs也用于vsM1，原轮必须照用；未来研究的总增益门与增量路由门可以按成本/应用理由分别事前定义，不能回改本轮。
