# 可复现与证据版本
受审分支 `audit/round2-review-20260921`，HEAD `45edd51b563a626e01b31af24e0d95afa6d56d7b`，比较基线`e0136d4`；本轮没有修改远程仓库或Notion。

基准合同采用`plans/plans_v5_0924/extracted_v2/...`：该目录是`PLAN_EXECUTION_AUDIT.md`，不是v1的`FULL_REVIEW.md`。同名ZIP不能当同内容；执行机再记录两份ZIP SHA、差异与实际采用v2。审查本机上个ZIP与v2关键文件Git blob一致，见evidence/BASELINE_IDENTITY.json。

环境：历史GPU torch2.3.1+cu121/xformers0.0.27/H100、TF32有效关闭；WBX额外Python依赖单独环境/路径，不能shadow认证torch。记录actual imports/HEAD/dirty sources而非只pip list。不要重新安装依赖悄然改变certified backend。

本包脚本只需Python3.10+和numpy。`recompute_native_evidence.py`真实执行前按Git blob及协议SHA固定输入，输出路径必须在repo之外。真实全cache/bootstrap、GPU与repo pytest在本次审查中均NOT_RUN；自检结果明确SYNTHETIC。连接器无法完整materialize1.7MB canonical JSON，本包保留其Git blob，不伪装已逐条重算。

历史核心Fp05规则：d.0034，4outerfold，7日块、seed20260924、10000draws、95%CI；嵌套预处理/网格读取原冻结源码。逐lead单位、norm/Q/scale、海陆/坐标和6/24/72时间身份始终绑定。不同CPU求和顺序的复算容差仅用于审计scalar重复性，绝不能回写S0或quality阈值。

所有旧run只读，RUN建议独立`/mnt/afs/260010168/earthdelta_followup_runs/<newid>`。不得从run目录slug推平台job_id；不得用hash文件中的自报UTC代替平台submission证据。清楚区别内部先后记录与外部时间认证。
