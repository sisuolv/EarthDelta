#!/usr/bin/env python3
"""Validate the delivered plan, never research results. No repository/network/GPU access.
The optional manifest is verified if present. --report must be a NEW file.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, sys
from pathlib import Path
from typing import Any

REQUIRED=[
'START_HERE_FOR_CODEX.md','FOLLOWUP_PLAN.md','EXECUTION_DAG.md','STOP_CONDITIONS.md',
'CODEX_TASKS.json','ARTIFACT_CONTRACT.md','TEST_PLAN.md','REPRODUCIBILITY.md',
'CURRENT_GAP_ANALYSIS.md','FULL_REVIEW.md','evidence/PLAN_AUDIT_RESULT.json',
'evidence/EVIDENCE_MANIFEST.json','evidence/REQUIRED_INPUTS.md','prompts/CODEX_EXECUTION_PROMPT.md',
 'tools/recompute_native_evidence.py','tools/recompute_auditor_arithmetic.py']
FIELDS=['id','priority','depends_on','scope','commands','acceptance_criteria','evidence_outputs',
'stop_if','status','estimated_minutes']
ALLOWED_VERDICTS={'PLAN_EXECUTED','PARTIALLY_EXECUTED','BLOCKED','FAILED_PLAN_COMPLIANCE','INSUFFICIENT_EVIDENCE'}

def load(p:Path)->Any:
    def reject(s:str): raise ValueError(f'Nonstandard JSON constant: {s}')
    return json.loads(p.read_text(encoding='utf-8'),parse_constant=reject)

def validate(root:Path)->dict:
    checks=[]
    def check(name:str,ok:bool,detail:Any=None):
        checks.append({'check':name,'passed':bool(ok),'detail':detail})
    for rel in REQUIRED: check('required:'+rel,(root/rel).is_file() and (root/rel).stat().st_size>0)
    for p in sorted(root.rglob('*.json')):
        try:load(p);check('json:'+str(p.relative_to(root)),True)
        except Exception as exc:check('json:'+str(p.relative_to(root)),False,str(exc))
    taskdoc=load(root/'CODEX_TASKS.json');tasks=taskdoc if isinstance(taskdoc,list) else taskdoc['tasks']
    ids=[t['id'] for t in tasks];by={t['id']:t for t in tasks}
    check('unique_task_ids',len(ids)==len(set(ids)))
    check('task_fields',all(all(k in t for k in FIELDS) for t in tasks))
    check('dependencies_exist',all(d in by for t in tasks for d in t['depends_on']))
    check('nonempty_task_scope',all(bool(t['scope']) for t in tasks))
    check('evidence_outputs_nonempty',all(isinstance(t['evidence_outputs'],list) and t['evidence_outputs'] for t in tasks))
    check('task_commands_are_strings',all(isinstance(c,str) for t in tasks for c in t['commands']))
    check('future_durations_not_invented',all(t['estimated_minutes'] is None for t in tasks if t['status']=='TO_BE_RUN'))
    visiting=set();visited=set()
    def walk(k):
        if k in visiting: raise ValueError('Cycle at '+k)
        if k in visited:return
        visiting.add(k)
        for d in by[k]['depends_on']:walk(d)
        visiting.remove(k);visited.add(k)
    try:
        for k in by:walk(k)
        check('acyclic_dag',True)
    except Exception as e:check('acyclic_dag',False,str(e))
    audit=load(root/'evidence/PLAN_AUDIT_RESULT.json')
    check('overall_verdict_enum',audit['overall_verdict'] in ALLOWED_VERDICTS)
    check('pinned_audited_head',audit['audited_commit']=='45edd51b563a626e01b31af24e0d95afa6d56d7b')
    check('no_new_gpu_authorized',audit['new_gpu_jobs_authorized'] is False)
    check('no_new_training_authorized',audit['new_training_authorized'] is False)
    check('confirm_closed',audit['confirm_status']=='UNASSIGNED_NO_ACCESS')
    check('fp02_not_silently_done',by['FP-02']['status']!='DONE')
    check('future_fp06_not_claimed_done',all(by[k]['status']=='TO_BE_RUN' for k in ('FP-06a','FP-06b','FP-06c')))
    check('historical_certifications_not_retrained',all(by[k]['status']=='DONE' for k in ('FP-00','FP-01','FP-03','FP-04','FP-05a','FP-05b')))
    check('wbx_done_is_code_scope_only',all(by[k]['status']=='DONE' for k in ('WBX-01A-code','WBX-01B-code')))
    obs=audit['auditor_executed']
    check('no_false_native_replay',obs['native_endpoint_recompute'] is False and obs['full_cache_bootstrap'] is False)
    check('no_false_gpu_or_repo_pytest',obs['gpu_jobs'] is False and obs['repo_pytest'] is False)
    check('fixed_delta',audit['observed_results']['delta_min']==.0034)
    findings=load(root/'evidence/FINDINGS.json')
    check('findings_evidenced',all(f.get('evidence') and f.get('commit') and f.get('evidence_status') in
          {'STATIC_CONFIRMED','EXECUTION_CONFIRMED','PLAUSIBLE_UNVERIFIED','MISSING'} for f in findings))
    check('findings_unique',len(findings)==len({f['id'] for f in findings}))
    stop=(root/'STOP_CONDITIONS.md').read_text()
    for phrase in ('BELOW/STRADDLE','0.0034','UNASSIGNED_NO_ACCESS','EXPOSED_NOT_CONFIRM','1e-5','1e-12','1e-11','PIVOT_STATIC'):
        check('stop_contains:'+phrase,phrase in stop)
    check('report_json_first',(root/'FULL_REVIEW.md').read_text().startswith('```json\n'))
    for p in sorted((root/'tools').glob('*.py')):
        try:ast.parse(p.read_text());check('syntax:'+p.name,True)
        except SyntaxError as e:check('syntax:'+p.name,False,str(e))
    check('no_symlink_entries',not any(p.is_symlink() for p in root.rglob('*')))
    manifest_path=root/'PACKAGE_MANIFEST.json'
    if manifest_path.is_file():
        m=load(manifest_path);actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=manifest_path}
        check('manifest_exact_file_set',actual==set(m['sha256']))
        for rel,want in sorted(m['sha256'].items()):
            p=root/rel
            check('sha256:'+rel,p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==want)
    return {'status':'PLAN_PACKAGE_VALIDATION_PASS' if all(c['passed'] for c in checks) else 'PLAN_PACKAGE_VALIDATION_FAIL',
            'scope':'Delivery/schema/DAG/locks/syntax/hashes only; NOT EarthDelta tests, GPU, native replay or scientific certification.',
            'n_checks':len(checks),'n_passed':sum(c['passed'] for c in checks),'checks':checks}

def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',type=Path,required=True);p.add_argument('--report',type=Path)
    a=p.parse_args()
    try:
        r=validate(a.package.resolve())
        if a.report:
            a.report.parent.mkdir(parents=True,exist_ok=True)
            with a.report.open('x',encoding='utf-8') as f:json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
        print(json.dumps({k:r[k] for k in ('status','scope','n_checks','n_passed')},ensure_ascii=False))
        if r['n_checks']!=r['n_passed']:
            print(json.dumps([c for c in r['checks'] if not c['passed']],ensure_ascii=False,indent=2));return 1
        return 0
    except (OSError,ValueError,KeyError,TypeError) as e:
        print('VALIDATION_ERROR: '+str(e),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
