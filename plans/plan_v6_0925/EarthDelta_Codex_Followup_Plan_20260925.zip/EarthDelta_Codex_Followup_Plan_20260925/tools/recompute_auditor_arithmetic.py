#!/usr/bin/env python3
"""Independent arithmetic on transcribed, source-attributed records; NOT a GPU replay.
No repository imports, no data stores, no model/label fitting. Writes only a new output.
"""
import argparse, collections, datetime, json, math
from pathlib import Path

COMMIT = '45edd51b563a626e01b31af24e0d95afa6d56d7b'
B = 'plans/plan_v4_0923/run_20260924T104725Z_fp05b'

def calculate():
    bad_runs = [(828,835),(1004,1019),(1204,1219),(1284,1307),(1396,1403),(1444,1459)]
    bad = {i for a,b in bad_runs for i in range(a,b+1)}
    pool = list(range(746,1444))
    clean = [i for i in pool if not any(j in bad for j in range(i-2,i+13))]
    candidates = collections.defaultdict(list)
    for i in clean: candidates[(i-746)//28].append(i)
    picked, dropped, structural, previous = [], [], [], -1
    for j in range(128):
        target = 746 + math.floor(j*697/127+0.5)
        block = (target-746)//28
        options = [i for i in candidates[block] if i > previous]
        if not options:
            dropped.append(j)
            if not candidates[block]: structural.append(j)
            continue
        chosen = min(options, key=lambda i:(abs(i-target),i))
        picked.append({'target_id':j,'target_index':target,'index':chosen,'block':block})
        previous = chosen
    expected_drops=[14,15,50,82,83,84,85,86,97,98,99,100,101,117,126,127]
    assert len(clean)==544 and len(picked)==112 and dropped==expected_drops
    folds=[]
    for k,(lo,hi) in enumerate([(0,5),(6,11),(12,17),(18,24)]):
        ev=[p for p in picked if lo<=p['block']<=hi]
        tr=[p for p in picked if not lo<=p['block']<=hi]
        purge=[p for p in tr if any(abs(p['index']-e['index'])<=18 for e in ev)]
        survivors=[p for p in tr if p not in purge]
        folds.append({'fold':k,'eval_n':len(ev),'train_n':len(survivors),'purged_n':len(purge)})
    assert [x['eval_n'] for x in folds]==[29,30,25,28]
    assert [x['train_n'] for x in folds]==[80,76,81,81]
    assert [x['purged_n'] for x in folds]==[3,6,6,3]
    m1=.0026144511753216325
    m3=.0026114318990800127
    oracle=.0031500541314198574
    h=.0019134760154940148
    assert abs((m3-m1)-(-3.0192762416195793e-6))<1e-16
    assert abs((oracle-m1)-.000535602956098225)<1e-16
    assert abs((m3-h)-.0006979558835859979)<1e-16
    intervals={'M3_vs_Fs':[.002389265466412697,.0028437429947231604],
               'oracle_vs_Fs':[.0028240021001966847,.0035073360723953512],
               'oracle_vs_M1':[.0004134062170108022,.0006669270416558893],
               'M3_vs_M1':[-.00020659132804764705,.00018101310838171305]}
    classify=lambda lo,hi:'ABOVE' if lo>=.0034 else ('BELOW' if hi<.0034 else 'STRADDLE')
    classifications={k:classify(*v) for k,v in intervals.items()}
    # Synthetic counterexample isolates the wrong-lead H24 subtraction. Not a real EarthDelta result.
    synthetic_h={6:.01,24:.02,72:.03}
    synthetic_g={6:.04,24:.04,72:.04}
    original={lead:synthetic_g[lead]-synthetic_h[24] for lead in synthetic_g}
    correct={lead:synthetic_g[lead]-synthetic_h[lead] for lead in synthetic_g}
    assert original[24]==correct[24] and original[6]!=correct[6] and original[72]!=correct[72]
    return {'status':'OBSERVED_AUDITOR_ARITHMETIC','commit':COMMIT,
       'scope':'Transcribed integrity index runs and reported summary numbers; not full native matrix/bootstrap rerun, not repository pytest, not GPU.',
       'sources':[B+'/admission/policy_dev_selection_STOP.json',
                  B+'/logs/policies_folds.stdout.log',B+'/evaluation/paired_block_bootstrap.json'],
       'selection':{'pool_n':len(pool),'clean_n':len(clean),'selected_n':len(picked),'dropped_target_ids':dropped,
                    'zero_candidate_strata':[i for i in range(25) if not candidates[i]],
                    'structurally_empty_strata_drop_n':len(structural),
                    'other_order_or_availability_drops_n':len(dropped)-len(structural),
                    'selected_indices':[p['index'] for p in picked], 'folds':folds},
       'headline_arithmetic':{'M3_minus_M1':m3-m1,'oracle_minus_M1':oracle-m1,
                    'M3_vs_F0_point_on_Fs_denominator':m3-h,
                    'static_share_of_oracle_point':m1/oracle,
                    'distance_delta_minus_M3_point':.0034-m3,
                    'delta_min':.0034,'classifications_from_reported_intervals':classifications,
                    'new_bootstrap_CIs_computed':False},
       'synthetic_wrong_lead_counterexample':{'status':'SYNTHETIC_NOT_WEATHER_EVIDENCE',
                    'H_by_lead':synthetic_h,'original_H24_for_all_leads':original,'correct_H_by_lead':correct,
                    'test_passed':True}}

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    obj=calculate();a.out.parent.mkdir(parents=True,exist_ok=True)
    with a.out.open('x',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
    print(json.dumps({'selection_n':obj['selection']['selected_n'],'empty_strata':obj['selection']['zero_candidate_strata'],
                      'structural_drops':obj['selection']['structurally_empty_strata_drop_n'],
                      'folds':obj['selection']['folds'],'static_share':obj['headline_arithmetic']['static_share_of_oracle_point']}))
if __name__=='__main__':main()
