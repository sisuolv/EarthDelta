# 后续计划：先修证据与计分，再诊断；公开比较不绑住主线

审查commit `45edd51b563a626e01b31af24e0d95afa6d56d7b`。所有历史DONE限定其scope；新任务均尚未运行。所有耗时 `MISSING_NEEDS_MEASURED_PROFILE`，不照抄草案<30min/1–2h/一项GPU的未实测估计。

## 顺序修改及理由
原草案FP06第一的方向合理，但“机械判决”之前要补现有数据的独立重算、追加错误字段勘误、关闭source/background消费漏洞和规则优先级。FP08已有log根因从开始并行，不必等诊断；它不影响2019DEV主效应。WBX02正式公开比较是可选背景支线，不能要求人类等其完成才决定是否继续。两页Notion是研究目标：当前受限K4离散路由试验既没证明也没否定完整predictive-state-conditioned adaptation。

## 阶段5的提前框架（FRAMEWORK_NOT_DECISION）
| 证据图景 | 可以提交人工考虑 | 不能自动推出 |
|---|---|---|
| 当前basis的oracle−static很小，共同修正占主导 | 归档这一pilot；保留简单静态修正作背景；评估是否有单一新basis假设值得取证 | 所有状态条件化方法无效；静态已达到0.34% |
| 候选有稳定功能差异，但旧feature/router没抓住 | 仅一个表示/路由假设的受限新实验，匹配静态对照，重新预登记 | 在旧DEV反复调到显著后称新独立证据 |
| 状态条件化优于匹配static，state-swap破坏该增益，安全成本支持 | 才讨论未来新DEV/confirm与更复杂factorization | 当前ridge正点估计已支持JEPA/memory或方法novelty |
| 新数据质量/曝光不明、原证据无法闭合 | 暂停扩张；只做缺口明确的工程审查或归档 | 自动把2021/22之一宣布confirm |
| 人工认为问题已无足够净价值 | 收尾并保留可复现的有限负面结果 | AI擅自决定终止整个研究方向 |

框架不是本轮战略决定。没有“某一个diagnostic p值通过就自动训练新K”的规则。保留delta0.0034与安全界；未来效用门更改必须新研究身份和新未见评价，不能追溯性挽救本轮。

## FP-06a — 只读封存、补新作业回执、独立复算现有标量与原端点抽样

依赖：FP-05a, FP-05b；状态：TO_BE_RUN；资源：CPU only；权限：OPEN_READ_ONLY。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 建立本轮RUN在repo之外；对旧FP05目录所有文件建hash目录并从只读挂载读取，结束重hash。
2. 读实际HEAD和工作区差异；read-only恢复两项C-J真实receipt，关联worker/protocol/源码/数据。任何MISSING不填假值。
3. 运行包内独立标量复算器；它不import原评分函数。对固定三条debug/三条DEV另做端点→loss FP64重算，严格依原V5/V6；记录实际原始两个来源。
4. 确认原24h点与CI、N112、23块、全部失败分母、8份CP3原始blob、全13mutant记录。分开条件CI和学习流程不确定性。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
python "$PKG/tools/validate_package.py" --package "$PKG"
python "$PKG/tools/recompute_native_evidence.py" --repo "$REPO" --out "$RUN/fp06/native_recompute.json"
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_audit_runner.py receipt-audit --repo "$REPO" --out "$RUN/fp06/receipts.json"
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_audit_runner.py endpoint-audit --inputs "$RUN/inputs.json" --out "$RUN/fp06/endpoint_audit.json"
```

### 输出
- `fp06/source_and_old_run_hashes_before.json`
- `fp06/receipts.json`
- `fp06/native_recompute.json`
- `fp06/endpoint_audit.json`
- `fp06/missing_inputs.json`
- `fp06/source_and_old_run_hashes_after.json`
- `fp06/evidence_gate.json`

### 成功标准
- receipt各字段完整、身份相符；N×5×3精确矩阵、F0与OOF同集合；原24h结果重现。
- 旧文件hash不变；缺原件写BLOCKED而非重跑。

### 失败处理
- 原24h/来源不符，先隔离而不是改阈值；旧文件变化；任何未来天气场读取
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## FP-06b — 附加式逐lead勘误与CPU消费闸门加固

依赖：FP-06a；状态：TO_BE_RUN；资源：CPU only；权限：CPU_PATCH_ONLY_NO_MODEL_RUN。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 在新script/version中实现H_h=(ΣFs_h−ΣF0_h)/ΣFs_h，G_F0,h=(ΣF0_h−Σpolicy_h)/ΣFs_h，逐bootstrap draw共同抽样。
2. 补F0背景、source manifest、dev_protocol、精确issue/候选/lead、所有冻结文件根hash检查；不把manifest passed当根授权。
3. 用lead不等H的合成数据、F0损坏、20issue授权子集、CPU source漂移、缺step、purged标签等注入真实入口；spy表明在读取/fit前拒绝。
4. errata列原错误字段与更正字段、affected_leads、unaffected24h、根因。旧evaluation、protocol、models从不覆写。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python -m pytest -q tests/test_fp06_errata.py tests/test_fp06_consumption_guards.py --junitxml="$RUN/fp06b/junit.xml"
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_audit_runner.py append-errata --inputs "$RUN/inputs.json" --out "$RUN/errata"
```

### 输出
- `errata/ERRATUM.md`
- `errata/effects_by_lead.json`
- `errata/paired_F0_intervals.json`
- `fp06b/tests.log`
- `fp06b/junit.xml`
- `fp06b/mutation_checks.json`
- `fp06b/gate.json`

### 成功标准
- 6/24/72分别同lead计分；原24hBELOW/STRADDLE/静态比较不变。
- 每个新增反例被预期guard杀死，不是import失败；旧目录hash不变。

### 失败处理
- 以FP07解释改24h结论；把修bug当额外HPO；修改17核心数值文件
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## FP-06c — FP06-RULES-v1语义真值表及正式DEV收尾

依赖：FP-06b；状态：TO_BE_RUN；资源：CPU only；权限：GATED_BY_EVIDENCE_AND_LITERAL_RULE_TESTS。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 抄录原有序rules和阈值，明确规则3终止与规则6 STRADDLE关系；先出可审真值表，不自行决定战略；原In order足以确定当前分支。
2. 遵守原In order first-match，当前预计到规则3 PIVOT_STATIC，同时标static_vsFs_BELOW、primary_M3_BELOW、oracle_total_STRADDLE。该标签只指本轮状态条件增量未达标。
3. 检查未覆盖分支，例如所有gain ABOVE但72h guard FAIL；遇未覆盖组合输出INCONCLUSIVE_RULE_COVERAGE并升级，不伪造现有规则、不运行更多实验。
4. 发布新decision/HANDOFF/claims，分开receiptPASS、CPUchecks、DEV结论、confirm未读和更大路线未判。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python -m pytest -q tests/test_fp06_decision_table.py
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_audit_runner.py fp06-decision --inputs "$RUN/inputs.json" --out "$RUN/fp06_final"
```

### 输出
- `fp06_final/rules_truth_table.json`
- `fp06_final/decision.json`
- `fp06_final/HANDOFF.md`
- `fp06_final/claims.json`

### 成功标准
- 真值表覆盖BELOW/ABOVE/STRADDLE/INVALID及边界；原效用界保留。
- 明确PIVOT_STATIC不等于静态已过0.34%，不等于终止EarthDelta，不授权GPU。

### 失败处理
- 规则有未决歧义；证据gate未过；CI跨阈值却被说成达标
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## FP-07a — 先冻结诊断问题与文件隔离，不重新训练天气模型

依赖：FP-06a；状态：TO_BE_RUN；资源：CPU only；权限：CPU_DESIGN_AND_HASH_ONLY。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 写诊断协议，明确原始FP05evaluation只读，所有新输出在RUN/diagnostics。保存前后完整hash、代码分支和访问日志。
2. 预列全部诊断、分组、样本分母、展示失败结果；不能事后只展示正月份。新特征/λ变化只标POST_HOC_EXPLORATORY。
3. 把阶段5框架先填好，标FRAMEWORK_NOT_DECISION；无需等WBX公开跑完。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_audit_runner.py freeze-diagnostics --inputs "$RUN/inputs.json" --out "$RUN/diagnostics/protocol.json"
```

### 输出
- `diagnostics/protocol.json`
- `diagnostics/protocol.sha256`
- `diagnostics/read_only_manifest.json`
- `strategy/decision_framework.md`

### 成功标准
- 旧数据只读挂载或至少copy+chmod+前后hash；任务不写旧repo/evaluation；诊断计划明确。

### 失败处理
- 未经冻结先扫所有分组后挑亮点；新窗口天气读取；改原N/阈值
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## FP-07b — 功能差异优先的诊断复盘与假设排序

依赖：FP-06c, FP-07a；状态：TO_BE_RUN；资源：CPU only；权限：CPU_DIAGNOSTIC_AFTER_SEALED_CLOSEOUT。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 把收益拆为共同改善G_Fs(M1)、可路由剩余oracle−M1、实现增量M3−M1；报告top2margin、regret、选action熵/份额及始终选expert0基线，不靠oracle命中率单指标。
2. 计算相对Fs/相对M1的centered advantages矩阵、相关/SVD/有效秩；有已存端点时才计算Q加权功能response余弦。不要以原始loss高度相关或权重hash不同证明功能差异。
3. 逐外折审λ/HPO路径、特征方差与PCA载荷/保留信息。三折λ=10000是记录，不足以诊断；k是regime的超参数不是ridge rank。比较ridge系数必须先映射到共同原始feature坐标，PCA符号/旋转不同不能直接比较。
4. 检查月份、已定义输入端regime、纬区若缓存足够；每格n/CI/缺失都展示，目标/真实未来误差分组只能描述。数据缺两周，不以N112代表整半年。
5. 若重演旧拟合器只是恢复未保存参数，则必须相同seed/outer/inner/data得到相同parameter digest与动作；保存新副本，不改变历史策略。增添intercept/calendar/PCA敏感性试验只在诊断run，禁止升级性能结论。
6. 功效用当前paired-block的估计量和有效块数，区分条件于已拟合OOF模型的CI；旧debug per_issue_sd .004769不能直接移植到DEV。诊断排序不是因果定论。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python -m pytest -q tests/test_fp07_readonly.py tests/test_fp07_diagnostics.py
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_diagnose.py --inputs "$RUN/inputs.json" --protocol "$RUN/diagnostics/protocol.json" --out "$RUN/diagnostics/results"
```

### 输出
- `diagnostics/results/headroom_decomposition.json`
- `diagnostics/results/centered_expert_matrix.json`
- `diagnostics/results/routing_regret.json`
- `diagnostics/results/hpo_feature_audit.json`
- `diagnostics/results/seasonal_coverage.json`
- `diagnostics/results/uncertainty_scope.json`
- `diagnostics/results/REPORT.md`
- `diagnostics/old_hashes_after.json`

### 成功标准
- 无新GPU/天气train；所有反事实/分组标签为diagnostic。
- 原报告hash全不变；给出假设优先级和下一笔资源应该区分什么，不虚称已定位根因。

### 失败处理
- 对旧2019H2调参得到更好数字后冒称新OOF证明；看到结果改诊断分组；写旧文件
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## FP-07c — 向人工提交有边界的新实验候选，不自动选择战略

依赖：FP-07b；状态：TO_BE_RUN；资源：CPU only；权限：DRAFT_ONLY_HUMAN_DECISION_REQUIRED。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 提交收尾、仅静态背景、一次机制实验、延期confirm四分支，绑定当前证据与成本，不要求WBX02c先完成。
2. 机制实验框架：同backbone/同fit数据/同训练预算，比较F0、matched constant PEFT、state-conditioned共享basis；以输入端state-swap/shuffle辨别是否真的依赖状态。第一版只加一个小encoder/一个basis方案。
3. learned predictive factors、orthogonality、memory、dynamic capacity、谱损失只在主状态条件机制有证据后分开检验，不把组件堆叠当novelty。
4. 新窗口须先审全项目曝光和数据质量。复用旧DEV只可探索；独立新DEV/confirm需新授权。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_audit_runner.py strategy-packet --inputs "$RUN/inputs.json" --diagnostics "$RUN/diagnostics/results" --out "$RUN/strategy"
```

### 输出
- `strategy/OPTIONS.md`
- `strategy/MINIMAL_MECHANISM_DESIGN_DRAFT.json`
- `strategy/authorization_required.json`

### 成功标准
- 输出框架而非代人工决定；每个实验假设可证伪且有预算前置。

### 失败处理
- 执行新训练/选择confirm；用当前5候选oracle否定全部连续适配空间
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## FP-08a — 2022现有日志与元数据根因审计，可从开始并行

依赖：FP-00；状态：TO_BE_RUN；资源：CPU only；权限：OPEN_EXISTING_LOGS_ONLY。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 先读取pull_2022.log、finalize_year返回/stacktrace及schema/下载完成标志、文件hash，不读取天气值或预测。
2. 区分缺chunk/非有限、时间轴和变量通道、坐标/regrid、正常阈值误报、远端同步失败、写入未完成；只按证据给原因。与2016/17同状态码不等于同根因。
3. 记录已存在下载/完整性扫描曝光类别；2021/22存在store不等于可用或未触碰。不给2022优先/2021替补结论。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_data_forensics.py inspect-existing --year 2022 --metadata-only --out "$RUN/data2022"
```

### 输出
- `data2022/log_index.json`
- `data2022/schema_report.json`
- `data2022/root_cause_status.json`
- `data2022/NO_MODEL_READS.json`

### 成功标准
- 原始错误和证据联结；证据不足写INCONCLUSIVE，给精确缺件；旧stores无改动。

### 失败处理
- 偷偷读新年truth/运行模型/补下数据/覆盖store；把missinglog当确认全年坏
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## FP-08b — 可选完整性诊断/修复方案，仅在独立批准后

依赖：FP-08a；状态：TO_BE_RUN；资源：CPU only；权限：LOCKED_SEPARATE_DATA_ACCESS_APPROVAL。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 对确实需要数值完整性读取的具体slab预先冻结最小read-set/指标，记录INTEGRITY_ONLY，禁止模型skill筛选。
2. 修复若批准，写新的quarantine store及manifest，不覆盖任何认证路径；原数据和错误证据保留。
3. 只产出数据质量报告，不自动将年设为confirm，不调用天气模型。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_data_forensics.py integrity-audit --approval "$RUN/approvals/data_integrity.json" --out "$RUN/data2022_integrity"
```

### 输出
- `data2022_integrity/read_set.json`
- `data2022_integrity/report.json`
- `data2022_integrity/exposure_delta.json`

### 成功标准
- 读取/repair范围与单独批准一致；无skill outcome，无旧文件覆盖。

### 失败处理
- 无单独授权；数据读取超readset；确认年被临时指定
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## WBX-02a — 恢复Tier原件，补真实评价入口的精确数据授权

依赖：WBX-01A-code, WBX-01B-code；状态：TO_BE_RUN；资源：CPU only；权限：CPU_GUARD_REPAIR_AND_ORIGINAL_EVIDENCE_ONLY。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 取TierA日志和TierB summary/gpu_record/真实receipt；从原FP03/FP04 panel独立抽至少两行，另全表查104family-issue×3集合。缺原件先MISSING，不跑新GPU。
2. 将官方metric≤1e-6relative、native in-job↔old panel bitwise、export/truth byteequal分开验收；不能仅看TIER_B_PASS。
3. 新通用evaluate/loader wrapper在I/O前检查root-approvedpermit、精确issue/support、truth valid times和cache角色；helper外部绕过不得进入正式runner。
4. CPU真实入口反例覆盖2021、2022、跨年lead、2020未授权support、自制year许可、缺vendor/换vendor源码等；不修改17core。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python -m pytest -q tests/test_wbx_actual_entry_guards.py tests/test_wbx_certificate_scope.py --junitxml="$RUN/wbx02a/junit.xml"
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r5_wbx_audit.py --inputs "$RUN/inputs.json" --out "$RUN/wbx02a"
```

### 输出
- `wbx02a/tierA_execution.json`
- `wbx02a/tierB_independent_pairs.json`
- `wbx02a/tierB_full_coverage.json`
- `wbx02a/year_entry_mutations.json`
- `wbx02a/vendor_pin_report.json`
- `wbx02a/gate.json`

### 成功标准
- 官方代码真实消费、值/路径/时间/原件每层有证据。
- 拒绝发生在source/truth loader读前，year-only许可不自动解锁confirm。

### 失败处理
- 缺原表却标认证PASS；把容差改成bitwise文字；任何未经授权年份读取
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## WBX-02b — 公开比较协议和runner实现，先F0/Fs，不假装OOF就是部署模型

依赖：WBX-02a, FP-06b；状态：TO_BE_RUN；资源：CPU only；权限：DRAFT_AND_CPU_IMPLEMENTATION_ONLY。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 先冻结仅已曝光精确时间集合与官方baseline共同00/12UTC、变量/levels/单位、init与valid_time、网格和regrid/masks/聚合定义；不能看到skill再选交集。
2. 优先F0/Fs背景；dynamic栏需要明确训练集合和可重载fitted scaler/PCA/router，不能拼接2019OOF动作，不能选最优外折模型。M1固定expert0展示也需标从旧DEV选取而非未见测试。
3. 明确HRES、ensemble mean、Pangu发布数据的共同truth及ERA5分析输入vs业务输入差别；只做retrospective背景，不冒充官方leaderboard。
4. 实现当前不存在的r4_wbx_benchmark.py CLI或新等价命名，明确help和dry-run无天气读取；从已有缓存可复用的部分开始估成本。
5. 不要求WBX支线完成后才讨论EarthDelta去留。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r4_wbx_benchmark.py --help
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r4_wbx_benchmark.py plan --approval "$RUN/approvals/wbx_metadata.json" --out "$RUN/wbx02b"
```

### 输出
- `wbx02b/protocol.DRAFT.json`
- `wbx02b/paired_support_manifest.json`
- `wbx02b/baseline_registry.json`
- `wbx02b/CLI_TESTS.json`
- `wbx02b/cost_profile_needed.json`

### 成功标准
- CPU接口和语义先通过；动态模型序列化不存在就只保留F0/Fs，不空填dynamic结果。

### 失败处理
- 把WBX smoke当公开性能认证；全2020默认放行；任何新GPU未获授权
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## WBX-02c — 可选公开背景比较运行，不是新的独立confirm

依赖：WBX-02b；状态：TO_BE_RUN；资源：OPTIONAL GPU + CPU; not authorized by this package；权限：LOCKED_SEPARATE_GPU_AND_DATA_APPROVAL。
预计耗时：MISSING_NEEDS_MEASURED_PROFILE。

### 输入与实现
1. 仅在配对协议与资源明确批准后用固定支持运行；可复用已存native forecast但必须identity一致。
2. 分开native objective与WBX公共网格metrics，报告覆盖、baseline缺项、有效日期、完整成本、所有失败，不能结果好才登表。

### 命令
`NEW_AFTER_IMPLEMENTATION:`为待建接口，先实现/测试，不声称已存在。
```bash
# NEW_AFTER_IMPLEMENTATION: implement and test first
python scripts/r4_wbx_benchmark.py run --protocol "$RUN/wbx02b/protocol.json" --approval "$RUN/approvals/wbx_gpu.json" --out "$RUN/wbx02c"
```

### 输出
- `wbx02c/job_result.json`
- `wbx02c/metrics.json`
- `wbx02c/coverage.json`
- `wbx02c/source_and_data_hashes.json`
- `wbx02c/REPORT.md`

### 成功标准
- 真实jobID+returncode+elapsed+hash齐；同support公平比较，不影响原FP05分类。

### 失败处理
- 预算/数据许可未有；任何2021/22/confirm数据；早期成功子集选择
缺输入=BLOCKED；现有正确输入下违反合同=INVALID/FAIL；统计证据不足=INCONCLUSIVE。它们不是同一回事。

## R25-12补充：动作不同不等于产生有效增量
`evaluation/failures.json`（45edd51，FP05b）显示M3为expert0/1=73/39，而M1为112/0；oracle为62/41/2/7。M3≈M1不是“实际没路由”。FP07必须将39个切换的正负增量逐项分解，并以loss差/代价加权；不能用动作熵或oracle准确率单独推断价值。当前0.34%的冻结门既用于vsFs也用于vsM1，原轮必须照用；未来研究的总增益门与增量路由门可以按成本/应用理由分别事前定义，不能回改本轮。
