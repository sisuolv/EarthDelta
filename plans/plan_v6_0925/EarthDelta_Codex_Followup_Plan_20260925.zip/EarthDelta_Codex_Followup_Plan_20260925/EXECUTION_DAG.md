# 执行DAG与科学隔离
```text
历史FP-05a/FP-05b（限定DONE）
    └─ FP-06a 只读证据、receipt、复算
          ├─ FP-06b CPU补链+append-only errata
          │     └─ FP-06c 原In order真值表 → 单测通过 → 正式DEV收尾
          └─ FP-07a 诊断协议+旧文件隔离
                    └─ [AND FP-06c] FP-07b CPU诊断
                                        └─ FP-07c 人工策略材料（不是自动决定）
历史FP-00 ─ FP-08a 2022已有日志/metadata（并行）
                 └─ [单独数据许可] FP-08b 可选完整性读取/修复方案
历史WBX代码 ─ WBX-02a 原认证补件+真实入口年份许可
                 └─ [AND FP-06b] WBX-02b 公共比较协议/CLI
                                      └─ [单独GPU+data批准] WBX-02c 可选运行
```
FP-07c不依赖WBX-02c，避免昂贵背景benchmark阻塞主线策略判断。数据可用性报告可以影响未来设计，但不回写原2019DEV结果。

任何节点FAIL/MISSING禁止其scientific后继；只读盘点、合成guard修复、独立日志审查不伪装成解锁。FP06按原In order走当前明确分支；未覆盖状态只能INCONCLUSIVE_RULE_COVERAGE，不偷换次序。FP07只能写新diagnostics，不可进入原evaluation目录。

本轮最大未经追加批准GPU作业数=0。已跑C-J1/C-J2不重跑；首次摘要不足先恢复原文件。confirmation仍UNASSIGNED_NO_ACCESS。
