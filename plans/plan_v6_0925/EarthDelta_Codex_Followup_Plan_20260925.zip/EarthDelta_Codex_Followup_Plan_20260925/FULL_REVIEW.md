```json
{
  "schema": "ed-plan-execution-audit/20260925-round2",
  "audit_date": "2026-09-24",
  "package_date_label": "20260925 (user-requested filename, not a future execution date)",
  "overall_verdict": "PARTIALLY_EXECUTED",
  "audited_commit": "45edd51b563a626e01b31af24e0d95afa6d56d7b",
  "observed_branch_head": "45edd51b563a626e01b31af24e0d95afa6d56d7b",
  "comparison_base": "e0136d4",
  "fp05a_verdict": "PASS_READ_ONLY_RECONSTRUCTION_WITH_SCOPE_LIMITS",
  "fp05b_execution_verdict": "COMPUTATIONAL_ARTIFACTS_PRESENT_GPU_RECEIPT_CHAIN_INCONCLUSIVE",
  "fp05b_headline_result_verdict": "BELOW_AND_STRADDLE_SUPPORTED_BY_READ_RECORDS_FULL_NATIVE_REPLAY_PENDING",
  "fp05b_data_isolation_verdict": "MAIN_PATH_ENFORCED_BUT_CPU_ASSET_AND_SUBSET_BINDING_GAPS",
  "wbx_tierA_verdict": "OFFICIAL_CODE_REUSE_STATIC_CONFIRMED_EXECUTION_RECEIPT_MISSING",
  "wbx_tierB_verdict": "IMPLEMENTATION_PRESENT_RAW_312_ROW_TABLE_AND_GPU_RECEIPT_MISSING",
  "year2022_finding_severity": "P1_DATA_RELEASE_BLOCKER_ROOT_CAUSE_INCONCLUSIVE_NOT_A_2019_PILOT_FAILURE",
  "followup_plan_soundness_verdict": "ADOPT_READ_ONLY_FIRST_APPROACH_WITH_MANDATORY_ORDER_AND_GATE_REVISIONS",
  "novelty_claim_status": "INCONCLUSIVE_NOT_ESTABLISHED",
  "weather_utility_claim_status": "NO_CONFIRMED_MINIMUM_USEFUL_DYNAMIC_INCREMENT; NOT_NO_POSITIVE_EFFECT",
  "formal_fp06_decision": "NOT_EXECUTED; FIRST_MATCH_READING_WOULD_REACH_RULE_3_PIVOT_STATIC",
  "observed_results": {
    "N": 112,
    "time_blocks": 23,
    "absent_strata": [
      16,
      19
    ],
    "delta_min": 0.0034,
    "M3_vs_Fs_24h": {
      "point": 0.0026114318990800127,
      "ci": [
        0.002389265466412697,
        0.0028437429947231604
      ],
      "status": "BELOW"
    },
    "oracle_vs_Fs_24h": {
      "point": 0.0031500541314198574,
      "ci": [
        0.0028240021001966847,
        0.0035073360723953512
      ],
      "status": "STRADDLE"
    },
    "M3_vs_M1_24h": {
      "point": -3.0192762416195793e-06,
      "ci": [
        -0.00020659132804764705,
        0.00018101310838171305
      ],
      "status": "BELOW"
    },
    "oracle_vs_M1_24h": {
      "point": 0.000535602956098225,
      "ci": [
        0.0004134062170108022,
        0.0006669270416558893
      ],
      "status": "BELOW"
    },
    "H_Fs_24h": {
      "point": 0.0019134760154940148,
      "ci": [
        0.0014975268352890169,
        0.0023419606037218717
      ]
    },
    "source": "plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/paired_block_bootstrap.json",
    "scope": "Read published numeric artifact, verify algebra/status independently; no full scalar-table bootstrap rerun in this session",
    "action_counts_24h": {
      "M1": {
        "expert_0": 112
      },
      "M2": {
        "expert_0": 92,
        "expert_1": 20
      },
      "M3": {
        "expert_0": 73,
        "expert_1": 39
      },
      "oracle": {
        "expert_0": 62,
        "expert_1": 41,
        "expert_2": 2,
        "expert_3": 7
      },
      "reference_selected_by_any_method": 0,
      "source": "plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/failures.json",
      "interpretation": "M3 switches on 39 issues; near-zero incremental mean is not action collapse to M1."
    }
  },
  "auditor_executed": {
    "repo_pytest": false,
    "gpu_jobs": false,
    "native_endpoint_recompute": false,
    "full_cache_bootstrap": false,
    "selection_and_outer_purge_arithmetic": true,
    "cp3_original_vs_poison_git_blob_comparison": true,
    "aggregate_effect_algebra_and_classification": true,
    "synthetic_wrong_lead_counterexample": true,
    "package_tool_selftests": true
  },
  "blocking_items": [
    {
      "id": "R25-01",
      "priority": "P0",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "6h/72h 的 F0 背景换算错误"
    },
    {
      "id": "R25-02",
      "priority": "P0",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "CPU评分与merge的证据消费链仍有缺口"
    },
    {
      "id": "R25-03",
      "priority": "P0",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "WBX年份helper未覆盖通用evaluate实际入口"
    },
    {
      "id": "R25-04",
      "priority": "P1",
      "evidence_status": "MISSING",
      "finding": "C-J1/C-J2与WBX完成回执及TierB原表未齐"
    },
    {
      "id": "R25-08",
      "priority": "P1",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "FP06当前分支清楚，但规则尚需全域覆盖测试"
    },
    {
      "id": "R25-09",
      "priority": "P1",
      "evidence_status": "MISSING",
      "finding": "2022 verification_failed 原始原因与可用性未核实"
    },
    {
      "id": "R25-10",
      "priority": "P1",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "TierB PASS不等于官方指标全部逐位相等"
    },
    {
      "id": "R25-11",
      "priority": "P1",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "正式benchmark runner及可部署拟合器尚未交付"
    }
  ],
  "all_findings": "evidence/FINDINGS.json",
  "initial_open_scope": [
    "CPU read-only receipt/hash/arithmetic inventory",
    "CPU synthetic contract tests",
    "2022 existing logs/metadata only"
  ],
  "new_gpu_jobs_authorized": false,
  "new_training_authorized": false,
  "confirm_status": "UNASSIGNED_NO_ACCESS",
  "fp06_rule_coverage_note": "Literal In order reaches rule 3 on current recorded data. Formal execution remains future; unhandled truth-table states must fail closed."
}
```

# EarthDelta 后续独立审查与研究计划（受审 HEAD 45edd51）

## 0. 审查结论与证据边界

**overall_verdict = PARTIALLY_EXECUTED。** 这不是回到上一轮的“S0没有过、没有共同Fs、没有bank”。FP-05a实质纠正曝光；FP-05b已有真实计算产物、冻结OOF动作和有信息量的开发结果。与此同时，本轮发现逐lead计分错误、CPU消费绑定和WBX实际入口的缺口；新GPU原始完成回执及WBX原表未能在当前可读取材料中闭合。不能把已有“独立复核PASS”作为免审凭据，也不能因附件缺少就反过来声称GPU没有运行。

本轮最准确的科学表述是：**受检五候选在该2019H2可用样本上产生了小的正向相对Fs效应，但主策略没有达到冻结的0.34%工程门，且没有证明状态依赖路由优于训练折选择的固定专家。** 这与“没有任何正效应”“整个状态条件化适配方向无效”不同。

### 固定版本与路径简称

受审分支 `audit/round2-review-20260921` 的实际HEAD为 `45edd51b563a626e01b31af24e0d95afa6d56d7b`，比较基线 `e0136d4`。以下路径全部固定于该HEAD，除明确标注本次生成文件。仓库路径简称如下：

- **A** = `plans/plan_v4_0923/run_20260924T093810Z_fp05a/`
- **B** = `plans/plan_v4_0923/run_20260924T104725Z_fp05b/`
- **F** = `plans/plan_v4_0923/run_20260924T013959Z_fp03_v2/`
- **K** = `plans/plan_v4_0923/run_20260924T033627Z_fp04_bank/`
- **OLD** = `plans/plans_v5_0924/extracted_v2/EarthDelta_Codex_Followup_Plan_20260924/`

验收基准采用用户指定的extracted_v2，不将两份同名zip拼成一个合同。该目录实际审查报告名为 `PLAN_EXECUTION_AUDIT.md`，不是用户描述中的 `FULL_REVIEW.md`；本次通过目录记录和本地上一轮包的Git blob内容身份核对，阅读相关报告、FOLLOWUP_PLAN与STOP。新包中的 `FULL_REVIEW.md` 是本次交付，不冒充旧文件。

本次已独立执行的是：选点规则与outer purge算术、汇总效应恒等式/区间分类、原始与CP3中毒文件的Git内容身份对比、逐lead错误的合成反例及交付工具自检。**未重新执行仓库pytest、GPU、全量native端点计分或完整112×5×3标量bootstrap。** 大 `candidate_results.json` 在Git树存在，但接口返回空内容；原TierB summary及若干artifact路径404。完整原矩阵复算已提供为可运行工具，而非伪造本次运行结果。

标注解释：STATIC_CONFIRMED指逐行源码/文件/数值记录核实；EXECUTION_CONFIRMED指实际执行日志或本次执行核实，并须说明是谁执行；PLAUSIBLE_UNVERIFIED指合理推断未取证；MISSING指本轮所需原件未取得，不等于文件在执行机上不存在。

## 1. 三项工作的四层验收

| 工作 | 计划要求与代码/文档层 | CPU/测试层 | GPU执行层 | 科学回答与剩余缺口 |
|---|---|---|---|---|
| FP-05a | 重建全项目曝光、恢复原证书与回执；不是只登记最终选中模型 | A中有前后17core pin检查、证书重算、历史receipt索引、逐行曝光记录 | 该任务本身CPU只读，不需要新GPU；补回的旧receipt不能代替CJ新receipt | D1纠错成立：2020H2不再当untouched confirm；完整性读取单独分类。只能按实际读取到的台账范围确认，不能担保所有未登记外部会话 |
| FP-05b | split_freeze、candidate_cache、policy_oof及实际CLI均存在；N112×5×3；结果前冻结名单/协议 | 917 passed、19 skipped的历史prefreeze日志；CP3四折×两毒化文件内容一致；mutation记录实际13条。没有本次仓库pytest | debug/dev有H100 worker、端点/状态/身份及计分产物。当前取得的jobs目录主要为argv/dryrun；真实平台ID+job_result+返回码+耗时完整联结尚缺 | 原24h表支持BELOW/STRADDLE与无已证实路由增量；需全矩阵本地独立复算、F0逐lead勘误及CPU根绑定补齐 |
| WBX Tier A/B | _vendor/evaluate/regrid/export/TierB脚本真实存在，实际导入官方实现 | 官方依赖相关测试存在，但缺TierA原始完整运行记录；部分测试依赖不存在会skip，不能拿数量替代内容 | TierB原summary路径404，未取得它的job_result/gpu_record/312行表；因此不能独立认证TierB GPU完成 | 可确认工程接入，不可宣布公开baseline benchmark已跑或全部bitwise；generic evaluate年份入口待加固，benchmark脚本和部署策略缺失 |

证据：A `entry/core_source_pin_check_before.json`、`...after.json`、`certificate_recompute.json`、`job_receipts_index.json`；B `tests/pytest_full_suite_fp05b_prefreeze.log`、`analysis/cj1_independent_verify.json`、`analysis/cj2_independent_verify_noloss.json`、`policies/cp3/`；`earthdelta/wbx/` 与 `scripts/r4_wbx_tierb.py`。上述“历史测试通过”是执行方日志层，不是审查方重新运行。

历史FP-00/01/03/04保持原限定性DONE。FP-02的入口残留虽部分由FP-05实际路径补齐，但不应因此把全部旧验收条目改成DONE。新任务表中“FP-05b DONE”只指原产物已生成，新发现的验收与勘误在FP-06子任务处理，不重新训练旧Fs或bank。

## 2. FP-05a是否真正修正曝光：是，不能再按最终资产逆推曝光

**STATIC_CONFIRMED。** A `entry/exposure_reconstruction_report.json` 与 `entry/exposure_ledger.json` 将X1_N64新增的2020H2训练与结果纳入曝光，区分GRADIENT_AND_RESULT、RESULT与INTEGRITY_ONLY。仅最终Fs的8个训练issue、16个资格issue和当前bank的训练组不足以定义项目曝光；失败候选、旧holdout调参和X1都算。

2019H2完整性扫描不等价于模型结果曝光，但必须记录实际读取范围。2020H2既有训练结果曝光，不能靠“没用过confirm这个标签”恢复未见身份。本轮正式协议保持 `confirm=UNASSIGNED_NO_ACCESS`。这是正确的工程基础，而不是新的科学增益。

A前后17个core源码pin一致支持本次只读任务未变动认证数值路径。证书复算和历史20项receipt索引增强了上一轮证据链，但本次只逐行取得部分大型索引；仍须由实际执行机对完整引用链复核。不能把该索引的“旧作业齐全”升级为新CJ/TierB已独立审完。

## 3. N=128→112：可接受为事前修订，但不能称全部原规则未变

**R25-06 / STATIC_CONFIRMED + 本次算术EXECUTION_CONFIRMED。** B `admission/policy_dev_selection_STOP.json` 明确原规则超过8个丢弃则STOP，实际16个丢弃。协调者保留原选点算法、接受112个已选issue而不采用备选算法，属于**结果揭示前的准入条件修订**：选择函数没换，原“最大丢弃8个”的接受门确实豁免了。

本次从已读完整性索引与冻结选择规则独立重建：698候选网格点、544个完整support的候选、112个保留点；16个被丢弃target编号为：

`14,15,50,82,83,84,85,86,97,98,99,100,101,117,126,127`。

其中10个target落在完全无候选的第16/19层；另6个与其他层的完整性缺口、最近点和严格递增/不可重复规则有关。**“两层结构性为空”可以解释无法补全，但不能解释全部16个丢点。** 对其他6点采用另一个算法可能改变保留数，故报告应列全，而非用两个空层概括所有丢弃。

没有取得“看到模型效果后选最有利规则”的证据。保留原算法比在三个新算法间选一个更可辩护，而且正式GPU规则在此之后才冻结。因此，不建议仅因这个修订就废弃全部试验；建议保留STOP、修订批准、算法不变、N与覆盖变化的完整链，结论限定为**23/25个周层的可用样本条件分布**，不是整半年无偏代表样本。

B协议冻结记录SHA为 `a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8`，`cache_protocol_v1.sha256` 中时间为2026-09-24 12:09:33.764371 UTC。后续计算目录与记录顺序相符，但当前未取得平台原始提交/完成回执，因此“外部可验证的先冻结后GPU提交”仍须补证。hash加自报时间不是可信时间戳服务。

## 4. 数据隔离、CP3与mutation：有实际约束，仍有真实漏洞

### 4.1 已经做到的事情

`earthdelta/split_freeze.py` 并非仅做标签：加载冻结台账，支持窗口与buffer冲突拒绝，allow-list与admission SHA绑定；`read_slab`核对被认证slice和实际store/index。`scripts/r4_candidate_cache.py` 在certify-admission/cache/merge调用清关，GPU路径消费S0、Fs、bank registry及源码；`scripts/r4_policy_oof.py` 的folds/fit-predict/score也从同一角色clearance入口开始。**不能继续沿用上一轮“没有split代码”的结论。**

独立选点/purge算术得到四折eval数29/30/25/28，train数80/76/81/81，purge数3/6/6/3，与 `B/logs/policies_folds.stdout.log` 一致。支持窗口84小时再留24小时buffer；相邻跨折issue时间差≤108小时需净化。内折实现读取到了同样purge逻辑，但本次未在完整原矩阵上重演所有inner拟合。

### 4.2 CP3不是单纯声称“PASS”

本次对Git tree逐项核对原fold文件与 `policies/cp3/fold{f}_{nan,1e9}/oof_predictions_fold{f}.json`：每折两次毒化结果与原文件具有相同blob内容身份：

| fold | 原始及两次CP3共有Git blob |
|---|---|
| 0 | `b8c101ac97fae3aa42f6d44982aa54f9070e4338` |
| 1 | `202ca06f3ecdbccbebeba1f418d145222c888e24` |
| 2 | `a3b8cfd205f8f92afa5cd7c3236f8317aabf0ee2` |
| 3 | `26ad64db0dfaadaef5c07057704c96624860ed3f` |

这是对已保存执行产物的字节级同一性核实，强于只读日志中的IDENTICAL。`FoldLabels`限制训练侧标签访问，预处理和inner HPO在训练侧重拟合；这些事实支持对应外折预测未依赖其验证标签。

但 `scripts/r4_policy_oof.py:stage_fit_predict`（读取范围40–225）实际只毒化eval_ids，**未毒化purged_ids**，而协议CP3写了eval及purged。补上后者是验收残留。完整标签表先被进程加载再包进FoldLabels，不是OS级不可见；正确访问约束和毒化测试是当前保障，不能宣称物理隔离。

### 4.3 mutation数量和检验范围

`B/tests/mutation_checks.json`实际有13条记录，不是prompt中的12条。它们声称KILLED，真实测试文件确有返回码、spy零调用及拒绝理由断言，因此不能简单判形式主义。另一方面，本次缺每条mutation的准确patch、baseline日志和mutant失败栈，无法保证每次都因预定合同断言失败，而不是不相关导入/语法错误。

特别是下列新问题没有被这些测试覆盖。**测试“杀死13个bug”并不意味着不存在第14个。**

### 4.4 计分消费端的缺口：R25-02

**STATIC_CONFIRMED。** `scripts/r4_policy_oof.py:bind,stage_score`（40–225）验证部分protocol/manifest/prediction文件，但：

- F0背景JSON在score直接读取路径，未检验manifest里的SHA。
- CPU policy入口没有调用GPU路径中更强的 `check_sources`、`bind_dev_protocol`；部分merge路径也欠缺相同根绑定。
- 被授权issue的子集不等于冻结N112：一个带PASS标记、精确合法但缩水的manifest仍可能通过clearance；必须从冻结的dev_protocol重建精确全集。
- 字段间身份相符不能代替外部冻结根；调用者同时更换manifest和其本地hash也不构成原实验授权。

这是**可绕过的消费能力问题，不是已经发现此次运行发生泄漏/篡改**。最小修复是在新CPU wrapper中封闭F0/source/dev_protocol/N×candidate×lead/prediction freeze的根链，追加真实入口反例。无需为这类修复重新训练或重新缓存天气轨迹。

## 5. 新发现的计分错误：6h/72h减错了Fs伤害量

**R25-01 / STATIC_CONFIRMED；已执行独立合成反例。** `scripts/r4_policy_oof.py:stage_score` 写法是：

```python
h = boot7['H_Fs_24h']['point']
for c in boot7['comparisons'].values():
    c['G_F0_point'] = c['point'] - h if c['baseline'] == 'M0' else None
```

这对24h成立，对6h和72h不成立。正确逐lead恒等式为：

\[
H_h=\frac{\sum_i L_{Fs,i,h}-\sum_i L_{F0,i,h}}{\sum_i L_{Fs,i,h}},\quad
G_{F0,h}(M)=\frac{\sum_i L_{F0,i,h}-\sum_i L_{M,i,h}}{\sum_i L_{Fs,i,h}}
=G_{Fs,h}(M)-H_h.
\]

**影响范围：** 6h/72h的 `G_F0_point` 无法信任；24h主M3/Fs、oracle/Fs、M3/M1、H24，以及72h对Fs的guard不因此改变。当前 `analysis/phasec_independent_recompute.json` 的验证范围没有关闭逐leadF0恒等式，所以其PASS没有发现此bug。

本包提供两件实际工具：合成H6/H24/H72彼此不同的反例，以及独立的scalar-cache复算器。后者用同一批bootstrap抽样逐lead计算F0差的配对CI，不用两个边际CI端点相减。实际原数据尚未运行，不能列出“已修正”的6/72h真实数字。

**处置应是append-only errata，不是封死纠错，也不是覆盖历史。** 新目录列原字段、正确字段、受影响lead、根因和不受影响24h声明；原evaluation与protocol保持字节不变。

## 6. 核心科学数字：结果有信息，但不能过度悲观或乐观

以下是直接读取B `evaluation/dev_results.csv` 与 `paired_block_bootstrap.json`，并独立核对代数/分类后的数字。单位均为百分比，分母是对应lead的Fs总loss；CI是原固定7日块、10000draws的95%percentile区间，不是本次从原端点重算。

| 比较 | 点估计 | 95%报告CI | 原0.34%门 |
|---|---:|---:|---|
| M3 ridge vs Fs，24h | +0.261143% | [+0.238927%, +0.284374%] | BELOW |
| M1 fold-train static vs Fs，24h | +0.261445% | [+0.225650%, +0.300814%] | BELOW |
| Oracle vs Fs，24h | +0.315005% | [+0.282400%, +0.350734%] | STRADDLE |
| M3 vs M1，24h | −0.000302% | [−0.020659%, +0.018101%] | BELOW |
| Oracle vs M1，24h | +0.053560% | [+0.041341%, +0.066693%] | BELOW |
| H_Fs，24h（正号是Fs伤害） | +0.191348% | [+0.149753%, +0.234196%] | 背景，不是策略 |

M3相对F0的点增益在同一Fs分母上为 **+0.069796%**，原表没有这一差的直接配对CI，不能把正点估计称为已确认优势。它也不是以F0为分母的通常百分比。72h的M3/Fs报告值 +0.438948%，CI [+0.380959%, +0.495153%]，原安全guard通过；它不能取代24h主门。

### 6.1 四条主结论放在一起，应怎么理解

1. **“未达到最小有用效果”成立。** M3区间上界小于0.34%，不只是一个大CI跨线的“不知道”。
2. **“未证明路由优于静态”成立。** M3−M1区间跨0，均值几乎为零；这是未显示增量，不是正式等价性证明。
3. **“沒有任何样本外正效应”不准确。** M3/Fs与M1/Fs的报告区间均全正。严谨表述应限定为“未证明达到冻结工程效用门的状态依赖增量”，同时说明完整独立原始重算和未来确认仍未完成。
4. **“更大路线已失败”不成立。** 这里只测一个弱样本训练、固定幅度/时域的五动作菜单；未测Notion中的连续basis组合、learned predictive state或匹配静态对照下的端到端适配。

### 6.2 M3≈M1并不是路由动作塌缩

B `evaluation/failures.json` 的实际选择如下：

| 方法 | expert0 | expert1 | expert2 | expert3 | no-edit |
|---|---:|---:|---:|---:|---:|
| M1 | 112 | 0 | 0 | 0 | 0 |
| M3 | 73 | 39 | 0 | 0 | 0 |
| Oracle | 62 | 41 | 2 | 7 | 0 |

M3在39个issue上改变了静态动作，约34.82%。它不是“从来没有路由”，而是这些切换没有形成净平均增量。最应先拆的是39次切换的净gain、正负贡献、top2损失差与regret；再看oracle选择2/3的9个稀少case是否被系统性漏掉。以oracle命中率或selection entropy单独判路由有无意义，会忽略近似等价专家间的无关切换与少量高价值错误。

### 6.3 首要解释：共同修正占主导，当前菜单的可路由剩余空间小

本次代数得到：

\[
G(M1)/G(oracle)=0.8299702,\qquad G(oracle)-G(M1)=0.000535603.
\]

即固定专家已取得约83%的oracle总点收益；再好的路由在当前菜单和样本上的可利用平均差，也受剩余约0.05356个百分点约束。其报告CI上界约0.06669个百分点，远小于冻结的0.34%增量门。这比“只因为N112太少”更有解释力，也表明直接换一个复杂router未必值得。

这仍是证据导出的假设排序，不是唯一因果定位。候选彼此功能相近、对Fs的共同偏差补偿、训练组15/16/7/6导致相同32updates下访问次数不同、上半年训练/下半年回顾性评估、固定0.25幅度与仅24h优化，以及粗特征/PCA均可能参与。

**不能将原始expert loss高度相关直接当功能同质证据。** 原始loss共同受天气难度驱动；应对relative-to-Fs收益作行/列中心化，区分共同issue项、静态expert偏置及state×expert交互，再看有效秩。权重digest不同也不证明功能差异；有端点时才做Q加权ΔY方向分析。

### 6.4 特征与功效的具体修订

`earthdelta/candidate_cache.py:legal_features_np`（420–515）用69通道、2×4 pooling、当前状态及两段历史差、4个calendar项，合计1660维，再用PCA降至8维。它有合法state信息，但不是Notion设计的预测状态因子。大尺度无监督PCA可能抹掉与专家差异相关的局部动力信号；这应作为可检验假设，不能因PCA存在就推定泄漏或无用。

HPO日志λ为10000/10000/10000/100，k为2/4/4/3。k是regime-router参数，不是ridge容量；λ差异不能单独证明拟合不稳。PCA基底符号/旋转不同，跨折直接比较投影坐标中的ridge系数没有解释意义，应映射回共同feature坐标或比较预测。

旧 `per_issue_sd=0.004769` 属于debug规划，不是本次配对块估计量的标准差。它不能直接论证当前结果“只是功效不够”。应报告当前7/14日敏感性、条件于冻结OOF模型的CI、有效23块、学习/HPO流程不确定性和样本缺失；不以事后功效换取扩样，不将同一DEV的多种新诊断CI变成新的确认结果。

### 6.5 对delta_min本身的判断

0.0034已经被本轮明确冻结为工程筛查线，不能因看到+0.26%就下调。与此同时，它同时用于总效应vsFs和路由增量vsM1，科学语义不完全相同：路由增量是否值得其成本，不能永久由旧Fs伤害值定义。未来独立实验可以基于实际成本与应用损失，分别事前定义总效益门与动态增量门；这不改变本轮BELOW/STRADDLE，不提供“本轮其实达标”的后门。

## 7. WeatherBench-X：真实复用，不等于认证完毕或可直接公开排名

### 7.1 导入链不是重新写RMSE冒充官方

**STATIC_CONFIRMED。** `_vendor.py`定位并检查固定官方repo/import路径；`evaluate.py`调用WBX metric/statistics/aggregation；`regrid.py`调用 `weatherbench2.regridding.ConservativeRegridder`。项目自己的numpy/reference/block oracle作为交叉对照，而不是主公开指标的替身。这一层工程完成应认可。

外部官方文档也明确WBX先累计统计量再计算metric，WB2公开评估指定forecast、ERA5/analysis、grid、初始化与lead。本次新增web核查仅帮助设计下一轮对齐合同，不证明EarthDelta运行过这些baseline。

### 7.2 Tier B的“逐位”要拆成三条链

`r4_wbx_tierb.py`的 `RTOL=1e-6` 与phase_evaluate说明：官方WBX重建objective对历史panel按相对误差门核查；另有in_job_pinned_objective↔recorded的bitwise标记，以及export↔设备denorm、truth↔in-job target的bitwise检查。**TIER_B_PASS不能自动改写成官方metric每条都逐位一致**，脚本PASS组合也没有把所有 `in_job_equals_recorded_bitwise` 作为同一个硬门。

312条预定anchor来自104个family×issue组合的3个lead：F0 8、Fs-adapter 8、merged Fs 44、四expert自组共44。它不是104个独立天气起报，更多不是bank样本外验证。Fs hook与merged路径的额外对照还被正确标为informational，不应暗中与主anchor混合。

**MISSING。** 用户指定 `artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json` 本次GitHub404，因此无法完成要求的至少2条独立原panel抽查，也无法排除原表family/issue选择性缺失。源码构造的固定集合和循环有正面证据，但源码逻辑不代替实际表。需补小JSON及job_record，不必重跑整套GPU。

Debug类似：本次从CJ1记录抽看3个24h配对值，如 `iss_039add2d41f5c08a` 的expert0值0.03134486261689623、`iss_04eb8e8d56c68faa` 的expert3值0.030332219143745648、`iss_292517fb189ee1bd` 的expert0值0.029999098972745407，其两列相同。**但独立FP04原panel一侧没有取得，因此这不是完成用户所要求的独立原件抽查**。REQUIRED_INPUTS列出了四个panel原路径与固定抽查要求。

### 7.3 年份闸门不是所有入口都生效

**R25-03 / STATIC_CONFIRMED。** TierB `build_selection`先检查H1窗口，truth读取也调用year helper；没有发现它实际读取2021/2022。然而通用 `evaluate` 与 `evaluate_single_chunk` 并未强制消费该helper，调用者可直接提供年份数据。单测 `test_default_year_gate...` / `test_confirm_freeze_gate` 只调用helper；不能证明实际evaluate的拒绝链。

更根本地，调用者自己写permit再算hash不等于项目授权。下一版要在loader前消费外部冻结root与精确issue/support/year清单，验证所有valid_time；低层纯metric函数可以保留用于合成数学测试，但任何真实数据入口必须经过同一个项目授权wrapper。2020年份也不能作为全项目曝光的替身。

### 7.4 正式benchmark runner还不是一条现成命令

`r4_wbx_benchmark.py`在受审提交404；当前OOF文件只保存parameter digests和预测，不是可部署scaler/PCA/ridge权重。因此不能把112条OOF动作映射到2020，不能选验证表现最好的一折模型，也不能说剩下只是一次聚合。

下一轮公共背景首先可以只比较F0/Fs；M3栏须在事前固定fit规则、正确保存/重载模型后另行加入。公共比较要固定共同00/12Z或真实可用起报、lead、变量/pressure levels、单位、坐标、truth、mask、初始化数据与计算预算，并说明只比已曝光子集不是全年leaderboard。HRES/IFSmean/Pangu的数据可比性不同，先审交集和授权，不以哪个baseline显得有利决定加入。

## 8. 2022：提前并行查日志，不自动改选2021

**R25-09 / MISSING（原始log）；PLAUSIBLE_UNVERIFIED（草案所述failure）。** `checkpoints/pull_2022.log`本次404，草案给出finalize_year的verification_failed，不能据此确认坏变量、损坏比例或同2016/2017的共同根因。

建议从开始就并行读取已有日志、stacktrace、下载/完成标志、schema/time/变量元数据。它是未来数据release与confirm讨论的P1阻塞，不是2019DEV已报告效应的原因。若需数值完整性读取，预先冻结read-set并标INTEGRITY_ONLY；不能顺带跑模型、重下全年或覆盖认证store。

“2022优先，2021备选”应暂停。年份更晚不自动更干净；2021存在store也不代表通过内容认证或完全未曝光。草案说2019 store完整可用，与本轮两个全空周不一致；可能后来修复，但缺新证据。应改为“本轮112个issue的认证窗口可用；全年状态待最新逐项证据”，不泛化成所有年度全量完整。

## 9. 对下一轮草案末尾五个问题的独立回答

### 问题1：阶段排序

认可先收尾再投入新GPU的方向。但FP06正式判决前应先完成同一旧缓存的证据恢复、独立标量复算和计分勘误；这不是重做FP05。FP08日志读取立即并行。WBX原件恢复/入口加固也是独立支线；正式公开baseline比较不应成为FP07或人类策略讨论的必需前置。

建议顺序：FP06a封存/复算 → FP06b勘误/消费测试 → FP06c有序决定 → FP07受限诊断 → 人工分支讨论；FP08日志与WBX取证从开始并行。不要为了“顺序零判断”直接把有计分bug的CSV签成最终全字段可信结果，也不要因旁表错误否定未受影响的24h效应。

### 问题2：FP07四项诊断够不够

不够。首先增加共同修正/可路由headroom/已实现增量的分解，以及实际39次切换的加权regret。专家相关性用centered advantages而非raw loss；跨折系数比较须同feature坐标。检查PCA留存、λ路径、calendar-only/intercept-only背景、稀少oracle2/3、训练组大小/训练访问次数与季节的混淆。新特征/正则方案作为POST_HOC_EXPLORATORY，不反向修改原动作。

若端点/原特征未缓存，明确不能做相应诊断。不能为补一项图表自动启动新GPU或者读取新年份。旧模型参数可用同数据/seed/代码复演恢复，但必须匹配原parameter digests、动作和训练label访问日志；保存新副本。

### 问题3：只读诊断防线怎样真实执行

在repo之外创建唯一RUN，旧protocol/evaluation/policies/caches以只读bind mount读取；没有挂载权限时制作固定副本、只读文件权限、禁写旧路径并前后重hash，说明它是检测而非对同UID对抗者的绝对防护。runner应拒绝输出目录位于源repo、路径穿越与指向旧目录的symlink；日志记录模型/数据访问。诊断问题列表与全分组展示先冻结，所有新产物带DIAGNOSTIC_ONLY，旧目录Merkle/hash清单前后不变。

最重要的防线不只是文件写权限：同一DEV上新调出的模型，不管是否写旧文件，仍是对旧DEV的自适应探索，不能再叫独立confirm。整张表所有月份与失败子集都要保存，禁止只报告最好月份；修bug走独立ERRATUM，不以“冻结”作为不能纠错的借口。

### 问题4：阶段5框架要不要提前

要，现在就列出框架，但不作人工战略选择。也无需等WBX公开benchmark跑完。分四个较小问题：原证据/计分能否闭合？固定菜单是否提供足够状态特异差异？一个更贴近Notion机制的最小实验是否值得其预算？数据质量与曝光是否允许未来独立评价？

当前工作假设优先支持“先归档这一K4路由pilot的有限结论，诊断候选空间，再考虑仅一个机制改版”，不支持立刻扩K、堆JEPA/memory或消耗confirm。人工可以选择收尾，或批准一个有具体反例与对照的新设计；Codex只能整理证据/成本/待授权项。

### 问题5：还有哪些遗漏的优先事项

必须补逐leadF0勘误、CPU source/background/精确全集绑定、真实WBX入口授权、原始receipt/Tier表、部署模型序列化、FP06真值表覆盖以及数据状态措辞纠错。科学层还要说明CI是既定OOF过程下的开发统计、原backbone checkpoint-selection历史与回顾性时间方向，避免当成未来在线性能或全气候样本结论。

## 10. FP06是否真是“零判断”：当前分支可以机械，完整规则仍有漏项

B `protocol/PREREGISTRATION.md:FP06-RULES-v1`原文明确 **In order**。当前读取结果按first-match：

1. 先解决INVALID证据检查（不能跳过）。
2. oracle/Fs=STRADDLE，不满足BELOW的STOP_CURRENT_BANK。
3. oracle/M1=BELOW，因此到 **PIVOT_STATIC**。

后续第6条不能作为全局“见到任何STRADDLE就否决第3条”的开关。**不用重新征求科学偏好来选择这条当前清楚的分支**；它也不意味着M1已经过0.34%，原文要求另外报告M1/Fs状态，当前也是BELOW。

但是“规则完整、任何情况都零解释”不成立。例如M3/M1、M3/Fs与oracle均ABOVE而72h guard失败：规则5不能继续，规则6又没有STRADDLE，原文没有命名终态。应写真值表，未覆盖组合fail-closed为待协调者处理的规则覆盖缺口，而不是默认CONTINUE。不能利用补真值表给当前负面结果换判决。

**本审查只给字面分支解读，未替执行方产出正式FP06决定。** 新包FP06c须等原始数据/receipt/勘误gate后，写独立decision.json与claims；它不是更大科研方向的人类战略决定。

## 11. 结合两页Notion，下一笔研究资源究竟应该投在哪里

两页Notion将EarthDelta定位为同一任务内部的physics/predictive-state-conditioned adaptation，而不是仅让天气样本选四个离散专家。原页强调输入物理复杂度、连续delta、从简单FiLM/Adapter起步；v2明确history encoder、预测状态因子、共享low-rank basis、state/router交换和匹配固定PEFT实验。它们是研究设计，不是证据；相关工作标题中的新颖性主张未在本轮重新完成系统文献核验。

当前实现保留了frozen backbone、低秩basis与state输入，但用月份训练四expert、固定0.25单专家和粗PCA做非常窄的取证。negative dynamic increment对该菜单有价值，对全部连续state adaptation没有逻辑否决力。反之，也不能因为Notion方案更丰富就假定换到它必然成功。

### 一个有边界的下一阶段机制框架（不是已授权实验）

问题改成：**在相同backbone、fit数据、训练预算与适配容量下，正确的输入状态—参数增量对应关系，是否比状态无关的最强匹配适配更好？**

保留F0与当前Fs作为背景，但主比较应是重新设计时同预算的constant-PEFT/basis mixture与state-conditioned mixture，而非只战胜当前训练8例且有伤害的Fs。首先只允许一个轻量state encoder、一个固定K basis设计、固定训练目标和hold；通过训练侧共同数据/预算控制，让专家数、样本访问次数和季节不再同时变化。全新的开发和确认身份按未来人工批准的曝光计划建立；旧2019H2可用来探索但不能成为新确认。

机制对照在相同天气输入上交换/打乱router state，保留动作分布、幅度与成本，优先季节内/合理状态支持内交换，避免仅通过极端OOD扰动“制造因果证据”。若正确state不比constant/shuffled好，就没有支持状态特异适配的机制；若差异存在，再逐一检验factorized versus single state、history versus snapshot、固定 versus动态容量。

**不建议现在同时叠加JEPA、memory、动态rank与谱损失。** 不是因为它们与文献重叠就无价值，而是当前最重要的未知量是参数适配差异能否被合法状态信息预测。一次改太多不能定位收益来自哪里，也无法回答Notion自己提出的必要性问题。最小实验框架已放入FP07c；不自动启动训练或选择confirm。

## 12. 阻塞项、允许动作与对外声明边界

| 优先级 | Finding | 最小后续行动 | 影响范围 |
|---|---|---|---|
| P0 | R25-01逐leadF0错误 | 相同旧cache独立复算，附加errata | 非24h F0旁表；不推翻原24h主表 |
| P0 | R25-02 CPU根绑定/全集 | 真实入口反例、F0/source/dev_protocol/精确N修复 | 正式计分签署与未来安全消费 |
| P0 | R25-03 WBX实际入口 | 外部冻结permit及精确support校验 | WBX新真实数据评价，不是已发现旧运行越权 |
| P1 | R25-04/10原件不足 | 两CJ job_result/TierA/B summary/原anchor | 独立执行认证，优先小文件而非重训 |
| P1 | R25-08规则覆盖 | first-match真值表，未覆盖failclosed | FP06正式收尾，当前字面rule3清楚 |
| P1 | R25-09 2022原因 | 现有logs/metadata并行读取 | 未来data release/confirm，不阻塞2019算术 |
| P1 | R25-11 runner/部署缺件 | 公共对齐协议与模型重载先行 | WBX正式排名支线 |

当前不得宣称：达到0.34%主目标；M3有已证实的路由增量；整个动态编辑路线已无效或已证明；TierB官方metric全表bitwise已由本次审完；公开baseline已跑；2022/2021可直接作为confirm；FP06已由本次正式执行；Notion全部机制与novelty已验证。

也不应反向宣称“没有任何正效应”或“GPU没运行”：现有记录支持小正效应和计算产物，但其证据范围有限。最合适的当前外部表述为：

> 在冻结的2019H2可用窗口（112起报、23个周块，两个周层缺失）上，主策略相对Fs有小幅正向开发效应，但未达到预登记最小有用效应，且相对固定专家没有已证实的增量。更大状态条件化适配机制及未来独立确认仍待验证。计分旁表的一项逐lead错误已被独立审查识别，修订将以附加勘误发布，不改变原24h结论。

## 13. 交付、权限与后续输入

完整新包按用户指定20260925命名，审查实际日期为2026-09-24；日期标签不是未来运行承诺。所有未来任务TO_BE_RUN。当前开放CPU只读证据、合成合同测试、2022已有logs/metadata；无新GPU、天气训练、新year数值读取或confirm授权。

包内 `FOLLOWUP_PLAN.md` 给出逐任务输入、NEW接口、验收和失败处理；`CODEX_TASKS.json` 延续FP编号，历史DONE均限定scope；`EXECUTION_DAG.md` 禁止gate失败后运行；`ARTIFACT_CONTRACT.md`规定真实job_id/returncode/elapsed/hash/指标，`TEST_PLAN.md`分开CPU/GPU/回归/科学。

必须补的精确材料见 `evidence/REQUIRED_INPUTS.md`。主要为两CJ完成回执、四个FP04原panel、TierB原summary及gpu_record、TierA日志、2022原failure日志。大candidate JSON已在仓库，不是不存在；执行机正常checkout后用本包独立复算器即可。原权重优先提供只读AFS路径及新鲜hash，而非上传全部GB文件。缺件时保存MISSING，不通过重复训练“补证据”。

### 外部核验资料（仅背景，不代替仓库证据）

- WeatherBench 2官方Evaluation Quickstart：`https://weatherbench2.readthedocs.io/en/latest/evaluation.html`
- WeatherBench 2官方评测配置：`https://weatherbench2.readthedocs.io/en/latest/official-evaluation.html`
- WeatherBench-X官方metrics API：`https://weatherbench-x.readthedocs.io/en/latest/api/metrics.html`
- WeatherBench-X官方aggregation API：`https://weatherbench-x.readthedocs.io/en/stable/api/aggregation.html`

对外研究价值判断来自本报告明确的推导和假设，不把这些官方文档引用当作EarthDelta方法新颖性的证明。
