# 分层测试计划
## A. 本包工具（已在生成时运行，非仓库科学试验）
`tools/recompute_auditor_arithmetic.py`独立重建698pool→544clean→112selected、16drops及四折purge；核对摘要代数/门槛与合成wrong-lead反例。`recompute_native_evidence.py --self-test`只合成数据；真实native scalar re-evaluation尚未运行。

## B. CPU单元/真实入口（TO_BE_RUN）
1. WRONG_LEAD_H：不同H6/H24/H72合成；旧算法必须失败，新算法逐lead成功，主24h不变。
2. F0背景同path改byte；cache subset仍属于allowlist但N非112；source hash漂移；dev protocol变更；缺prediction freeze/错norm/漏candidate或lead/重复id；真实score/merge入口读取/fit spy为0后拒绝。
3. outer eval与purged labels分别nan/1e9；对应outerfold预测/参数digest不变，其他外折合法用作训练时不要求其不变。inner scaler/PCA/HPO只fit innertrain，所有候选同fold。
4. WBX actual evaluate/loader：2021、2022、跨年target、2020非授权support、自签year permit、truth文件替换、vendor路径/HEAD漂移；拒绝发生在数据load前。只测assert_years_authorized helper不够。
5. FP06 first-match truth table覆盖门槛等号、STOP/PIVOT/INCONCLUSIVE、规则3遇oracle-totalSTRADDLE以及static自身BELOW。禁止后续诊断改变classification。
6. readonly negative：试图覆盖旧evaluation/protocol/prediction被文件权限拒绝，旧目录hash前后不变。所有mutants记录diff+预期assertion+returncode，不能以import失败叫KILLED。

## C. 回归（TO_BE_RUN）
保留17core SHA；跑旧917/19对应suite并逐项报告skip，新增WBX真实deps测试不得全部skip仍称通过。历史log不等于本轮重新执行。新CPUwrapper不改变数值路径；如改变受认证core先停止另立S0审查，不自动耗GPU。

## D. GPU证据门
当前只恢复C-J1/C-J2/TierB旧receipts，不提交新GPU。未来WBX-02c需单独预算/数据批准。job_id+job_result rc/elapsed、source/weights/datahash、完整case集齐才算该轴PASS；源码与CPU测试不顶替GPU执行。

## E. 独立数字核对
标量层用包内独立实现（不import生产评分器），核对112×5×3、main bootstrap与所有lead F0配对CI；原端点层另按冻结Q/scale对固定抽样真实文件复算。TierB至少两行从独立原FP03/04 panel比对，整312keys集合完整。没有原tensor/panel就MISSING，不用决定文件中的expected列冒充独立来源。

## F. 科学结果验证
看BELOW/STRADDLE不是测试失败。小正效应、最小有用效应、增量路由、业务安全成本、全学习过程泛化和独立confirm分开。当前M3正CI但未达d；M3−M1跨0不证明严格等效。14day敏感性/diagnostic月子集不替换冻结主结论。
