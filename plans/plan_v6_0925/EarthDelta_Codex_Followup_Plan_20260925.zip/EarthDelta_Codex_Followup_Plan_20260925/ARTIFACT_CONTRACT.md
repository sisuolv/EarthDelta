# 产物合同
每个节点保存task_result.json：task_id、status(OBSERVED/TO_BE_RUN/MISSING/INVALID/BLOCKED)、开始/结束UTC、argv、cwd、实际commit、dirty diff hash、执行源码清单、输入文件完整SHA256、输出完整SHA256、returncode、elapsed_seconds、环境版本、权限文件hash、错误类别和实际通过/未通过门。历史引用记录origin_commit和原路径，不把复制日期当原执行时间。

GPU节点额外：平台job_id、run_id、submission原响应、原始job_result.json、invocation、source snapshot manifest、每worker stdout/stderr、device/model/cuda/torch/xformers/TF32有效getters、checkpoint/Fs/bank加载后digest、admission/content hash、model前后hash、所有attempt与失败成本。dry-run单独标NOT_SUBMITTED；平台完成与脚本完成分开记录。

缓存/评分：exact N×candidate×lead keys，issue UTC/support/role/窗口权限，原生预测/真值端点dtype/shape/file hash，Q/scale/mask/normalization输入与源码，PASS/FAIL_NONFINITE及回退合同，全部planned/attempted/missing分母。F0单独schema但完整集合一致并在消费时fresh hash。manifest的passed必须可重算，不接受自报。

统计：每issue method action、原scalar loss、每block每method每lead totals；bootstrap seed/draws/blocks/抽样index hash、共同分母、H_h和G_F0,h逐draw关系、CI estimator条件范围、所有预注册对比与14日敏感性。0.34%以fraction0.0034保存，报告百分数只显示层乘100。

诊断：独立protocol hash/完整query列表、原始数据只读来源、所有subgroup n及缺失、不只保存好结果、post-hoc标签、原结果hash前后完全一致。重演拟合参数只能相同digests，不选择新最优模型。

勘误：原文件hash、错误字段、lead、影响范围、原值、正确算法/新值、独立重算输出hash、未受影响的24h字段验证；旧文件永久保留。不能把errata当作取消不利原试验。

WBX：官方仓库commit+实际导入路径和源码hash，完整case/variable/level/unit/grid/lead/region/mask/truth/baseline intersection；regrid派生数据独立hash。TierB三链分别保存：native↔旧panel exact、export/truth byte equality、官方metric relative residual。104family-issue与unique meteorological issues分别计数。

不保存密钥、cookie或token。所有新JSON用allow_nan=False或明确编码status/null；fail-open空集合all([])禁止。
