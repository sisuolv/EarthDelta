# 补充材料：先从执行机只读定位，不因聊天缺附件重跑
固定受审提交 `45edd51b563a626e01b31af24e0d95afa6d56d7b`。可在同一AFS直接消费；只有无法访问AFS时才需要上传小型审计补丁包。

## FP-06前必须补
1. `artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/` 和 `artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/` 下原始 `job_result.json`、submission/invocation、source_manifest、stdout/stderr、4worker shard.json/provenance。必须得到平台job_id、run_id、returncode、elapsed_seconds、started/finished UTC；不得从目录名推造job_id。
2. 已提交 `plans/plan_v4_0923/run_20260924T104725Z_fp05b/cache/dev/candidate_results.json`、`background_f0.json`、`cache_manifest.json`、policies全部文件及protocol。它们不都是缺失文件：大candidate JSON存在GitHub，但本会话fetch返回空content且未完成本地整表复算。Codex正常git checkout即可；小型合并上传可把112×5×3标量/状态/time/动作压缩而保持原hash联结。
3. `artifacts/round2_cci/ed-r4bankbj2-0924052624-dde08d/expert{0,1,2,3}/bank_panels_expert{k}.json`（4个JSON）。现有debug决定文件有期望/实际两列，不等价于独立原panel。
4. 每个cache分片issue.json中引用的端点、truth、F0端点文件以只读路径挂载；至少预先固定三条debug和三条DEV做独立native FP64计分，完整coverage/hash通过。不是上传全部大权重的要求。
5. mutation 13条的精确patch、基线测试exit、mutant pytest stdout/stderr/exit与预期失败断言。缺失则保留历史声明，追加新版本再验，不伪造旧日志。

## WBX原认证补件
- `artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json`（原路径GitHub404），其引用的gpu_record.json、真实job_result/submission/source、表中forecast/truthmanifest。
- TierA原始summary、环境依赖版本、pytest完整日志和跳过项；由已有README/本机记录解析真实路径，不凭空写一个目录名。
- TierB至少两条记录必须跟 `plans/plan_v4_0923/run_20260924T013959Z_fp03_v2/certify/fs/panel_initial_final.json` 或上述4个FP04原panel独立对账。104×3是family×issue×lead，不是104个独立起报。

## 2022根因
`checkpoints/pull_2022.log`（GitHub404）、finalize_year原始结果JSON/stacktrace、下载进度/commit/源URL及schema/meta/完成标志。现在不需要2022数值天气场，不授权新模型读取。

## 权重文件只需原身份与本地挂载
Fs adapter SHA256 `7b39226b550a2795b1ed85020057bec46064f132b1c36d77a4db9b5682323089`；merged Fs `1e48438ee98dc72552786011d25d9db3cc208672ceb8a7fc725c7f8fde77a79b`；bank.pt `c3e3e34b60b463b41a6c824fa680d844a2830cd2c7b40d3fc4544dc985b85f81`，以认证manifest及执行机fresh hash为准。本轮CPU收尾不需要重新读取多GB骨干；未来真推理前必须复核。

没有上述新receipt时，FP-06保留BLOCKED_EVIDENCE_CHAIN而不是“GPU未运行”；独立CPU补证与修复可继续，禁止正面science认证或新GPU。
