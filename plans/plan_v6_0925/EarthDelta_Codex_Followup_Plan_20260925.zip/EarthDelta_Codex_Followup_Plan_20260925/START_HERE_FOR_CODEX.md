# EarthDelta：20260925 后续执行入口
受审代码 `45edd51b563a626e01b31af24e0d95afa6d56d7b`，分支 `audit/round2-review-20260921`。文件名按用户要求为20260925；审查发生于2026-09-24，本包没有预先执行未来任务。

先读 `evidence/PLAN_AUDIT_RESULT.json` → `FULL_REVIEW.md` → `CURRENT_GAP_ANALYSIS.md` → `STOP_CONDITIONS.md` → `EXECUTION_DAG.md` → `CODEX_TASKS.json` → `FOLLOWUP_PLAN.md` → `ARTIFACT_CONTRACT.md`/`TEST_PLAN.md`/`REPRODUCIBILITY.md`。参考两页Notion的研究目标，但不要把设计文字当本轮证据。

**结论：PARTIALLY_EXECUTED。** FP05核心表不是没有正效应，而是M3未达0.34%工程门且未证明优于固定专家；已发现6/72h F0换算bug和消费链/年份入口漏洞。保留全部旧结果，发布append-only errata。FP06尚未正式执行。

先以CPU只读做FP-06a、FP-08a。代码加固和合成测试可以按DAG进行，但没有新GPU、天气训练、2021/22天气值读取或confirm授权。不能重复FP00–05训练来填GitHub附件缺口。

建议环境变量（RUN必须在REPO外；不覆盖已有目录）：
```bash
export REPO=/mnt/afs/260010168/EarthDelta
export PKG=/path/to/EarthDelta_Codex_Followup_Plan_20260925
export RUN=/mnt/afs/260010168/earthdelta_followup_runs/round2_audit_$(date -u +%Y%m%dT%H%M%SZ)
mkdir -p "$RUN"
python "$PKG/tools/validate_package.py" --package "$PKG"
```
记录`git rev-parse HEAD`与未提交diff；HEAD变化时比较数值相关diff，不用旧短hash覆盖现有工作区。先查17core pins和已冻结FP05 source artifact。新增修复另建源码身份，不改历史的pin/协议或下游假装仍同版本。

`tools/recompute_native_evidence.py`是本包已实现的CPU复算工具，真实本机执行仍为TO_BE_RUN。`NEW_AFTER_IMPLEMENTATION`注释标记的CLI/测试是待实现接口，不能复制当已存在命令。不存在脚本时先实现并测--help，再执行；工具输出没有permission代替人工批准。

遇MISSING保存精确路径；遇hash/行为冲突停止该分支；CI/策略不支持则诚实结论，不加样本、换阈值、改旧结果。
