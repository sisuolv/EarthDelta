# 当前缺口与原草案采纳表

基于可见的前轮工具返回及原附件；没有在本次打包重新审完整远程仓库/跑GPU。
精确路径+完整commit为证据定位；不发明未取得文件的file:line。
`evidence/CONTEXT_OBSERVATIONS.json`给出全部E编号、原数字与来源。

| 项目 | 已有证据 / 范围 | 尚缺 / 后续 |
|---|---|---|
| FP05a曝光修正 | E02；`plans/plan_v4_0923/run_20260924T093810Z_fp05a/entry/exposure_reconstruction_report.json`明确56条X1H2、698候选slots；已撤销2020H2 confirm | 全原台账按真实job和support再核；这次不重训 |
| FP05a源pin/证书 | before/after与certificate JSON已取回记录，17/17为原报告 | 本地重hash既有资产，明确原件与摘要层 |
| FP05b准入 | E03/E04；STOP和协调者resolution确实有记录 | 是否属于授权偏离、outcome揭示时序；2空层只解释10个drop，不是所有16个 |
| FP05b工程执行 | 有CJ1/CJ2目录、4worker核验摘要、cache/OOF/结果记录 | 原job_id/result/submit/rc/elapsed与端点文件原件仍需本地读取 |
| FP05b统计 | E06包含完整24h小数/CI；N112、23block | 本包工具待在CCI独立跑，不能说已经独立通过 |
| F0衍生列 | E07；`scripts/r4_policy_oof.py::stage_score`可见跨lead扣24h H_Fs | FP06c按各lead重算并出勘误；主24h与72h-vs-Fs旧门不改 |
| 隔离消费链 | `split_freeze`有真实角色+allow-list+support gate | E11：merge/OOF源pin、背景F0 hash、精确DEV列表检查；原cache封装通过不等于全部入口都通过 |
| mutation/CP3 | E08/E15：13项KILLED记录与8次hash不变日志 | 原注入diff/断言/rc、purged标签、正对照；未读原log不自动升级语义杀死 |
| WBX接入 | E10；_vendor真实引用官方repos，evaluate真用metrics/aggregation，非只写依赖名 | 运行时module origin、公开evaluate入口gate、native对账vs官方指标两条链分别验证 |
| WBX TierB | 原附件报告104×3通过 | E12原表仍缺；至少2条原两侧记录+全量ID对账 |
| 2022 | 原附件24–25行报告verification_failed | E13日志原件/根因缺；FP08尽早做，必要时回查共用数据管线 |
| FP06 | 原规则文本已取回，不是所有阈值未知 | 没有正式decision；first-match与any STRADDLE分支不得临场隐藏歧义 |
| FP07 | 四类诊断是尚未执行草案 | 本包补可执行隔离/贡献分解/正确PCA系数比较与精度限制 |
| 标准benchmark | 原附件WBX02提出公开baseline表 | 保留为WBX02b；已曝光年份不等于每条已曝光；无冻结serving M3不能凭空选一折 |

## 采纳与修改

- 采用原草案“廉价只读收尾/诊断优先；人工决策最后”的方向（原附件28–35,99–111行）。
- 修改FP06前置：先数值/执行输入有效性，再规则真值表；规则完整才可称机械。
- 修改FP08排序：日志先行并行，不在WBX/诊断结束后才发现2022或共用代码问题。
- 保留原FP07四类问题，补充`M3−M1`贡献分解、oracle−static上限和feature瓶颈。
  原附件所述“λ不同就拟合不稳”“loss相关就没有专家差异”只是待检假设，不当作定理。
- 修改WBX范围：先验收公共入口，再运行已有资产的context表；不把2020整年称无新增曝光。
- 不把原计划“未证明收益”回改成成功；更准确地区分“>0”“≥δ_min”“比M1好”“confirm”。

## 不能宣称

不能称本包已经确认全部真实GPU执行、完整标量/端点一致、所有入口无泄漏，不能称2022可用。
不能把当前特定bank/ridge的开发结果当全技术路线无价值，也不能用Notion愿景代替机制证据。
