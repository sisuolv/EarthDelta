# 分层测试与验收

## A. 本包工具测试（不是仓库测试）
`python -m pytest -q -p no:cacheprovider "$PKG/tests"`。
合成样例覆盖阈值相等、同lead F0恒等式/paired CI、旧跨lead字段bug、
bootstrap确定性、矩阵缺项/重复、M1非训练折选型、fold泄漏、输出不覆盖、JSON无NaN、路径不越界。
再跑`python tools/validate_package.py --package .`核文件、JSON、DAG、hash。
这些成功只说明打包工具的相应行为，不证明原EarthDelta真实数据通过。

## B. CPU仓库/独立入口验证
在只读源基础上建隔离测试副本，先读取原测试收集/依赖；不能假造pytest数量。
已有tests中test_split_freeze/test_fp05_consumption_chain/test_policy_oof_isolation等按原环境运行；
保存完整junit、argv、stdout、rc和scope，不能把skip说成pass。
若旧测试依赖CCI绝对路径，保持原协议字节；由审计映射层处理，不改原hash凑过。

新增负例必须覆盖：merge/OOF源pin漂移；dev子集manifest；背景F0被改；
score未冻结预测；purged标签poison；全数据PCA；外折标签选lambda；
WBX公开evaluate/evaluate_single_chunk绕过；init合法但valid跨年；新年份伪装旧路径；
自生成授权hash不能作为人工许可；缺support/extra row/重复row不能静默忽略。
测试要有真实I/O/模型构造spy，证明拒绝发生在读取前，不仅检查返回字符串。

## C. 历史GPU核验
本轮不自动提交GPU。核原C-J1/C-J2四worker、exact分片、producer job、协议pin、
真实rc/elapsed；至少3条debug原两侧anchor和全ID join；原始端点→loss抽查使用
事先声明（例如字典序first/middle/last）而非挑相等行。
缺端点原件先定位本地，不要求上传整年数据，不为补当时记录重训。

## D. 回归与隔离
前后hash一致，旧目录不新增/删除文件；包括原evaluation、protocol、folds、predictions。
所有mutation只在副本；包preflight guard也检查新增文本文件。
原source补丁若必须实现，仅形成patch+新测试证据，不直接写原pinned源。
WBX官方指标复用、native兼容对账、年份权限三个方面分别验收。

## E. 科学验证
先完整复算冻结7日结果，14日仅保留原报告性质。主24h结果对齐后再讨论收益解释。
独立计算各lead H_Fs/F0 CI；不能只重跑原phasec脚本继承其盲点。
M3与M1近零需要点/CI/不同选择率/贡献，不能声明等价；oracle−static衡量可利用空间。
相同loss基线造成的原损失相关性不代表expert增益无差异。
开发阶段OOF与最终confirm、已拟合策略条件CI与全学习流程CI分别标注。

## F. 通过与停止
所有结果按四层存：代码存在/CPU通过/真实执行/科学答案；其间不能自动升级。
`BELOW`或负面结论可为合格科学交付。identity/purge/原主指标错误则阻止科学下游。
缺背景benchmark不阻止完成现有主表复算；避免把非核心材料变成无止境循环gate。
