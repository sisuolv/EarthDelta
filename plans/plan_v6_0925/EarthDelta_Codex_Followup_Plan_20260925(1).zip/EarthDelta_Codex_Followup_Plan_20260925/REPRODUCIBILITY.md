# 复现、版本与记录

- 历史源commit：`45edd51b563a626e01b31af24e0d95afa6d56d7b`。本轮打包未再查询远程分支。
- 固定FP05b协议SHA：`a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8`；原记录frozen_utc=2026-09-24T12:09:33.764371Z。
  后者不是独立时间认证，必须与原真实提交回执核对。
- 工具仅需Python3.10+；数值复算用numpy，测试用pytest。不自动pip改动CCI原GPU环境。
  本包本地实测版本保存在`evidence/TOOL_TEST_RESULT.json`；那不是原生产环境版本。
- 原计划/脚本的27个pin与FP04 core17分别核对。源快照在原HEAD只读，扩展工具在包或AUDIT_ROOT。
- CCI绝对路径映射仅在工具内存发生，原JSON/manifest字节不变。外部路径需要显式审查，
  不允许自动读任意文件。独立历史worktree中的原件副本必须有相同hash。
- 原指标使用10,000 draw、seed20260924、7日整块、Fs逐lead分母，14日保留敏感性。
  float最后几位的归约差可记录；审计比较容差1e-12不是改动原V5或S0容差。
- `tools/recompute_frozen_results.py`只读标量cache/冻结action，不读weather tensors。
  输出main match不能代替端点张量的真实性/原GPU执行证明。
- 脚本不会正式执行FP06规则决定：先完整性与语义真值表，再独立decision trace。
- 每次尝试使用新目录；禁止覆盖。耗时来自实际命令记录，不引用旧runtime作新承诺。
- 包内原附件SHA见PACKAGE_MANIFEST/EVIDENCE_MANIFEST；外部原文件与repo版分别比较。
- 所有上游commit、运行时module __file__、已使用*.py hash保存；不升级依赖后仍用旧证书。
- before/after hash记录与只读mount互补：hash检测变化，不等于能够阻止恶意同权限程序。
  Codex遵循只写AUDIT_ROOT；真实只读mount可用时使用，无权限则保存限制，不声称强隔离。
- 不上传凭据、整年数据或模型权重；只在确有必要时提取原件摘要并保留原hash。
