"""Synthetic tests of package utilities. They do not execute EarthDelta or validate real GPU data."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import sys
import numpy as np
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from common import EvidenceError, mapped_path, new_output_dir, write_new
from recompute_frozen_results import CANDIDATES, COMPARISONS, DELTA, LEADS, METHODS, assemble, bootstrap, compare_report, status

def small_arrays():
    ids = [f"i{k}" for k in range(12)]
    blocks = {i: k // 2 for k,i in enumerate(ids)}
    L = np.ones((12,7,3))
    for n in range(12):
        for hi,h in enumerate(LEADS):
            fs=1+0.01*n+0.1*hi
            L[n, METHODS.index("M0"), hi] = fs
            harm=[.01,.02,.05][hi]
            L[n, METHODS.index("F0"), hi] = fs*(1-harm)
            for m in ("M1","M2","M3","M4","M5"):
                L[n, METHODS.index(m), hi]=fs*(1-.025)
    return ids, L, blocks

def test_threshold_boundaries():
    assert status(DELTA, DELTA+.001)=="ABOVE"
    assert status(DELTA-.001, DELTA)=="STRADDLE"
    assert status(DELTA-.001, DELTA-1e-10)=="BELOW"

def test_same_lead_f0_identity_and_paired_interval():
    ids,L,bl=small_arrays(); r=bootstrap(ids,L,bl,draws=100)
    for h in LEADS:
        gain=r["G_vs_F0_by_method_and_lead"]["M3"][str(h)]
        assert abs(gain["point"]-(.025-r["H_Fs_by_lead"][str(h)]["point"]))<1e-14
    assert r["G_vs_F0_by_method_and_lead"]["M3"]["72"]["point"] < 0

def test_detect_24h_harm_reused_for_other_leads():
    ids,L,bl=small_arrays(); calc=bootstrap(ids,L,bl,draws=100)
    old=copy.deepcopy(calc)
    for c in old["comparisons"].values():
        c["G_F0_point"] = c["point"]-.02 if c["baseline"]=="M0" else None
    core, derived=compare_report(calc,old)
    assert not core and len(derived)==6
    assert {d["lead_hours"] for d in derived}=={6,72}

def test_detect_core_metric_change():
    ids,L,bl=small_arrays(); c=bootstrap(ids,L,bl,draws=100); old=copy.deepcopy(c)
    old["comparisons"]["M3_vs_Fs"]["point"] += .01
    core,_=compare_report(c,old)
    assert len(core)==1

def test_bootstrap_deterministic():
    ids,L,bl=small_arrays()
    assert bootstrap(ids,L,bl,draws=100)==bootstrap(ids,L,bl,draws=100)

def test_reject_nonpositive_bootstrap_denominator():
    ids,L,bl=small_arrays(); L[:,METHODS.index("M0"),:]=0
    with pytest.raises(EvidenceError): bootstrap(ids,L,bl,draws=100)

def make_rows():
    ids=[f"i{k}" for k in range(12)]
    times={i:1562414400+k*7*86400 for k,i in enumerate(ids)}
    supports={i:[t-12*3600,t+72*3600] for i,t in times.items()}
    pred={i:{"M0":"reference","M1":"expert_0","M2":"expert_0","M3":"expert_0"} for i in ids}
    rows=[]; bg={}
    for k,i in enumerate(ids):
        bg[i]={"f0_cpu":{str(h):.95+k*.01 for h in LEADS}}
        for c in CANDIDATES:
            for h in LEADS:
                ref=1+k*.01; val=ref-(.03 if c=="expert_0" else .01 if c!="reference" else 0)
                rows.append({"issue_id":i,"candidate_id":c,"lead_hours":h,"status":"PASS","cpu_loss":val,"gain_vs_fs":ref-val})
    folds={"folds":[],"issue_blocks":{i:k for k,i in enumerate(ids)},"supports_utc_epoch":supports}
    for f in range(4):
        ev=ids[3*f:3*f+3]; tr=[i for i in ids if i not in ev]
        inn=[]
        for g in range(3):
            iev=tr[3*g:3*g+3]; itr=[i for i in tr if i not in iev]
            inn.append({"train_ids":itr,"eval_ids":iev})
        folds["folds"].append({"fold":f,"train_ids":tr,"eval_ids":ev,"inner":inn})
    return rows,pred,bg,folds

def test_assemble_and_m1_training_check():
    rows,pred,bg,folds=make_rows(); ids,L,acts,m1,m5=assemble(rows,pred,bg,folds)
    assert L.shape==(12,7,3) and m5=="expert_0" and set(m1.values())=={"expert_0"}

def test_reject_duplicate_rows():
    rows,pred,bg,folds=make_rows(); rows.append(rows[0])
    with pytest.raises(EvidenceError,match="Duplicate"): assemble(rows,pred,bg,folds)

def test_reject_missing_candidate():
    rows,pred,bg,folds=make_rows(); rows.pop()
    with pytest.raises(EvidenceError,match="exact"): assemble(rows,pred,bg,folds)

def test_reject_invalid_static_choice():
    rows,pred,bg,folds=make_rows(); pred["i0"]["M1"]="expert_3"
    with pytest.raises(EvidenceError,match="M1"): assemble(rows,pred,bg,folds)

def test_reject_future_labels_in_fold_train():
    rows,pred,bg,folds=make_rows(); folds["folds"][0]["train_ids"].append("i0")
    with pytest.raises(EvidenceError,match="overlap"): assemble(rows,pred,bg,folds)

def test_no_overwrite(tmp_path):
    p=tmp_path/"a.json"; write_new(p,{"a":1})
    with pytest.raises(FileExistsError): write_new(p,{"a":2})
    assert json.loads(p.read_text())["a"]==1

def test_json_no_nan(tmp_path):
    with pytest.raises(ValueError): write_new(tmp_path/"nan.json",{"a":float("nan")})
    assert not (tmp_path/"nan.json").exists()

def test_ref_path_mapped_without_rewriting_source(tmp_path):
    repo=tmp_path/"repo"; repo.mkdir()
    p=mapped_path(repo,"/mnt/afs/260010168/EarthDelta/x.json")
    assert p==repo/"x.json"
    with pytest.raises(EvidenceError): mapped_path(repo,"/etc/passwd")

def test_output_must_be_outside_repo(tmp_path):
    repo=tmp_path/"repo"; repo.mkdir()
    with pytest.raises(EvidenceError): new_output_dir(repo,repo/"new")

def test_refuse_existing_output_directory(tmp_path):
    repo=tmp_path/"repo"; repo.mkdir(); out=tmp_path/"audit"; out.mkdir()
    with pytest.raises(FileExistsError): new_output_dir(repo,out)

def test_inventory_detects_new_protected_text(tmp_path,monkeypatch):
    import preflight
    repo=tmp_path/"repo"; repo.mkdir(); (repo/"source").mkdir()
    monkeypatch.setattr(preflight,"ROOTS",["source"])
    (repo/"source/a.py").write_text("x=1\n")
    before,_=preflight.inventory(repo)
    (repo/"source/b.py").write_text("x=2\n")
    after,_=preflight.inventory(repo)
    assert set(after)-set(before)=={"source/b.py"}

def test_hfs_sign_is_not_forced_nonnegative():
    ids,L,bl=small_arrays()
    L[:,METHODS.index("F0"),:]=L[:,METHODS.index("M0"),:]*1.02
    r=bootstrap(ids,L,bl,draws=100)
    assert r["H_Fs_by_lead"]["24"]["point"] < 0
