# STOP 条件与不能放宽的门槛

## 1. 先后与真实性

审查历史基准 `45edd51b563a626e01b31af24e0d95afa6d56d7b`；cache协议SHA `a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8`。
源码、协议、准入、样本列表、预测与评分的身份/时序必须闭合。记录中的时间不等于
外部不可篡改时间：`.sha256`侧车12:09:33Z应与真实scheduler提交时间核对，
不从目录名12:38/12:57倒造提交回执；不能用事后重跑证明当时先冻结。

若有效输入下原指标不可重算→`INVALID_RESULT`；缺原件/资产/授权→`BLOCKED`；
CI不足或规则不完备→`INCONCLUSIVE/RULE_INCOMPLETE`。这些不是一种失败。

## 2. 历史数值和split原样保持

完整可机读转录见 `evidence/FROZEN_THRESHOLD_REGISTRY.json`，执行前重hash原文件。

| 对象 | 不得擅改 |
|---|---|
| S0 | ps4官方配置；torch2.3.1+cu121 / xformers0.0.27；TF32关闭；1/4/12步max abs≤1e-5 |
| Fs v2资格 | Ntrain=8、H32、已选lr=.0025；Q1有限；clip0；逐visit≤1.25、epoch上浮1.02；Q3训练8/8方向；训练24h每点ratio<1且均值≤.99；训练72h均值≤1.01；资格holdout24h均值≤1.02 |
| Fs merge | atol=max(1e-5,1.5e-3×delta_max_abs)，rtol=1e-5；不能称逐位，也不用于放宽S0 |
| bank | K4/rank4/blocks18–23；共享认证Fs；singleton=.25、rho=.25、max_active1、hold4后Fs继续；32updates；own-group24h均值ratio严格<1；不能按DEV效果剔专家 |
| A1–A5 | 原声明exact、差值0；4专家×1/4/12和hold后8步完整；特定probe不能泛化为所有初态 |
| split | 2019候选池2019-07-06T12Z..12-27T18Z，698 slots；t−12h..t+72h、15×6h支持；曝光两侧24h，端点接触算冲突 |
| confirm | 2020H2=EXPOSED_NOT_CONFIRM；本轮confirm=null/UNASSIGNED_NO_ACCESS，不自动准入2021/2022 |
| 实际N/层 | 128目标、原maxdrop8、实drop16；接受N112的协调者记录必须保留；16/19为空层、23/25被覆盖，不能不加说明外推 |
| 五候选 | reference+expert0..3；F0仅背景，不进入selector或五候选oracle |
| OOF | 4外折固定blocks0–5/6–11/12–17/18–24；3内折；purge24h；scaler/PCA8在相应train内；λ=.1/1/10/100/1000/10000；k=2/3/4 |
| 统计 | 24h主；6h诊断、72h守门；paired7日block、B10000、seed20260924、95% percentile；14日仅敏感性 |
| 效用 | δ_min=.0034；ABOVE low≥d；BELOW high<d；否则STRADDLE；72h守门low≥−d；不得事后降低 |
| 数值检查 | V4非有限比例≤.02；V5相对1e-12；V6 atol1e-11/rtol1e-8；debug anchors精确0，不以1e-6近似自动通过 |

Fs的Q6只是有限面板点均值容忍，不是普遍“无害证明”。δ_min是工程screen，不是
跨时间/跨lead的F0回本常数。每个lead的F0收益必须扣该lead的H_Fs，每个bootstrap draw分母重算。

## 3. 全入口与不可回写

任何直接路径绕过数据角色、精确issue列表、源pin或prediction freeze时，锁定该下游。
不把行标签、一个自选文件的hash、或“年份2020”当作任意样本科学访问许可证。
必须检查初始化与valid_time跨年；完整feature/label支持域；全候选矩阵；背景F0 hash。

历史注入/重跑测试在隔离副本执行；禁止原pinned源原地变异。语法/依赖失败不算语义KILLED。
不能把改验证标签后评分不变当作无泄漏证明，正确不变对象是该折模型/预测。

**FP-05b 的 BELOW/STRADDLE 结论不得因为 FP-07 诊断结果而被重新解读为达标。**
禁止重选旧N、旧专家、旧fold、阈值、lead、HPO或有利seed，禁止覆盖旧`evaluation/`。
精确代码错误允许另发版本化勘误，保留原值、改值、原因与影响范围；不得擦除旧结果。

## 4. FP06原规则，不由本包预先决定

按原文核对：INVALID；oracle/Fs BELOW→STOP_CURRENT_BANK；oracle/M1 BELOW→PIVOT_STATIC；
M3/M1 BELOW且oracle空间not BELOW→STOP_CURRENT_SELECTOR；M3/M1与M3/Fs均ABOVE且72h过→CONTINUE；
path存在STRADDLE→INCONCLUSIVE。当前组合触发顺序解释问题时先写真值表，
不能凭“零判断”略过。任何未定义的边界/缺失字段必须保持INCONCLUSIVE。

## 5. 资源/2022/战略

旧FP05b协议cap4、infra retry1、timeout3600s不继承为新预算。新GPU/API/训练授权=0。
2022日志根因可先做；必要时仅固定技术校验、隔离副本、无模型效果，记录完整性读取。
不能自动重下载整年、修改旧store或看年份效果择优。数据就绪≠未曝光confirm。
没有真实人工战略决定，禁止开始新科学run、扩大K或自动跑confirm。

## 6. 触发后

保存`STOP.json`：task/规则原出处/实际值/UTC/source commit/inputs hashes/argv/rc/实测耗时/
已发生的读取/已保全产物/允许的补证动作。停止依赖该gate的后继，不删除失败文件。
独立的只读分支可继续；不得无止境以缺少非必要背景材料拖延已经可完成的数值核验。
