# 后续计划：保留原研究框架，先闭合关键证据，再决定下一步

## 相对原附件的明确调整

原附件阶段1~5保留：FP06判定、FP07诊断、FP08数据根因、WBX02标准评测、人工去留。
本包把轻量证据固定/独立数字放在FP06前，把FP08日志根因提前并行；WBX拆成
历史接入验收和可选背景表。阶段5框架现在公开，但决定仍由人作。
原文所有预计“<30分钟/1~2小时”等属于未测计划，执行任务统一
`MISSING_NEEDS_MEASURED_PROFILE`；不得把草案预估当真实耗时。

## 重点解释

**已报告的24h事实**：M3/Fs CI在零以上但低于δ_min；M3/M1接近零；oracle/M1空间很小。
由此没有证明“实用的动态增量”，不等于没有任何正收益，更不等于所有预测状态条件适配都无效。
G_F0跨lead字段有已见代码问题，先新目录复算，原24h BELOW/STRADDLE不因此改门。

历史协议有实值，不应继续写所有阈值未知。完整转录在`evidence/FROZEN_THRESHOLD_REGISTRY.json`，
执行前以原protocol SHA验证。原72h价值依据若薄弱就披露，不临场设计更有利门。

## 任务详情
下列命令中已有tools均包含在本包；空命令项需要Codex先审本地接口并实现审计代码，
不是本包声称已经存在的科学CLI。新代码写AUDIT_ROOT并配测试，不得原地修改pinned文件。


## FP-06a — 只读固定当前工作区、原协议和历史证据，恢复可证明的完成层级

状态：TO_BE_RUN；依赖：无；优先级：P0。

输入：
- `plans/plans_v5_0924/extracted_v2/EarthDelta_Codex_Followup_Plan_20260924/（优先PLAN_EXECUTION_AUDIT.md；FULL_REVIEW.md若只在v1存在则记录映射）`
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/cache_protocol_v1.json`
- `plans/plan_v4_0923/run_20260924T093810Z_fp05a/entry/exposure_ledger.json`

已提供命令：
```bash
python "$PKG/tools/preflight.py" snapshot --repo "$REPO" --out "$AUDIT_ROOT/preflight"
python "$PKG/tools/collect_local_evidence.py" --repo "$REPO" --out "$AUDIT_ROOT/local_evidence"
```

输出：
- `preflight/snapshot.json`
- `local_evidence/manifest.json`
- `FP-06a/thresholds_verified.json`
- `FP-06a/task_result.json`

成功标准：
- 完整HEAD及dirty状态保存，17/27源pin核对
- 原协议SHA与本包记录一致；两旧zip映射/差异明确
- 缺失原件先查CCI；不是缺附件就重新跑GPU

停止条件：
- HEAD/source pin不符且未处理
- 原冻结协议损坏
- 任何覆盖旧run行为

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-06b — 独立复核曝光、准入STOP、真实job/冻结时序和消费入口；补最小回归

状态：TO_BE_RUN；依赖：FP-06a；优先级：P0。

输入：
- `plans/plan_v4_0923/run_20260924T093810Z_fp05a/`
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/admission/`
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/tests/`
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/policies/cp3/`
- `CCI原C-J1/C-J2 job_result和四组anchor`

已提供命令：
```bash
python "$PKG/tools/preflight.py" verify --snapshot "$AUDIT_ROOT/preflight/snapshot.json"
```

输出：
- `FP-06b/job_receipt_join.json`
- `FP-06b/preregistration_timeline.json`
- `FP-06b/stop_resolution_review.json`
- `FP-06b/anchor_pairs.json`
- `FP-06b/entrypoint_matrix.json`
- `FP-06b/mutation_semantics.json`
- `FP-06b/cp3_scope.json`
- `FP-06b/task_result.json`

成功标准：
- 原始job ID、rc、elapsed、argv与源/协议一致；核协议sidecar时间先于真实submit时间
- 至少3条CJ1原两侧anchor浮点/bytes逐项对账，不能只信decision的pairs
- 16drop中10个处于空层、其余6个另有规则原因，全部保留；协调者处置明确分类型
- 13项mutation记录逐条验证语义杀死，8次poison补purged范围与训练标签正对照
- 覆盖cache/merge/folds/fit-predict/score；优先测试source drift、subset manifest、F0 hash、public WBX路径；无历史泄漏证明则不称已泄漏

停止条件：
- 预注册或身份链无法闭合：对应科学gate BLOCKED
- 已发现真实标签泄漏：停止旧结果科学解释
- 不准在旧pinned源原地注入mutation；用隔离副本

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-06c — 从完整已冻结cache独立复算主结果与所有lead的F0对比，附加勘误不改原表

状态：TO_BE_RUN；依赖：FP-06a；优先级：P0。

输入：
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/cache/dev/`
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/policies/`
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/`

已提供命令：
```bash
python "$PKG/tools/recompute_frozen_results.py" --repo "$REPO" --out "$AUDIT_ROOT/FP-06c"
```

输出：
- `FP-06c/recomputed.json`
- `FP-06c/audit_result.json`
- `FP-06c/ERRATA_G_F0.md`
- `FP-06c/task_result.json`

成功标准：
- N112x5x3完整；fold-train M1合法；7日/14日CI及15个原对比对齐
- 按每个lead计算H_Fs与G_F0及paired CI；不把24h H_Fs扣到6h/72h
- 主结果错误→BLOCKED；仅衍生字段错→记录影响边界和addendum，不能丢弃
- 清楚标本脚本核标量层，端点→loss仍待本地原始张量抽查

停止条件：
- hash/矩阵/折隔离不符
- 主24h点估计/CI不符；不可换seed凑一致
- 要求覆盖evaluation旧文件

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-08a — 提前定位2022 verification_failed：先看日志与校验器，不读模型效果

状态：TO_BE_RUN；依赖：FP-06a；优先级：P0_PARALLEL。

输入：
- `checkpoints/pull_2022.log`
- `earthdelta/data/pull_wb2.py`
- `已存在的下载/验数manifest`

已提供命令：
```bash
python "$PKG/tools/preflight.py" verify --snapshot "$AUDIT_ROOT/preflight/snapshot.json"
```

输出：
- `FP-08a/root_cause_from_logs.json`
- `FP-08a/impact_scope.json`
- `FP-08a/integrity_check_plan.json`
- `FP-08a/task_result.json`

成功标准：
- 首次失败位置/退出码/预期实际对象版本分类
- 区分源数据/下载/manifest/校验器/共用预处理问题
- 判断是否可能影响2019/2020旧结果；无证据不称无影响

停止条件：
- 模型/forecast/skill评估请求
- 自动根据得分改用2021
- 日志缺失只标该分支MISSING，不全局停止其它独立只读任务

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-08b — 需要时仅在隔离副本复现技术校验；不取得confirm科学访问权限

状态：CONDITIONAL；依赖：FP-08a；优先级：P1_CONDITIONAL。

输入：
- `FP-08a/integrity_check_plan.json`
- `已存在2022数据（存在性待核）`

命令：`NEW_TO_IMPLEMENT_AFTER_INPUT_REVIEW`。Codex需在新审计目录实现并测试；不猜测原CLI。先读实际脚本确认入口。

输出：
- `FP-08b/validator_result.json`
- `FP-08b/read_ledger.json`
- `FP-08b/data_readiness.json`
- `FP-08b/task_result.json`

成功标准：
- 固定校验项目在读数据前保存；只输出坐标/计数/hash/缺失/完整性状态
- 不产出天气示例、性能、策略选择信息；新增读取记INTEGRITY_READ_ONLY
- 修复发生在独立副本；原data/checkpoint/pins不变；不自动下载新年份
- 校验PASS仅数据就绪，不等于未曝光confirm

停止条件：
- 新增下载/原数据覆盖/效果试跑
- 校验计划需要超出既有授权，保存BLOCKED并停止该分支

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-06 — 在独立输入核验后应用原FP06-RULES-v1；有歧义则记录而不编造决定

状态：TO_BE_RUN；依赖：FP-06b, FP-06c；优先级：P0。

输入：
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/PREREGISTRATION.md`
- `FP-06b/stop_resolution_review.json`
- `FP-06c/audit_result.json`

命令：`NEW_TO_IMPLEMENT_AFTER_INPUT_REVIEW`。Codex需在新审计目录实现并测试；不猜测原CLI。先读实际脚本确认入口。

输出：
- `FP-06/fp06_rule_truth_table.json`
- `FP-06/decision_trace.json`
- `FP-06/formal_decision.json`
- `FP-06/claims.md`
- `FP-06/task_result.json`

成功标准：
- 将6条原顺序规则转成含边界的完整真值表
- 显式处理oracle/Fs STRADDLE与oracle/M1 BELOW当前组合：first-match可能PIVOT_STATIC，但不得忽略最后any STRADDLE文案
- 未明确的历史解释输出RULE_INCOMPLETE/INCONCLUSIVE并给两种推导；不临场把解释冒充早已冻结
- 不能用M3相对Fs正收益替代超过δ_min或超过M1；72h仍保持原门
- 原结论/代码勘误/新解释分别写，不修改历史协议

停止条件：
- 输入完整性/隔离失败
- 需要临场补价值阈值、继续门或结论优先级

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## WBX-02a — 验证官方调用、公共入口年份闸门及历史TierA/B对账，准备标准runner

状态：TO_BE_RUN；依赖：FP-06a；优先级：P0。

输入：
- `earthdelta/wbx/`
- `reference/_manifest.json`
- `artifacts/wbx_smoke/20260924T135007Z_tierB/`

已提供命令：
```bash
python "$PKG/tools/collect_local_evidence.py" --repo "$REPO" --out "$AUDIT_ROOT/WBX-02a_local_inputs"
```

输出：
- `WBX-02a/vendor_runtime.json`
- `WBX-02a/tierB_reconciliation_full.csv`
- `WBX-02a/year_gate_negative_tests.json`
- `WBX-02a/runner_readiness.json`
- `WBX-02a/task_result.json`

成功标准：
- 确认官方metrics/regrid函数真正执行，module path/commit/hash记录
- 完整104x3预定ID集合先核；至少两条FP03/04原记录人工抽查
- evaluate和evaluate_single_chunk直接调用、跨年valid_time、内存array/路径别名均有负例；只校验init年份不够
- 自给freeze hash不是人工授权；输出目录新wrapper/patch，不改旧core17/27
- 区分native兼容分数逐位对账与官方RMSE/ACC已验收，不把前者替代后者

停止条件：
- 公共入口能无授权读取2021/2022/confirm时锁runner
- 原对账表缺失不伪造312个PASS
- 旧年份标签不自动赋予所有issue已曝光资格

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## WBX-02b — 可选：只用现有可核验预测和baseline资产搭建标准benchmark表

状态：CONDITIONAL；依赖：WBX-02a, FP-06；优先级：P2_CONDITIONAL。

输入：
- `已有2020逐issue预测、显式曝光allow-list、baseline本地可用性`
- `scripts/r4_wbx_benchmark.py（存在性/真实CLI待本地检查）`

命令：`NEW_TO_IMPLEMENT_AFTER_INPUT_REVIEW`。Codex需在新审计目录实现并测试；不猜测原CLI。先读实际脚本确认入口。

输出：
- `WBX-02b/availability_and_comparability.json`
- `WBX-02b/benchmark_table.csv`
- `WBX-02b/exposure_delta.json`
- `WBX-02b/task_result.json`

成功标准：
- 核实际CLI --help后在新run目录运行；不存在则标NEW_TO_IMPLEMENT，不能假装已有命令可跑
- 不把全年2020当零新增曝光，逐issue检查；确有新forecast需要另行授权
- HRES/IFS/Pangu缺资产或不可比则NOT_AVAILABLE，不编数据；同时间/变量/单位/grid/指标对齐
- M3没有唯一冻结serving模型时不把4个OOF模型任意挑一个来充数；先报F0/Fs/可用固定模型
- native分数不直接放到官方RMSE排名；结果为context/in-sample或retrospective，不作confirm

停止条件：
- 需要新GPU/API/新年份下载而无独立授权
- 用2020训练组表现证明样本外方法收益

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-07a — 冻结诊断清单、隔离目录与只读输入，确认诊断不回写旧结果

状态：TO_BE_RUN；依赖：FP-06；优先级：P1。

输入：
- `FP-06/formal_decision.json`
- `FP-06c/recomputed.json`
- `原cache/features和OOF记录`

已提供命令：
```bash
python "$PKG/tools/preflight.py" verify --snapshot "$AUDIT_ROOT/preflight/snapshot.json"
```

输出：
- `FP-07a/diagnostic_protocol.json`
- `FP-07a/read_write_contract.json`
- `FP-07a/task_result.json`

成功标准：
- FP06可为负结果或RULE_INCOMPLETE，但FP06b/c的数据/指标完整性必须明确有效
- 只读mount/副本+前后hash；不在旧evaluation写任何文件
- 诊断计划先保存；新增任何假设另记POST_HOC_DIAGNOSTIC

停止条件：
- 冻结结果被改
- 原实验失效仍做功效/机制成功解释

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-07b — 按原草案四类诊断开展库/路由/季节/统计精度复盘，保持描述性

状态：TO_BE_RUN；依赖：FP-07a；优先级：P1。

输入：
- `cache/dev/candidate_results.json`
- `cache/features或可定位1660维features`
- `policies/oof_predictions*.json`
- `原folds/inner HPO记录`

命令：`NEW_TO_IMPLEMENT_AFTER_INPUT_REVIEW`。Codex需在新审计目录实现并测试；不猜测原CLI。先读实际脚本确认入口。

输出：
- `FP-07b/diagnostics.md`
- `FP-07b/expert_diversity.json`
- `FP-07b/router_increment.json`
- `FP-07b/season_support.json`
- `FP-07b/precision_review.json`
- `FP-07b/task_result.json`

成功标准：
- 比较expert损失差/收益差相关性和oracle-over-static，而不是只看原始loss高度相关
- M3与M1不同选择率、贡献、regret、margin；一致率与收益不是同一指标
- λ差异非自动不稳；不同折PCA基底的ridge系数不可直接比较；仅有parameter_digest时不要伪造coeff
- 按固定月/已有regime描述；跨fold cluster ID不是统一气象标签
- per_issue_sd=.004769是原计划exposed数据profile，不等于DEV iid SE；报告23block及14day敏感性/CI宽度，不以观察功效证明效应不存在
- 允许确定性重建原参数时必须同旧配置/特征hash，写新诊断目录；不引入新候选/新特征重新选赢家

停止条件：
- 事后新调参产生新的主结果
- 读confirm效果
- 据诊断把BELOW/STRADDLE改说达标

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## FP-09-HUMAN — 汇总阶段5框架供人工选择：有限重设计/当前配置收尾/后续confirm设计

状态：HUMAN_DECISION_REQUIRED；依赖：FP-06, FP-07b, FP-08a；优先级：HUMAN_GATE。

输入：
- `FP06与FP07/08结果`
- `WBX-02a结果（可标尚未闭合）`
- `WBX-02b是可选背景，不阻止整理人工讨论`

命令：`NEW_TO_IMPLEMENT_AFTER_INPUT_REVIEW`。Codex需在新审计目录实现并测试；不猜测原CLI。先读实际脚本确认入口。

输出：
- `FP-09-HUMAN/decision_brief.md`
- `FP-09-HUMAN/human_decision.json（等待真实授权，不由Codex生成批准）`

成功标准：
- 输出框架和证据，不伪造人工批准
- 是否新训练/新预算/新confirm由用户明确决定；允许先把当前配置收尾与长期idea拆开
- 原Notion预测状态条件适配的广泛假设不被K4 ridge单实验自动否定
- 之后的新实验必须新run/新protocol/新授权，旧dev标已曝光

停止条件：
- Codex自行决定开始科学GPU或替代人工战略决策

失败处理：保存STOP/task_result及已完成证据；只停止依赖失败gate的后继；独立只读分支可继续。预计耗时：`MISSING_NEEDS_MEASURED_PROFILE`。


## 阶段5人工框架——框架，不是决定

| 方向 | 有用的判据 | 不允许的推论 |
|---|---|---|
| 收尾当前K4/ridge配置 | 当前bank相对合法固定专家的可利用空间不足，且无单个可证伪修正假设；或安全/数据资格不满足 | 不可推出所有动态编辑均无价值 |
| 有限重设计 | 明确区分bank无互补性、路由未利用、特征压缩/季节支持问题；只批准一个有限对照 | 不靠盲目加K、JEPA、memory、rank堆叠取代假设 |
| 未来confirm | 候选和estimand/比较对象已冻结；有开发证据与合格独立数据；成本/安全明确 | 不能拿当前BELOW/STRADDLE自动换年份试到成功 |
| 保留更广泛idea | Notion中的predictive-state/basis机制尚未由这次cheap-policy试验完整测试 | 不把“模块尚未测试”写成“已有效”或“已被否定” |

原2019H2可以在新协议下作为已曝光开发数据继续研究；不能重新称最终confirm。
新价值门、新模型或新目标要先明确登记，新结果不能合并进旧主表。
人工现在即可讨论当前配置是否暂停，不必为取得公开baseline排名继续消耗资源。
