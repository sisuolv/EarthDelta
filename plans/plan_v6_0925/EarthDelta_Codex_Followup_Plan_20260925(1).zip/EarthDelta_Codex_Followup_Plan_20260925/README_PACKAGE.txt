EarthDelta_Codex_Followup_Plan_20260925
Read START_HERE_FOR_CODEX.md first.
This archive is a plan plus read-only CPU audit utilities, not a GPU result or scientific acceptance certificate.
Do not overwrite historical outputs. Default new scientific GPU/API/confirmation authorization: NONE.
Package file integrity: python tools/validate_package.py --package .
Synthetic utility tests: python -m pytest -q -p no:cacheprovider tests
Exact attached draft is preserved in inputs/.
