# EarthDelta：Codex 后续执行入口

**先做 FP-06a，再按 DAG 开展 CPU 取证／复算。不要重训已完成的 Fs/bank，不要读取 confirm 模型效果。**

本包以用户给出的分支 `audit/round2-review-20260921` 和此前实际读取的完整 commit
`45edd51b563a626e01b31af24e0d95afa6d56d7b` 为历史审查基准。创建日期 2026-09-24，包名日期 20260925。
它是后续执行计划，**不是新增GPU实验/完整独立审计已经通过的报告**。

## 先读
`evidence/SCOPE_AND_CORRECTIONS.md` → `CURRENT_GAP_ANALYSIS.md` →
`FOLLOWUP_PLAN.md` → `EXECUTION_DAG.md` → `STOP_CONDITIONS.md` → `CODEX_TASKS.json`。
原附件未修改，见 `inputs/FOLLOWUP_PLAN_20260924_ROUND2.original.md`。
上轮验收以 v2 的 `PLAN_EXECUTION_AUDIT.md`/`FOLLOWUP_PLAN.md`/`STOP_CONDITIONS.md` 为主；
不要因v2没有`FULL_REVIEW.md`就说所有上轮材料缺失，完整读取并记录v1/v2映射。

## 本地启动示例
在解压后的本包根目录执行；REPO必须指向真实CCI工作区。不要把API密钥写入任何文件。
```bash
set -euo pipefail
export PKG="$PWD"
export REPO=/mnt/afs/260010168/EarthDelta
test -d "$REPO/.git" || git -C "$REPO" rev-parse --show-toplevel
export AUDIT_ROOT="$(dirname "$REPO")/EarthDelta_followup_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$AUDIT_ROOT"
PYTHONDONTWRITEBYTECODE=1 python "$PKG/tools/validate_package.py" --package "$PKG"
PYTHONDONTWRITEBYTECODE=1 python -m pytest -q -p no:cacheprovider "$PKG/tests"
python "$PKG/tools/preflight.py" snapshot --repo "$REPO" --out "$AUDIT_ROOT/preflight"
python "$PKG/tools/collect_local_evidence.py" --repo "$REPO" --out "$AUDIT_ROOT/local_evidence"
```
随后按任务实现必要的独立核验；现有标量复算入口已提供：
```bash
python "$PKG/tools/recompute_frozen_results.py" --repo "$REPO" --out "$AUDIT_ROOT/FP-06c"
```
输出目录必须新建、在源仓库之外；脚本拒绝覆盖。外部路径由helper按CCI前缀映射，
**不修改冻结JSON里的绝对路径**。只读源代码/旧run保持原样；新脚本、测试、修补建议、
README patch都写到AUDIT_ROOT，后续合并须新的明确操作，不能破坏源pin。

## HEAD变化处理
先保存actual HEAD/diff。禁止`git reset --hard`、强制checkout或覆盖用户变更。
本包工具对历史复算严格要求原commit；新HEAD另建diff审查。必要时建立独立历史worktree，
把所需小证据复制进该工作区（不更改原件）；缺本地artifacts不能靠重训冒充历史已验收。

## 工作权限与自主范围
允许读取本地原件、CPU复算、隔离副本中的负例/回归、已有dev缓存描述性诊断。
Codex可自行安排独立CPU分支、实现审计工具和修复审计工具本身；保存来源、测试与影响范围。
默认**不授权任何新GPU/API科学作业、新训练、新候选搜索、新年份下载或confirm效果访问**。
WBX标准表先复用已有预测；需要额外forecast或资产下载时标BLOCKED，不自动开资源。

## 不能忽略的已见问题
1. `G_F0_point`旧scorer对6/72h也扣24h `H_Fs`；在新目录复算/勘误。
2. OOF/merge源pin、F0文件hash、subset manifest和WBX直接入口需要具体负例。
3. mutation记录实际13项；poison只遍历eval_ids，而协议写eval+purged，需补范围证据。
4. BEFORE/AFTER hash、数值一致、真实job回执和科学门槛是不同层。

不要只看工具退出0：复算可能输出`PRIMARY_REPRODUCED_WITH_DERIVED_FIELD_ERRORS`。
这表示主表可对齐但有勘误待处理，不是无问题验收。收到STOP只停止相关后继，独立只读分支仍可完成。
