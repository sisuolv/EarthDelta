"""Shared read-only evidence helpers; no model, network, scheduler or dataset I/O."""
from __future__ import annotations
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BASELINE = "45edd51b563a626e01b31af24e0d95afa6d56d7b"
PROTOCOL_SHA = "a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8"
REMOTE_ROOT = "/mnt/afs/260010168/EarthDelta"
A = "plans/plan_v4_0923/run_20260924T093810Z_fp05a"
B = "plans/plan_v4_0923/run_20260924T104725Z_fp05b"
P3 = "plans/plan_v4_0923/run_20260924T013959Z_fp03_v2"
P4 = "plans/plan_v4_0923/run_20260924T033627Z_fp04_bank"

class EvidenceError(RuntimeError):
    pass

def utc() -> str:
    return datetime.now(timezone.utc).isoformat()

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def write_new(path: Path, obj: Any) -> None:
    """Exclusive creation: never overwrite original or prior audit outputs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    with path.open("x", encoding="utf-8") as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())

def git(repo: Path, *args: str) -> str:
    p = subprocess.run(["git", "-C", str(repo), *args], capture_output=True,
                       text=True, timeout=30, check=False)
    if p.returncode:
        raise EvidenceError(f"git {' '.join(args)} failed: {p.stderr.strip()}")
    return p.stdout.strip()

def beneath(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False

def mapped_path(repo: Path, value: str) -> Path:
    """Map recorded CCI absolute paths without changing the frozen source JSON."""
    text = str(value)
    if text.startswith(REMOTE_ROOT + "/"):
        p = repo / text[len(REMOTE_ROOT) + 1:]
    else:
        p = Path(text)
        if not p.is_absolute():
            p = repo / p
    if not beneath(p, repo):
        raise EvidenceError(f"Path outside the allowed repository: {value}")
    return p

def checked_ref(repo: Path, ref: dict[str, Any], name: str) -> Path:
    if not isinstance(ref, dict) or not ref.get("path") or not ref.get("sha256"):
        raise EvidenceError(f"Missing path/hash for {name}")
    p = mapped_path(repo, ref["path"])
    if not p.is_file():
        raise EvidenceError(f"Missing {name}: {p}")
    if sha256(p) != ref["sha256"]:
        raise EvidenceError(f"Hash mismatch: {name}: {p}")
    return p

def new_output_dir(repo: Path, out: Path) -> Path:
    out = out.resolve()
    if beneath(out, repo) or beneath(repo, out):
        raise EvidenceError("Output must be outside the source repository and cannot contain it")
    out.mkdir(parents=True, exist_ok=False)
    return out
