#!/usr/bin/env python3
"""Independent scalar re-computation of the frozen FP-05b cache and OOF outputs.
Uses numpy only; never imports EarthDelta, reads weather tensors or changes old outputs.
Reconstructs 7/14-day paired block bootstrap, all original contrasts, and lead-specific
F0 contrasts. This audits already-saved losses, NOT their derivation from GPU tensors.
"""
from __future__ import annotations
import argparse
import csv
import itertools
import json
import sys
from pathlib import Path
from typing import Any
import numpy as np
from common import (A, B, BASELINE, PROTOCOL_SHA, EvidenceError, checked_ref, git,
                    load_json, new_output_dir, sha256, utc, write_new)

CANDIDATES = ("reference", "expert_0", "expert_1", "expert_2", "expert_3")
LEADS = (6, 24, 72)
METHODS = ("F0", "M0", "M1", "M2", "M3", "M4", "M5")
DELTA = 0.0034
DRAW_COUNT = 10000
SEED = 20260924
ORIGIN = 1562414400
COMPARISONS = (
    ("oracle_vs_Fs", "M4", "M0", 24), ("oracle_vs_M1", "M4", "M1", 24),
    ("M5_vs_Fs", "M5", "M0", 24), ("M1_vs_Fs", "M1", "M0", 24),
    ("M2_vs_Fs", "M2", "M0", 24), ("M2_vs_M1", "M2", "M1", 24),
    ("M3_vs_Fs", "M3", "M0", 24), ("M3_vs_M1", "M3", "M1", 24),
    ("M1_vs_Fs_72h", "M1", "M0", 72), ("M2_vs_Fs_72h", "M2", "M0", 72),
    ("M3_vs_Fs_72h", "M3", "M0", 72), ("M1_vs_Fs_6h", "M1", "M0", 6),
    ("M2_vs_Fs_6h", "M2", "M0", 6), ("M3_vs_Fs_6h", "M3", "M0", 6),
    ("F0_vs_Fs_background", "F0", "M0", 24),
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise EvidenceError(message)


def status(lo: float, hi: float) -> str:
    return "ABOVE" if lo >= DELTA else ("BELOW" if hi < DELTA else "STRADDLE")


def assemble(rows: list[dict], predictions: dict, background: dict, folds: dict) -> tuple:
    """Check exact Cartesian coverage and rebuild losses/actions without production code."""
    ids = sorted(predictions)
    require(bool(ids), "Empty predictions")
    require(set(folds["issue_blocks"]) == set(ids), "Folds and predictions have different issue sets")
    require(set(background) == set(ids), "F0 coverage is incomplete or contains extra issues")
    keys = [(r["issue_id"], r["candidate_id"], int(r["lead_hours"])) for r in rows]
    expected = set(itertools.product(ids, CANDIDATES, LEADS))
    require(len(keys) == len(set(keys)), "Duplicate cache rows")
    require(set(keys) == expected, "Cache is not the exact N x 5 x 3 matrix")
    raw = {}
    for r in rows:
        k = (r["issue_id"], r["candidate_id"], int(r["lead_hours"]))
        require(r.get("status") in ("PASS", "FAIL_NONFINITE"), f"Unsupported row status: {k}")
        if r["status"] == "PASS":
            require(r.get("cpu_loss") is not None and np.isfinite(r["cpu_loss"]), f"Nonfinite PASS loss: {k}")
        else:
            require(r.get("cpu_loss") is None, f"FAIL row has a loss: {k}")
        raw[k] = r
    require(sum(r["status"] == "FAIL_NONFINITE" for r in rows) / len(rows) <= .02,
            "Frozen V4 nonfinite cap exceeded")
    loss_by_candidate = np.empty((len(ids), 5, 3), dtype=np.float64)
    for n, iid in enumerate(ids):
        for hindex, h in enumerate(LEADS):
            ref = raw[iid, "reference", h]
            require(ref["status"] == "PASS" and ref["cpu_loss"] > 0, f"Invalid reference: {iid}/{h}")
            for cindex, c in enumerate(CANDIDATES):
                r = raw[iid, c, h]
                loss_by_candidate[n, cindex, hindex] = ref["cpu_loss"] if r["status"] != "PASS" else r["cpu_loss"]
                if r["status"] == "PASS":
                    require(r.get("gain_vs_fs") is not None, f"Missing gain: {iid}/{c}/{h}")
                    require(abs(float(r["gain_vs_fs"]) - (ref["cpu_loss"] - r["cpu_loss"])) <= 1e-12,
                            f"Stored gain differs from endpoints loss difference: {iid}/{c}/{h}")
    index = {i: n for n, i in enumerate(ids)}
    fold_eval = [i for f in folds["folds"] for i in f["eval_ids"]]
    require(len(fold_eval) == len(set(fold_eval)) and set(fold_eval) == set(ids), "OOF coverage not exactly once")
    supports = folds["supports_utc_epoch"]
    times = {}
    for iid in ids:
        a, b = supports[iid]
        require(b - a == 84 * 3600, "Unexpected support width in frozen OOF record")
        t = a + 12 * 3600
        times[iid] = t
        require((t - ORIGIN) // (7 * 86400) == folds["issue_blocks"][iid], "Calendar block mismatch")
    def check_purge(train, ev):
        require(bool(train) and bool(ev), "Empty train/eval fold")
        require(len(train) == len(set(train)) and len(ev) == len(set(ev)), "Duplicate fold IDs")
        require(set(train) <= set(ids) and set(ev) <= set(ids), "Unknown fold IDs")
        require(not set(train) & set(ev), "Train/eval overlap")
        for i in train:
            a, b = supports[i]
            for j in ev:
                c, d = supports[j]
                require(not (a - 24*3600 <= d and c <= b + 24*3600), "Full-support purge violation")
    m1_choices = {}
    for f in folds["folds"]:
        check_purge(f["train_ids"], f["eval_ids"])
        for inner in f["inner"]:
            require(set(inner["train_ids"] + inner["eval_ids"]) <= set(f["train_ids"]), "Inner fold leaves outer train")
            check_purge(inner["train_ids"], inner["eval_ids"])
        tr = [index[i] for i in f["train_ids"]]
        gains = loss_by_candidate[tr, 0, 1, None] - loss_by_candidate[tr, :, 1]
        choice = CANDIDATES[int(np.argmax(gains.mean(axis=0)))]
        m1_choices[str(f["fold"])] = choice
        for iid in f["eval_ids"]:
            require(predictions[iid]["M1"] == choice, f"M1 not selected on fold train: {iid}")
    m5 = int(np.argmin(loss_by_candidate[:, :, 1].sum(axis=0)))
    m4 = np.argmin(loss_by_candidate[:, :, 1], axis=1)
    losses = np.empty((len(ids), len(METHODS), len(LEADS)), dtype=np.float64)
    actions = {}
    for n, iid in enumerate(ids):
        actions[iid] = {}
        for mi, m in enumerate(METHODS):
            if m == "F0":
                for hi, h in enumerate(LEADS):
                    val = background[iid]["f0_cpu"].get(str(h))
                    require(val is not None and np.isfinite(val), f"Missing/nonfinite F0: {iid}/{h}")
                    losses[n, mi, hi] = val
                continue
            c = CANDIDATES[int(m4[n])] if m == "M4" else CANDIDATES[m5] if m == "M5" else predictions[iid][m]
            require(c in CANDIDATES, f"Illegal action: {iid}/{m}")
            if m == "M0":
                require(c == "reference", "M0 must be no-edit")
            actions[iid][m] = c
            losses[n, mi] = loss_by_candidate[n, CANDIDATES.index(c)]
    return ids, losses, actions, m1_choices, CANDIDATES[m5]


def bootstrap(ids: list[str], losses: np.ndarray, blocks: dict, *, factor: int = 1,
              draws: int = DRAW_COUNT) -> dict:
    b = {i: int(blocks[i]) // factor for i in ids}
    unique = sorted(set(b.values()))
    require(len(unique) >= 2, "Too few blocks for audit")
    S = np.zeros((len(unique), len(METHODS), 3), dtype=np.float64)
    for bi, block in enumerate(unique):
        members = [n for n, i in enumerate(ids) if b[i] == block]
        # Explicit sums mirror the specified operation, not any production function.
        for mi in range(len(METHODS)):
            for hi in range(3):
                S[bi, mi, hi] = sum(float(losses[n, mi, hi]) for n in members)
    idx = np.random.default_rng(SEED).integers(0, len(unique), size=(draws, len(unique)))
    samples = S[idx].sum(axis=1)
    total = S.sum(axis=0)
    mindex = {m: k for k, m in enumerate(METHODS)}
    hindex = {h: k for k, h in enumerate(LEADS)}
    def contrast(method, base, h):
        mi, bi, hi = mindex[method], mindex[base], hindex[h]
        den = samples[:, mindex["M0"], hi]
        require(bool(np.all(den > 0)), "Nonpositive bootstrap denominator")
        vals = (samples[:, bi, hi] - samples[:, mi, hi]) / den
        point = (total[bi, hi] - total[mi, hi]) / total[mindex["M0"], hi]
        lo, high = np.percentile(vals, [2.5, 97.5])
        return {"point": float(point), "ci_low": float(lo), "ci_high": float(high)}
    result = {"n_blocks": len(unique), "blocks": unique, "draws": draws, "seed": SEED,
              "block_days": 7 * factor, "delta_min": DELTA, "comparisons": {}}
    for name, method, base, h in COMPARISONS:
        r = contrast(method, base, h)
        r.update(method=method, baseline=base, lead_hours=h,
                 status_vs_delta_min=status(r["ci_low"], r["ci_high"]))
        if h == 72 and method in ("M1", "M2", "M3"):
            r["harm72_guard_pass"] = r["ci_low"] >= -DELTA
        result["comparisons"][name] = r
    result["H_Fs_by_lead"] = {str(h): contrast("F0", "M0", h) for h in LEADS}
    result["G_vs_F0_by_method_and_lead"] = {
        m: {str(h): contrast(m, "F0", h) for h in LEADS} for m in ("M1", "M2", "M3", "M4", "M5")}
    # Includes F0 background for comparison to the exact stored CSV column.
    for r in result["comparisons"].values():
        r["correct_G_F0_point"] = (r["point"] - result["H_Fs_by_lead"][str(r["lead_hours"])]["point"]
                                    if r["baseline"] == "M0" else None)
    return result


def compare_report(calc: dict, historical: dict, *, atol: float = 1e-12) -> tuple[list, list]:
    core_errors, derived_errors = [], []
    require(set(calc["comparisons"]) == set(historical["comparisons"]), "Comparison list changed")
    for name, c in calc["comparisons"].items():
        old = historical["comparisons"][name]
        for key in ("point", "ci_low", "ci_high"):
            if not np.isfinite(old[key]) or abs(c[key] - old[key]) > atol:
                core_errors.append({"comparison": name, "field": key, "stored": old[key], "recomputed": c[key]})
        if old["status_vs_delta_min"] != c["status_vs_delta_min"]:
            core_errors.append({"comparison": name, "field": "status_vs_delta_min"})
        if "harm72_guard_pass" in c and old.get("harm72_guard_pass") != c["harm72_guard_pass"]:
            core_errors.append({"comparison": name, "field": "harm72_guard_pass"})
        if old.get("G_F0_point") is not None and c["correct_G_F0_point"] is not None:
            val = float(old["G_F0_point"])
            if not np.isfinite(val) or abs(val - c["correct_G_F0_point"]) > atol:
                derived_errors.append({"comparison": name, "lead_hours": c["lead_hours"],
                    "field": "G_F0_point", "stored": val, "correct_same_lead": c["correct_G_F0_point"],
                    "reason_to_investigate": "Stored code subtracts H_Fs_24h even on 6h/72h rows."})
    return core_errors, derived_errors


def run(repo: Path, out: Path) -> int:
    out = new_output_dir(repo, out)
    start = utc()
    try:
        require(git(repo, "rev-parse", "HEAD") == BASELINE, "Historical audit must use the exact pinned source worktree")
        protocol_path = repo / B / "protocol/cache_protocol_v1.json"
        require(sha256(protocol_path) == PROTOCOL_SHA, "Frozen protocol hash mismatch")
        protocol = load_json(protocol_path)
        d = protocol["decided"]
        require(d["delta_min_fs_relative"] == DELTA and d["seed"] == SEED and d["bootstrap_draws"] == DRAW_COUNT,
                "Frozen statistical constants differ")
        require(d["confidence_level"] == .95 and d["outer_folds"] == 4 and d["base_block_days"] == 7,
                "Unsupported confidence/fold/block specification")
        cache_path = repo / B / "cache/dev/cache_manifest.json"
        cache = load_json(cache_path)
        require(cache["passed"] is True and cache["protocol_sha256"] == PROTOCOL_SHA, "Invalid cache manifest")
        dev_path = checked_ref(repo, cache["dev_protocol"], "dev protocol")
        dev = load_json(dev_path)
        require(dev["protocol_sha256"] == PROTOCOL_SHA, "Dev protocol not chained")
        dec_path = checked_ref(repo, dev["debug_decision"], "debug decision")
        require(load_json(dec_path)["verdict"] == "PASS", "No PASS debug decision")
        split_path = checked_ref(repo, protocol["inputs"]["split_freeze"], "split freeze")
        require(cache["split_freeze_sha256"] == sha256(split_path), "Cache split mismatch")
        rows_path = checked_ref(repo, cache["candidate_results"], "candidate results")
        bg_path = checked_ref(repo, cache["background_f0"], "F0 background (not checked by historical scorer)")
        freeze_path = repo / B / "policies/prediction_freeze.json"
        fz = load_json(freeze_path)
        require(fz["protocol_sha256"] == PROTOCOL_SHA and fz["cache_manifest_sha256"] == sha256(cache_path),
                "Prediction freeze not chained to protocol/cache")
        require(fz["dev_protocol_sha256"] == sha256(dev_path), "Prediction dev protocol mismatch")
        pred_path = checked_ref(repo, fz["oof_predictions"], "OOF predictions")
        fold_path = checked_ref(repo, fz["folds"], "folds")
        checked_ref(repo, fz["label_access_log"], "label access log")
        for name, ref in fz["per_fold_files"].items():
            checked_ref(repo, ref, name)
        pred = load_json(pred_path)
        require(pred.get("poisoned") is None, "Poisoned output cannot be scored")
        ids0 = sorted(pred["predictions"])
        require(len(ids0) == 112 and ids0 == sorted(cache["issue_ids"]) == sorted(dev["issue_ids"]),
                "Exact frozen N=112 issue list mismatch")
        folds = load_json(fold_path)
        require(set(folds["empty_blocks"]) == {16, 19}, "Frozen coverage changed")
        ids, losses, actions, m1, m5 = assemble(load_json(rows_path)["rows"], pred["predictions"],
                                             load_json(bg_path)["issues"], folds)
        calc7 = bootstrap(ids, losses, folds["issue_blocks"])
        calc14 = bootstrap(ids, losses, folds["issue_blocks"], factor=2)
        historical_path = repo / B / "evaluation/paired_block_bootstrap.json"
        historical = load_json(historical_path)
        require(historical["prediction_freeze_sha256"] == sha256(freeze_path), "Historical score not bound to predictions")
        errors7, derived = compare_report(calc7, historical["primary_7day_blocks"])
        errors14, _ = compare_report(calc14, historical["sensitivity_14day_blocks_report_only"])
        errors = errors7 + [{**e, "sensitivity_days": 14} for e in errors14]
        for calc, key, days in ((calc7, "primary_7day_blocks", 7),
                                (calc14, "sensitivity_14day_blocks_report_only", 14)):
            old_h = historical[key]["H_Fs_24h"]
            new_h = calc["H_Fs_by_lead"]["24"]
            for field, old_val in (("point", old_h["point"]), ("ci_low", old_h["ci"][0]),
                                    ("ci_high", old_h["ci"][1])):
                if not np.isfinite(old_val) or abs(float(old_val) - new_h[field]) > 1e-12:
                    errors.append({"comparison": "H_Fs_24h", "field": field,
                                   "block_days": days, "stored": old_val, "recomputed": new_h[field]})
        # CSV is independently checked against the stored JSON, then calculation.
        csv_path = repo / B / "evaluation/dev_results.csv"
        with csv_path.open(newline="", encoding="utf-8") as f:
            first = next(f)
            require("coverage caveat" in first, "Missing CSV coverage disclosure")
            csv_rows = list(csv.DictReader(f))
        require(len(csv_rows) == len(COMPARISONS) and len({r["comparison"] for r in csv_rows}) == len(COMPARISONS),
                "CSV comparison coverage mismatch")
        for row in csv_rows:
            c = calc7["comparisons"][row["comparison"]]
            for key in ("point", "ci_low", "ci_high"):
                if abs(float(row[key]) - c[key]) > 1e-12:
                    errors.append({"comparison": row["comparison"], "field": "CSV." + key})
        write_new(out / "recomputed.json", {"primary_7day_blocks": calc7, "sensitivity_14day_blocks": calc14,
                   "M1_choices_by_fold": m1, "M5_choice": m5, "n_issues": len(ids),
                   "M3_M1_different_action_count": sum(v["M3"] != v["M1"] for v in actions.values()),
                   "scope": "Independent scalar/cache audit; original GPU tensor scoring not rerun."})
        results = {"status": "STOP_CORE_RESULT_MISMATCH" if errors else (
                   "PRIMARY_REPRODUCED_WITH_DERIVED_FIELD_ERRORS" if derived else "SCALAR_RESULTS_REPRODUCED"),
                   "source_commit": BASELINE, "started_utc": start, "ended_utc": utc(),
                   "core_result_errors": errors, "derived_field_errors": derived,
                   "primary_metrics_match": not errors, "formal_FP06_decision": "NOT_APPLIED",
                   "old_outputs_modified": False,
                   "input_files": [{"path": str(p.relative_to(repo)), "sha256": sha256(p)} for p in
                      [protocol_path, cache_path, rows_path, bg_path, freeze_path, pred_path, fold_path, historical_path, csv_path]]}
        write_new(out / "audit_result.json", results)
        print(json.dumps({k: results[k] for k in ("status", "primary_metrics_match", "formal_FP06_decision")}, ensure_ascii=False))
        return 2 if errors else 0
    except Exception as exc:
        write_new(out / "STOP.json", {"status": "STOP", "error": str(exc), "started_utc": start, "ended_utc": utc(),
                   "action": "Repair only audit tooling or locate inputs; do not alter the historical protocol/output."})
        raise


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    try:
        return run(args.repo.resolve(), args.out)
    except Exception as exc:
        print(json.dumps({"status": "STOP", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
if __name__ == "__main__":
    raise SystemExit(main())
