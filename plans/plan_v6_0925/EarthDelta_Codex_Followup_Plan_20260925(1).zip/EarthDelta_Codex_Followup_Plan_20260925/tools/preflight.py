#!/usr/bin/env python3
"""Snapshot protected source/evidence hashes and detect later modification, including additions.
Only local text/evidence metadata are read: no weather forward, zarr or checkpoint loads.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from common import A, B, P3, P4, BASELINE, EvidenceError, beneath, git, load_json, new_output_dir, sha256, utc, write_new

ROOTS = [A, B, P3, P4,
         "plans/plans_v5_0924/extracted_v2/EarthDelta_Codex_Followup_Plan_20260924",
         "earthdelta", "scripts", "tests", "reference/_manifest.json", "README.md",
         "plans/plan_v4_0923/FP05A_PLAN.md", "plans/plan_v4_0923/FOLLOWUP_PLAN_20260924_ROUND2.md"]
SUFFIXES = {".py", ".md", ".json", ".jsonl", ".csv", ".txt", ".log", ".yaml", ".yml", ".toml", ".sha256", ".sh"}

def inventory(repo: Path) -> tuple[dict, list]:
    files, missing = {}, []
    for rel in ROOTS:
        p = repo / rel
        if not p.exists():
            missing.append(rel)
            continue
        for f in ([p] if p.is_file() else p.rglob("*")):
            if not f.is_file() or f.suffix not in SUFFIXES or "__pycache__" in f.parts:
                continue
            if not beneath(f, repo):
                raise EvidenceError(f"Symlink escapes repository: {f}")
            files[f.relative_to(repo).as_posix()] = {"sha256": sha256(f), "bytes": f.stat().st_size}
    return dict(sorted(files.items())), missing

def snapshot(repo: Path, out: Path) -> int:
    out = new_output_dir(repo, out)
    started = utc()
    head = git(repo, "rev-parse", "HEAD")
    if head != BASELINE:
        write_new(out / "STOP.json", {"status": "STOP_HEAD_DRIFT", "actual_head": head,
                 "expected_audit_commit": BASELINE, "utc": utc(),
                 "action": "Review new commits separately; no reset or hidden branch substitution."})
        return 2
    files, missing = inventory(repo)
    # Verify core17/current new-file pins against their historical protocols.
    pin_checks = []
    for rel in [P4 + "/protocol/bank_protocol_v1.json", B + "/protocol/cache_protocol_v1.json"]:
        p = repo / rel
        if not p.is_file():
            pin_checks.append({"protocol": rel, "status": "MISSING"})
            continue
        pins = load_json(p).get("source_at_preregistration", {})
        bad = [name for name, expected in pins.items()
               if not (repo / name).is_file() or sha256(repo / name) != expected]
        pin_checks.append({"protocol": rel, "n_pins": len(pins), "mismatches": bad,
                           "status": "PASS" if pins and not bad else "FAIL"})
    status = "SNAPSHOT_SAVED_NOT_SCIENTIFIC_ACCEPTANCE"
    write_new(out / "snapshot.json", {"status": status, "repo": str(repo), "source_commit": head,
               "started_utc": started, "ended_utc": utc(), "files": files,
               "roots": ROOTS, "missing_roots": missing, "pin_checks": pin_checks,
               "git_status_porcelain": git(repo, "status", "--porcelain"),
               "scope": "Protected text/source files only. Weights, arrays and dataset integrity need separate checks."})
    print(json.dumps({"status": status, "files": len(files), "missing_roots": missing,
                      "pin_checks": pin_checks}, ensure_ascii=False))
    return 2 if any(x["status"] != "PASS" for x in pin_checks) else 0

def verify(manifest: Path) -> int:
    old = load_json(manifest)
    repo = Path(old["repo"])
    now, missing = inventory(repo)
    before = old["files"]
    changed = [p for p in set(before) & set(now) if before[p]["sha256"] != now[p]["sha256"]]
    added, removed = sorted(set(now) - set(before)), sorted(set(before) - set(now))
    head_same = git(repo, "rev-parse", "HEAD") == old["source_commit"]
    ok = not changed and not added and not removed and head_same and missing == old["missing_roots"]
    print(json.dumps({"status": "PASS_HASH_GUARD" if ok else "STOP_FROZEN_INPUT_CHANGED",
                      "utc": utc(), "changed": sorted(changed), "added": added,
                      "removed": removed, "head_same": head_same}, ensure_ascii=False, indent=2))
    return 0 if ok else 2

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)
    a = sub.add_parser("snapshot"); a.add_argument("--repo", type=Path, required=True); a.add_argument("--out", type=Path, required=True)
    v = sub.add_parser("verify"); v.add_argument("--snapshot", type=Path, required=True)
    args = ap.parse_args()
    try:
        return snapshot(args.repo.resolve(), args.out) if args.command == "snapshot" else verify(args.snapshot)
    except Exception as exc:
        print(json.dumps({"status": "STOP", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
if __name__ == "__main__":
    raise SystemExit(main())
