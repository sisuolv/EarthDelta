#!/usr/bin/env python3
"""Copy a small, targeted LOCAL evidence bundle; no uploads, network or model execution.
The resulting files may contain secrets in old logs: review/redact copies before sharing.
"""
from __future__ import annotations
import argparse
import json
import shutil
import sys
from pathlib import Path
from common import EvidenceError, beneath, new_output_dir, sha256, utc, write_new

PATTERNS = [
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/job*",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/submission*",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/invocation.json",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/source_manifest.json",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/create_argv.json",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/worker.log",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/**/shard.json",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/**/issue.json",
    "artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/**/gpu_losses.json",
    "artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/job*",
    "artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/submission*",
    "artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/invocation.json",
    "artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/source_manifest.json",
    "artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/create_argv.json",
    "artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/worker.log",
    "artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/**/shard.json",
    "artifacts/round2_cci/ed-r4bankbj2-0924052624-dde08d/expert*/bank_panels_expert*.json",
    "artifacts/wbx_smoke/20260924T135007Z_tierB/**/*.json",
    "artifacts/wbx_smoke/20260924T135007Z_tierB/**/*.csv",
    "artifacts/wbx_smoke/20260924T135007Z_tierB/**/*.log",
    "checkpoints/pull_2022.log",
]

def collect(repo: Path, out: Path) -> int:
    out = new_output_dir(repo, out)
    matches, missing, oversize = set(), [], []
    for pattern in PATTERNS:
        found = [p for p in repo.glob(pattern) if p.is_file()]
        if not found:
            missing.append(pattern)
        matches.update(found)
    files = []
    for p in sorted(matches):
        if not beneath(p, repo):
            raise EvidenceError(f"Symlink leaves repository: {p}")
        rel = p.relative_to(repo)
        size = p.stat().st_size
        if size > 32 * 1024**2:
            oversize.append({"path": rel.as_posix(), "bytes": size, "action": "Hash/inspect locally; provide targeted excerpt with original hash."})
            continue
        expected = sha256(p)
        dst = out / "files" / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dst)
        if sha256(dst) != expected:
            raise EvidenceError(f"File changed during copy: {rel}")
        files.append({"path": rel.as_posix(), "sha256": expected, "bytes": size})
    status = "LOCAL_BUNDLE_SAVED_WITH_MISSING_PATTERNS" if missing or oversize else "LOCAL_BUNDLE_SAVED"
    write_new(out / "manifest.json", {"status": status, "created_utc": utc(), "source_repo": str(repo),
               "files": files, "missing_patterns": missing, "oversize": oversize,
               "not_verified": "The content and historical chronology of these records have not been certified by this copy operation.",
               "sharing": "LOCAL ONLY. Inspect logs for credentials before uploading; preserve original hashes and a redaction map."})
    print(json.dumps({"status": status, "files": len(files), "missing_patterns": missing}, ensure_ascii=False))
    # Missing optional pattern != scientific failure; a human/agent checks required inputs per task.
    return 0

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, required=True); ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    try:
        raise SystemExit(collect(a.repo.resolve(), a.out))
    except Exception as e:
        print(json.dumps({"status": "STOP", "error": str(e)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(2)
