#!/usr/bin/env python3
"""Validate package structure, task DAG and declared file hashes. Not scientific acceptance."""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
from pathlib import Path

REQUIRED = ["START_HERE_FOR_CODEX.md", "FOLLOWUP_PLAN.md", "EXECUTION_DAG.md", "STOP_CONDITIONS.md",
            "CODEX_TASKS.json", "ARTIFACT_CONTRACT.md", "TEST_PLAN.md", "REPRODUCIBILITY.md",
            "CURRENT_GAP_ANALYSIS.md", "evidence/PLAN_AUDIT_RESULT.json", "evidence/EVIDENCE_MANIFEST.json",
            "evidence/REQUIRED_INPUTS.md", "prompts/CODEX_EXECUTION_PROMPT.md"]
FIELDS = {"id", "priority", "depends_on", "scope", "commands", "acceptance_criteria", "evidence_outputs", "stop_if", "status", "estimated_minutes"}

def validate(root: Path) -> dict:
    errors = []
    for rel in REQUIRED:
        if not (root / rel).is_file():
            errors.append(f"Missing {rel}")
    for p in root.rglob("*.json"):
        try:
            json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"Invalid JSON {p.name}: {exc}")
    try:
        tasks = json.loads((root / "CODEX_TASKS.json").read_text())["tasks"]
        graph = {t["id"]: t["depends_on"] for t in tasks}
        if len(graph) != len(tasks):
            errors.append("Duplicate task ID")
        for t in tasks:
            if not FIELDS <= set(t):
                errors.append(f"Missing fields {t.get('id')}: {FIELDS-set(t)}")
            if t["status"] == "DONE" and not (t.get("done_scope") and t.get("evidence_outputs")):
                errors.append(f"DONE without scoped evidence: {t['id']}")
            if set(t["depends_on"]) - set(graph):
                errors.append(f"Unknown dependency for {t['id']}")
        seen, active = set(), set()
        def visit(n):
            if n in active:
                raise ValueError(f"Cycle at {n}")
            if n in seen:
                return
            active.add(n)
            for d in graph[n]: visit(d)
            active.remove(n); seen.add(n)
        for n in graph: visit(n)
    except Exception as exc:
        errors.append(f"Task validation: {exc}")
    mp = root / "PACKAGE_MANIFEST.json"
    if not mp.is_file():
        errors.append("Missing PACKAGE_MANIFEST.json")
    else:
        m = json.loads(mp.read_text())
        expected = set(m["files"])
        actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()
                  and p != mp and "__pycache__" not in p.parts and ".pytest_cache" not in p.parts}
        if expected != actual:
            errors.append(f"Manifest file set differs; missing={sorted(expected-actual)} extra={sorted(actual-expected)}")
        for rel, rec in m["files"].items():
            p = root / rel
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != rec["sha256"]:
                errors.append(f"Package file hash mismatch: {rel}")
    return {"status": "PASS_PACKAGE_STRUCTURE_ONLY" if not errors else "FAIL", "errors": errors,
            "scope": "Files, DAG and package hashes only; not a repository test, GPU proof or scientific decision."}

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument("--package", type=Path, required=True)
    a=ap.parse_args(); r=validate(a.package.resolve()); print(json.dumps(r,ensure_ascii=False,indent=2))
    raise SystemExit(0 if not r["errors"] else 2)
