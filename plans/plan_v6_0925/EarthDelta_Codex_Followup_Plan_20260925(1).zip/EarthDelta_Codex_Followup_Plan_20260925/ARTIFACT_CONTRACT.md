# 实验与审计产物合同

## 每个任务目录

必须有`task_result.json`、`commands.jsonl`、`stdout.log`、`stderr.log`和`evidence_manifest.json`。
任务可没有GPU；此时`gpu_job_id=null`、`gpu_execution=NOT_APPLICABLE`，不能伪造job。
字段模板见`evidence/TASK_RESULT_TEMPLATE.json`。状态、证据层级和科学判定分开。
所有生成文件使用exclusive create；失败重试用新attempt目录，不能覆盖原尝试。

### task_result字段
`task_id/status/evidence_state/source_commit/started_utc/finished_utc/elapsed_seconds/returncode/`
`inputs/commands/evidence_outputs/integrity_gate/scientific_verdict/gate_passed/missing_inputs/deviations/`
`access_summary/old_inputs_unchanged`。未来值null，evidence_state=TO_BE_RUN；缺件MISSING。
elapsed来自实测单调计时或原系统回执，不从目录名或文件mtime伪造。

### 源/原件证据
每项保存原绝对路径、映射后本地路径、大小、SHA256、source commit、字段定位/行号，
证据标签只用STATIC_CONFIRMED / EXECUTION_CONFIRMED / PLAUSIBLE_UNVERIFIED / MISSING。
EXECUTION_CONFIRMED须说明REVIEWER_RERUN或RAW_EXECUTION_RECORD，不能把读摘要当重跑。

## GPU原回执
`scheduler_submission.json/job-id.txt/job_result.json/invocation.json/source_manifest.json/`
`worker.log`及原配置：job_id/run_id、设备、起止UTC、rc、elapsed、argv、容器、依赖、
protocol/data/weights/source hash。scheduler状态和worker状态均保留，差异不能忽略。
副本脱敏不改变原hash身份；任何密钥不得写入可分享包。

## 指标
保存精确issue/candidate/lead/fold/block/stratum/权重集合和全部PASS/FAIL，
原始Fs/F0/candidate losses与每方法action。主估计量是同lead Fs分母；
每个bootstrap draw方法和分母共同重采样；CI不通过相减独立CI端点获得。
每个lead保存H_Fs(h)、G_Fs(h)、G_F0(h)、G_static(h)，以及公式、单位、方向、CI、阈值。
统计块数、覆盖缺失、fallback非有限、比较层级、探索性标签完整保存。

## anchor / WBX对账
两侧source path/hash、issue/candidate/lead键、dtype/shape、解析前后精度、
exact_float_equal、raw_bytes_equal、atol/rtol分开。JSON小数相等不是张量bytes相同。
先登记expected_id_set，再输出all_rows/missing/duplicate/mismatch/failed，不只导出相等行。
WBX104×3必须说明104的单位；不是自动104个独立天气事件。

## mutation / poison
每项baseline test PASS、单个diff、mutant_source_hash、完整argv/log/具体失败断言/rc、
还原后PASS；语法/导入失败单列INVALID_MUTANT，不计KILLED。
poison记录fold、eval/purged/train集合、施加值、未毒化/毒化hash与比对对象；
同折模型/预测才是不变对象，验证标签改变后评分不变不是所需条件。

## FP07与FP08
诊断先冻结输入hash/清单、只读路径、输出路径；记录新增POST_HOC_DIAGNOSTIC条目。
2022技术验数的所有字节读取写INTEGRITY_READ_ONLY；不把技术校验说成看过模型效果，
也不隐瞒技术读取。不能凭非有限计数判断某年模型表现。

## 判断门
`gate_passed=true`不得同时存在阻塞该gate的missing_inputs。任务完成可伴随负科学结果。
局部附录错误需要明确影响范围；只有确认主结果有效才可继续基于主结果诊断。
