# 所需原件与补充上传清单

**先检查CCI原仓库本地文件。** 用户已说明weights/data/artifacts被gitignore；这不意味着不存在。
能在本地核实的文件不要求用户重复上传。本包附collect_local_evidence.py只收集LOCAL副本，不联网上传。

## 可立即使用（不是重新索取）

| 输入 | 已有依据 |
|---|---|
| 原后续草案 | 包内`inputs/FOLLOWUP_PLAN_20260924_ROUND2.original.md`；原字节 |
| 原结果小数、协议阈值、代码观察 | `CONTEXT_OBSERVATIONS.json`和`FROZEN_THRESHOLD_REGISTRY.json`；执行前核repo原件hash |
| 源分支历史完整HEAD | `45edd51b563a626e01b31af24e0d95afa6d56d7b`；不是本轮新查询的当前分支状态 |
| Git可跟踪的cache/OOF | `plans/plan_v4_0923/run_20260924T104725Z_fp05b/cache/dev/`、`policies/`、`evaluation/`；本地应直接读取 |

## A. FP06b需要的原始执行小文件

已知C-J1目录：
`artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/`

已知C-J2目录：
`artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/`

各取`job-id.txt`、`job_result.json`、`submission.json`或实际scheduler回执、
`invocation.json`、`source_manifest.json`、`create_argv.json`、`worker.log`、所有`shard.json`。
这里未看到的实际job ID必须从原件读，不把目录后缀当ID，不伪造rc/耗时。
原FP05a `entry/job_receipts_index.json`可指路；20/20是原本地审计记录，不是本包复核结果。

## B. 至少3条CJ1原始anchor两侧数据

旧anchor原件目录：
`artifacts/round2_cci/ed-r4bankbj2-0924052624-dde08d/expert{0..3}/bank_panels_expert{k}.json`

原记录SHA：
- expert0: `ff256077bf073e69a99c770e041928ebab69b32f896b3492481fac562f8f28de`
- expert1: `8b8372d7539028595d7bf2a208703fa0c3809e44e74e56ed977e52d40a386937`
- expert2: `1391f9c195e5665cd4698e63ecacff8d6bede64c19e0f4a6e25a9f1eb2f6026f`
- expert3: `691ec9f50a450919f4519a4d2fa7a499eedbb7711fd07e08cc5ae295f337f48c`

C-J1每issue的`issue.json`和`gpu_losses.json`（目录从shard.json解析）；再按同ID配对。
仅交decision里一对相同数字不能替代原件。若要验证tensor bitwise，需要对应endpoints/
truth/F0 endpoint的hash和明确的dtype/shape；本地可算，不先要求上传所有大张量。

## C. OOF与数值

完整candidate_results.json、background_f0.json、cache_manifest.json、dev_protocol.json、
folds.json、prediction_freeze.json、oof_predictions*.json和8次cp3输出。
1660维feature文件如GitHub缺失，在`cache_manifest.features`记录的真实路径定位。
原模型可能仅保存parameter_digests；没有系数文件时不编造coeff稳定性；可按冻结配置
在新目录确定性重建，并说明它是新诊断重建，不是历史保存的权重。
原mutation仅有摘要时补单条diff/完整pytest日志/断言；实际13项，不是12项。

## D. WBX

`artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json`完整表及其引用的104×3两侧记录；
TierA/B真实运行日志/命令/环境、公开metric计算输出、原FP03/04面板。
`reference/_manifest.json`与本地官方repos HEAD/所用源码hash，不打包上游仓库/字体/权重。
公开baseline数据不存在时WBX02b可BLOCKED，不让其阻止FP06/FP07。

## E. 2022

`checkpoints/pull_2022.log`完整脱敏日志、校验器版本/参数/首次失败/rc、预期与实际对象
manifest/hash/大小，以及已经发生的2021/2022读取记录。
仅作技术验数，不提供这些年份模型预测/误差/示例图；完整性检查通过不代表confirm可用。

## F. 战略决策

无需为CPU取证额外索取用户曾给过的材料；遇到本地也不存在的阻塞件再按精确路径列清单。
新训练/新GPU/新API/新年份下载/confirm需要新的真实人工授权；Codex不能自己生成审批。
