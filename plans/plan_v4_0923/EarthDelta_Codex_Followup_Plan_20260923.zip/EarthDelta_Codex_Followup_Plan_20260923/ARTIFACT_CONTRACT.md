# 产物合同

## 状态不是同一个轴

每个产物需明确：
- `evidence_state`: `OBSERVED` / `TO_BE_RUN` / `MISSING`；
- `stage_status`: `PASS` / `FAIL_IMPLEMENTATION` / `BLOCKED` / `INCONCLUSIVE` / `NOT_STARTED`；
- `evidence_status`: `STATIC_CONFIRMED` / `EXECUTION_CONFIRMED` / `PLAUSIBLE_UNVERIFIED` / `MISSING`；
- `evidence_level`: `CODE` / `CPU_TEST` / `GPU_EXECUTION` / `PARITY` / `DEV_UTILITY` / `SCIENTIFIC_CONFIRMATION`；
- `evidence_kind`: `RAW_EXECUTION` / `ARCHIVED_RECOMPUTATION` / `TRACKED_SUMMARY` / `SOURCE_INSPECTION`。

OBSERVED的tracked summary不能伪装RAW_EXECUTION。TO_BE_RUN的metrics为null，不填0、PASS或模拟真实值。
配置文件自己有`status=FROZEN`不代表任何任务运行了。任务argv、提交manifest、queued状态都不是完成证据。

## 每项 task 的最少记录

```json
{
  "task_id": "FUP-01",
  "evidence_state": "TO_BE_RUN",
  "stage_status": "NOT_STARTED",
  "run_id": null,
  "job_id": null,
  "exit_code": null,
  "started_utc": null,
  "finished_utc": null,
  "git_head": null,
  "dirty_diff_sha256": null,
  "source_manifest_sha256": null,
  "config_sha256": null,
  "predecessor_certificates": [],
  "metrics": null,
  "artifact_manifest_sha256": null
}
```

真实执行后记录完整argv（密钥通过环境且不写值）、cwd、env版本、设备、原始stdout/stderr、错误与returncode。
GPU要求平台job_id和raw job_result（包含启动/结束/worker/device/状态）；仅本地scriptrun_id不替代jobID。
CPU本地测试允许job_id=null，但必须有明确local执行标记、命令、exit code、JUnit、collected/passed/failed/skipped数量及原因。

## 身份链

```text
原计划与批准变更
→ frozen source（git + dirty patch + 实际import文件hash）
→ frozen config / checkpoint / raw NPZ与inverse schema / variables / coordinate values
→ admission的实际UTC与所有chunk内容
→ S0 raw manifest + registered outputs + committed result
→ 单一Fs的质量/冻结/重载证书
→ 单个动态expert权重/qualification
→ assembled-bank行为证书 + registry
→ complete-cache manifest
→ trainfold preprocess/model + frozen actions
→ evaluator + raw outcomes + paired stats
```

消费者必须核对链条，不是只记录它。每条引用保存路径、文件SHA-256、schema、前驱config/source身份。
相对路径优先，若资产外置则声明asset_root与完整hash；禁止只依赖路径字符串相同。公共32/64短标签不代替完整文件SHA256。

## S0专用

冻结1/4/12及1e-5，保存每个最大差/均值差/比较空间/dtype/finite/重复性。
记录NN输出、inverse input/diff、raw add、renormalize逐步诊断与OO/OB/BO/BB标签，区别共同状态和自由rollout。
每次官方export记录独立源码commit与实际module路径/hash、rawinput、normalizedinput、所有输出的shape/dtype/hash。
正式gate的原生输出通常在独立run子目录；`s0/s0_gate_result.json`等任务预期名是索引规范，可在`artifact_index.json`指向原生路径，禁止改写其中数值/状态或把摘要当raw文件。

## Fs与bank专用

保存初始F0与唯一Fs stateSHA，完整Fs训练trace、同panel共同初始/各checkpoint末态loss、质量判决。
保存dynamic down/up因子、expert/block索引、rank、scale、a0/rho/hold、Fs/norm/Q身份、独立reload预测差和assembly预测差。
不得只保存fs_adapter.pt却声称dynamicbank已交付。profile前后stateSHA必须一致或仅操作未发布副本。

## Cache与policy专用

每条 `(issue_id,candidate_id)` 保存reference/candidate/truth路径与hash、native6/24/72 loss/gain、状态、成本、source/registry与角色。
metadata内写的loss必须可以由raw端点和Q重算。完整cache交叉积/失败ledger由独立checker验证。
policy/freeze路径仅读取训练fold标签和该评分fold合法feature；prediction_freeze在对应评分标签读取之前发布。
保存fold清单、purge support、seed、preprocess与模型hash、static/regime选优范围、每issue先保存的action和predictedgain。
独立scorer读取outcomes，保存paired processblock统计、oracle上限、合法policy效应、72hguard、attempted/complete及全部成本。

## 发布和回归

每个任务使用新run目录；先staging，验证完整性/hash后发布最终manifest与PASS marker。
中断、缺件、异常不能留下可消费PASS。非关键cleanup warning单轴记录；未知计算/CUDA错误不得降级成可认证成功。
原始FAIL与旧报告始终保留。修改source/权重/数据后产生新identity，不补写旧run来“关闭finding”。
