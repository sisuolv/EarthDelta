#!/usr/bin/env python3
"""Validate only this delivery package. Never run project/GPU tasks."""
from pathlib import Path
import json, hashlib

root=Path(__file__).resolve().parents[1]
checks=[]
def check(name,ok):
    checks.append({'check':name,'passed':bool(ok)})
    if not ok: raise AssertionError(name)
def load(p):return json.loads((root/p).read_text(encoding='utf-8'))
required=['START_HERE_FOR_CODEX.md','FOLLOWUP_PLAN.md','EXECUTION_DAG.md','STOP_CONDITIONS.md','CODEX_TASKS.json','ARTIFACT_CONTRACT.md','TEST_PLAN.md','REPRODUCIBILITY.md','CURRENT_GAP_ANALYSIS.md','evidence/PLAN_AUDIT_RESULT.json','evidence/EVIDENCE_MANIFEST.json','evidence/REQUIRED_INPUTS.md','prompts/CODEX_EXECUTION_PROMPT.md']
check('required files exist',all((root/p).is_file() for p in required))
r=load('evidence/PLAN_AUDIT_RESULT.json')
check('OUTPUT_SCHEMA top-level fields',set(['overall_verdict','baseline','plan_items','special_verdicts','blocking_findings','required_next_actions','claims_that_must_not_be_made']).issubset(r))
check('overall enum',r['overall_verdict'] in ['PLAN_EXECUTED','PARTIALLY_EXECUTED','BLOCKED','FAILED_PLAN_COMPLIANCE','INSUFFICIENT_EVIDENCE'])
check('baseline fields',all(k in r['baseline'] for k in ['planned_source','implementation_commit','comparison_base']))
check('plan item schema',all(set(['id','planned_requirement','implementation_status','code_evidence','test_evidence','execution_evidence','goal_status','evidence_status','gap_or_risk']).issubset(x) for x in r['plan_items']))
check('plan item enums',all(x['implementation_status'] in ['COMPLETE','PARTIAL','BLOCKED','NOT_STARTED','NOT_APPLICABLE'] and x['goal_status'] in ['ACHIEVED','PARTIALLY_ACHIEVED','NOT_ESTABLISHED'] and x['evidence_status'] in ['STATIC_CONFIRMED','EXECUTION_CONFIRMED','PLAUSIBLE_UNVERIFIED','MISSING'] for x in r['plan_items']))
check('positive source lines',all(isinstance(e['line'],int) and e['line']>0 and isinstance(e['file'],str) for x in r['plan_items'] for e in x['code_evidence']))
check('special verdict fields',all(k in r['special_verdicts'] for k in ['s0_parity_verdict','fs_fit_divergence_verdict','stage4_readiness','novelty_claim_status','weather_utility_claim_status']))
t=load('CODEX_TASKS.json');ts=t['tasks'];ids={x['id'] for x in ts}
check('unique task IDs',len(ids)==len(ts))
check('task fields',all(set(['id','priority','depends_on','scope','commands','acceptance_criteria','evidence_outputs','stop_if','estimated_minutes']).issubset(x) for x in ts))
check('initial task lock',t['current_task']=='FUP-01' and [x['id'] for x in ts if x['unlocked']]==['FUP-01'])
check('future state',all(x['status']=='TO_BE_RUN' for x in ts))
check('not authorized scientific training',t['scientific_training_authorized'] is False)
check('time estimate type',all(isinstance(x['estimated_minutes'],int) and x['estimated_minutes']>0 and x['estimate_basis'] for x in ts))
check('dependencies known',all(d in ids for x in ts for d in x['depends_on']))
seen=set()
for x in ts:
    check('ordered dependencies '+x['id'],all(d in seen for d in x['depends_on']))
    seen.add(x['id'])
by={x['id']:x for x in ts}
def ancestors(id):
    out=set(by[id]['depends_on'])
    for p in by[id]['depends_on']:out.update(ancestors(p))
    return out
check('S0 and Fs before expert/cache',all({'FUP-01','FUP-03'}.issubset(ancestors(x)) for x in ['FUP-04','FUP-05','FUP-06']))
check('commands populated',all(x['commands'] and x['acceptance_criteria'] and x['stop_if'] and x['evidence_outputs'] for x in ts))
stop=(root/'STOP_CONDITIONS.md').read_text(encoding='utf-8')
check('frozen tolerance and missing thresholds','1e-5' in stop and 'TO_BE_PREREGISTERED_AFTER_PILOT_VARIANCE_ESTIMATE' in stop)
check('original plan snapshots',len(list((root/'evidence/source_plan').glob('*.md')))==5)
check('required report snapshots',len(list((root/'evidence/reference_reports').glob('*')))==3)
e=load('evidence/EVIDENCE_MANIFEST.json')
check('review did not invent executions',not e['runtime_actions_by_this_review']['gpu_jobs_run'] and not e['runtime_actions_by_this_review']['repository_tests_run'])
check('GPU summary not raw certification',e['latest_s0']['kind']=='TRACKED_SUMMARY' and e['latest_s0']['raw_s0_result']=='MISSING')
manifest=root/'PACKAGE_MANIFEST.json'
if manifest.exists():
    m=load('PACKAGE_MANIFEST.json')
    check('package hashes',all(hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in m['files']))
print(json.dumps({'status':'PASS','scope':'DELIVERY_PACKAGE_ONLY_NOT_EARTHDELTA_TESTS','checks_count':len(checks),'checks':checks},ensure_ascii=False,indent=2))
