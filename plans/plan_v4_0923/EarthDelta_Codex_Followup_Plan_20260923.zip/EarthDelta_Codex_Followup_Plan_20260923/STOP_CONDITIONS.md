# STOP 条件与不可偷偷修改的原计划合同

本包恢复 `plans_v3_0922` 原 fitted-Fs 路线；以下不是新论文方案。
权威原文在 `evidence/source_plan/NEXT_STEPS_10H_PLAN.md` 与 `CLAUDE_10H_PROMPT.md`。
旧报告和失败记录永不覆盖。全部未来结果 TO_BE_RUN；只有实际读到证据才 OBSERVED。

## 1. 冻结数字与范围

| 条目 | 保持的值/规则 | 来源与状态 |
|---|---|---|
| 官方 backbone | ps4；官方 pinned commit `58dfee5a6037399a40fefd492bc00421e0c885a8`；同一checkpoint内容身份 | 原计划 :215-221；实际路径还需原始config/资产 |
| Normalization | official_zero_diff_mean，独立官方transforms；FP32执行 | 原计划 :215-221；逆参数原始dtype必须忠实复现 |
| S0 parity | normalized state 最大绝对差 `<=1e-5`，1、4、12 steps 全部 | SPRINT_8H_DECISION.json:13-17；任何一项FAIL阻断 |
| Input normalized binding | 已有config默认 `1e-6`；须核对实际已冻config，不自动扩大 | `earthdelta/contracts.py` GateIdentityConfig；原始config MISSING |
| 专家bank | 默认K=4/rank=4/blocks18–23；max_active=1 | 原计划 :231-232 |
| 动作 | 显式no-edit + singleton；a0=0.25、rho=0.25 | 原计划 :232；不引入新强度 .1875 本轮评测 |
| 应用窗口 | 4×6h，窗口后从已编辑状态继续 **Fs** | 原计划 :233,239；绝非重置到F0或原轨迹 |
| 主目标 | 24h native全目标；6h诊断；72h损害guard | 原计划 :234 |
| 历史/目标 | t-12/t-6/t；t+6/t+24/t+72；真实UTC完整support | 原计划 :165 |
| 样本角色 | bank_fit与policy_dev时间隔离、history/target purge；confirm不读取 | 原计划 :235,261,288；实际UTC列表需原始冻结manifest |
| 初始训练 | 16–32 updates诊断；500为历史起始上限，不是完成/收敛证据 | 原计划 :243；不得不经profile/资格直接追满500 |
| cache | debug8全部候选，随后DEV32/64/128按profile事前冻结 | 原计划 :245-257 |
| 方法 | Fs/no-edit、外折fit-only static、regime、ridge direct-gain、offline oracle | 原计划 :236,261-274 |
| 推断 | 默认固定1seed和有限cheap HPO；过程/UTC块而非grid/candidate为独立单位 | 原计划 :272-274 |
| 本窗口禁止 | dual-head/E3、JEPA/memory/动态rank/spectral、新backbone、连续组合、新finalconfirm | 原计划 :237,288 |

**合并等价公差不是 S0 公差。** Round4 记录的 merge 分析有 `atol=max(1e-5,1.5e-3*delta_max_abs)`、`rtol=1e-5`（ROUND4_REPORT :204-225）。它只属于单独的合并数值定义，不得替换固定 S0 1e-5，也不能用新的公式追认旧失败。最终使用哪一个 merge tolerance 需从已冻结的实际 config 核实，不能根据本轮观察差异回填。

## 2. 前置硬门

- STOP-S0：任一 expected/reference/observed identity不一致、原始证据缺失、任一注册horizon超1e-5、缺已评估criteria或verdict未提交，均不得认证S0。所需材料缺失为BLOCKED/MISSING，不自动科学否定。
- STOP-SOURCE：变更影响S0行为的imported代码、inverse语义、checkpoint/norm/输入/horizon，旧S0证书不再认证新执行。新run重新绑定；不覆写历史。
- STOP-DATA：总体admission FAIL、任何必需history/target没有实际内容证书、绝对UTC/role/norm/grid不同、placeholder或重复样本，拒绝train/cache。
- STOP-FS：固定资格panel的退化或不满足已批准质量门，Fs不能发布；不得执行expert training。旧0/8改善且冻结面板明显退化的Fs与所有依赖产物隔离。
- STOP-COMMON：workers不同Fs、missing dynamic checkpoint、independent reload或assembled行为不一致，整库不得放行cache。不能只保留较好workers后声称commonFs。
- STOP-PROFILE：任何profile改变合格bank state，资格失效；须用副本/恢复并重新qualification，不能把额外更新排除计数。
- STOP-REGISTRY：正式消费必须非空唯一、显式no-edit、真实系数/support/hold和Fs/权重/Q/norm/source绑定；仅写metadata/状态字符串不算校验。
- STOP-EXECUTION：前驱False/异常/缺证书时立即停止依赖handler；只在finally写diagnostic/handoff，不能继续training后再统一rc=1。

## 3. 科学生存规则

价值阈值与功效分别定义。未定字段均标：

```text
TO_BE_PREREGISTERED_AFTER_PILOT_VARIANCE_ESTIMATE
```

这不是让 variance 自动决定价值。threshold_certificate 必须分别列：
1. `delta_min` 的研究/使用价值依据；
2. pilot 的配对过程方差与数值噪声；
3. alpha、目标power、有效过程数/最大N和MDE；
4. 72h损害/非劣margin与选择依据；
5. 追加样本与重试cap；
6. 签名/冻结时间、谁批准、是否早于相应比较结果。

原计划没有给 Fs-quality margin、72h业务容忍度或minimum-utility固定百分比，本包也不编造。后来 shared-F0 的1.001/1.05等工程尺度不自动迁移到原计划。
没有 quality 规则不能发布 Fs；没有价值阈值/功效证据可以记录描述性DEV，但不能给科学PASS/FAIL。

- STOP-ORACLE：完整合格库在注册目标/预算下，oracle收益的上置信界仍低于delta_min，停止当前库；不推广为所有参数编辑不可行。
- PIVOT-STATIC：同权限trainfoldstatic解释有用收益，合法动态策略没有超过冻结minimum-dynamic价值，优先静态；不能用test最优静态冒充合法基线。
- STOP-SELECTOR：oracle有空间但合法regime/ridge在批准cap内没有足够证据，停止当前selector扩张；仅有明确诊断时另批准一次有限挑战，不默认叠模块。
- INCONCLUSIVE：CI跨阈值/过程数不足/样本不完整时不强行科学PASS或FAIL。达到时间/资源上限停止并留档，不无限追加。
- ORACLE-PASS 仅说明事后空间。不能将 E[max g] 当成 E[max E(g|I)] 或可部署收益。
- 本窗口不评价双头相对direct优势；将来若direct等效且更便宜，需正式等效/非劣证据才能判factorization价值不足，不能靠“未显著”完成等效证明。

## 4. 不可改变的分母与开放范围

不按收益删专家/候选/天气过程，不把运行失败填成0收益；保留attempted、complete、失败/回退成本。
缺候选不能称completeoracle。发生非finite或内容异常按事前规则BLOCK，不在successfulsubset计算headline。
S0/debug/profile暴露样本不得当未触碰confirm。DEV只是开发线索，不是最终确认。
`sealed_labels`文件名本身不是权限隔离；预测reader必须被实际拒绝访问其评分fold的truth/候选结果。
所有任务结束须独立验收才解锁下一步；当下仅FUP-01 unlocked。
