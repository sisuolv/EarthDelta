# EarthDelta 下一迭代执行计划

依据 `a3596e6b804e9d23b72d1247b08c47129d6b50b1` 对 `plans_v3_0922` 的执行审查。当前分支观察为 `fdd92d79b1b03e8397d4c487d7fa4a347ae6fc37`，仅文档变化。

本文件与 CODEX_TASKS.json 一致。初始只解锁 FUP-01；全部科学训练/cache为LOCKED。
本轮恢复原计划 fitted-Fs 路线，S0 FAIL 与 Fs-fit deterioration 均为前置阻塞，不用“新F0路线存在”绕过。

## 命令环境

所有命令在本地**实际源码 checkout**根目录运行。请在 `run_env.json` 记录下列路径，由用户现有资产解析，不猜测挂载：

```bash
export ED_RUN=/absolute/path/to/new_isolated_run
export ED_ASSETS=/absolute/path/to/existing_assets
export S0_CONFIG="$ED_RUN/s0/gate_config.json"
export REF_DIR="$ED_RUN/s0/official_reference"
```

路径是需填写的运行变量，不是已存在资产。`mkdir`不生成合法config或certificate。
沿用环境允许时执行CPU测试；缺依赖先报告，不擅自升级共享Torch或联网下载大权重。
所有将新增的文件/参数/CLI均明确 TO_BE_IMPLEMENTED_BEFORE_RUN；本包交付的是工程合同，不是假冒已实现程序。
`scripts/plan_followup_run.py` 为 FUP-02 新增的薄调度入口，复用现有函数；任务只解锁后才实现对应分支。

## 时间估计口径

下列 `estimated_minutes` 是编码/运行/排错的**规划时间盒**，不是当前硬件实测或完成保证。
未知排队、checkpoint复制、数据IO不计入虚构GPU时数；开始GPU工作前用已授权profile更新estimate并记录依据。
原计划10小时是此前窗口安排，不能自动续授新的10小时。当前批准总时限/作业数未提供时记 BLOCKED_RESOURCE_AUTHORIZATION。

## 逐任务合同

### FUP-01 — S0 证据补齐、根因定位及原容差复验

**目标与范围：** 只处理 S0：不训练 Fs/experts，不生成 scientific cache，不放宽容差。

**依赖：** 无；只读源证据输入。

**CPU/GPU：** 必需：源码/合同/回归测试或统计审查；条件必需；已有资产与本轮资源授权齐全才提交。

**规划时间盒：** 120 分钟；后续执行的规划时间盒，不是已测硬件运行时或完成保证；排队/资产复制未知，GPU 段须由真实 profile 再核定。

**输入：** 前驱真实证书、冻结 run config、required-input 清单中与本任务相关资产；缺失不推测。

**Files：**
- `earthdelta/bridge/stormer_bridge.py`
- `earthdelta/contracts.py`
- `scripts/s0_gate.py`
- `scripts/export_upstream_reference.py`
- `scripts/r4_s0_parity_diagnose.py`
- `tests/test_s0_gate_end_to_end.py`
- `tests/test_normalization_policy.py`
- `tests/test_s0_transform_factories.py (CREATE)`

**Implementation：**
1. 先记录 checkout HEAD、父提交、dirty patch、相关源文件 SHA 和 Python 实际 imported __file__；允许新 task 分支但不得 reset/clean 用户工作树。建立 ED_RUN 新目录，旧失败 artifacts 只读。
2. 请求或读取本地 pt-7ant09uv 原始 job_result、S0 JSON、config、官方 reference、实际 norm NPZ/NPY 和 checkpoint 身份；缺件记 MISSING，禁止从摘要伪造 raw result。
3. 检查 raw input mean/std 与 diff mean/std 的 dtype。官方 get_reverse_transform 在源 dtype 上求 reciprocal 和 inverse mean 后才转执行 dtype；不要先 float 再 double 伪恢复。
4. 最小修复两个工厂：from_npz_dir 与 create_normalization_from_npy。保留原始常量或确定的逆变换派生参数；保证正式 S0、diagnose 与随后 Fs 路径的相同执行语义。若 NPY 已损失精度，按绑定的官方 NPZ 重新导出独立 NPY 资产及新身份，不改旧资产。
5. 更新 normalizer 的原精度/派生逆参数身份或显式 execution schema，保持 exporter 数值 transforms 独立；共享 serializer 不等于共享待审数值实现。旧前向常量 digest 不足以单独证明逆变换一致。
6. 修改现有 diagnose：所有模型调用一致 interval/10=0.6；OO/OB/BO/BB 四组合，逐 t=1..12 保存共同状态局部比较和自由 rollout 累积比较，定位 first_difference。再做仅替换 input inverse、仅替换 diff inverse 的消融。
7. CPU 合成 fixture 对 raw float64/float32、NPY/NPZ、不同初始化与输入差异反例验证。真实 GPU 只跑已登记 exposed S0 输入与注册 1/4/12，保留 1e-5。独立参考与 gate 运行使用同一新版 source/config，结果不覆盖旧 run。
8. 正式 gate 保留 expected/ref/observed 身份和已修复的异常/发布控制。精度探针诊断可 status=COMPLETED，但不得伪装 S0 PASS。源码变更后旧 S0 证书失效。

**Tests：**
- raw 源常量先 inverse 与截断后 inverse 的区分性用例；两个生产工厂等价，而不是同一个 mock normalizer 自比较。
- 真实 run_s0_gate/main 的错身份、错 raw/normalized、四步同形但数值错误、空 horizon/缺件、晚期异常应拒绝。
- CPU 数值机制测试不生成可消费 GPU S0 证书；真实 GPU 四组合和原注册 S0 分开报告。

**Run command（TO_BE_RUN）：**

```bash
git rev-parse HEAD && git status --short && git diff --stat
PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/test_normalization_policy.py tests/test_s0_gate_end_to_end.py tests/test_s0_transform_factories.py -q -rs
python scripts/r4_s0_parity_diagnose.py --run "$ED_RUN" --assets "$ED_ASSETS" --out "$ED_RUN/s0/diagnostic.json"
python scripts/export_upstream_reference.py --config "$S0_CONFIG" --output-dir "$REF_DIR"
python scripts/s0_gate.py --config "$S0_CONFIG" --reference-dir "$REF_DIR" --output-dir "$ED_RUN/s0/gate_output"
```

**Expected artifacts：**
- `source/source_manifest.json`
- `source/working_tree.diff`
- `s0/diagnostic.json`
- `s0/per_step_differences.jsonl`
- `s0/config.json`
- `s0/job_result.json`
- `s0/stdout.log`
- `s0/stderr.log`
- `s0/reference_manifest.json`
- `s0/s0_gate_result.json`
- `tasks/FUP-01/decision.json`

**Success / acceptance：**
- 取得可核验 raw GPU gate：身份 criteria 全部通过，1/4/12 normalized 最大绝对差分别 <=1e-5，verdict_committed=true。
- runtime dtype/TF32/backend、代码与资产 SHA、参照与本地输入/输出身份完整；对正式工厂数值语义作证，不只验证诊断工厂。
- 最小补丁通过针对性 CPU/回归；根因证据或 remaining gap 如实记录。独立验收前不解锁 FUP-02。

**Failure / stop：**
- raw 资产或当前 GPU 授权缺失 → BLOCKED；CPU 部分可完成，不能冒充整个任务 PASS。
- 任何注册 horizon/身份 FAIL → 停在 S0；不改 tolerance、删 horizon、换有利输入或继续训练。
- 四组合无法定位唯一根因 → PLAUSIBLE_UNVERIFIED/INCONCLUSIVE，保留证据，不凭猜测宣告修复。

**完成后：** 保存 task decision，停止并等待独立验收；不得自行解锁。

### FUP-02 — 最小生产边界：STOP、native Q 与原计划数据准入

**目标与范围：** 修复实际 common-Fs 路线入口。禁止重写全量下载器、无关 concurrency 或额外模型。

**依赖：** FUP-01。

**CPU/GPU：** 必需：源码/合同/回归测试或统计审查；无默认 GPU 训练授权。

**规划时间盒：** 75 分钟；后续执行的规划时间盒，不是已测硬件运行时或完成保证；排队/资产复制未知，GPU 段须由真实 profile 再核定。

**输入：** 前驱真实证书、冻结 run config、required-input 清单中与本任务相关资产；缺失不推测。

**Files：**
- `scripts/r2_fs_bank_train.py`
- `earthdelta/static_adapter.py`
- `earthdelta/pilot_contract.py`
- `earthdelta/data/make_splits.py`
- `earthdelta/metrics_contract.py`
- `earthdelta/registry.py`
- `scripts/plan_followup_run.py (CREATE thin CLI)`
- `tests/test_plan_followup_guards.py (CREATE)`

**Implementation：**
1. 将 --stage all 改为显式 DAG，前驱 False/BLOCKED/异常不得调用后继。写 blocked_children，区分诊断文件与合格发布；单独调用后继也必须验证前驱证书，而非只相信内存 ctx 存在。
2. 新增薄 CLI plan_followup_run.py 统一读取 spec/frozen_run.json，仅调度现有 Fs/bank/native 函数并加载证书，不另写一套网络或训练算法。--stage choices 为 preflight/fs-fit-freeze/bank-fit-qualify/cache-debug/cache-dev/fit-cheap/freeze-actions/score-dev/decision；子阶段按后续 task 才实现/解锁。
3. 原始输入角色用 bank_fit、policy_dev、exposed；confirm 禁止读取。基于实际 UTC 联结 t-12,t-6,t,t+6,t+24,t+72；每个使用 chunk 有 finite/shape/coordinate/channel/hash 证明。原始 split manifest 未取得时不猜年份、不自动套用 shared-F0 的 2018/2019/2020 划分。
4. 在 load_admitted_samples/load_admitted_sample 强制消费总体 PASS、norm/grid/source身份与所有实际 horizon 内容证书；按绝对时间重新定位，拒绝 index 相对正确但时间轴已移动的情况。
5. native scoring 统一 full_objective_loss/gain 的同一 Q_eff，float64 形成误差并累加；旧 quadratic_gain 若仍被本任务消费，修 broadcast 后每个约简切片分母。未使用 old head/calibration 明确排除。
6. 区分 draft coefficient registry 和正式 artifact-bound registry；正式消费要求 Fs/norm/Q/grid/动态 checkpoint identity、非空、唯一ID和显式 no-edit；不能以 metadata 存在代替验证。
7. source-dependent模块变化使原 gate 证书不适用时，返回 FUP-01 复验并停止，不为“已通过一次”跳过。

**Tests：**
- 调用真实 runner：强制 fs_fit=False、fs_freeze异常、过期 S0 时，expert/profile/cache handler 调用次数为零。
- 总体 admission=False但行admitted=True、部分目标缺证书、time+24h、norm改变、缺history、角色重叠必须失败。
- native非均匀Q/scale端点恒等式、零约简分母/复数/NaN反例；history/target purge 与全候选同issue角色守卫。
- 正式 registry 缺共同Fs/权重/Q、重复、空表、缺no-edit拒绝；宽松草稿不能用于消费。

**Run command（TO_BE_RUN）：**

```bash
PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/test_plan_followup_guards.py tests/test_metric_contract.py tests/test_pilot_admission_b09.py tests/test_candidate_registry_b15.py -q -rs
python scripts/plan_followup_run.py --stage preflight --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/admission"
```

**Expected artifacts：**
- `spec/frozen_run.json`
- `spec/threshold_certificate.json`
- `admission/admission.json`
- `admission/issue_manifest.json`
- `admission/content_certificates.json`
- `tests/cpu.xml`
- `tasks/FUP-02/decision.json`

**Success / acceptance：**
- 原计划实际输入的完整数据证书、split/角色/目标冻结且实际消费通过；真实 runner fail-closed。
- native计分与正式registry生产接线有区分性CPU验收；无 confirm/heldout/F0静默替换；新源码与S0依赖兼容。

**Failure / stop：**
- 缺原始split或实际资产 → BLOCKED，不从计划表生成假admission。
- STOP不生效、scalar gain与fullobjective冲突或身份不一致 → FAIL_IMPLEMENTATION。
- 数值相关source改变使 S0过期 → 返回FUP-01，不前进。

**完成后：** 保存 task decision，停止并等待独立验收；不得自行解锁。

### FUP-03 — 只拟合、选择并发布一份合格 Fs

**目标与范围：** 解决 Round4 Fs-fit deterioration 与共同参考问题；本任务不训练动态专家。

**依赖：** FUP-02。

**CPU/GPU：** 必需：源码/合同/回归测试或统计审查；条件必需；已有资产与本轮资源授权齐全才提交。

**规划时间盒：** 60 分钟；后续执行的规划时间盒，不是已测硬件运行时或完成保证；排队/资产复制未知，GPU 段须由真实 profile 再核定。

**输入：** 前驱真实证书、冻结 run config、required-input 清单中与本任务相关资产；缺失不推测。

**Files：**
- `earthdelta/static_adapter.py`
- `scripts/r2_fs_bank_train.py`
- `scripts/plan_followup_run.py`
- `tests/test_fs_quality_gate.py (CREATE)`
- `tests/test_fs_static_adapter.py`

**Implementation：**
1. S0/admission硬门验证后才实跑；在bank_fit侧先固定相同initial与候选checkpoint复评panel、seed/order、质量门、最多重试次数及GPU cap。缺质量阈值依据不能发合格证书。
2. 先16–32updates诊断，保存loss、clip前后梯度、实际参数更新、delta范数、optimizer状态和checkpoint。500仅历史起始上限；不为完成数量盲跑，也不自动保留旧LR=.01。候选LR/选择规则须在新的结果前批准。
3. 所有候选用共同初始和同一个固定面板算逐样本差及6/24/72端点。把训练质量门与hook/merge数值等价门分开；finite和nonzero都不足以证明quality。
4. 选择只能使用bank_fit侧预注册资格数据，不读policy_dev/confirm。不允许删除退化样本、复用原8/8失败产物并改称PASS。没有合格Fs则停止，不能默默fallbackF0。
5. 只冻结并保存一份Fs；同时保存adapter和merged/always-on执行形态、参考初始F0 SHA、stateSHA、norm/Q/source/data关系。独立加载复算。
6. 验证同一Fs与adapter常开/merged的注册horizon等价、no-edit严格返回Fs、hold后继续Fs。merge自身的注册公差与S0 1e-5分开，不能用merge delta-relative阈值修改S0。

**Tests：**
- 构造所有paired样本退化但finite/merge-equivalent的假训练结果，quality必须FAIL且无qualified_publish；测试旧反例0/8改善。
- 测试同checkpoint面板评估而不是roundrobin首次/末次visit当作共同初末状态；checkpoint选择不看dev。
- 新进程load固定Fs输出/身份一致；缺质量certificate、wrongbaseline/norm/Q不放行。

**Run command（TO_BE_RUN）：**

```bash
PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/test_fs_quality_gate.py tests/test_fs_static_adapter.py tests/test_plan_followup_guards.py -q -rs
python scripts/plan_followup_run.py --stage fs-fit-freeze --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/fs"
```

**Expected artifacts：**
- `fs/fit_trace.jsonl`
- `fs/panel_initial_final.json`
- `fs/quality_decision.json`
- `fs/fs_adapter.pt`
- `fs/fs_merged_backbone.pt`
- `fs/reference_manifest.json`
- `fs/reload_verification.json`
- `fs/job_result.json`
- `tasks/FUP-03/decision.json`

**Success / acceptance：**
- Fs质量与数值等价分别PASS；固定面板、来源、配置完整；所有后继仅能加载唯一合格Fs。
- 旧8/8退化产物明确隔离；新reference可独立重载，未用dev/confirm选择。根因可以仍未完全因果闭合，但资格与门必须成立。

**Failure / stop：**
- S0或admission不PASS → BLOCKED，不执行optimizer。
- 固定面板不满足事前质量门或达到重试cap → STOP_CURRENT_FS_SETUP；experts/cache保持LOCKED。
- Fs quality阈值、panel、预算尚未批准 → BLOCKED_CONFIGURATION，不借新F0工程阈值顶替。

**完成后：** 保存 task decision，停止并等待独立验收；不得自行解锁。

### FUP-04 — 共同 Fs 上 K=4 专家交付、重载与组装验收

**目标与范围：** 先解决可消费专家产物；不做新backbone/多专家组合/幅度泛化。

**依赖：** FUP-03。

**CPU/GPU：** 必需：源码/合同/回归测试或统计审查；条件必需；已有资产与本轮资源授权齐全才提交。

**规划时间盒：** 90 分钟；后续执行的规划时间盒，不是已测硬件运行时或完成保证；排队/资产复制未知，GPU 段须由真实 profile 再核定。

**输入：** 前驱真实证书、冻结 run config、required-input 清单中与本任务相关资产；缺失不推测。

**Files：**
- `earthdelta/bank_training.py`
- `earthdelta/static_adapter.py`
- `earthdelta/registry.py`
- `earthdelta/value_pilot.py (复用序列化原语，不改reference成F0)`
- `scripts/r2_fs_bank_train.py`
- `scripts/plan_followup_run.py`
- `tests/test_common_fs_bank.py (CREATE)`

**Implementation：**
1. 所有worker显式load同一个FUP03 reference；比较完整state/norm/Q/source，而不是各自重复fs_fit。默认K4rank4blocks18–23；K2降配仅因profile且在devoutcome前批准，产生新registry身份。
2. 原计划动作no-edit+singleton a0=rho=.25，max_active1，hold4×6h；24h训练、6诊断72guard。保持固定系数bank梯度，无需caller controller梯度。
3. 资格使用bank_fit侧预注册panel；检查来源、非零响应、finite/稳定性、专家差异与恢复。合格但dev输的专家不能事后删除；不合格专家导致库资格不足而非静默K缩小。
4. 动态因子保存为有schema的state_dict，绑定expert/block/config和共同Fs/norm/Q；新进程严格加载逐一重算。任何训练profile只用副本，不修改已验收bank；statehash前后断言。
5. assembled K4逐singleton在已登记panel上与各独立checkpoint做1/4/12步行为比较；检验非零bank的no-edit和保存再加载。验证后再发布bank_manifest/registry。
6. 正式registry要绑定qualification记录与输出权重；禁止仅靠状态字符串或系数表宣布commonbank成立。

**Tests：**
- worker引用不同Fs、换norm/Q、缺dynamic文件、错expert slot、坏reload、profile修改bank、组装输出不等价均拒绝。
- 零初始化B更新后验证A/B梯度；保持backbone冻结和hookcleanup；当前不启用activation checkpoint replay/共享model线程。
- CPU synthetic bank/state roundtrip和真实GPUqualification分别保存，前者不能代替后者。

**Run command（TO_BE_RUN）：**

```bash
PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/test_common_fs_bank.py tests/test_bank_gradients.py tests/test_bank_training.py -q -rs
python scripts/plan_followup_run.py --stage bank-fit-qualify --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/bank"
```

**Expected artifacts：**
- `bank/expert_0.pt`
- `bank/expert_1.pt`
- `bank/expert_2.pt`
- `bank/expert_3.pt`
- `bank/qualification.json`
- `bank/assembly_equivalence.json`
- `bank/assembled_bank.pt`
- `bank/bank_manifest.json`
- `bank/registry.json`
- `bank/profile.json`
- `tasks/FUP-04/decision.json`

**Success / acceptance：**
- 所有专家具有同一合格Fs内容身份；native质量资格、保存/独立重载、assembly行为和nonzero/noedit通过。
- 正式registry与实际载入权重和source一一对应；profile不变更资格版本；所有GPU工作有jobid/rawlogs。

**Failure / stop：**
- S0/Fs quality/reference/cert不匹配 → BLOCKED，禁止专家训练。
- 某专家不合格/缺恢复/assembly失败 → BLOCKED_BANK；不生成完整oracle。
- 预算不足 → 停止新作业，交付现状；不能输出未运行的PASS。

**完成后：** 保存 task decision，停止并等待独立验收；不得自行解锁。

### FUP-05 — debug8 与冻结 policy_dev 全候选缓存

**目标与范围：** 原计划 Fs-relative cache。新 shared-F0 缓存原语可复用，但不能把F0结果改名Fs。

**依赖：** FUP-04。

**CPU/GPU：** 必需：源码/合同/回归测试或统计审查；条件必需；已有资产与本轮资源授权齐全才提交。

**规划时间盒：** 90 分钟；后续执行的规划时间盒，不是已测硬件运行时或完成保证；排队/资产复制未知，GPU 段须由真实 profile 再核定。

**输入：** 前驱真实证书、冻结 run config、required-input 清单中与本任务相关资产；缺失不推测。

**Files：**
- `scripts/plan_followup_run.py`
- `earthdelta/value_pilot.py`
- `earthdelta/registry.py`
- `earthdelta/pilot_contract.py`
- `tests/test_plan_cache_contract.py (CREATE)`

**Implementation：**
1. 先8个exposed issue跑全部5候选检查程序；不把这些样本收入后续效应统计。
2. 依据真实profile、I/O、可用角色和有效过程数，在看devgain之前冻结DEV32/64/128其一、候选序、seed、processblocks和扩样规则；N128不是硬性通过条件。
3. 每issue同输入/共同Fs/真值，完整12步一次rollout保存6/24/72，noedit与hold后Fs继续。记录完整raw endpoints与native loss/gain，使缓存可独立复算。
4. 做Fs/reference/bank/norm/Q/source/split传递校验；每issue×candidate唯一并完整，不成功子集评分；失败清晰记录且不填零。
5. feature与outcomes reader物理/接口分离。缓存可离线产生outcomes，但policy_fit/freeze程序不得读取本折被评分候选结果。保存checkpoint/registry/每文件sha、timing、attempted/complete/cost。
6. 统计用真实天气过程/UTC块，不能用grid/candidate/lead增加N。所有cache产物staging验证后发布。

**Tests：**
- 缺一个候选、重复、错reference、错role、改time/hash、NaN、空registered表全部阻断完整cache。
- 用同一e/u/Q手算native端点恒等式；outcomes改写后invalidatecache；debug不能入DEV。

**Run command（TO_BE_RUN）：**

```bash
PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/test_plan_cache_contract.py -q -rs
python scripts/plan_followup_run.py --stage cache-debug --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/cache_debug"
python scripts/plan_followup_run.py --stage cache-dev --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/cache_dev"
```

**Expected artifacts：**
- `cache_debug/debug_report.json`
- `cache_dev/cache_manifest.json`
- `cache_dev/candidate_outcomes.parquet`
- `cache_dev/forecasts/`
- `cache_dev/legal_features/`
- `cache_dev/failure_ledger.jsonl`
- `cache_dev/costs.json`
- `tasks/FUP-05/decision.json`

**Success / acceptance：**
- 被冻结issue×全部注册candidate覆盖100%，包括noedit；或如实BLOCKED没有伪造完整缓存。
- Fs/reference之后继续、全部数据身份、失败分母可核查；合法feature和oraclelabel明确隔离。

**Failure / stop：**
- 前驱任一gate不PASS或当前source改变 → BLOCKED。
- cache缺候选/身份/内容不完整 → BLOCKED_CACHE，不做oracle/策略排行榜。
- 看到dev结果后想改N/专家/时段/目标 → STOP_PROTOCOL_CHANGE，需新run和独立批准。

**完成后：** 保存 task decision，停止并等待独立验收；不得自行解锁。

### FUP-06 — cheap-policy 开发外折、动作冻结与真实结算

**目标与范围：** 仅 Fs/noedit、trainfoldstatic、regime、ridge direct-gain、offline oracle；不做dualhead/E3/finalconfirm。

**依赖：** FUP-05。

**CPU/GPU：** 必需：源码/合同/回归测试或统计审查；无默认 GPU 训练授权。

**规划时间盒：** 60 分钟；后续执行的规划时间盒，不是已测硬件运行时或完成保证；排队/资产复制未知，GPU 段须由真实 profile 再核定。

**输入：** 前驱真实证书、冻结 run config、required-input 清单中与本任务相关资产；缺失不推测。

**Files：**
- `scripts/plan_followup_run.py`
- `earthdelta/plan_dev_evaluation.py (CREATE minimal module)`
- `tests/test_plan_dev_evaluation.py (CREATE)`

**Implementation：**
1. 冻结time-ordered外折和完整support purge；每折normalization、聚类、static选择与ridge超参都只用训练侧。bank_fit不包含评分dev。历史t-12/t-6/t只按已批准合法输入。
2. 实现小型static/regime/ridge，oracle单独evaluation-only。先输出每折每issue的预测gain和选定动作及其hash，再在只读独立score步骤加载对应outcomes。
3. 评估原计划24h native loss、gain_vs_Fs、gain_vs_trainfoldstatic、6h诊断、72hguard、harmful/noedit、attempted/complete和实际离线/在线成本。reference、oracle所有成本分开。
4. paired resampling以完整天气过程/UTC块，所有方法同一抽样；定义block与bootstrapseed，不把候选/网格当重复。少块时只报描述性DEV并标INCONCLUSIVE。
5. 预登记delta_min价值依据与alpha/power/N/MDE；CI跨阈值不能PASS也不能科学FAIL。完整oracle只测hindsight上限；cheap合法策略增益才是可利用空间。
6. 任何future-truth/同issue实际响应/oraclescore进入预测reader立即阻断。禁止用冻结动作之后的holdout结果反向调整模型。

**Tests：**
- 修改评分foldtruth不会改变先保存的actions；修改fitfoldlabel可以影响fit；static/regime不得用全DEV挑优。
- 独立±1误差与动作0,±.5的反例：oracle .75、最优合法期望0，防止oraclePASS误写deployablePASS。
- 过程聚合与paired抽样一致；损失先聚合再sqrt；失败不能静默剔除；缺有效blocks输出INCONCLUSIVE。

**Run command（TO_BE_RUN）：**

```bash
PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m pytest tests/test_plan_dev_evaluation.py -q -rs
python scripts/plan_followup_run.py --stage fit-cheap --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/policies"
python scripts/plan_followup_run.py --stage freeze-actions --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/frozen_actions"
python scripts/plan_followup_run.py --stage score-dev --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/dev_results"
```

**Expected artifacts：**
- `policies/fit_manifest.json`
- `frozen_actions/actions.parquet`
- `frozen_actions/prediction_freeze.json`
- `dev_results/results.csv`
- `dev_results/paired_statistics.json`
- `dev_results/oracle_static_policy_gaps.json`
- `dev_results/decision.json`
- `tasks/FUP-06/decision.json`

**Success / acceptance：**
- 拿到合法、完整、可复算的DEV表即可算工程任务执行完成；科学CONTINUE/PIVOT/STOP按预注册证据另外判定。
- gate不因无正效应而伪造PASS；最少确认信息/资源公平；无最终confirm读取。

**Failure / stop：**
- prediction freeze缺失/role泄漏/基础身份失效 → FAIL_IMPLEMENTATION。
- oracle上界小于价值阈值且不确定性充分小 → STOP_CURRENT_BANK；强static解释全部有用收益 → PIVOT_STATIC。
- oracle大但cheap无可信信号 → INCONCLUSIVE或达到capSTOP_CURRENT_SELECTOR；不自动加dualhead。
- CI宽/独立过程少 → INCONCLUSIVE；不得改指标/分母制造成功。

**完成后：** 保存 task decision，停止并等待独立验收；不得自行解锁。

### FUP-07 — 独立证据验收与下一轮决策

**目标与范围：** 输出原计划完成度与开发结论；不授权新模块或最终确认。

**依赖：** FUP-06。

**CPU/GPU：** 必需：源码/合同/回归测试或统计审查；无默认 GPU 训练授权。

**规划时间盒：** 30 分钟；后续执行的规划时间盒，不是已测硬件运行时或完成保证；排队/资产复制未知，GPU 段须由真实 profile 再核定。

**输入：** 前驱真实证书、冻结 run config、required-input 清单中与本任务相关资产；缺失不推测。

**Files：**
- `scripts/plan_followup_run.py`
- `CURRENT_GAP_ANALYSIS.md`
- `evidence/PLAN_AUDIT_RESULT.json`

**Implementation：**
1. 逐链复查commit/source/checkpoint/data/Fs/bank/registry/actions/results；哈希、jobID、exit code和任务锁一致。
2. 按code/CPU/GPU/S0/downstream/科学证据六层更新状态；未运行项继续TO_BE_RUN或MISSING，不能抹掉历史FAIL。
3. 做明确CONTINUE_NEXT_ITERATION/PIVOT_STATIC/STOP_CURRENT_BANK/STOP_CURRENT_SELECTOR/INCONCLUSIVE决策。任何新双头/E3/confirm都另需新批准，不由本任务自动解锁。
4. 若早期任务BLOCKED，允许执行只读handoff子动作保存缺件清单，但该任务overall仍BLOCKED；不得伪造完整DAGPASS。

**Tests：**
- 运行产物身份、状态与rawmetrics复算自检；任务依赖无跳过；最终decision可由保存表重算。

**Run command（TO_BE_RUN）：**

```bash
python scripts/plan_followup_run.py --stage decision --config "$ED_RUN/spec/frozen_run.json" --out "$ED_RUN/handoff"
```

**Expected artifacts：**
- `handoff/FINAL_STATUS.json`
- `handoff/RESULTS.md`
- `handoff/evidence_manifest.json`
- `handoff/REQUIRED_INPUTS.md`
- `tasks/FUP-07/decision.json`

**Success / acceptance：**
- 工程状态与科学结论分别给出且所有引用可定位；未证明项不作公开声明。

**Failure / stop：**
- 任一来源缺失或不可复算 → INCONCLUSIVE/MISSING；不输出无条件研究成功。
- 新科学阶段未获批准 → 保持LOCKED并结束本轮。

**完成后：** 保存 task decision，停止并等待独立验收；不得自行解锁。
