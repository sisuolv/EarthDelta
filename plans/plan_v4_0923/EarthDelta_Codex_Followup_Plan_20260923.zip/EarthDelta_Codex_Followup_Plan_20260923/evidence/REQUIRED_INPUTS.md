# Codex 执行前必须补齐的输入

可提供文件或本地/集群可读取的挂载路径和完整SHA；不要求把多GB checkpoint重复上传聊天。
不需要补充就能完成的：阅读此包、取得受审源码、做不使用真实权重的CPU边界补丁。
无法从本包推断的：精确资产路径、实际已冻split名单、最新rawGPU结果和本轮资源授权。

| 优先级/最早任务 | 必须输入 | 当前状态 | 缺失影响 |
|---|---|---|---|
| P0/FUP01 | 完整私有checkout，refs a3596e6/fdd92d79/d749a1c，相关git diff及实际worker dirty source bundle/import manifest | GitHub connector已读取受审范围；本ZIP无checkout | 无源码不能改代码，停BLOCKED_SOURCE |
| P0/FUP01 | `pt-7ant09uv` 的raw `job_result.json`、完整stdout/stderr、`s0_gate_result.json`、paritydiagnostic、实际worker source/env manifest | MISSING；只有tracked summary | 不能独立确认/复算最新GPU结果，也不能认证S0 |
| P0/FUP01 | 该run真实 `s0/gate_config.json`、官方reference manifest、`input_norm.pt`、`official_output_6h_1step.pt`、`official_output_6h_4step.pt`、`official_output_6h_12step.pt` | MISSING | 无法校验绑定与数值；不得自己制造reference |
| P0/FUP01 | ps4 checkpoint或只读挂载+SHA；官方源码pinned58dfee5；实际原始norm NPZ、提取NPY、S0 rawinput、lat/lon、channels以及dtype/hash | MISSING（路径由用户环境提供） | CPU可做合成补丁，真实S0 BLOCKED |
| P0/FUP01 | 当前CCI执行接口/worker可用性、环境镜像/overlay、当前明确的GPU作业数/时长/费用cap和授权 | MISSING | 不提交GPU；此前10h计划不是当前授权 |
| P1/FUP02 | 原计划使用的完整admission manifest、bank_fit/policy_dev/finalconfirm排除清单、真实UTCsupport、所有所需chunk内容certificate及source/hash | MISSING；旧8行2cert反例只有归档 | 不猜年份/角色；不自动采用新F0的616issue |
| P1/FUP02 | `CURRENT_STATUS` 所述66passed/3skipped与最新307套件原始logs、JUnit、命令、依赖和source binding | MISSING；Round4历史307+127日志已读 | 当前完整CPU验收仍未证实 |
| P1/FUP03 | `pt-3x63g0c6` / `pt-cdj1s2le` / `pt-2r6tbwu7` 各expert的run_record/fs_fit_record/fs_post_freeze、初始/最终权重identity、同panel样本/优化器/训练logs | 只有Round4report、重算归档和引用SHA；原文件MISSING | 可静态修门；要独立复算旧8/8与新对照必须补原始文件 |
| P1/FUP03 | 新Fs质量阈值/固定panel/seed/order、候选LR/checkpoint选择、有限retry授权与预算 | TO_BE_RUN / 待事前登记 | 未定不能发布qualifiedFs |
| P1/FUP04+ | 合格Fs、dynamicweights、qualification、assembled证书、registry、cache与frozenactions | TO_BE_RUN，不是用户已经欠交的结果 | 由前驱任务生成，禁止伪造来填空 |

## 文件定位提示（已观察的引用，非本包内实际存在）

- 最新run：`ed-sprint8h-20260922T035313Z`，GPU job `pt-7ant09uv`。
  raw路径仅说明在本地 `artifacts/`，本审查未获得精确子路径；请提供 `artifact_index.json`，不要依猜测建立链接。
- 历史formal：`artifacts/round2_cci/ed-r3-j4-bank-formal-v2-0922011307-2d8e12/expert{0..3}/run_record.json`。
- 历史S0：`artifacts/round2_cci/ed-r3-j1-s0gate-0921200335-0180dc/s0_gate_output/s0-gate-20260921t200508599573z/s0_gate_result.json`。
- 历史admission：`artifacts/round2_next/20260921T170142Z_r3p001_10h/j3_fs_bank/admission_record.json`。

本包 `evidence/reference_reports/` 是报告快照，不是上述raw文件的替身。不上传任何secret/token。
