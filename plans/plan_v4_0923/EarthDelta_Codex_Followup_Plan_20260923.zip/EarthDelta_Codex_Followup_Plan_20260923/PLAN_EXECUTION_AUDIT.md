# EarthDelta 原计划执行审查报告

以下 JSON 遵循输入 OUTPUT_SCHEMA.json 的字段组织；该输入文件本身是枚举占位模板，不是标准 JSON Schema。

```json
{
  "overall_verdict": "PARTIALLY_EXECUTED",
  "baseline": {
    "planned_source": "plans/plans_v3_0922/NEXT_STEPS_10H_PLAN.md + CLAUDE_10H_PROMPT.md + 三份 Stage1A review",
    "implementation_commit": "a3596e6b804e9d23b72d1247b08c47129d6b50b1",
    "comparison_base": "d749a1c62521226df857587e08f7d067b0f15355",
    "observed_branch_head": "fdd92d79b1b03e8397d4c487d7fa4a347ae6fc37",
    "head_change_scope": "新增审查文档；earthdelta/scripts/tests/reference 子树与 implementation_commit 相同"
  },
  "plan_items": [
    {
      "id": "B05",
      "planned_requirement": "校验权重/scale/有效约简分母",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "earthdelta/metrics_contract.py",
          "line": 148
        },
        {
          "file": "earthdelta/metrics_contract.py",
          "line": 215
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "weighted_mse 与新 native reducer 已校验；旧 quadratic_gain 仍只查全局权重和，逐 F 零切片可能产生 NaN。"
    },
    {
      "id": "B06",
      "planned_requirement": "同一 native Q_eff、端点 gain 与校准分离",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "earthdelta/metrics_contract.py",
          "line": 557
        },
        {
          "file": "earthdelta/metrics_contract.py",
          "line": 652
        },
        {
          "file": "earthdelta/heads.py",
          "line": 356
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [
        "OBSERVED: 历史 Fs 路径使用 native objective；不等于预测 head 合同已统一。"
      ],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "新 full-objective 已实现并接线；旧 head 仍向唯一 gain 添加可训练 calibration。未使用旧 head 不应阻塞固定系数库。"
    },
    {
      "id": "B08",
      "planned_requirement": "实际切片内容与 artifact binding 在入口生效",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "earthdelta/pilot_contract.py",
          "line": 1517
        },
        {
          "file": "earthdelta/pilot_contract.py",
          "line": 1538
        },
        {
          "file": "earthdelta/static_adapter.py",
          "line": 1925
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [
        "OBSERVED: Round4 artifact_crosschecks.json 记录旧准入 8 行、2 份抽样内容证书；原始准入记录本包 MISSING。"
      ],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "preflight 不是死代码；旧训练消费仍不强制总体 PASS 和全部所需内容证书。新 F0 admission 不自动修复旧 Fs 消费者。"
    },
    {
      "id": "B09",
      "planned_requirement": "真实 UTC/history/target、角色与归一化身份准入",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "earthdelta/data/make_splits.py",
          "line": 911
        },
        {
          "file": "earthdelta/data/make_splits.py",
          "line": 949
        },
        {
          "file": "earthdelta/static_adapter.py",
          "line": 1817
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "实际时间端点与 placeholder 拒绝有效；消费端未闭合 absolute-time/norm/content。原计划需要 t-12/t-6/t，不能以新 F0 的 t-6/t 替代。"
    },
    {
      "id": "B12",
      "planned_requirement": "串行、独立模型、禁止不支持 replay",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "earthdelta/bridge/stormer_bridge.py",
          "line": 996
        },
        {
          "file": "earthdelta/bridge/stormer_bridge.py",
          "line": 1123
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [
        "MISSING: 当前 GPU 共享模型并发安全验收；原计划并未要求支持该模式。"
      ],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "controlled-vs-controlled model-id guard 已接线；普通 forward 不受同一 guard 保护。保持串行独立进程即可，不扩建并发框架。"
    },
    {
      "id": "B13",
      "planned_requirement": "真实 gate 异常撤销 PASS、提交与 cleanup 分离",
      "implementation_status": "COMPLETE",
      "code_evidence": [
        {
          "file": "scripts/s0_gate.py",
          "line": 1957
        },
        {
          "file": "scripts/s0_gate.py",
          "line": 2411
        },
        {
          "file": "scripts/s0_gate.py",
          "line": 2419
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。",
        "OBSERVED: Round4 记录实际 orchestration 的 provisional-PASS 异常反例已拒绝。"
      ],
      "execution_evidence": [],
      "goal_status": "ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "仅关闭该状态/发布子合同；不等于官方数值 parity、旧训练 runner 或科学准入已通过。"
    },
    {
      "id": "B14",
      "planned_requirement": "失败/缺失字段不会使报告格式化崩溃",
      "implementation_status": "COMPLETE",
      "code_evidence": [
        {
          "file": "scripts/s0_gate.py",
          "line": 2455
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [],
      "goal_status": "ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "format_finite 和报告降级已实现；当前 HEAD 全套测试运行证明仍需另取。"
    },
    {
      "id": "B15",
      "planned_requirement": "非空、唯一、显式 no-edit、实数系数和正式 registry",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "earthdelta/registry.py",
          "line": 609
        },
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 492
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [
        "OBSERVED: 历史 registry JSON 存在，不代表具备可重载动态权重身份。"
      ],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "系数表校验存在并调用；旧正式 registry 尚未绑定共同 Fs、动态权重、Q/norm。"
    },
    {
      "id": "S0",
      "planned_requirement": "ps4/官方 transforms/独立身份与 1/4/12-step parity",
      "implementation_status": "BLOCKED",
      "code_evidence": [
        {
          "file": "scripts/s0_gate.py",
          "line": 2038
        },
        {
          "file": "earthdelta/bridge/stormer_bridge.py",
          "line": 250
        },
        {
          "file": "scripts/s0_gate.py",
          "line": 238
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。",
        "OBSERVED: tests/test_s0_gate_end_to_end.py:500-680 定义真实 CLI 的身份/四步负例；定义不作本次执行。"
      ],
      "execution_evidence": [
        "OBSERVED: SPRINT_8H_DECISION.json:9-17，pt-7ant09uv，1/4/12 步差 5.9604644775390625e-6 / 3.933906555175781e-5 / 1.3911724090576172e-4，容差 1e-5。",
        "MISSING: 该 job 原始 s0_gate_result.json、job_result.json、逐步诊断与 tensors。"
      ],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "已实现完整身份/多步检查；现有机读摘要为 FAIL，不能认证通过。input inverse 精度及 NPY/NPZ 工厂不一致是待验证根因，不是已解决结果。"
    },
    {
      "id": "FS-FIT",
      "planned_requirement": "bank_fit 侧训练/选择一份合格且冻结的 Fs",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "earthdelta/static_adapter.py",
          "line": 954
        },
        {
          "file": "earthdelta/static_adapter.py",
          "line": 990
        },
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 304
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [
        "OBSERVED: Round4 GPU 重算归档中 pt-cdj1s2le expert2/3 为 0/8 改善；冻结 Fs/F0 比 4.066871 / 1.070957。",
        "MISSING: 原始逐样本 run records/weights 本次未提供；未独立复算全部数列。"
      ],
      "goal_status": "NOT_ESTABLISHED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "当前 eligible 仍未纳入固定面板质量；8/8 退化 finding 未关闭。有限退化不等于数学无限发散。"
    },
    {
      "id": "COMMON-FS-BANK",
      "planned_requirement": "共同 Fs 上 K=4/rank=4，qualification、保存/重载、registry",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 369
        },
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 475
        },
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 564
        },
        {
          "file": "scripts/r4_value_pilot.py",
          "line": 278
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [
        "OBSERVED: Round4 归档中三个历史 job 各有 4 个不同 Fs digest，旧动态 bank 缺保存权重。",
        "OBSERVED: 新 shared-F0 保存/qualification/assembly 代码存在，但 sprint decision 明示未执行。"
      ],
      "goal_status": "NOT_ESTABLISHED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "旧多 worker 不构成共同参考库；新 F0 路线是不同研究规格，不能计作原计划 Fs 目标完成。"
    },
    {
      "id": "STOP-ADMISSION",
      "planned_requirement": "前置 FAIL 不执行后继，证据与源码传递绑定",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 975
        },
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 995
        },
        {
          "file": "scripts/r4_value_pilot.py",
          "line": 475
        }
      ],
      "test_evidence": [
        "OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。"
      ],
      "execution_evidence": [
        "OBSERVED: 最新 sprint decision 记录 S0 失败后 downstream NOT_STARTED。",
        "OBSERVED: Round4 归档记录旧 fs_freeze=False 后 bank_train 仍执行。"
      ],
      "goal_status": "PARTIALLY_ACHIEVED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "最新 sprint 的停止行为应保留；旧 --stage all 仍违反硬门合同。source/hash 记录不能替代消费端强制校验。"
    },
    {
      "id": "STAGE4-CACHE",
      "planned_requirement": "共同 Fs 上 debug8、冻结 DEV32/64/128 的全候选缓存",
      "implementation_status": "PARTIAL",
      "code_evidence": [
        {
          "file": "scripts/r4_value_pilot.py",
          "line": 328
        },
        {
          "file": "scripts/r2_fs_bank_train.py",
          "line": 963
        }
      ],
      "test_evidence": [
        "OBSERVED: test_value_pilot.py 定义覆盖完整性检查；本次未复跑。"
      ],
      "execution_evidence": [
        "OBSERVED: 最新 sprint decision cache=NOT_STARTED。",
        "MISSING: 完整共同 Fs candidate cache manifest/outcomes。"
      ],
      "goal_status": "NOT_ESTABLISHED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "新 F0 cache/merge 有实现，但未执行且不满足原计划参考合同；不能把 argv/manifest 准备算成运行。"
    },
    {
      "id": "STAGE4-POLICY",
      "planned_requirement": "purged 开发外折、train-fold static/regime/ridge、先冻结动作再评分",
      "implementation_status": "NOT_STARTED",
      "code_evidence": [
        {
          "file": "scripts/r4_value_pilot.py",
          "line": 475
        }
      ],
      "test_evidence": [],
      "execution_evidence": [
        "MISSING: 拟合记录、冻结动作、开发决策表与 process-level 统计。"
      ],
      "goal_status": "NOT_ESTABLISHED",
      "evidence_status": "MISSING",
      "gap_or_risk": "当前新 CLI 仅到 merge-cache，缺 head/freeze/evaluation；旧 head 定义不等于完整开发流程执行。"
    },
    {
      "id": "FINAL-CONFIRM",
      "planned_requirement": "本窗口不读取最终 confirm；双头/E3 后续再比较",
      "implementation_status": "NOT_APPLICABLE",
      "code_evidence": [],
      "test_evidence": [],
      "execution_evidence": [
        "MISSING: 最终确认和双头优势实验证据。"
      ],
      "goal_status": "NOT_ESTABLISHED",
      "evidence_status": "STATIC_CONFIRMED",
      "gap_or_risk": "原计划 :235-237/:288 主动暂缓这些内容；未执行不是本窗口违约，但也不能作相应科学声明。"
    },
    {
      "id": "SCIENTIFIC-CLAIMS",
      "planned_requirement": "不把工程进展或 oracle 准备当作 weather utility/novelty",
      "implementation_status": "BLOCKED",
      "code_evidence": [],
      "test_evidence": [],
      "execution_evidence": [
        "MISSING: 合法策略对强静态的真实开发效用、后续公平双头对照与确认结果。"
      ],
      "goal_status": "NOT_ESTABLISHED",
      "evidence_status": "MISSING",
      "gap_or_risk": "没有可复核的新科学效果；结论为 INCONCLUSIVE，而非方法无价值或 novelty 已成立。"
    }
  ],
  "special_verdicts": {
    "s0_parity_verdict": "BLOCKED_MULTISTEP_PARITY; OBSERVED 摘要为 FAIL，原始 job/tensors MISSING",
    "fs_fit_divergence_verdict": "MUST_FIX_BEFORE_STAGE4; 未关闭",
    "stage4_readiness": "BLOCKED_BY_S0_FS_QUALITY_COMMON_BANK_ADMISSION",
    "novelty_claim_status": "INCONCLUSIVE_NOT_ESTABLISHED",
    "weather_utility_claim_status": "INCONCLUSIVE_NOT_ESTABLISHED"
  },
  "blocking_findings": [
    {
      "id": "PA-01",
      "priority": "P0",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "正式 S0 仍须保持 BLOCKED；未出现新 PASS 证据。",
      "evidence": [
        "reference_reports/SPRINT_8H_DECISION.json:9-17; job pt-7ant09uv",
        "scripts/s0_gate.py:2038-2449 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1"
      ],
      "minimal_action": "取得原始 S0 evidence；定位并修复实际工厂和逆变换后，按冻结 1e-5 / 1,4,12 步重验。"
    },
    {
      "id": "PA-02",
      "priority": "P0",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "旧阶段 runner 在子阶段 False/异常后继续调用所有依赖 handler。",
      "evidence": [
        "scripts/r2_fs_bank_train.py:963-995 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "codex_audit_round4/ROUND4_REPORT.md:116-120"
      ],
      "minimal_action": "单一前驱证书验证器，FAIL/BLOCKED 立即阻断后继；测试真实 main/handler 调用次数。"
    },
    {
      "id": "PA-03",
      "priority": "P0",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "Fs 资格仍只看 finite/非零更新，未对已观察到的固定面板全面退化拒绝发布。",
      "evidence": [
        "earthdelta/static_adapter.py:954-994 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "reference_reports/ROUND4_REPORT.md:24-35; pt-cdj1s2le expert2/3"
      ],
      "minimal_action": "同一初始/候选末态的训练侧固定面板质量门；最多批准范围内重试；不合格就不冻结可消费 Fs。"
    },
    {
      "id": "PA-04",
      "priority": "P1",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "旧 workers 各自 Fs、缺动态 checkpoint 且 profiling 改变已验收 bank，不能交付 common-Fs bank。",
      "evidence": [
        "scripts/r2_fs_bank_train.py:304-440,541-620 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "codex_audit_round4/evidence/artifact_crosschecks.json:latest_formal_expert_files,distinct_fs_digests"
      ],
      "minimal_action": "只发布一份合格 Fs；所有 expert 显式加载相同身份；保存/独立重载/组装行为验收；profile 副本。"
    },
    {
      "id": "PA-05",
      "priority": "P1",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "旧训练入口未闭合整体 admission、完整目标证书、绝对时间和 norm 身份。",
      "evidence": [
        "earthdelta/static_adapter.py:1817-1952 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "earthdelta/data/make_splits.py:911-1035 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1"
      ],
      "minimal_action": "在实际 loader 拒绝外层 FAIL、缺证书、换 time/norm/grid；证书覆盖实际六个原计划 history/input/target 时次。"
    },
    {
      "id": "PA-06",
      "priority": "P1",
      "evidence_status": "STATIC_CONFIRMED",
      "finding": "B05/B06/B15 不能笼统 CLOSED：旧 diagnostic/head/formal-registry 仍有残留。",
      "evidence": [
        "earthdelta/metrics_contract.py:148-219 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "earthdelta/heads.py:351-359 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "earthdelta/registry.py:609-655 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1"
      ],
      "minimal_action": "修实际消费 native/registry 边界；旧 head 若不使用，明确禁止进入本轮，不为它重写整个方法。"
    },
    {
      "id": "PA-07",
      "priority": "P1",
      "evidence_status": "MISSING",
      "finding": "没有共同 Fs Stage4 完整 cache、OOF 冻结动作和开发决策表；shared-F0 代码不能充抵。",
      "evidence": [
        "source_plan/NEXT_STEPS_10H_PLAN.md:227-274",
        "scripts/r4_value_pilot.py:278-345,475-493 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "reference_reports/SPRINT_8H_DECISION.json:20-25"
      ],
      "minimal_action": "S0→Fs quality→bank/assembly gates 全过后，才按原计划生成 DEV evidence；不启动 final confirm。"
    },
    {
      "id": "PA-08",
      "priority": "P1",
      "evidence_status": "MISSING",
      "finding": "最新完整 GPU 和 CPU 源码绑定证据缺失；报告摘要不足以独立复算 current-head parity/全部测试。",
      "evidence": [
        "reference_reports/SPRINT_8H_RESULTS.md:25-28",
        "CURRENT_STATUS.md:7-17",
        "codex_audit_round4/evidence/targeted_tests.log; additional_tests.log 属历史 snapshot"
      ],
      "minimal_action": "补原始 logs/JUnit/job_result/source manifest/tensors；记录缺失为 MISSING，不以旧记录认证新实现。"
    },
    {
      "id": "PA-09",
      "priority": "P0",
      "evidence_status": "PLAUSIBLE_UNVERIFIED",
      "finding": "input inverse 先 float32 与 NPY/NPZ 工厂语义不一可能造成多步误差累积，但尚无根因闭合。",
      "evidence": [
        "earthdelta/bridge/stormer_bridge.py:250-402 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "scripts/s0_gate.py:238-281 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1",
        "scripts/r4_s0_parity_diagnose.py:110-142 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1"
      ],
      "minimal_action": "共同状态逐步 OO/OB/BO/BB；修 interval/10 探针，分别替换 input/diff inverse，保留旧失败参照。"
    }
  ],
  "required_next_actions": [
    "FUP-01: 补原始证据并修复/重验 S0；唯一初始解锁任务。",
    "FUP-02: 修真实入口 STOP/native Q/admission/registry 证据消费。",
    "FUP-03: 训练侧选择并独立发布唯一合格 Fs；失败阻止专家训练。",
    "FUP-04: 相同 Fs 上专家训练、qualification、保存/重载及组装行为验收。",
    "FUP-05: debug8 后冻结 DEV32/64/128，全候选 cache。",
    "FUP-06: train-fold static/regime/ridge、动作冻结与 purged 开发评分；无 final confirm。",
    "FUP-07: 分轴报告和独立验收；不自动延长研究范围。"
  ],
  "claims_that_must_not_be_made": [
    "官方 Stormer 多步 parity 已通过。",
    "B01–B15 或全部计划均已关闭。",
    "500 updates 或合并数值等价证明 Fs 合格。",
    "四个不同 Fs 上训练的专家构成共同 Fs 的 K=4 bank。",
    "新 shared-F0 pilot 完成了原 fitted-Fs 计划。",
    "已完成 candidate cache、policy fitting、holdout/confirm evaluation。",
    "CPU 测试数或已提交 GPU 作业证明天气预测有效或 novelty 成立。",
    "未执行的确认集/双头实验已经支持方法优势。"
  ]
}
```


## 1. 总体结论

**overall_verdict = PARTIALLY_EXECUTED。Stage 4 readiness = BLOCKED。**

这不是“什么都没做”：真实 S0 身份链/多步检查、native objective、数据入口校验和若干CPU修复已有实质进展；历史 H100/Fs job 也执行过。
但不是“原计划已完成”：没有一份已证明合格的共同 Fs、可恢复的同参考K4库，以及原计划的完整开发候选cache/cheap-policy表。

部分旧执行逻辑明确不符合计划：`scripts/r2_fs_bank_train.py:975-995` 在前驱失败后仍继续handler；`earthdelta/static_adapter.py:954-994` 没有对已观察的固定面板训练退化设quality拒绝。
最新 shared-F0 sprint 则在S0失败后停止，这一点与STOP要求一致。不能混淆两条路线或不同时间的执行。
原计划允许基础层以S0失败和阻塞证据交付（source_plan/NEXT_STEPS_10H_PLAN.md:11-19），故总体不是仅因没有下游就判全部 FAILED_PLAN_COMPLIANCE。

### 实际版本

branch观察HEAD `fdd92d79b1b03e8397d4c487d7fa4a347ae6fc37`（2026-09-23文档提交）；实现 `a3596e6b804e9d23b72d1247b08c47129d6b50b1`；基线 `d749a1c62521226df857587e08f7d067b0f15355`。
Git tree确认生产源码与测试未比实现提交更新。未发现使S0事实改变的新运行artifact。

## 2. 完整阅读与取证范围

完整读取五份source_plan、CURRENT_STATUS、EVIDENCE_MANIFEST、三份reference_reports和OUTPUT_SCHEMA；新取GitHub commit/tree/compare元数据与关键生产函数、原始历史测试logs及GPU重算归档。
本次没有运行仓库测试/GPU，未下载多GB权重/天气数据。未把超大compare响应称为完整逐行diff审计。
最新 S0 原始tensor/joblogs不在附件；附带报告是可观察的摘要，不是足以独立复算的完整执行证据。

## 3. 四层对照

逐项表及精确file:line见 CURRENT_GAP_ANALYSIS.md；JSON的code/test/execution/goal字段保存同一分层。

| 领域 | 代码与测试 | 真正执行 | 目标状态 |
|---|---|---|---|
| B05/B06 | 新native Q/scale/FP64 reducer接入；旧诊断分母/head校准残留；历史相关tests存在 | 原Fs使用native计分；不是head实验 | 部分达成 |
| B08/B09 | preflight实际调用artifact/slice/content；UTC/端点/placeholder校验有效；旧消费证书链不完整 | 旧8rows仅2cert/horizon6vs24由归档指出；新616为另一条F0摘要 | 部分达成 |
| B12 | controlled-vs-controlled共享模型guard有效；ordinaryforward未全覆盖 | 串行路径观察，无通用并发验收 | 本轮串行约束可用，不扩scope |
| B13/B14 | provisional verdict撤销、classifiedcleanup、format_finite已实现；历史针对性CPU通过 | 不代表S0数值通过 | 对应子合同达成 |
| B15 | 非空/唯一/noedit/实系数registry有效 | 旧registry没有动态权重完整身份 | 部分达成 |
| S0 | expected/ref/actual、raw→norm与全部registeredrollout检查已接线 | pt-7ant09uv摘要1stepPASS、4/12FAIL；rawMISSING | BLOCKED |
| Stage3b | staticadapter/Fsfit/K4r4可运行代码与历史job | formal多worker退化、4不同Fs、旧dynamicweights缺失 | 共同合格Fs/bank未成立 |
| Stage4 | 新F0cache/merge实现；原Fs无完整已运行cache/policy流水 | cache/policy/eval无结果，最新摘要NOT_STARTED | NOT_ESTABLISHED |
| 最终confirm/dualhead/E3 | 原计划明确暂缓，不是窗口硬性交付 | 无证据 | 无科学结论；未执行本身不违约 |

## 4. 专项判决

### S0 parity

`SPRINT_8H_DECISION.json:9-17` 报告job `pt-7ant09uv`：

| steps | max abs diff | 1e-5 |
|---|---:|---|
| 1 | 5.9604644775390625e-06 | PASS |
| 4 | 3.933906555175781e-05 | FAIL |
| 12 | 1.3911724090576172e-04 | FAIL |

它与当前程序的多步检查相容，但原始S0 JSON、job_result和tensors没有提供，独立重新认证仍 INCONCLUSIVE。
按现有FAIL摘要必须保持BLOCKED；没有新artifact可证明事实改变。

可检验而非已证明根因：input inverse在FP32截断后构造；from_npz保留diff源常量但正式NPY gate工厂未接入；diagnose后处理探针interval未/10、未沿每步追踪。最小行动是OO/OB/BO/BB共同状态/自由轨迹与分别替换input/diffinverse，保持原容差，不凭猜测报修复成功。

### Fs-fit divergence

`reference_reports/ROUND4_REPORT.md:24-35`：pt-3x63g0c6的expert1/3为0/8改善，Fs/F0比4.644734/1.219248；pt-cdj1s2le的expert2/3为0/8，4.066871/1.070957。不是所有workers退化，亦不是无限发散。first/lastvisit指标和共同checkpoint复评不同，归档另以冻结后同panelloss支持退化。
当前eligibility仍只看finite/非零更新，因此MUST_FIX_BEFORE_STAGE4，不能用合并等价或平台SUCCEEDED证明质量。四个Fs摘要不同的问题也未被删掉两个坏worker解决。

### Stage4、novelty、weather utility

Stage4 BLOCKED_BY_S0_FS_QUALITY_COMMON_BANK_ADMISSION。
Novelty/weather utility INCONCLUSIVE_NOT_ESTABLISHED。本轮不重新发明文献结论；没有合法策略真实效果表，更没有确认或双头优势证明。
新F0 .1875强度插值或联合目标评估属于另一份规格，不计原10h计划完成；确认集和双头原本不属于此窗口要求。

## 5. 最小后续行动与优先级

1. FUP-01：补rawGPU证据、实际source/资产绑定，定位并修复S0，原1e-5/1,4,12重验。
2. FUP-02：真实runnerfailclosed、native计分、完整原计划slice/role/registry消费。
3. FUP-03：同一固定panel选择唯一合格Fs，质量门不允许退化产物发布。
4. FUP-04：同一Fs上专家、dynamic权重、独立reload、assembly行为与非mutatingprofile。
5. FUP-05：debug8后预冻DEV32/64/128完整候选cache。
6. FUP-06：trainfoldstatic/regime/ridge与oracle，actions先freeze再score；统计不足INCONCLUSIVE。
7. FUP-07：只读验收和handoff，不自动开启confirm/dualhead。

所有未来执行 TO_BE_RUN，只有FUP-01初始解锁。缺件/预算/S0失败时停止；Fs质量未过不得训练expert或cache。

## 6. 不能对外宣称

不能宣称计划完整执行、S0多步通过、所有Bfinding关闭、500updates使Fs合格、不同Fs专家是commonbank、Stage4或confirm已完成、工程工作量证明novelty或weatherutility。
可以宣称：部分工程实现和历史测试/运行已完成；当前数值和资格门真实阻塞；下游科学目标尚未建立。

## 7. 附件与缺失输入

本ZIP的FOLLOWUP_PLAN、CODEX_TASKS、DAG等构成可执行合同，但不包含私有source checkout、大checkpoint或rawGPU。
详细必须补充材料见 evidence/REQUIRED_INPUTS.md。文件清单与每文件SHA见 PACKAGE_MANIFEST.json；ZIP的SHA由外部.sha256给出，避免自引用hash。
