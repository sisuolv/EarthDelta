# Codex 从这里开始

任务是续做 **plans_v3_0922 的共同 fitted-Fs 开发计划**，不是重做 novelty review，也不是默认采用后来 shared-F0 sprint。

## 读取顺序
1. `CURRENT_GAP_ANALYSIS.md` 与 `evidence/PLAN_AUDIT_RESULT.json`。
2. `evidence/source_plan/NEXT_STEPS_10H_PLAN.md`、`CLAUDE_10H_PROMPT.md`，并参考三个 Stage1A review。
3. `STOP_CONDITIONS.md`、`ARTIFACT_CONTRACT.md`、`evidence/REQUIRED_INPUTS.md`。
4. `FOLLOWUP_PLAN.md`、`EXECUTION_DAG.md`、`CODEX_TASKS.json`、`TEST_PLAN.md`、`REPRODUCIBILITY.md`。

## 当前实际起点
- branch `audit/round2-review-20260921` 当前观察 HEAD `fdd92d79b1b03e8397d4c487d7fa4a347ae6fc37`；数值源码与 `a3596e6b804e9d23b72d1247b08c47129d6b50b1` 相同；比较基线 `d749a1c62521226df857587e08f7d067b0f15355`。
- S0 摘要：1 step PASS，4/12 FAIL，冻结最大绝对差容差 `1e-5`；raw GPU evidence 尚未交付本审查。
- 原 fitted-Fs 质量、共同参考专家库和 Stage4 开发表未实现；不得用 shared-F0 的代码或616样本准入宣称这些原目标完成。

## 现在只允许
**FUP-01 的源码/CPU诊断修复与证据整理。** 所有其它 task `unlocked=false`。
真实 GPU S0 需要现有资产、冻结 config 和本次资源授权；缺任何一项记 BLOCKED。不得提交专家/Fs训练或cache。
FUP-01 即使通过，也先写 decision/真实日志并停止，等待独立验收和明确解锁，不自改任务锁。

## 必须停止
原容差/注册horizon未过、身份不一致、缺原始证据、用户工作树发生未知变化，或达到批准资源cap。
不 reset/clean/rebase 用户工作树，不覆盖历史 artifacts，不把准备好的 argv 当作完成。不上传密钥。
所有未来结果 `TO_BE_RUN`，已见原始/摘要 evidence 明确区分为 `OBSERVED`，缺失 `MISSING`。
