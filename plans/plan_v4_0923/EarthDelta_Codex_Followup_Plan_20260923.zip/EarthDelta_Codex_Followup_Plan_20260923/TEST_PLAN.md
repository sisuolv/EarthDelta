# 分层测试计划

## 层 0：交付包本身

`python tools/validate_package.py` 检查schema形状、引用文件、DAG、任务锁、未来状态和必需文件。
它只检验此计划包，不运行EarthDelta或GPU。其PASS不能升级成项目测试PASS。

## 层 1：静态源码与 CPU 单元/真实编排

保留已有测试，不削弱断言。优先使用同一合法fixture，单独改一个字段形成负例。

| 领域 | 必测反例 | 证明边界 |
|---|---|---|
| Normalizer | 原始float64先inverse vs截断FP32；两工厂相同执行语义；只改policy仍改变identity | CPU算术/工厂性质，不是StormerGPUparity |
| S0 | 错/缺identity、错原始/归一化输入、四步有限但数值错、空horizon、多目录歧义、晚期异常 | 调实际run_s0_gate/main，不能mock全部checks然后只测dict |
| Runner | fs_fitFalse/fs_freeze异常/expired证书后所有后继handler零次调用 | 有效执行门，不是最终rc=1而继续训练 |
| NativeQ | 非均匀lead/area/variable+scale；端点恒等式；每个有效目标正分母 | 不用按F诊断均值冒充native全目标 |
| Admission | 外层FAIL行True、缺一个所需端点hash、时间轴偏移、错norm/坐标、角色跨support | 实际loader拒绝，不是只提供未用helper |
| Fs quality | finite且merge一致但全paired退化；wrongpanel；dev参与选择 | 训练质量拒绝发布，不是finite即合格 |
| Bank | 不同Fs、错slot/scale、缺dynamic权重、profilemutation、坏reload/assembly | 可消费commonreferencebank的数值边界 |
| DEV | labelpoison评分fold不能改变已冻actions、trainfoldstatic和ridge、缺candidate不报fulloracle | 合法信息边界，不是科学收益保证 |

指定测试命令见FOLLOWUP_PLAN。新增tests先实现再运行；依赖缺失记录BLOCKED；不静默跳过关键测试并总体声称通过。

## 层 2：真实 GPU gate

只有当前资源授权与原始资产齐备时运行。固定ps4、FP32、official policy、注册1/4/12、原容差1e-5。
官方exporter用真xformers和官方iterative module，不能用SDPA替代冒称official。
通过原始job_result、stdout/stderr、source/config/checkpoint身份和每horizon输出验证；CPU小网络不替代此门。
first1stepPASS不放行12step science。环境forward/backward PASS不等于bridgeparity。

## 层 3：真实训练/qualification/原生输出

FUP03单一Fs质量门通过后才FUP04experts；Fs合并等价和质量独立，bank恢复和assembly行为单独验证。
缓存必须实际计算全部注册候选，不把保存argv/已提交job/预分配空数组当实际结果。
一个SUCCESS平台job可内含科学/资格FAIL；必须检查各级判决和rawmetrics。

## 层 4：科学结果与结论

本窗口只能DEV线索，不finalconfirm。paired分析以完整过程block；每方法同抽样；失败和成本分母相同。
完整oracle只是hindsight空间。合法static/regime/ridge的OOF真实收益与其差别才支持是否继续。
统计功效不足为INCONCLUSIVE。当前没有任何结果证明dualhead、responsefactorization或weatherutility。

## 既有记录不可混合

Round4 307+127已执行日志与686collection分开；当前66/3摘要缺原始log，不推成独立复验。
本次计划包生成不执行上述项目测试。新任务必须记录其实际git/dirty-source对应关系，不能继承旧测试数当新的验收成绩。
