# 当前计划执行缺口审查

审查日期：2026-09-23。`overall_verdict = PARTIALLY_EXECUTED`。

## 版本、资料和阅读边界

原计划：`plans/plans_v3_0922`；实现提交 `a3596e6b804e9d23b72d1247b08c47129d6b50b1`；比较基线 `d749a1c62521226df857587e08f7d067b0f15355`。
本次重新读取 branch 得到实际 HEAD `fdd92d79b1b03e8397d4c487d7fa4a347ae6fc37`，其父提交为实现提交，仅新增本次审查文档。
两次 Git tree 比较确认 `earthdelta=8d344f4538f23f2fe3a0e7f518a26b0b0e09c07f`、
`scripts=76fd3459feeb381f1f6b9792ca5fee72de68b38e`、
`tests=67f02384badda00a8139516c04e24044c7b4c353`、
`reference=f127c7c902a02525645bffd09a1acff0dc4b51a4` 相同。
实现审查定位到 a3596e6，不能把 fdd92d79 文档提交当修复提交。

完整读取输入 ZIP 中 source_plan 五文件、CURRENT_STATUS、EVIDENCE_MANIFEST 和 reference_reports 三文件。
通过 GitHub connector 读取固定提交的实际函数、历史测试日志和 GPU 重算归档，读取 compare 元数据及部分变更；没有声称逐行读取全部超大 compare diff。
本次未执行仓库 pytest、未重新训练、未运行 GPU。最新 raw GPU tensors/job logs 没有上传；只有 tracked summary。
附带 16 文件审查包本身没有源代码 checkout、checkpoint 或真正的 raw GPU evidence。

引用约定：`source_plan/` 与 `reference_reports/` 表示原始上传审查包中的路径；本包逐字镜像位于 `evidence/source_plan/` 与 `evidence/reference_reports/`。`earthdelta/`、`scripts/`、`tests/` 和 `codex_audit_round4/` 表示受审 Git checkout 的相对路径，不表示这些源码/raw artifacts 已包含在本 ZIP。

## 总体判决的范围

原计划 `NEXT_STEPS_10H_PLAN.md:11-19` 允许基础层以真实 S0 失败/外部阻塞 evidence 交付，不承诺通过；因此不能仅因 downstream 停止就判全部违约。
但旧 `--stage all` 绕过前驱失败、Fs 退化仍 eligible，是已确认的局部 `FAILED_PLAN_COMPLIANCE`，见 PA-02/PA-03。
总体取 PARTIALLY_EXECUTED：有效补丁/历史测试/运行存在，原计划正常层的共同 Fs bank 与 DEV 表未达成，Stage4 被阻塞。

最新 F0 sprint 是不同路线。原计划 `:230-239` 明确 no-edit 与 hold 后 continuation 均为 Fs，不可偷偷变成 F0。
未跑最终 confirm 不单独算违反原计划：`:235-237,288` 本来就禁止本窗口读 confirm、暂缓 dual-head/E3。

## 四层对照

L1=代码实现；L2=已读测试执行记录；L3=真实 GPU 记录；L4=实验支持的目标。
OBSERVED 不自动表示四层均过；记录摘要与原始执行 evidence 分开。

| 计划项 | L1 代码 | L2 CPU | L3 GPU | L4 目标/缺口 |
|---|---|---|---|---|
| B05 | PARTIAL；`earthdelta/metrics_contract.py:148`；`earthdelta/metrics_contract.py:215` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | MISSING / 未取到针对该性质的 GPU 运行验收 | PARTIALLY_ACHIEVED；weighted_mse 与新 native reducer 已校验；旧 quadratic_gain 仍只查全局权重和，逐 F 零切片可能产生 NaN。 |
| B06 | PARTIAL；`earthdelta/metrics_contract.py:557`；`earthdelta/metrics_contract.py:652`；`earthdelta/heads.py:356` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | OBSERVED: 历史 Fs 路径使用 native objective；不等于预测 head 合同已统一。 | PARTIALLY_ACHIEVED；新 full-objective 已实现并接线；旧 head 仍向唯一 gain 添加可训练 calibration。未使用旧 head 不应阻塞固定系数库。 |
| B08 | PARTIAL；`earthdelta/pilot_contract.py:1517`；`earthdelta/pilot_contract.py:1538`；`earthdelta/static_adapter.py:1925` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | OBSERVED: Round4 artifact_crosschecks.json 记录旧准入 8 行、2 份抽样内容证书；原始准入记录本包 MISSING。 | PARTIALLY_ACHIEVED；preflight 不是死代码；旧训练消费仍不强制总体 PASS 和全部所需内容证书。新 F0 admission 不自动修复旧 Fs 消费者。 |
| B09 | PARTIAL；`earthdelta/data/make_splits.py:911`；`earthdelta/data/make_splits.py:949`；`earthdelta/static_adapter.py:1817` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | MISSING / 未取到针对该性质的 GPU 运行验收 | PARTIALLY_ACHIEVED；实际时间端点与 placeholder 拒绝有效；消费端未闭合 absolute-time/norm/content。原计划需要 t-12/t-6/t，不能以新 F0 的 t-6/t 替代。 |
| B12 | PARTIAL；`earthdelta/bridge/stormer_bridge.py:996`；`earthdelta/bridge/stormer_bridge.py:1123` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | MISSING: 当前 GPU 共享模型并发安全验收；原计划并未要求支持该模式。 | PARTIALLY_ACHIEVED；controlled-vs-controlled model-id guard 已接线；普通 forward 不受同一 guard 保护。保持串行独立进程即可，不扩建并发框架。 |
| B13 | COMPLETE；`scripts/s0_gate.py:1957`；`scripts/s0_gate.py:2411`；`scripts/s0_gate.py:2419` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。；OBSERVED: Round4 记录实际 orchestration 的 provisional-PASS 异常反例已拒绝。 | MISSING / 未取到针对该性质的 GPU 运行验收 | ACHIEVED；仅关闭该状态/发布子合同；不等于官方数值 parity、旧训练 runner 或科学准入已通过。 |
| B14 | COMPLETE；`scripts/s0_gate.py:2455` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | MISSING / 未取到针对该性质的 GPU 运行验收 | ACHIEVED；format_finite 和报告降级已实现；当前 HEAD 全套测试运行证明仍需另取。 |
| B15 | PARTIAL；`earthdelta/registry.py:609`；`scripts/r2_fs_bank_train.py:492` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | OBSERVED: 历史 registry JSON 存在，不代表具备可重载动态权重身份。 | PARTIALLY_ACHIEVED；系数表校验存在并调用；旧正式 registry 尚未绑定共同 Fs、动态权重、Q/norm。 |
| S0 | BLOCKED；`scripts/s0_gate.py:2038`；`earthdelta/bridge/stormer_bridge.py:250`；`scripts/s0_gate.py:238` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。；OBSERVED: tests/test_s0_gate_end_to_end.py:500-680 定义真实 CLI 的身份/四步负例；定义不作本次执行。 | OBSERVED: SPRINT_8H_DECISION.json:9-17，pt-7ant09uv，1/4/12 步差 5.9604644775390625e-6 / 3.933906555175781e-5 / 1.3911724090576172e-4，容差 1e-5。；MISSING: 该 job 原始 s0_gate_result.json、job_result.json、逐步诊断与 tensors。 | PARTIALLY_ACHIEVED；已实现完整身份/多步检查；现有机读摘要为 FAIL，不能认证通过。input inverse 精度及 NPY/NPZ 工厂不一致是待验证根因，不是已解决结果。 |
| FS-FIT | PARTIAL；`earthdelta/static_adapter.py:954`；`earthdelta/static_adapter.py:990`；`scripts/r2_fs_bank_train.py:304` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | OBSERVED: Round4 GPU 重算归档中 pt-cdj1s2le expert2/3 为 0/8 改善；冻结 Fs/F0 比 4.066871 / 1.070957。；MISSING: 原始逐样本 run records/weights 本次未提供；未独立复算全部数列。 | NOT_ESTABLISHED；当前 eligible 仍未纳入固定面板质量；8/8 退化 finding 未关闭。有限退化不等于数学无限发散。 |
| COMMON-FS-BANK | PARTIAL；`scripts/r2_fs_bank_train.py:369`；`scripts/r2_fs_bank_train.py:475`；`scripts/r2_fs_bank_train.py:564`；`scripts/r4_value_pilot.py:278` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | OBSERVED: Round4 归档中三个历史 job 各有 4 个不同 Fs digest，旧动态 bank 缺保存权重。；OBSERVED: 新 shared-F0 保存/qualification/assembly 代码存在，但 sprint decision 明示未执行。 | NOT_ESTABLISHED；旧多 worker 不构成共同参考库；新 F0 路线是不同研究规格，不能计作原计划 Fs 目标完成。 |
| STOP-ADMISSION | PARTIAL；`scripts/r2_fs_bank_train.py:975`；`scripts/r2_fs_bank_train.py:995`；`scripts/r4_value_pilot.py:475` | OBSERVED: Round4 targeted_tests.log 307 passed + additional_tests.log 127 passed；属于当时 working-tree snapshot，不是当前 HEAD 全量复跑。 | OBSERVED: 最新 sprint decision 记录 S0 失败后 downstream NOT_STARTED。；OBSERVED: Round4 归档记录旧 fs_freeze=False 后 bank_train 仍执行。 | PARTIALLY_ACHIEVED；最新 sprint 的停止行为应保留；旧 --stage all 仍违反硬门合同。source/hash 记录不能替代消费端强制校验。 |
| STAGE4-CACHE | PARTIAL；`scripts/r4_value_pilot.py:328`；`scripts/r2_fs_bank_train.py:963` | OBSERVED: test_value_pilot.py 定义覆盖完整性检查；本次未复跑。 | OBSERVED: 最新 sprint decision cache=NOT_STARTED。；MISSING: 完整共同 Fs candidate cache manifest/outcomes。 | NOT_ESTABLISHED；新 F0 cache/merge 有实现，但未执行且不满足原计划参考合同；不能把 argv/manifest 准备算成运行。 |
| STAGE4-POLICY | NOT_STARTED；`scripts/r4_value_pilot.py:475` | MISSING / 未取到对应执行日志 | MISSING: 拟合记录、冻结动作、开发决策表与 process-level 统计。 | NOT_ESTABLISHED；当前新 CLI 仅到 merge-cache，缺 head/freeze/evaluation；旧 head 定义不等于完整开发流程执行。 |
| FINAL-CONFIRM | NOT_APPLICABLE；无本轮必需实现/证据缺失 | MISSING / 未取到对应执行日志 | MISSING: 最终确认和双头优势实验证据。 | NOT_ESTABLISHED；原计划 :235-237/:288 主动暂缓这些内容；未执行不是本窗口违约，但也不能作相应科学声明。 |
| SCIENTIFIC-CLAIMS | BLOCKED；无本轮必需实现/证据缺失 | MISSING / 未取到对应执行日志 | MISSING: 合法策略对强静态的真实开发效用、后续公平双头对照与确认结果。 | NOT_ESTABLISHED；没有可复核的新科学效果；结论为 INCONCLUSIVE，而非方法无价值或 novelty 已成立。 |

## 按优先级排列的 finding

### PA-01 · P0 · STATIC_CONFIRMED

正式 S0 仍须保持 BLOCKED；未出现新 PASS 证据。

证据：`reference_reports/SPRINT_8H_DECISION.json:9-17; job pt-7ant09uv`；`scripts/s0_gate.py:2038-2449 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`。

最小处置：取得原始 S0 evidence；定位并修复实际工厂和逆变换后，按冻结 1e-5 / 1,4,12 步重验。

### PA-02 · P0 · STATIC_CONFIRMED

旧阶段 runner 在子阶段 False/异常后继续调用所有依赖 handler。

证据：`scripts/r2_fs_bank_train.py:963-995 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`codex_audit_round4/ROUND4_REPORT.md:116-120`。

最小处置：单一前驱证书验证器，FAIL/BLOCKED 立即阻断后继；测试真实 main/handler 调用次数。

### PA-03 · P0 · STATIC_CONFIRMED

Fs 资格仍只看 finite/非零更新，未对已观察到的固定面板全面退化拒绝发布。

证据：`earthdelta/static_adapter.py:954-994 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`reference_reports/ROUND4_REPORT.md:24-35; pt-cdj1s2le expert2/3`。

最小处置：同一初始/候选末态的训练侧固定面板质量门；最多批准范围内重试；不合格就不冻结可消费 Fs。

### PA-09 · P0 · PLAUSIBLE_UNVERIFIED

input inverse 先 float32 与 NPY/NPZ 工厂语义不一可能造成多步误差累积，但尚无根因闭合。

证据：`earthdelta/bridge/stormer_bridge.py:250-402 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`scripts/s0_gate.py:238-281 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`scripts/r4_s0_parity_diagnose.py:110-142 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`。

最小处置：共同状态逐步 OO/OB/BO/BB；修 interval/10 探针，分别替换 input/diff inverse，保留旧失败参照。

### PA-04 · P1 · STATIC_CONFIRMED

旧 workers 各自 Fs、缺动态 checkpoint 且 profiling 改变已验收 bank，不能交付 common-Fs bank。

证据：`scripts/r2_fs_bank_train.py:304-440,541-620 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`codex_audit_round4/evidence/artifact_crosschecks.json:latest_formal_expert_files,distinct_fs_digests`。

最小处置：只发布一份合格 Fs；所有 expert 显式加载相同身份；保存/独立重载/组装行为验收；profile 副本。

### PA-05 · P1 · STATIC_CONFIRMED

旧训练入口未闭合整体 admission、完整目标证书、绝对时间和 norm 身份。

证据：`earthdelta/static_adapter.py:1817-1952 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`earthdelta/data/make_splits.py:911-1035 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`。

最小处置：在实际 loader 拒绝外层 FAIL、缺证书、换 time/norm/grid；证书覆盖实际六个原计划 history/input/target 时次。

### PA-06 · P1 · STATIC_CONFIRMED

B05/B06/B15 不能笼统 CLOSED：旧 diagnostic/head/formal-registry 仍有残留。

证据：`earthdelta/metrics_contract.py:148-219 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`earthdelta/heads.py:351-359 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`earthdelta/registry.py:609-655 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`。

最小处置：修实际消费 native/registry 边界；旧 head 若不使用，明确禁止进入本轮，不为它重写整个方法。

### PA-07 · P1 · MISSING

没有共同 Fs Stage4 完整 cache、OOF 冻结动作和开发决策表；shared-F0 代码不能充抵。

证据：`source_plan/NEXT_STEPS_10H_PLAN.md:227-274`；`scripts/r4_value_pilot.py:278-345,475-493 @ a3596e6b804e9d23b72d1247b08c47129d6b50b1`；`reference_reports/SPRINT_8H_DECISION.json:20-25`。

最小处置：S0→Fs quality→bank/assembly gates 全过后，才按原计划生成 DEV evidence；不启动 final confirm。

### PA-08 · P1 · MISSING

最新完整 GPU 和 CPU 源码绑定证据缺失；报告摘要不足以独立复算 current-head parity/全部测试。

证据：`reference_reports/SPRINT_8H_RESULTS.md:25-28`；`CURRENT_STATUS.md:7-17`；`codex_audit_round4/evidence/targeted_tests.log; additional_tests.log 属历史 snapshot`。

最小处置：补原始 logs/JUnit/job_result/source manifest/tensors；记录缺失为 MISSING，不以旧记录认证新实现。

## 特别裁定

- **S0：BLOCKED_MULTISTEP_PARITY。** `pt-7ant09uv` 的 tracked JSON 报告一步 5.9604644775390625e-6、四步 3.933906555175781e-5、十二步 1.3911724090576172e-4；1e-5 不改变。它是 OBSERVED 的结果摘要，不是本次独立 GPU 重算；原始日志/tensors 为 MISSING。
- **Fs：MUST_FIX_BEFORE_STAGE4。** `reference_reports/ROUND4_REPORT.md:24-35` 与当前有限性资格代码相互支持；pt-cdj1s2le expert2/3 的 0/8 改善、冻结 Fs/F0 4.066871/1.070957 没有新 artifact 推翻。first/last 为同样本首次/末次访问的优化前 loss，不冒称共同 checkpoint 精确复评；归档另有同八样本冻结面板结果。该退化不是无限发散、也不直接否定研究 idea。
- **Stage4：BLOCKED。** S0、Fs quality/common reference、动态权重交付、消费侧 admission 都须先成立。
- **Novelty/weather utility：INCONCLUSIVE_NOT_ESTABLISHED。** 本轮不是重新检索 novelty；缺的是合法策略实际结果。代码量、434 历史测试和环境执行均不能补上这一层。

## 测试与执行证据的精确口径

已亲读 `codex_audit_round4/evidence/targeted_tests.log`（307 passed）和 `additional_tests.log`（127 passed）。两者属于 Round4 捕获的 working tree；`audit_source_snapshot.json` 以 d749a1c 为基底并逐文件记录摘要，而不等于所有结果对应干净 d749 或当前整个 HEAD。
686 是 collection 数，不是运行通过数。CURRENT_STATUS 的 66 passed/3 skipped 只有摘要，原始该次日志/JUnit/source binding 未提供；不能升级为本次已复验。
历史 GPU job_result/重算归档证明曾进行旧 Fs job，不能认证最新正常 scientific pipeline；最新 616 admission、H100 和 S0 状态按 supplied/tracked summary OBSERVED 记录。没有后台任务、argv 文件或计划日程可替代真实运行证据。

## 不可对外宣称

不得宣称 S0 已通过、共同 Fs K=4 bank 已合格、Stage4 已运行、最终 confirm 已完成、双头/response 比 direct-gain 更好或 weather utility/novelty 获得证明。也不得将 shared-F0 成功的可能性改写为已经执行原 fitted-Fs 计划。
