# 可复现性合同

## 版本

预期branch：`audit/round2-review-20260921`。
已观察HEAD：`fdd92d79b1b03e8397d4c487d7fa4a347ae6fc37`；受审实现：`a3596e6b804e9d23b72d1247b08c47129d6b50b1`；比较基线：`d749a1c62521226df857587e08f7d067b0f15355`。
前两者earthdelta/scripts/tests/reference树相同，文档新增不是修复。执行前重新读取HEAD和dirty状态。
任何不同实现须输出diff/source manifest说明，不自动reset回旧HEAD，也不默认新代码已受审。
保留原计划 `plans_v3_0922` 与 later shared-F0 `novelty_review_20260922` 的不同身份与角色。

## 原始资料与源码

本包含五份原计划/复查和三份报告快照，没有完整私有源代码checkout、真实GPU日志或权重。
原始输入包文件SHA和远程source定位写入 evidence/EVIDENCE_MANIFEST.json。
程序引用必须使用被检查的commit与file:line；未来修改行号后报告新commit而不是继续假借旧行号。

## 环境

记录Python/Torch/torchvision/lightning/timm/xformers/CUDA/cuDNN/driver、设备型号、实际import路径、overlay/容器digest。
TF32、matmul precision、determinism、dtype、batch、随机seed、实际clock/timezone写config。
不擅自pip升级共享环境，不模拟Lightning/xformers；缺环境报告BLOCKED。
原dtype inverse公式、原NPZ assethash与derived constants应统一身份规范；数学等价不代表FP32位相等。

## 数据/目标/动作

原冻结split、真实UTCsupport、所有读取字段、坐标值、变量序、norm、Q/scale与采样顺序记录完整。
本次没有原始精确split名单，不能编造。新F0角色样本不是原Fs角色的自动替代。
只读bank_fit和已批准policy_dev，confirm禁用。S0/debug/profile exposure记录防止以后冒充未接触。
固定K/rank/blocks/coeff/hold，Fsnoedit/continuation不能改F0。若profile需K2须在dev效果前独立批准并新registry。

## 训练与模型

初始Fs/F0、每candidatecheckpoint、optimizer状态、固定面板、训练样本order与update次数可回放。
只训练一份Fs，workers重载相同权重。动态bank保存完整因子与身份，independentreload/assembly验证。
所有profile操作副本；以statehash证实。记录失败尝试成本，不从最终模型训练预算中隐藏。

## 运行/统计

所有命令/作业有UTC起止、exitcode、rawlog、jobid、资源上限与hash；排队时间与执行时间分列。
多process每GPU独立model，不并发共享带hook模型，不启用未支持replay。
按purged时间外折fitpreprocess/static/regime/ridge；动作先冻后score。统计block定义/seed/CI方法预注册。
bootstrap/MDE的统计阈值与研究价值delta_min独立。可复算loss→gain→selectedoutcome→aggregate。

## 历史保护

不覆盖任何旧FAIL、report、checkpoints或用户未跟踪文件。新run关联parentrun但身份独立。
公共仓库/聊天/zip不包含key、token、账号密码或不需要的个人环境秘密。只记录凭证环境变量名。
