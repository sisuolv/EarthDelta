请先读取本包 START_HERE_FOR_CODEX.md，再依指定顺序读取原计划、CURRENT_GAP_ANALYSIS、PLAN_AUDIT_RESULT、FOLLOWUP_PLAN、EXECUTION_DAG、STOP_CONDITIONS、CODEX_TASKS.json、ARTIFACT_CONTRACT、TEST_PLAN、REPRODUCIBILITY 和 REQUIRED_INPUTS。你的任务是续做 plans_v3_0922 的共同 fitted-Fs 开发计划，而不是重做文献评估、增加模块或把 shared-F0 结果冒充原计划完成。

先确认实际checkout HEAD、dirty worktree和worker source。当前只解锁 FUP-01 的S0源码/CPU取证修复；GPU诊断必须已有本轮明确资源授权、冻结config和真实资产。缺件逐项写MISSING/BLOCKED，不要猜路径、伪造结果或从摘要生成raw证书。保留原S0 1e-5与1/4/12-step，修两个normalizer工厂及逐步诊断后才真实复验；不直接放宽tolerance。

按DAG工作，每一步持续保存源码/配置/资产hash、原始stdout/stderr、exit code、平台job ID和实际metrics，区分OBSERVED/TO_BE_RUN/MISSING及代码、CPU、GPU、parity、DEV效应。FUP-01完成或BLOCKED后保存decision并停止等待独立验收，不自行解锁FUP-02。未来得到明确解锁时，S0、唯一Fs质量、commonbank qualification与assembly、完整cache必须依次通过才能做cheap-policy开发评估。旧Fs的8/8退化未解决时不得执行expert训练或Stage4；后继runner不能在前驱FAIL后继续。原计划不读finalconfirm、不默认训练dualhead/E3，不改reference或split制造收益，不覆盖历史FAIL/用户未提交文件，不泄露凭证。任何STOP条件触发即停止依赖阶段并输出可核查handoff。
