# 执行依赖和判决

```text
FUP-01 真实 S0（初始只开放 S0 源码/CPU取证；GPU另需授权）
  ├─ 身份/1,4,12-step FAIL 或资产缺失 → BLOCKED；所有训练/cache锁住
  └─ 原1e-5 PASS + 独立验收
       ↓ 明确解锁
FUP-02 生产入口STOP + nativeQ + 原计划数据/split/registry合同
  ├─ FAIL → FAIL_IMPLEMENTATION；source变化使S0失效则返回FUP-01
  └─ PASS
       ↓
FUP-03 唯一 Fs：训练侧质量资格 + 冻结 + 独立加载
  ├─ Fs-fit deterioration / 资格不足 → STOP_CURRENT_FS_SETUP / BLOCKED
  └─ 质量与数值等价两门各自PASS
       ↓
FUP-04 同一 Fs 上专家K4r4 → 独立qualification → 组装行为等价
  ├─ 不同Fs/缺权重/坏reload/不合格expert → BLOCKED_BANK
  └─ PASS
       ↓
FUP-05 debug8 → 预冻DEV32/64/128 → 完整候选cache
  ├─ 缺候选/错身份/失败丢分母 → BLOCKED_CACHE
  └─ PASS
       ↓
FUP-06 train-fold static/regime/ridge → freeze actions → DEV score
  ├─ Oracle低上界 → STOP_CURRENT_BANK
  ├─ 静态解释收益 → PIVOT_STATIC
  ├─ cheap合法增益 → CONTINUE_NEXT_ITERATION（仅建议，不自动授权）
  └─ CI跨阈值/有效过程少 → INCONCLUSIVE
       ↓
FUP-07 分层证据验收与只读handoff → 停止本轮
```

## 每个门究竟说明什么

| 门 | PASS 能说明 | FAIL 能说明 | CI跨阈值 |
|---|---|---|---|
| S0 | 该身份/精度/输入/注册horizon的桥接一致 | 当前实现未获官方等价资格，不是否定研究idea | 数值门无CI替代；不放宽冻结容差 |
| 数据/执行合同 | 该实际消费路径不绕过准入 | 实验有效性不足 | 不用统计CI豁免错身份/漏证书 |
| Fs quality | 当前所选唯一Fs符合训练侧事前质量门 | 当前Fs产物/训练设置不合格 | 如使用CI质量门，跨阈值即不足，不发合格证书 |
| Bank | 相同Fs、注册动作的资格和可恢复性成立 | 不能测该完整库 | 分清数值资格与小panel统计，不事后删专家 |
| Cache | 该registry×issue实际结果完整可查 | 不能称完整oracle | 覆盖率不是效应显著性 |
| Oracle | 存在hindsight空间，只能支持尝试合法学习 | 仅否定该库/目标/预算的足够空间 | INCONCLUSIVE，不宣称部署效果 |
| Legal DEV | 当前合法策略有开发线索或无收益证据 | 依具体预注册比较决定停止/pivot | INCONCLUSIVE；不等于confirm |

所有门还需要独立验收和本轮明确授权。不能把旧“阶段all最终返回1”当执行依赖控制。
若选择 shared-F0 替代路线，必须另签规格变更、重开任务图；不能在本图中跳过 Fs 并称原计划完成。
