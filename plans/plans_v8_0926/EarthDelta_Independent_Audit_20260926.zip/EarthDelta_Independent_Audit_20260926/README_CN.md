# EarthDelta 独立审核：标量重算与下一阶段计划

## 已读取的版本
- main HEAD：9a41f3f076b9f20966bce8c4174578db93bc8ae8。
- 科学证据固定：9e91191d506784e4e4d8935b736a96bdfb6dca00。
- GitHub compare/commit records 显示随后两次提交仅改 README.md 和 reviews/。本次没有本地私有 checkout，**没有执行 git log**，也没有执行 GPU 实验、原仓库测试套件或读取 ERA5 / checkpoints / endpoints。

## 取证限制——请先阅读
连接器不能返回 1,699,389 字节的 canonical candidate_results.json；本次独立数值计算使用同提交 candidate_results.parquet 的完整 1,680 行所需列，配合从 background_f0.json 和 oof_predictions.json 完整提取的 F0 损失与动作。Parquet 列由独立 Thrift / Snappy 读取代码解码，没有调用 EarthDelta 或 Claude 的评分函数。原始列窗口记录另附 capture/。

这证明“已读取标量副本的独立复算”，**不等于已经完成 canonical JSON 全文件哈希验证、JSON 与 Parquet 的逐项一致性验证、端点到标量重建或整个 GPU 流水线复现**。独立脚本在种子 0、10,000 次抽样下，与仓库 Claude scalar_recheck.txt 的十五组 F0 表格结果匹配到其输出精度；这仍不能替代上述缺失的逐项验证。

默认输入是精简派生文件，不是原始文件的字节级副本。副本只含数值计算所需列，没有独立取得原 JSON 每行状态字段。脚本对存在的非 PASS 字段拒绝计算，对缺省字段不声称已验证 PASS。

## 本次实际运行
```bash
python independent_scalar_audit.py --draws 100000 --seed 20260926 --out independent_bootstrap.json
python independent_scalar_audit.py --draws 10000 --seed 0 --out independent_bootstrap_seed0.json
python independent_scalar_audit.py --days 14 --out sensitivity_14days.json
python independent_scalar_audit.py --days 28 --out sensitivity_28days.json
```

唯一运行依赖：Python 3.10+ 与 NumPy。结果区间条件于既有 OOF 动作；没有在 bootstrap 中重新训练策略，不能解释成完整训练流程的不确定性。

## 在有权限的原仓库完成剩余 canonical 检查
```bash
git -C /path/to/EarthDelta log --oneline --name-status 9e91191..HEAD
git -C /path/to/EarthDelta diff --name-only 9e91191 HEAD
python independent_scalar_audit.py --repo /path/to/EarthDelta --draws 100000 --seed 20260926 --out canonical_recompute.json
```
`--repo` 模式读取三个原始 JSON，先核对 Git blob SHA。若矩阵缺 issue_time，使用同目录冻结 folds.json 的 issue_blocks 进行注册的 7 日块及 14/28 日并块。该 canonical 模式在本次环境中未执行，必须在原仓库验证。

数值表：gain = 100 × [ΣL(F0) − ΣL(method)] / ΣL(F0)，是**原训练目标的 MSE 损失改善百分比，不是标准变量 RMSE 改善百分比**。主表两个 oracle 均在 24h 选动作，6/72h 复用该动作。另附 per_lead_oracles_diagnostic.json 是逐时效重选的上包络，不能与主表混用。

## 数据访问边界
next_stage_plan.json 是建议，不代表执行授权。先冻结数据角色与访问规则，再修复/读取相应角色的数据。2022 拟为 confirm，但其未暴露身份仍须用已有访问记录核验；在最终方案冻结前不得读取 2022 数值，包括有限性扫描。不能根据技能挑年份，不能把旧 2020 重新称为未见测试集。

成本为规划上限，不是已测量的耗时。先在训练角色数据测量每步前向/反向时间；任何资源上限到达都不能通过增加审计轮或更换年份自动续期。
