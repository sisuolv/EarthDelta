import base64, struct, ctypes, ctypes.util, json
from pathlib import Path
from thrift.protocol.TCompactProtocol import TCompactProtocol
from thrift.transport.TTransport import TMemoryBuffer
from thrift.Thrift import TType
import numpy as np
ROOT=Path(__file__).parent

def rv(p,t):
    f={TType.BOOL:p.readBool,TType.BYTE:p.readByte,TType.I16:p.readI16,TType.I32:p.readI32,TType.I64:p.readI64,TType.DOUBLE:p.readDouble,TType.STRING:p.readBinary}
    if t in f: return f[t]()
    if t==TType.STRUCT: return rs(p)
    if t in [TType.LIST,TType.SET]:
        tt,n=p.readListBegin(); a=[rv(p,tt) for _ in range(n)]; p.readListEnd(); return a
    if t==TType.MAP:
        k,v,n=p.readMapBegin(); a={rv(p,k):rv(p,v) for _ in range(n)};p.readMapEnd();return a
    raise ValueError(t)
def rs(p):
    out={};p.readStructBegin()
    while True:
        _,t,i=p.readFieldBegin()
        if t==TType.STOP:break
        out[i]=rv(p,t);p.readFieldEnd()
    p.readStructEnd();return out

def get_meta():
    b=base64.b64decode((ROOT/'parquet_metadata_prefix.b64').read_text())
    # Byte offset 99900 from encoded lines; footer starts 99976.
    tr=TMemoryBuffer(b[76:]);p=TCompactProtocol(tr);p.readStructBegin();out={}
    for _ in range(4):
        _,t,i=p.readFieldBegin();out[i]=rv(p,t);p.readFieldEnd()
    return out
if __name__=='__main__':
    m=get_meta();print('metadata',m[1],m[3],len(m[2]),len(m[4]))
    for c in m[4][0][1]:
        cm=c[3];off=min(cm.get(11,cm[9]),cm[9]);print(cm[3], 'physical',cm[1], 'codec',cm[4], 'offset',off, 'length',cm[7], 'lines',off//45+1,(off+cm[7]+44)//45)

lib=ctypes.CDLL(ctypes.util.find_library('snappy'))
lib.snappy_uncompress.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t)]
lib.snappy_uncompress.restype=ctypes.c_int

def unsnappy(b,n):
    out=ctypes.create_string_buffer(n);sz=ctypes.c_size_t(n)
    assert lib.snappy_uncompress(b,len(b),out,ctypes.byref(sz))==0
    assert sz.value==n
    return out.raw

def varint(b,pos):
    v=0;s=0
    while True:
        x=b[pos];pos+=1;v|=(x&127)<<s
        if x<128:return v,pos
        s+=7

def hybrid(b,bw,n):
    vals=[];p=0
    while len(vals)<n:
        head,p=varint(b,p)
        if head&1:
            k=(head>>1)*8;nb=(k*bw+7)//8;x=int.from_bytes(b[p:p+nb],'little');p+=nb
            vals.extend([(x>>(i*bw))&((1<<bw)-1) for i in range(k)])
        else:
            k=head>>1;nb=(bw+7)//8;x=int.from_bytes(b[p:p+nb],'little');p+=nb;vals.extend([x]*k)
    return np.array(vals[:n])

def loaded_bytes():
    sparse=bytearray(110577);mask=bytearray(110577)
    for f in ROOT.glob('pq_*_*.b64'):
        start,end=map(int,f.stem.split('_')[1:]);raw=''.join(f.read_text().split());b=base64.b64decode(raw);off=(start-1)*45
        assert len(b)==(end-start+1)*45,(f,len(b))
        sparse[off:off+len(b)]=b;mask[off:off+len(b)]=b'\1'*len(b)
    return bytes(sparse),mask

def plain(b,typ,n):
    if typ in (2,5):return np.frombuffer(b,dtype={2:'<i8',5:'<f8'}[typ],count=n).copy()
    if typ==6:
        a=[];p=0
        for i in range(n):
            ln=struct.unpack_from('<I',b,p)[0];p+=4;a.append(b[p:p+ln].decode());p+=ln
        return np.array(a)
    raise ValueError(typ)

def column(name):
    m=get_meta();cm=next(c[3] for c in m[4][0][1] if c[3][3]==[name.encode()]);off=min(cm.get(11,cm[9]),cm[9]);nb=cm[7]
    allb,mask=loaded_bytes();assert all(mask[off:off+nb]),(name,off,nb)
    b=allb[off:off+nb];tr=TMemoryBuffer(b);vals=[];dic=None
    while sum(map(len,vals))<cm[5]:
        pos=tr.cstringio_buf.tell();hdr=rs(TCompactProtocol(tr));payload=tr.read(hdr[3]);raw=unsnappy(payload,hdr[2]);typ=hdr[1]
        if typ==2:
            dic=plain(raw,cm[1],hdr[7][1]);assert hdr[7][2]==0
        elif typ==0:
            dp=hdr[5];n=dp[1];assert dp[3]==3 and dp[4]==3
            nd=struct.unpack_from('<I',raw)[0];defs=hybrid(raw[4:4+nd],1,n);assert (defs==1).all()
            enc=raw[4+nd:];assert dp[2] in (8,2);idx=hybrid(enc[1:],enc[0],n);vals.append(dic[idx])
        else:raise ValueError(hdr)
    return np.concatenate(vals)
