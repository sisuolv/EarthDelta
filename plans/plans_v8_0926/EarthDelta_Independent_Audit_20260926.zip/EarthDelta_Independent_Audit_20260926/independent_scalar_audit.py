"""Independent F0 paired-block audit. No EarthDelta or prior-review imports.
Run with --repo /path/to/EarthDelta to use the three original JSON files.
Without --repo, use the connector-retrieved compact inputs accompanying this audit.
Reported bootstrap is conditional on already-fitted OOF actions, not a refit bootstrap.
"""
from pathlib import Path
import argparse, json, hashlib, datetime
import numpy as np

LEADS=(6,24,72)
CANDS=('reference','expert_0','expert_1','expert_2','expert_3')
ANCHOR=1562414400

def load_inputs(repo=None):
    root=Path(__file__).resolve().parent
    if repo:
        p=Path(repo)/'plans/plan_v4_0923/run_20260924T104725Z_fp05b'
        expected = {
            'cache/dev/candidate_results.json': 'c23c73d9819ffc3a9acb2dbcf231455d1cce8948',
            'cache/dev/background_f0.json': 'a625cfc03fc9e36fc83a7bba19b6eec46b6346b9',
            'policies/oof_predictions.json': '0384c5e09303890f17cb56088b53f44ae226c662',
        }
        for name, sha in expected.items():
            raw=(p/name).read_bytes()
            got=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
            if got!=sha: raise ValueError(f'Pinned git blob mismatch: {name}: {got}')
        rows=json.loads((p/'cache/dev/candidate_results.json').read_text())['rows']
        # Some scalar schemas omit exact issue times. The frozen fold map is
        # sufficient for the registered 7-day blocks and their 14/28-day unions.
        if any('issue_time' not in row for row in rows):
            fold_doc=json.loads((p/'policies/folds.json').read_text())
            if fold_doc['block_days'] != 7 or fold_doc['block_origin_utc'] != '2019-07-06T12Z':
                raise ValueError('Frozen fold origin differs')
            block_map=fold_doc['issue_blocks']
            rows=[dict(row, issue_time=ANCHOR+int(block_map[row['issue_id']])*604800) for row in rows]
        f0=json.loads((p/'cache/dev/background_f0.json').read_text())['issues']
        actions=json.loads((p/'policies/oof_predictions.json').read_text())['predictions']
    else:
        rows=json.loads((root/'candidate_selected_columns.json').read_text())['rows']
        f0=json.loads((root/'background_f0_extracted.json').read_text())['issues']
        actions=json.loads((root/'oof_actions_extracted.json').read_text())['predictions']
    return rows,f0,actions

def audit(rows,f0,actions,B=100000,seed=20260926,days=7):
    if B<10000 or days not in (7,14,28): raise ValueError('Use >=10000 draws and registered 7-day blocks or 14/28-day unions')
    bykey={}; times={}
    for r in rows:
        k=(r['issue_id'],int(r['lead_hours']),r['candidate_id'])
        if k in bykey: raise ValueError('Duplicate candidate key: '+str(k))
        if r.get('status','PASS')!='PASS': raise ValueError('Non-PASS row requires explicit fallback decision')
        bykey[k]=float(r['cpu_loss']); t=int(r['issue_time'])
        if r['issue_id'] in times and times[r['issue_id']]!=t: raise ValueError('Inconsistent issue time')
        times[r['issue_id']]=t
    ids=sorted(times,key=lambda i:(times[i],i));n=len(ids)
    if n!=112 or len(rows)!=1680 or set(ids)!=set(f0) or set(ids)!=set(actions):raise ValueError('Coverage mismatch')
    losses=np.array([[[float(f0[i]['f0_cpu'][str(h)])]+[bykey[i,h,c] for c in CANDS] for h in LEADS] for i in ids])
    if not np.isfinite(losses).all() or not (losses>0).all():raise ValueError('Invalid losses')
    acts={m:np.array([1+CANDS.index(actions[i][m]) for i in ids]) for m in ('M1','M3')}
    acts.update(Fs=np.ones(n,dtype=int),oracle5_at24=np.argmin(losses[:,1,1:],axis=1)+1,oracle6_at24=np.argmin(losses[:,1,:],axis=1))
    blocks=(np.array([times[i] for i in ids])-ANCHOR)//(86400*days)
    unique,which=np.unique(blocks,return_inverse=True); nb=len(unique)
    if days==7 and (nb!=23 or set(range(25))-set(unique)!={16,19}): raise ValueError('Unexpected weekly block coverage')
    rng=np.random.default_rng(seed)
    # Independent implementation: resample block indices, aggregate by block sums;
    # variable-sized clusters retain every original issue and the random denominator.
    draws=rng.integers(0,nb,size=(B,nb))
    def compare(base,alt,denominator=None):
        den=base if denominator is None else denominator
        numer=base-alt
        bn=np.bincount(which,weights=numer,minlength=nb)
        bd=np.bincount(which,weights=den,minlength=nb)
        boot=100*bn[draws].sum(axis=1)/bd[draws].sum(axis=1)
        ci=np.quantile(boot,[.025,.975])
        return {'gain_percent':float(100*numer.sum()/den.sum()),'ci95_percent':ci.tolist()}
    table=[]
    for l,h in enumerate(LEADS):
        base=losses[:,l,0]
        for m,action in acts.items():
            alt=losses[np.arange(n),l,action]
            table.append(dict(lead_hours=h,method=m,**compare(base,alt)))
    f=losses[:,1,1]; m1=losses[np.arange(n),1,acts['M1']];m3=losses[np.arange(n),1,acts['M3']]
    orc=losses[np.arange(n),1,acts['oracle5_at24']]
    extra={'oracle5_vs_M1_Fs_denominator':compare(m1,orc,f),
           'oracle5_vs_M1_F0_denominator':compare(m1,orc,losses[:,1,0]),
           'M3_vs_M1_Fs_denominator':compare(m1,m3,f),
           'oracle5_vs_Fs':compare(f,orc), 'M1_vs_Fs':compare(f,m1),'M3_vs_Fs':compare(f,m3),
           'oracle6_F0_count':int(np.sum(acts['oracle6_at24']==0)),
           'M3_action_counts':{CANDS[j-1]:int(np.sum(acts['M3']==j)) for j in np.unique(acts['M3'])},
           'any_edit_beats_F0_counts':{str(h):int(np.sum(losses[:,l,1:].min(1)<losses[:,l,0])) for l,h in enumerate(LEADS)},
           'F0_mean_loss':{str(h):float(losses[:,l,0].mean()) for l,h in enumerate(LEADS)}}
    return {'evidence_commit':'9e91191d506784e4e4d8935b736a96bdfb6dca00','B':B,'seed':seed,'n_issues':n,'block_days':days,'nonempty_blocks':nb,'anchor':'2019-07-06T12:00:00Z','block_counts':dict(zip(map(str,unique),np.bincount(which).tolist())), 'table':table,'extra':extra}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo');p.add_argument('--draws',type=int,default=100000);p.add_argument('--seed',type=int,default=20260926);p.add_argument('--days',type=int,default=7);p.add_argument('--out',default='independent_bootstrap.json');args=p.parse_args()
    result=audit(*load_inputs(args.repo),B=args.draws,seed=args.seed,days=args.days)
    Path(args.out).write_text(json.dumps(result,indent=2))
    for r in result['table']:
        print(f"{r['lead_hours']:2}h {r['method']:15} {r['gain_percent']:+.6f}% [{r['ci95_percent'][0]:+.6f}, {r['ci95_percent'][1]:+.6f}]")
    print(json.dumps(result['extra'],indent=2))
