# Reproducibility

Code/science base 9e91191d506784e4e4d8935b736a96bdfb6dca00; observed main 9a41f3f076b9f20966bce8c4174578db93bc8ae8; after-base history has two commits and only README/reviews changes. Remote API history used; no local git log/worktree inspection succeeded. Third-party Stormer pinned 58dfee5.

Independent scalar bootstrap: numpy float64, B=10000, seed=0, UTC origin 2019-07-06T12Z, 23 nonempty7-dayblocks, F0 sum denominator resampled jointly. Input projections have SHA256 in EVIDENCE_MANIFEST; they do not establish original whole-file byte identities.

Original canonical run files under plans/plan_v4_0923/run_20260924T104725Z_fp05b. Preserve paths/hash bindings; do not rewrite historical files to adapt absolute paths. Use explicit path-map as a new artifact when necessary.

The runtime used for independent CPU projection scoring was not the certified GPU overlay. NoGPU/fullrepo pytest this audit. --repo mode permits local canonical recheck; --projection reproduces only the supplied observed projection results.

Roles and support constraints are in CODEX_TASKS.json. 2019 is not clean confirm; 2020was trained on; 2021/2022 content currentlyUNVERIFIABLE. 2022 access is gated at T04, never used to choose years.

更精确角色：fit=2018全年+2020Q1–Q3；train-internal validation=2020Q4；DEV起报从2021-01-02T00Z至2021-12-26T18Z预选192个等距6h网格点，先冻结再取值；confirm=2022，仅T04独立许可后读取。以上均TO_BE_RUN，不伪称已经冻结。
