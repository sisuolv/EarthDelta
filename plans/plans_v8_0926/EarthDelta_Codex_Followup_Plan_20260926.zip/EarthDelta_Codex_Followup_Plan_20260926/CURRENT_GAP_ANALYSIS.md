# Current gaps

P0 research: old evaluation answers Fs-relative aggregate editing, not improvement of raw Stormer on standard variables; F0-relative6/72 harm recomputed. Frozen FP06 staysPIVOT_STATIC; new decision is no further old-bank scaling.

P0 data: pull_wb2.py 1000–1181 permits unconditional completion after zero-length loops; finalize returns verification_failed; main1360–1419 only prints; shell marksrc0success. is_year_complete423–448 shape counts only. Proxycause remainsUNVERIFIABLE.

P1 measurement: 69-channelstate-std objective differs fromupstreamdiffpressure training; loss contribution !=weight !=gradient. Per-variable script recon notidentity proof;reportCI usesonly1000of4000draws; upper29%notindependentlyrecomputed.

P1 inference: OOFbootstrapconditionalfixedpredictions;23blocks/B10000doesnotprovide10000independentsamples. Multiple targets/years skill-based selection forbidden.

P1 currentcode: strictbool/INVALIDrc andWBXmainvalidyears areFIXEDin9e91191. Remaining:optionalverified_bundle + uncheckedsource/input/CLIthreshold;singlechunkvalid_timesoptional;posthocpairedF0interval stillFsdenominator (nameiscomparisonnotdenominator).

P1 core: localteacher explicitlynotglobaloracle; e0/du separateconditionalmeans do not generally recover expectedgain undercompressedfeatures. Test directgain, responseanduncertainty baseline, don'tassumealgebraguaranteesutility.

P2 process: no additional audit-only round;oneboundedminimum-data/measurementclosure thenheadroom. Core realexecutionnotvisible;do notclaimneverrunoutsidegit.
