# EarthDelta — 2026-09-26 独立裁决执行入口

审核基准 `9e91191d506784e4e4d8935b736a96bdfb6dca00`；观察 main HEAD `9a41f3f076b9f20966bce8c4174578db93bc8ae8`。先读 FULL_REVIEW.md、evidence/PLAN_AUDIT_RESULT.json、CODEX_TASKS.json、FOLLOWUP_PLAN.md、STOP_CONDITIONS.md、ARTIFACT_CONTRACT.md、TEST_PLAN.md、REPRODUCIBILITY.md。

先运行本包独立scalar投影复算（工程复现）；在真实checkout再用 `--repo` 跑canonical JSON。这两个证据级别不可互换。不得把输入投影伪称为完整原件。

本包不是GPU启动授权。T01先冻结角色；T02–T04须逐门推进并取得资源/数据许可。原FP05b文件只读。原FP06按冻结规则仍为PIVOT_STATIC；新的研究处置是停止扩大旧K4，并不倒改旧协议结论。

最重要的工作不是补无限provenance，而是以F0与标准变量为锚，证明有限编辑族还有值得预测的状态依赖增量。旧目标损失百分比不是RMSE百分比。先测headroom，后训核心e0/du。

```bash
python "$PKG/tools/independent_recompute.py" --projection "$PKG/inputs" --out "$NEW_RUN/projection_replay"
python "$PKG/tools/independent_recompute.py" --repo "$REPO" --out "$NEW_RUN/canonical_replay"
```
