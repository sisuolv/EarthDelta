# Artifact contract

每个task_result记录id,status,commit,dirty_diff_hash,inputs_hashes,exact_argv,seed,elapsed,output_hashes,failure_reason。执行状态只用OBSERVED/TO_BE_RUN/MISSING/BLOCKED；未做的GPU和原件验证必须显式标缺。

四个独立结论字段必须存在：ENGINEERING_PASS、EXPERIMENT_EXECUTED、SCIENTIFIC_SUPPORT、NOVELTY_SUPPORT。不得从测试/rc/S0推出后两项。

数值结果必须标baseline、denominator、metric（native squared loss或物理RMSE/ACC）、oracle_action_selection_lead、reference/Fs身份、变量/坐标/normalization、支持窗、数据角色、条件于固定OOF还是重训不确定性。所有主oracle一个动作跨变量/时效；per-variable/per-lead oracle另标上界诊断。

环境记录image、overlay lock/hash、torch/xformers/CUDA、实际导入路径、有效TF32。旧合同Torch2.3.1+cu121/xformers0.0.27只是既有合同，不是本轮GPU认证；S0 1e-5不得放宽。

保留原FP05b路径readonly；新run目录写入，禁止覆盖旧CSV/JSON。完成后重算旧文件hash。

本包inputs是审查者传输投影，NOT完整canonical原件。正规本地重放必须读取Git canonical JSON并生成逐键对账报告。
