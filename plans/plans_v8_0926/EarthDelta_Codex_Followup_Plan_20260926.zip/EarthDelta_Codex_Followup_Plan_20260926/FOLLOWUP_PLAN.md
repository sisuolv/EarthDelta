# 后续四任务计划

所有阈值为建议资源决策标准，应在T01冻结；不是已证实行业最低收益。所有成本为预算估计。

## T01 — 一次性关闭会改变测量或导致越权的缺口；先冻结数据角色，再取必要数据。

状态：TO_BE_RUN；依赖：无。

输入：main@9e91191；原FP05b canonical标量文件；本包投影与独立重算；批准的数据角色合同；既有DEV端点（可用时）

方法：记录API与本地版本；运行独立canonical标量重算，与本包/Claude输出对账。最小修复零时间、失败退出码、内容完整性、FP06受信输入与阈值、WBX single-chunk。按冻结的fit/dev年份定点修复，保留原store与新版本映射，不修全部8年。实现六变量四时效统一MSE/RMSE入口；对已有端点只读复核。

数据访问：只读Git/已曝光2019结果；批准后可读取fit与2021 DEV，禁止2022。

成功：canonical标量重算一致；本地投影差异有解释；零时间/NaN/错通道/错valid-time/缺许可/错threshold负例全部阻断；需要的fit/dev支持窗口内容可靠。逐变量数组缺失仅阻断相应事实认证，不造结果。

失败：原数值无法解释、输入身份不一致、声明完成但内容不完整、角色未批准。

停止：数据角色签署前零confirm/holdout数据读取；2022在T04前零数组访问；两次相同传输失败后停止该数据分支并保留错误。测量修复timebox 1工作日，不再扩展为无限审计。

成本：{"gpu_hours": 0, "engineering_days": "0.5–1", "network_days": "0–3（未实测，依赖缺块规模与可达性）"}

命令/伪命令：
```text
git status --porcelain=v1; git log --oneline --name-status 9e91191..HEAD
python "$PKG/tools/independent_recompute.py" --repo "$REPO" --out "$NEW_RUN/scalar" --draws 10000 --seed 0
TO_IMPLEMENT: minimal data/metric/authorization negative tests, then python -m pytest <actual added test paths> -q
TO_IMPLEMENT: role manifest signed before any new fit/dev/confirm array read
```

产物：roles_frozen.json；canonical_recompute.json；data_manifest.json；metric_contract.json；minimal_tests.xml；old_hashes_before_after.json

## T02 — 区分坏静态参考、目标选择和训练规模；建立真正值得比较的部署基线。

状态：TO_BE_RUN；依赖：T01。

输入：通过T01的fit/dev数据；F0资产；两种事前冻结的训练损失；测量合同

方法：在相同训练起报与预算下比较：F0、一个合理训练的静态LoRA、滞后误差EWMA/简单输出校准。有限对照旧69通道状态标准化损失和预先冻结六变量多时效权重；不得把差分std简单套到终点状态误差上称为官方loss。训练先用固定训练内验证选择checkpoint；2021只作公开DEV。学习率/样本数/更新数上限事前固定，不按单次正面结果加跑。所有基线使用同一合法信息。

数据访问：fit=2018+2020，train-internal validation；dev=2021；2019仅历史诊断；confirm封存。

成功：训练/重载稳定；静态模型只有通过F0-relative标准变量安全门才可成为Fs*，否则保留F0作为后续参考。确认差异来自目标或训练的主张需匹配实验，不由旧loss share直接推断。

失败：静态或输出订正有实质性退化；只在旧聚合目标提升；两份固定稳定配方均失败。

停止：超过8 H100卡时或两份预定配方即停；不以剔除专家/年份/变量改善结果；不读取2022；失败Fs不得送入T03。

成本：{"gpu_hours": "4–8 H100（预算估计，先计时）", "engineering_days": "1–2"}

命令/伪命令：
```text
TO_IMPLEMENT: fixed_manifest_train(recipe_id, role=fit, no_confirm=True)
TO_IMPLEMENT: delayed_EWMA(available_time_checked=True)
TO_IMPLEMENT: evaluate_standard_table(baseline=F0, leads=[6,24,72,120])
```

产物：baseline_recipes_frozen.json；fit_trace.json；baseline_standard_metrics.json；availability_log.json；gpu_timing.json；baseline_gate.json

## T03 — 最小可证伪headroom试验：测量已冻结编辑族的实际非线性空间，而非先训练复杂selector。

状态：TO_BE_RUN；依赖：T02。

输入：F0或合格Fs*；仅fit生成的K=4–8编辑方向；T02标准基线；预先固定192个2021 DEV起报及12个fit工程探针

方法：固定方向、作用窗、系数norm/边界和预算；先在12个fit起报检查ε/2,ε,2ε、混合方向和20步120h路径，再在192个全年分层DEV起报生成响应。中心差分2K+2轨迹（含重现检查），使用稀疏盒QP；每例最多3个非零候选做实际非线性复验。并列报告有限候选、局部线性代理、实际复验后hindsight-best；一个动作作用所有变量/时效。F0总是候选；不得用每变量oracle拼成一个模型。

数据访问：方向仅fit；headroom/dev可用未来truth但不训练部署系数；确认年禁止读取。

成功：建议GO：实际非线性hindsight在两项主指标相对F0点改善均>=2%，且相对最强已部署基线的额外改善均>=0.5%，配对CI下界>0、保护门通过；同时有训练侧拟合、DEV验证的便宜直接gain探针呈正面信号。阈值是T01前冻结的资源分配标准，不是已证实行业门槛。

失败：在数值检验有效且固定候选完整的前提下，两项主指标的oracle-minus-best-deployable-baseline CI上界均<0.5%，停止此编辑族；不能据此否定所有低秩编辑或局部QP之外的可达最优。

停止：N=192固定不追加；预算8 H100卡时；线性误差>10%只许一次事前规定半径减半，否则改用已冻结有限候选响应或INCONCLUSIVE；GPU/数据/稳定性失败不判科学STOP。未达GO但也不满足失败规则=>INCONCLUSIVE并暂停，不拿confirm救结论。

成本：{"gpu_hours": "4–8 H100上限（实际按N*(2K+2+J)*t_roll/3600另加训练/I/O估算）", "engineering_days": "1–2"}

命令/伪命令：
```text
TO_IMPLEMENT: freeze_direction_dictionary(fit_only=True,K<=8,max_active=2)
TO_IMPLEMENT: probe --role fit --n 12 --eps 0.01,0.02,0.04 --steps 20
TO_IMPLEMENT: headroom --role dev --n 192 --nonlinear-verification-budget 3 --include-f0
TO_IMPLEMENT: no_confirm_go_stop_report()
```

产物：direction_manifest.json；linearization_checks.json；headroom_per_issue.json；headroom_standard_table.json；nonlinear_verification.json；research_gate.json

## T04 — 仅GO后检验e0/du路线的增量价值，并在封存确认集执行一次最终比较。

状态：TO_BE_RUN；依赖：T03。

输入：T03 GO；冻结编辑族和训练缓存；同信息同预算直接gain/直接router与输出校准基线；角色许可与训练完成的部署模型

方法：用fit训练e0/du及direct-gain，比较标量路由、响应分解、同信息输出订正；利用分解的误差/响应oracle替换只作诊断。全部模型/候选/指标/阈值在2021 DEV上最终确定，然后冻结commit、权重和一次性2022评估manifest。此后才由独立数据流程做2022完整性扫描；不合格阻断，不按技能筛年份。所有部署动作不得读未来truth。

数据访问：fit=2018+2020；dev=2021；完成模型/角色冻结与独立访问审计后才可读取2022确认支持窗。

成功：两项主指标相对F0及最强可部署基线均有正的配对CI；相对后者点改善均>=0.5%，24个保护单元同时非劣（伤害上置信界<=0.5%）。直接gain同样有效则只有响应路线额外证明迁移/标签效率才能主张响应机制价值。

失败：未达预设实用改善或保护门失败；响应路线不优于直接路线且无额外优势。保留有限配置负结果。

停止：没有T03GO不执行；16 H100卡时预算；2022只一次且不能按结果返调；技术失败按事先相同配置重试一次，不以结果选择种子。

成本：{"gpu_hours": "8–16 H100（估计含一次确认；先测吞吐）", "engineering_days": "1–2"}

命令/伪命令：
```text
TO_IMPLEMENT: fit_heads --fit-only --matched-info-budget
TO_IMPLEMENT: freeze_deployment_and_confirm_manifest()
TO_IMPLEMENT: content_check_confirm --permit <approved> --no-skill-selection
TO_IMPLEMENT: confirm_once --metrics <frozen> --all_baselines --steps 20
```

产物：head_training_records.json；matched_baseline_table.json；deployment_freeze.json；confirm_access_log.json；confirm_standard_metrics.json；final_claims.json
## 具体日期与冻结

以CODEX_TASKS.json为机器可读唯一任务合同。fit=2018全年+2020Q1–Q3；训练内validation=2020Q4（已曝光，不叫clean holdout）；dev=2021（192个固定等距起报）；confirm=2022。T01先签角色再读新增数组，T04固定最终方法后才读confirm。缺失/替补规则也须事前固定。
