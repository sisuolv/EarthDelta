"""Validate package shape and hashes; this is not a scientific validation."""
from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parents[1]
required=['START_HERE_FOR_CODEX.md','FOLLOWUP_PLAN.md','EXECUTION_DAG.md','STOP_CONDITIONS.md','CODEX_TASKS.json','ARTIFACT_CONTRACT.md','TEST_PLAN.md','REPRODUCIBILITY.md','CURRENT_GAP_ANALYSIS.md','evidence/PLAN_AUDIT_RESULT.json','evidence/EVIDENCE_MANIFEST.json','evidence/REQUIRED_INPUTS.md','prompts/CODEX_EXECUTION_PROMPT.md']
for f in required:
 if not (ROOT/f).is_file():raise ValueError('missing '+f)
o=json.loads((ROOT/'CODEX_TASKS.json').read_text());tasks=o['tasks'];ids={t['id'] for t in tasks}
if len(tasks)!=len(ids) or not 3<=len(tasks)<=5:raise ValueError('bad task count')
keys={'id','goal','depends_on','inputs','method','data_roles','metrics','success','failure','stop_rule','data_access','est_cost','priority','scope','status','commands','acceptance_criteria','evidence_outputs','stop_if','estimated_minutes'}
seen=set()
for t in tasks:
 if not keys<=t.keys():raise ValueError('missing task fields')
 if not set(t['depends_on'])<=seen:raise ValueError('DAG invalid')
 if t['status']!='TO_BE_RUN':raise ValueError('future task mislabeled')
 seen.add(t['id'])
checks=json.loads((ROOT/'SHA256SUMS.json').read_text())
for f,v in checks.items():
 if hashlib.sha256((ROOT/f).read_bytes()).hexdigest()!=v:raise ValueError('hash mismatch '+f)
print(json.dumps({'package_validation':'PASS','files_hashed':len(checks),'task_count':len(tasks),'scientific_success':False}))
