"""Independent paired block ratio bootstrap; no EarthDelta/Claude scorer imports.
Supports canonical JSON when --repo is given, otherwise audited scalar projections.
The projection contains the five used columns decoded from the Git-tracked Parquet
and the F0/action fields transcribed from the Git JSON. It is NOT the full source.
"""
from pathlib import Path
import argparse, csv, json, datetime as dt, hashlib
import numpy as np

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path);ap.add_argument('--projection',type=Path,default=Path(__file__).resolve().parents[1]/'inputs');ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'run_results');ap.add_argument('--draws',type=int,default=10000);ap.add_argument('--seed',type=int,default=0);a=ap.parse_args()
    if a.draws<10000: raise ValueError('at least 10000 draws')
    if a.repo:
        root=a.repo/'plans/plan_v4_0923/run_20260924T104725Z_fp05b'
        paths=[root/'cache/dev/candidate_results.json',root/'cache/dev/background_f0.json',root/'policies/oof_predictions.json']
        rows=json.loads(paths[0].read_text())['rows']; bg=json.loads(paths[1].read_text())['issues']; act=json.loads(paths[2].read_text())['predictions']
        bg={i:v['f0_cpu'] for i,v in bg.items()}; scope='canonical JSON'
    else:
        paths=[a.projection/'scalar_projection.json',a.projection/'f0_cpu_projection.csv',a.projection/'action_projection.json']
        rows=json.loads(paths[0].read_text());bg={r['issue_id']:{h:float(r[h]) for h in ('6','24','72')} for r in csv.DictReader(paths[1].open())};act=json.loads(paths[2].read_text());scope='audited projection; canonical-file byte identity not independently reconstructed'
    cs=['reference','expert_0','expert_1','expert_2','expert_3'];hs=[6,24,72];d={};times={}
    for r in rows:
        key=(r['issue_id'],r['candidate_id'],int(r['lead_hours']))
        if key in d: raise ValueError('duplicate key')
        if r.get('status','PASS')!='PASS': raise ValueError('non-PASS row requires explicit frozen fallback handling')
        d[key]=float(r['cpu_loss']);times[r['issue_id']]=int(r['issue_time'])
    ids=sorted(times,key=lambda i:(times[i],i));n=len(ids)
    assert n==112 and len(d)==1680 and set(ids)==set(bg)==set(act)
    x=np.array([[[d[i,c,h] for h in hs] for c in cs] for i in ids]);f0=np.array([[bg[i][str(h)] for h in hs] for i in ids]);assert np.isfinite(x).all() and np.isfinite(f0).all() and np.min(f0)>0
    pos=np.arange(n);o5=x[:,:,1].argmin(1);all6=np.concatenate([f0[:,None,:],x],axis=1);o6=all6[:,:,1].argmin(1)
    methods={'Fs':x[:,0,:], 'M1':x[pos,[cs.index(act[i]['M1']) for i in ids],:], 'M3':x[pos,[cs.index(act[i]['M3']) for i in ids],:],'oracle5_at24':x[pos,o5,:], 'oracle6_at24':all6[pos,o6,:], 'oracle5_per_lead':x.min(1),'oracle6_per_lead':all6.min(1)}
    origin=int(dt.datetime(2019,7,6,12,tzinfo=dt.timezone.utc).timestamp());blocks=np.array([(times[i]-origin)//604800 for i in ids]);ub=np.unique(blocks);assert len(ub)==23 and set(range(25))-set(ub)=={16,19}
    names=list(methods);arr=np.stack([f0]+[methods[k] for k in names],axis=1)
    sums=np.array([arr[blocks==b].sum(0) for b in ub]);rng=np.random.default_rng(a.seed);draw_idx=rng.integers(0,len(ub),size=(a.draws,len(ub)))
    bs=sums[draw_idx].sum(1);total=sums.sum(0);pt=(total[0]-total[1:])/total[0];vals=(bs[:,0:1,:]-bs[:,1:,:])/bs[:,0:1,:];lo,hi=np.quantile(vals,[.025,.975],axis=0)
    table=[{'lead_hours':h,'method':m,'gain_percent':100*pt[j,k],'ci_low_percent':100*lo[j,k],'ci_high_percent':100*hi[j,k]} for k,h in enumerate(hs) for j,m in enumerate(names)]
    fsdenom={m:{str(h):float((methods['Fs'][:,k].sum()-methods[m][:,k].sum())/methods['Fs'][:,k].sum()) for k,h in enumerate(hs)} for m in ('M1','M3','oracle5_at24')}
    oracle_m1=(total[2,1]-total[4,1])/total[1,1];gdraw=(bs[:,2,1]-bs[:,4,1])/bs[:,1,1]
    gain=x[:,[0],1]-x[:,1:,1];double=gain-gain.mean(0,keepdims=True)-gain.mean(1,keepdims=True)+gain.mean();sing=np.linalg.svd(double,compute_uv=False)
    out={'status':'RECOMPUTED','source_scope':scope,'n':n,'blocks':ub.tolist(),'block_counts':{str(b):int((blocks==b).sum()) for b in ub},'seed':a.seed,'draws':a.draws,'positive_means':'lower native squared loss than F0; not RMSE percentage','table':table,'oracle_choice_rule':'main oracles choose one action by 24h loss and keep it across leads; per-lead oracles separately reported','oracle6_at24_F0_count':int((o6==0).sum()),'F0_no_worse_than_all5_counts_by_lead':dict(zip(map(str,hs),map(int,(f0<=x.min(1)).sum(0)))),'original_Fs_denominator_effects':fsdenom,'oracle_minus_M1_Fs_denominator':{'point':float(oracle_m1),'ci':np.quantile(gdraw,[.025,.975]).tolist()},'action_counts':{m:{c:sum(act[i][m]==c for i in ids) for c in cs} for m in ('M1','M3')},'double_centered_gain_singular_values':sing.tolist(),'input_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    a.out.mkdir(parents=True,exist_ok=True);(a.out/'independent_f0_bootstrap.json').write_text(json.dumps(out,indent=2)+'\n')
    with (a.out/'independent_f0_bootstrap.csv').open('w') as fh:
        wr=csv.DictWriter(fh,fieldnames=table[0]);wr.writeheader();wr.writerows(table)
    for r in table:print(f"{r['lead_hours']:2} {r['method']:18} {r['gain_percent']:+.6f} [{r['ci_low_percent']:+.6f}, {r['ci_high_percent']:+.6f}]")
    print('oracle-M1',out['oracle_minus_M1_Fs_denominator']);print('counts',out['action_counts']); print('F0wins',out['F0_no_worse_than_all5_counts_by_lead'])
if __name__=='__main__': main()
