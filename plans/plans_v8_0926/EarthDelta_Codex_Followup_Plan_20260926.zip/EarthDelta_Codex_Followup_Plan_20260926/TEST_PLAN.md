# 三层验证

## CPU
原始scalar完整性（112×5×3，正finite损失，固定issue时间）；独立block-sum与显式issue-resampling一致；共同bootstrap方法/时效对齐；F0自身零skill；oracle6逐lead非负、固定24动作其他lead允许负；结果不随行顺序改变。
真实入口负例：空时间、缺变量/错顺序、缺chunk、NaN、finalize_failed、错阈值/非bool、坏证书、未批准时间窗、single_chunk假坐标均拒绝；不能将无关import错误当拒绝测试通过。
逐变量以每例MSE池化后开方；Bootstrap>=10000；精确坐标/变量/npz绑定，reconciliation是必要非充分条件。

## GPU（仅获批后）
同checkpoint的F0官方前向1/4/12/20步；非零hook系数、reversion/continuation；训练梯度方向用小步有限差分/下降检查；不是仅测finite。Fs质量门、source/bank重载、真实非线性响应与20步场输出。

## 科学
对齐信息/成本/F0及强静态/输出订正；两主目标+24格保护（6变量×4时效）；7/14day联合block统计与多重保护；有限hindsight不是可部署方法；确认集只打开一次。
