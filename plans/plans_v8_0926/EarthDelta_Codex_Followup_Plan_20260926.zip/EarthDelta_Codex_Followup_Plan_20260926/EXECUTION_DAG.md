# DAG

T01 角色冻结+必要数据/测量修复 → T02 对齐静态/输出基线 → T03 固定编辑族headroom → [GO且人工批准] T04 核心方法+一次confirm。

G0：官方无编辑前向；G1：实际hook/20-step/训练方向数值；G2：拟合Fs训练质量与F0安全；G3：专家方向资格与cache完整；G4：F0-relative真实headroom；G5：核心方法优于同信息基线；G6：一次确认。

G0不推出G1，G1不推出G2，G3不推出G4，G4的hindsight不推出G5。没有合格Fs可用F0作新参考，但不能给失败Fs换标签绕过G2。

T03 STOP仅针对已测方向族、幅度、目标、分布。INCONCLUSIVE不触发自动扩样。T04前2022不读数组。
