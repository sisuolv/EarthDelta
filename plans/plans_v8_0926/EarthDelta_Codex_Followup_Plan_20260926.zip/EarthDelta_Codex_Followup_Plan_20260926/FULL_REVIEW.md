# EarthDelta 独立复核：2026-09-26

## 一句话判断
停止扩大当前K4/selector配置；保留原FP05b冻结结论，以F0和标准变量完成一次最小测量/数据修复后，做有限、训练侧冻结方向的非线性headroom试验，再决定是否检验e0/du核心假设。

## 版本与证据边界
代码/科学基准：9e91191d506784e4e4d8935b736a96bdfb6dca00。实际观察mainHEAD：9a41f3f076b9f20966bce8c4174578db93bc8ae8。
之后有2个提交：5149684ccf3c443abee4d3419c3a6d2288cc8459与9a41f3f...。GitHub compare的完整文件集合只有README.md、reviews/CHATGPT_PRO_AUDIT_PROMPT_20260926.md、reviews/claude_independent_review_20260926/scalar_recheck.py。没有其他代码/实验文件变更。本地工作区连接失败；用远端提交历史/比较核实，没有运行本地git log，不认证本地clean/sync。

本轮数值独立实现不导入EarthDelta或Claude scorer。canonical candidate_results.json较大，接口未能完整物化；实际使用Git中的Parquet便利副本的5个数值列，经独立Thrift/SNAPPY解析得到1680条完整标量记录，再与分页读取的Git background_f0.json和oof_predictions.json字段联结。检查了canonical锚点及旧Fs-relative效应。没有声称完整canonical JSON逐字节重算。包内--repo路径支持从原始三个JSON直接重放；此项仍应在本地完成。该传输限制不应被隐藏。

本轮实际执行B=10000独立bootstrap和另一份显式抽样交叉计算；6项数值验证通过。没有新GPU、没有完整仓库pytest、没有重算逐变量端点。用户明确不可见的zarr、checkpoint、artifacts、pull日志、外部执行目录一律不作已核实事实。

## 1. 五段结论

**做到哪里。** 已有冻结骨干、静态Fs、K4候选和112例2019H2的离线OOF结果；M3是直接标量gain ridge，不是e0/du响应核心的验证。原计划P1还要求标准变量24/72/120h、F0与强静态、线性度；当前证据没有完成这个科学门。见原计划§4.2、§4.6、§4.7。

**哪些地方有问题。** 旧主目标是69通道按状态std归一化的平方误差，且F0只作背景；这不能代表标准天气效用。Fs允许资格集+2%损害，实测记录约+0.339%，后续相对Fs的修复容易掩盖相对F0的净损害。数据拉取层有false-success路径。原始逐变量/传输事故不可见，不能把提出的因果归因当定论。

**哪些结论可信。** 标量重算显示M3相对F0在6h/24h/72h为-0.211%/+0.0699%/-0.720%；这是旧native squared loss而非RMSE。当前菜单的oracle-static增量很小。原规则PIVOT_STATIC仍是正确的冻结协议处置；新科研决策可停止当前菜单，但不可倒写协议。

**哪些仍未证明。** e0/du可预测性、响应路线优于direct gain、标准变量收益、全局连续编辑headroom、QBO因果机制、原始GPU与当前zarr内容全部尚未独立证明。这个配置失败，不等于核心假设已被否定。

**接下来的顺序。** 角色/指标与必要数据→强静态和输出订正对照→有限非线性headroom→仅GO后训练核心并一次确认。两份复查的原计划都不原样采纳。

## 2. D1–D8裁决

|分歧|裁决|证据|依据与理由|
|---|---|---|---|
|D1 最强基线|PARTIAL|RECOMPUTED/CODE_READ|F0是不可省略的主锚点，6/72h优于所有主表编辑策略；M1在24h旧目标略优。不存在无条件全时效排序。|
|D2 权重|PARTIAL|CODE_READ；份额DOC_READ/UNVERIFIABLE|static_adapter.py:327–360用inp_std，官方iterative_module.py训练归一化差分并用WEIGHT_DICT气压权重。已实现损失不同，但loss贡献不是硬编码权重或梯度份额。|
|D3 逐变量退化|PARTIAL|CODE_READ/DOC_READ；数值UNVERIFIABLE|脚本面积加权MSE→跨起报均值→sqrt是正确形式；未绑定端点/坐标/std身份，report实际只用1000 bootstrap，maxdiff只是print。|
|D4 72h guard|CONFIRMED仅Fs协议；F0安全解读REFUTED|RECOMPUTED/CODE_READ|M3对Fs约+0.439%，对F0约-0.720%；两者并不矛盾。|
|D5 selector而非headroom瓶颈|REFUTED|RECOMPUTED/CODE_READ|oracle−M1点0.0536%，CI约[0.0419%,0.0669%]，远低0.340%；加减恒等式不识别原因。|
|D6 下一步|PARTIAL，两原计划都需改|INFERRED/CODE_READ|不先做旧目标selector-only；Claude方向较合理但局部QP不是真全局上界，必须固定方向/幅度、非线性复验并分开oracle与可部署效用。|
|D7 数据|PARTIAL|CODE_READ/DOC_READ；根因UNVERIFIABLE|pull层零步标记、failed finalize rc0、shape-only检查成立；代理fsspec丢块只是可能机制。|
|D8 Fs认证|PARTIAL|CODE_READ/DOC_READ|8个完整天气起报、32更新的资格门可作小规模工程门，不是泛化或统计非劣证明；下游必须同时报告F0。|

## 3. F0标量重算

G_F0(M,h)=100*(sum_i L_F0,i,h-sum_i L_M,i,h)/sum_i L_F0,i,h。
UTC块起点2019-07-06T12Z，23个非空7日块（缺16/19），B=10000，seed=0，各方法时效共同重采样，分母每次重算。区间为条件于固定OOF预测的百分位CI。主oracle5、oracle6均按24h选择每例动作，再保持该动作到6/72h；oracle6含F0。不是每个时效重新优化。

|h|方法|改善%|95%CI%|
|---|---|---:|---|
|6|Fs|-0.269|[-0.293,-0.247]|
|6|M1|-0.217|[-0.241,-0.195]|
|6|M3|-0.211|[-0.235,-0.190]|
|6|oracle5|-0.213|[-0.235,-0.192]|
|6|oracle6|-0.155|[-0.175,-0.135]|
|24|Fs|-0.192|[-0.234,-0.150]|
|24|M1|+0.0702|[+0.0300,+0.114]|
|24|M3|+0.0699|[+0.0305,+0.112]|
|24|oracle5|+0.124|[+0.0825,+0.168]|
|24|oracle6|+0.155|[+0.120,+0.194]|
|72|Fs|-1.16|[-1.38,-0.944]|
|72|M1|-0.690|[-0.885,-0.495]|
|72|M3|-0.720|[-0.925,-0.512]|
|72|oracle5|-0.671|[-0.886,-0.453]|
|72|oracle6|-0.437|[-0.599,-0.276]|

与Claude scalar_recheck.txt在四位小数百分数输出精度内全15行一致，最大差4.87e-5个百分点（四舍五入尺度）。另一份显式issue-resampling对M1@24CI差2.99e-14个百分点。

补充：逐lead重新选的oracle6在6h为+0.00109%[0,+0.00282]，72h+0.156%[+0.0834,+0.232]，按定义不劣于F0；这不是同一条24h策略。F0不差于全部5候选的起报数为109/112(6h)、31/112(24h)、83/112(72h)，不是每例都胜。

旧协议排除F0在研究“固定Fs之上的额外编辑”时定义合法；把它用作天气改善的充分筛选则有设计缺口。把F0加入新候选是新协议，不可改写旧FP05b。

## 4. 权重与逐变量审查

当前loss为(1/69) sum_v MSE_v/sigma_state,v²。官方Stormer training_step则对各rollout step的归一化差分做纬度加权误差，再用WEIGHT_DICT：t2m=1，u10/v10/mslp各0.1，压力层各变量内权重p/sum(p)。不能只把官方diff_std接到当前终点状态loss，就称复现了官方多步训练目标。

per_variable_report.txt记录F0@24损失贡献：湿度49.5%，压力层U/V风44.8%，含10m风为47.6%，Z/T/MSLP/T2m约2.90%。这些是某批样本的实现损失份额，不是“湿度显式权重50%”或“50%梯度”；梯度还取决于残差与模型Jacobian。50–150hPa约29%未从已读脚本/输出独立得到。所有端点份额数值仍UNVERIFIABLE。

state std标准化不是数学错误；问题是声明的天气目标与该代理目标不等价。是否正是权重、样本数或优化导致退化，要靠同数据/更新预算的损失对照，不能据表做因果判定。

per_variable.py:9–21硬编码128个纬度点并按cos归一化，对此等间隔含格心球面网格合理；实际坐标仍必须绑定。channel从2019.zarr读，std另取reference目录，无原manifest/hash核对；对每issue最后一行endpoint_file覆盖前行，没有检验所有引用一致。

per_variable_report.py:10–18用mean(mse/std²)重建标量，≤3.5e-9若来自真实执行，支持总体归一化/聚合一致；它是多对一映射，不能证明通道标签/纬向方向/坐标/真值身份及独立数据正确。该脚本仅打印max，没强制finite/threshold/完整键集。纬度反向在对称cos权重下甚至可保留总体误差。

报告根号置于跨起报MSE均值后是正确的pooled RMSE，而不是平均逐例RMSE。代码造4000次draws，CI函数只用前1000。六变量四时效之外另看许多变量存在多重比较；不能把大量未校正逐格CI变为确证性结论。逐变量oracle更是每变量/每lead分别选动作，只能标不同任务的事后诊断。

“只有50–100hPa风改善”过强：同文件还有T2m@6h +0.130%、10m U@24h +0.0600%，以及部分更低层V贡献为正。合理说法是平流层风主导了旧aggregate的正贡献，而非唯一正信号。

## 5. 两份复查遗漏或没有充分处理的事项

### P0
1. 可部署天气判定不能绕开F0：旧Ps/Fs相对指标允许弱参考被修复却仍净伤害原骨干。保留原判定，另建F0标准指标gate。证据见独立表与policy_oof.py:372–465。
2. 拉取失败语义会伪造complete：pull_wb2.py:1000–1137无正时间长度门，变量返回后无条件mark；1147–1181的verification_failed在1360–1419只打印；run_multi_year_pull.sh只据rc重试。最小修复：严格时间轴/变量/内容验证→原子标记→状态映射非零；不修整库就直接科研。

### P1
3. OOF区间不包含模型拟合/专家训练方差，外折训练集重叠带来跨fold依赖；固定23块百分位bootstrap是条件描述，不自动覆盖整个学习算法的不确定性。增加预声明14日敏感性、固定策略确认；需要学习过程CI时重训内层，不能仅增加B。
4. 多重比较与“点估计>=d”混用：旧BELOW是CI对0.34%的关系，不是对0；新6×4保护要联合控制，不能看完结果选指标或只保留上层风。
5. 当前r7_followup_decomposition.py:129–159只在4专家内按每个lead重选best，6h排除了本可胜出的reference，且不是原oracle5的24h固定动作；24h此数据reference无赢家，主headroom点不受影响。summary的stop_rule_triggered硬编码False。应明确oracle定义并计算真正阈值规则，不把输出文句当科学根因。
6. 旧fail-open与WBX主入口跨年缺口已修复：r5_audit_runner.py:27–58改is True，INVALID返回2；wbx/evaluate.py:234–249包含valid years；erratum已补pairedF0及逐字段24h对账。不应再次报告为未修复。剩余漏洞是verified_bundle可缺失、source/input只是结构存在、载入delta与CLI delta可不同，以及single_chunk valid_times仍可省略/坐标未绑定。最小修复formal/test模式分离，绑定受信gate与唯一delta。
7. paired_F0_intervals的对照是F0，但调用policy_oof bootstrap仍用sumM0分母。这与原协议一致，不是算错；字段必须明确denominator，不能和本轮F0分母数值混用。
8. 特征x_t,x_t-x_t-6,x_t-x_t-12+日历合法，无future truth入参；scaler/PCA/内层HPO均在对应train拟合，purge支持t-12..t+72且加24h。未见该实现的直接标签泄漏证据；然而双向crossfit并非在线部署，ERA5分析也不等于实时可得观测。2019是骨干选模年，2020test标签已被训练使用，不能当外部clean test。延长到120h必须扩支持窗，旧72h purge不能直接复用。
9. S0只有无编辑前向有限初态1/4/12，不认证实际hook梯度/混合系数及20-step路径。新实验只对新增实际路径补方向/非线性测试，不每轮全量重跑S0。
10. Fs 8个全场起报不是8个独立标量训练样本，但天气分布覆盖仍极窄；32更新的资格门不说明充分训练。Bank 15/16/7/6组的不等访问次数与不同月份共同变化，不能将专家差异全归为天气流型。
11. response均值插入恒等式不自动给条件期望gain。压缩上下文z下，E[g|z]=2mu_e^TQmu_d-mu_d^TQmu_d+2E[(e-mu_e)^TQ(d-mu_d)|z]-E[(d-mu_d)^TQ(d-mu_d)|z]。分别回归均值可能漏协方差项；全状态下确定性du则该项消失。应与direct gain做真实对照，而不是凭恒等式保证价值。

### P2
12. 原headroom是必要但非充分门；teacher.py:1–6已明确局部线性代理非global oracle。数值求出的nonlinear最佳仅是已搜索家族的可实现下界（对最优收益而言），不能据其失败证明所有连续参数没有空间。
13. r7“unweighted_block_mean_direct_gain”实际是块内gain总和再跨块平均，与逐起报均值差N/B=4.87倍；主ratio不受影响。口径/单位需清楚。
14. 大量审计包重复与关键模型未检验形成机会成本。T01只修影响数据/度量/放行的最小问题，下一决策必须是科学headroom，而不是更多文档验证。

## 6. 数据事故因果边界

finiteness_scan_2015/2018/2019开头分别报告扫描0..735、非有限216/192/124步；H2扫描736..1459，88/724步。这是Git扫描记录，不能自动认证现有store。已读样例失效集中同一变量全部13压力层。2019局部索引44、828均非8整倍数；若源全局时间轴从1959开始，2019偏移模8为4，所以可能仍全局8对齐。完整chunk分区和源time元数据未取得，不声称所有hole都已重算。

该形态与块下载/写入故障兼容，不唯一定位代理。官方fsspec当前FSMap默认将FileNotFoundError/IsADirectoryError/NotADirectoryError转换KeyError，而不是所有timeout/500；实际用版本与HTTP异常必须读原件。源码还用fillNaN预创建中间zarr，因此未写块/旧完成标记/中断写入/源块本来缺失/重网格NaN传播也可能。比较源chunk的HTTP状态、内容hash、对应局部写入及异常栈才可归因。仅shape=全年×69或两变量nanmean不证明全场完整。

## 7. 研究价值

核心假设仍值得一次窄、便宜、可停的检验。当前测试direct-gain有限K4，未测试同历史e0/du、标签效率、跨目标/方向迁移，不能从配置失败直接否定框架。也不能把未检验功能和一般代数称为已实证novelty。

充分训练模型的状态依赖低秩headroom先验是未知。若F0恰为E[Y|history]，任意确定性历史编辑delta增加期望平方误差||delta||²；实际充分训练不等于Bayes条件均值，偏差/漂移可能留下空间。文献只支持适配有时有效，不能提供本设置>=2%的概率。

已确认的主来源：Aurora Nature2025 (https://www.nature.com/articles/s41586-025-09005-y)；WeatherPEFT ICLR2026 (https://proceedings.iclr.cc/paper_files/paper/2026/hash/4e6219cc3913fd508dbd7f3f6d90cd4e-Abstract-Conference.html)；Strobach等GMD2022 Green函数参数调整(https://gmd.copernicus.org/articles/15/2309/2022/)；官方Stormer58dfee5 (https://github.com/tung-nd/stormer/tree/58dfee5)。前两项不是逐起报无未来真值的参数编辑效用证明；Green函数先例说明有限差分响应/加权最小二乘不新。Aurora与WeatherPEFT不能给EarthDelta可达增益保证。

QBO判断未知。QBO文献Baldwin等2001 (https://agupubs.onlinelibrary.wiley.com/doi/abs/10.1029/1999RG000073)描述赤道平流层纬向风的准两年振荡。当前正贡献大项是V50/V100，不能直接等同QBO；半年数据也不能分辨跨相位机制。最多在已有端点上做一次纬度分区、纬向均值偏差与中心化RMSE分解；不要另开昂贵QBO主线。

## 8. 下一阶段与机器计划

详见FOLLOWUP_PLAN.md和CODEX_TASKS.json。共四任务，先数据角色冻结与最小测量修复，再标准目标/强静态/输出校准对照，再train-only固定方向、192例DEV非线性headroom；仅GO后拟合核心与一次2022确认。标准表Z500/T850/T2m/MSLP/U850/Q700 ×6/24/72/120h。原始native loss保留诊断，不作为天气RMSE。

提出的2%/0.5%是资源决策工作阈值，必须事前冻结，不是文献标定常数。Go还需动态oracle超过强静态/输出基线，不能只超过F0；Stop只针对有限家族。方向K4–8、最多3个QP候选复验、稀疏max_active2，避免16维全子集爆炸。线性半径诊断失败时停止连续解释，不能放大epsilon追收益。

角色建议：2018+2020fit，2019legacydev，2021新DEV，2022封存confirm；不是宣称2022现已干净。T01先签署用途/完整支持窗，T04最终模型冻结后才核验/读取确认数组；发现既有曝光/缺失即BLOCKED，不按技能换年。成本规划T01 GPU0、T02 4–8、T03 4–8、T04 8–16 H100卡时（未实测）；先计时，合计16–32卡时上限估计，独立于网络/排队。最早Stop可以只用旧端点的CPU标准指标诊断；新假设检验仍要合格数据与新固定家族。

## 9. 不可核实项

详见evidence/REQUIRED_INPUTS.md。不可见不等于不存在；DOC_READ不等于执行复现。缺失涵盖canonical全字节、逐变量原NPZ/端点、source坐标与std、GPU权重/run、空年份与代理事故原日志、local worktree、未来headroom与QBO机制/成本。不要用摘要补齐。
