# Hard STOP

- 原S0容差1e-5不变；新120h路径需20-step覆盖。未通过的后端/edited path不可用于新的科学run。
- Fs发散/质量门失败，不冻结发布、不进入bank/cache。旧H500与指定H32身份分别记录。
- 不在角色与支持窗冻结前读取任何confirm/holdout值。T01只是指定2022，不授权读；T04前须冻结最终模型与一次评测。
- 禁止重写FP05b的候选、112例、fold、0.0034门槛、24h主时效、数字与原判定；纠错用新的append-only erratum。
- Go建议2%oracle/F0 + 0.5%额外oracle/deployable双主目标；Stop建议有效oracle额外收益CI上界<0.5%（两主目标）；中间=INCONCLUSIVE。这些不是原FP05b门槛，不可套回旧结果。
- 数据失败/求解失败/线性失败是技术BLOCKED，不是科学证伪。
- Oracle方向只从fit生成；DEV未来truth只供事后系数上界诊断，不能进入部署forward。
- 不默认重拉2015–2022八年、不按sigma阈值静默删真实极值、不用NaN补数据通过。
- 资源上限：T02 8、T03 8、T04 16 H100卡时（估计预算），先测吞吐；未经批准不超限。
