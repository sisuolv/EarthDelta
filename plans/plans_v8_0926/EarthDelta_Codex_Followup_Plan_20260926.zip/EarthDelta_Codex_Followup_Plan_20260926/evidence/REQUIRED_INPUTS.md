# 待补原始材料

## U1 完整canonical candidate_results.json与本轮传输投影逐字段一致性
本轮实际重算使用Git Parquet数值列投影及Git JSON的F0/action字段；没有完整canonical JSON字节认证。包内--repo模式供本地直接核验。

- `完整candidate_results.json`
- `background_f0.json`
- `oof_predictions.json`
- `cache_manifest.json`

## U2 逐变量真实RMSE、loss share及≤3.5e-9对账的原始执行
代码及文字输出已读，端点与NPZ不可见；29%上层份额亦未在已读report输出找到独立计算。

- `per_channel_mse.npz`
- `endpoints.npy`
- `f0_endpoints.npy`
- `truth.npy`
- `2019.zarr坐标/通道元数据`
- `normalize_std.npz及原hash/manifest`

## U3 2016/2017/2022为空、2020 q100 102sigma、代理丢块根因
可确认代码允许虚假完成，不能确认不可见日志中的实际事故。

- `对应.zarray/.zattrs/.zmetadata`
- `源/目标chunk inventory`
- `HTTP异常/状态及fsspec版本`
- `pull_YEAR.log`
- `multiyear日志`
- `写入完成标记和失败恢复记录`

## U4 S0实际job、权重来源、所有GPU数值/训练反传执行
git中的说明与协议不是本轮GPU复现；S0前向不认证编辑反传。

- `checkpoint及fresh SHA`
- `normalization manifest`
- `source snapshot`
- `S0 gate/reference tensor`
- `job_result与argv`
- `Fs/bank trace与权重/端点`

## U5 本地工作区、external Codex目录、全部第三方clone、完整核心真实运行历史
本地连接失败；远端API可查历史，不声称实际本地git log执行。

- `git status`
- `git log --name-status 9e91191..HEAD`
- `外部执行manifest`
- `训练调用记录`

## U6 真正动态编辑的可达headroom、e0/du可预测性、QBO因果解释、实测后续GPU成本
当前K4只检验特定候选与direct-gain route。

- `新方案受控实验`
- `train-only方向与响应缓存`
- `纬向平均/纬度分区误差和QBO指标`
- `实测t_roll/t_update及I/O`