# 执行前仍需定位的外部原件

**先从同一AFS读取，不要求用户重复上传GitHub已有JSON。**
这份清单指本审查尚未获得，不断言这些文件在执行机不存在。执行机也找不到才生成小型补件包。

## 最新H100 / S0（优先）
- `/mnt/afs/260010168/acp_runs/ed-r6-s0-overlay-recheck-20260925T115020Z/s0/gate_output/s0-gate-20260925t115202730947z/s0_gate_result.json`；预期报告SHA `4aab593d3326f754b866815e9a5d0a15ff1336a1f51079ba38689d4251949670`。
- `/mnt/afs/260010168/acp_runs/ed-r6-s0-overlay-recheck-20260925T115020Z/` 的原scheduler提交/终态、job_result/result、stdout/stderr、argv/source/config/overlay清单；具体子路径从原索引解析，不能编造。
- `/mnt/afs/260010168/acp_runs/ed-r6-h100-overlay-20260925T114520Z/result.json`，登记sha a274a272393cfc616f436092dc7b797d8f9b1c490a44bf08677721da5ddb315e。
- `/mnt/afs/260010168/acp_runs/ed-r6-h100-4single-20260925T113532Z/shard*/result.json`，四原生job的缺依赖trace和实际GPU分配记录。
- gate引用的official reference manifest/config/upstreamcommit与tensorhash、checkpoint/norm/input/coords原hash，及实际执行source snapshot；目前不能给未取得的对象编SHA。

## Fs lineage / 历史负例
- `codex_audit_round4/evidence/gpu_records_recomputed.json`引用的 pt-3x63g0c6、pt-cdj1s2le 原 `FsFitRecord`、run_record、最终panel与权重hash；尤其
  `artifacts/round2_cci/ed-r3-j4-bank-formal-v2-0922011307-2d8e12/expert*/`。
- `plans/plan_v4_0923/run_20260924T013959Z_fp03_v2/certify/fs/` manifest、quality/qualification、L0/L1panel和其引用的V2-J3/J4原trace与jobreceipt；这些小JSON大多已在repo，优先本地git文件。
- `plans/plan_v4_0923/run_20260924T033627Z_fp04_bank/certify/bank/` 与
  `artifacts/round2_cci/ed-r4bankbj2-0924052624-dde08d/expert{0,1,2,3}/bank_panels_expert{k}.json`。
- 权重仅要求本地路径和freshhash：Fsadapter 7b39226b550a2795b1ed85020057bec46064f132b1c36d77a4db9b5682323089；
  mergedFs 1e48438ee98dc72552786011d25d9db3cc208672ceb8a7fc725c7f8fde77a79b；
  bank c3e3e34b60b463b41a6c824fa680d844a2830cd2c7b40d3fc4544dc985b85f81。不得只信manifest不重hash实际被消费文件。

## FP05原件 / 勘误
- `artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/` 与 `ed-r4cachecj2-0924125702-926f58/`
  原job_result/submission/invocation/source/stdout/stderr、4worker shard/provenance；真实job_id从原件解析（本审查未取得，不能猜）。
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/cache/dev/{candidate_results,background_f0,cache_manifest}.json`、policies/folds/actions/freeze、protocol、bootstrap已在repo：无需重新上传，必须独立整表复算。
- 对固定3debug+3dev，issue.json所引用的endpoints/truth/F0端点本地只读挂载；原panel抽查，不只比较summarytrue。
- v6声称的48CPU tests原日志/junit/环境；新增FP06/FP07/erratum正式run的真实输出若已在AFS必须按原路径提供，不重造过去产物。

## WBX / 2022
- `artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json` 全312项及其引用gpu_record/job/source/forecast/truth；TierA原路径从记录解析，不杜撰目录。
- `checkpoints/pull_2022.log`、finalize结果/stacktrace、下载器/validator版本、expected/actual对象manifest/大小/hash、当前完成标志及所有已发生access记录。
- 此阶段不需要2021/2022模型效果，也不要求整年数据上传；发现需技术验数时先列明确规则和允许输出。

## 不是补件要求
不需要访问密钥、不要求公开私有仓库、不需立即上传多GB权重/整年数据。日志脱敏保留原hash和脱敏说明。
