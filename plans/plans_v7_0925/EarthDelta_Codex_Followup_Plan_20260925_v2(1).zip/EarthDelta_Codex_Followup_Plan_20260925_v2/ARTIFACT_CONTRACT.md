# 证据与产物合同

## 1. 每个任务统一字段
`task_result.json`: schema、task_id、status、evidence_state(OBSERVED/TO_BE_RUN/MISSING)、
source_commit、dirty_diff_sha256、started/finished_utc、argv/cwd、returncode、elapsed_seconds、
inputs/outputs(path,bytes,sha256)、gate_passed、scientific_verdict、new_stage4_authorized=false、
missing_inputs、deviations、ENGINEERING_PASS/EXPERIMENT_EXECUTED/SCIENTIFIC_SUPPORT/NOVELTY_SUPPORT。
标签必须逐项赋值，不允许一个PASS同时代表四种支持。
CPU测试记真实收集/通过/跳过/失败数量、stdout/stderr/junit、Python/依赖/平台；缺log写MISSING。

## 2. 新S0 overlay合同（必须落实，当前原件仍MISSING）
job_id `pt-lujnmfhg`；文档登记执行源码 `85ed929f565191cf428ba8d491000542e55fe49e`，审查remote `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。
Torch `2.3.1+cu121`、xformers `0.0.27`、H100、FP32、有效TF32 matmul/cudnn均off。
ps4；checkpoint SHA `7fde884ec85f4999d4bcb02d55ed72c142912071956083ebee08d3d86311b695`；
normalization `ed-norm-identity/1:3e0b216bfbf34ab0`、policy `official_zero_diff_mean`。
1/4/12步每项max_abs_diff均需≤`1e-5`；文档报告0，不能以报告代替读取。
原件`/mnt/afs/260010168/acp_runs/ed-r6-s0-overlay-recheck-20260925T115020Z/s0/gate_output/s0-gate-20260925t115202730947z/s0_gate_result.json`；登记hash `4aab593d3326f754b866815e9a5d0a15ff1336a1f51079ba38689d4251949670`。
来源`evidence/S0_OVERLAY_CONTRACT.json`中的null必须按真实原件填写，不猜测。

必须保存 scheduler提交和终态、job_result、returncode、elapsed、hostname、allocation、实际CUDA device、
container镜像digest、所有overlay wheel和imported-module路径/hash、CUDA/cuDNN/driver、启动argv、
checkpoint/norm/input/coord/variables/protocol/call-graph源码 hash、upstream commit/manifest/reference tensor hashes。
核对 `scripts/s0_gate.py` Gitblob f0695cef22e68737cbe44dd943ac7f040404bd39、
`stormer_bridge.py` Gitblob f06eb061ccfcaf71693fb4e52be719a1fbc2fcb3；Gitblob不是SHA256，二者分别记录。
官方参考必须和同一checkpoint/norm/config/source一致，不能自比较自产参考。
4卡分配和4副本验证分别记录；没有副本证据就不宣称4次独立parity。
原生四job缺xformers需保留失败结果，不能计为官方环境通过。

## 3. Fs/bank
严格按asset identity存FsFitRecord原trace、训练顺序/样本集、LR/schedule/seed、preclip/A/Bgrad、
optimizer-step、参数是否有限、固定L0/final完整panel、Q1–Q6原规则及判断、4副本决定与无替换证据。
保存质量certificate→指定adapter→mergedFs→bank→cache的hash链；merge等价与质量门分别存。
legacy500/v1H256/v2H32不得混用；禁将旧不同Fs的专家拼成共同库。

## 4. FP05标量、勘误与FP06
每cell含issue/candidate/lead/status/cpu_loss/gain、role/time/support/shard/identity。
精确112×5×3与F0背景112×3，所有失败fallback依原协议；V1–V8全集、source/实际输入hash完整。
输出d=.0034、seed20260924、10000pairedwhole7dayblocks、23blocks、14day敏感性、固定actions/folds。
每lead独立H_Fs和直接(M−F0)配对CI；不相减边际CI。
勘误保存旧值/新值/全部比较；24h point/CI/status全量不变。缺comparison不可从交集中“全通过”。
脚本自身与imported数值依赖都写hash；gatefalse/invalid非零退出；negative verdict独立不等于程序失败。
FP06不得信任任意providedstatus或boolean；以已核原始输入重算规则并绑定gatebundle。

## 5. FP07与WBX
FP07记录先验诊断列表、protocolhash、唯一输入路径、全部递归childhash、只读挂载/边界，
原树before/after、所有探索性新增项；不得写原FP05文件。
WBX每项区分oldnativepanel bitwise、官方metric数值容差、regrid/aggregation单位与顺序。
完整312预期键、所有missing/duplicate/mismatch、>=2人工原pair；上游运行模块origin/commit/hash。
授权绑定真实datasetcoords与init+lead/history支持，不能靠任意caller年份列表。

## 6. 日志安全与发布
日志先保存完整原件，再提供脱敏副本；不上传密钥。保存原hash和脱敏方式。
core、official-GPU、WBX环境分别lock；容器/overlay安装成功及import/forward/backward/S0分别验收。
本包不含权重/数据/字体，也不修改远端仓库。
