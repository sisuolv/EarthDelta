# 现状与差距

本次远端HEAD `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714` 已核实。工作区连接404，本地状态没有被确认。
完整逐finding位置、证据标签和处置见 evidence/FINDINGS.json；逐任务四层见 TASK_STATUS_V6.json。

| 范围 | 可关闭的旧误判 | 仍需做什么 |
|---|---|---|
| S0 | 不能再以9月21日的旧FAIL断言9月25日同配置失败 | 新pt-lujnmfhg原件、overlay wheel/container/source/reference binding（R7-03） |
| Fs | 当前formal方向门和Q1–Q6已存在，不是旧finite-onlylogger | 拒绝legacy500；将H32资产链、全horizon/最终panel与实际消费者绑定（R7-05/06） |
| FP04 | 当前已共同Fs认证，不能说所有worker仍各训Fs | 不把训练资格/单probe提升为OOS；不剔除旧坏Fs拼bank |
| FP05b | 已有冻结cache/OOF/evaluation；M3对Fs有小正记录效应 | 全标量独立复算、原native端点/回执；保留未过.0034及M3≈M1（R7-12） |
| FP06 | 正确first-match纯函数已实现，本轮5tests实测通过 | CLI fail-open、unboundstatus/threshold、正式可信receipt缺失（R7-07） |
| lead勘误 | `r5_score_erratum.py`已存在，逐lead公式已修 | 不只比较status；真正pairedF0 CI；自身sourcehash与非零失败码（R7-08） |
| OOF | exact IDs/source/background hash和eval+purged poison代码已有 | V1–V8全集、dev语义、矩阵完整性及真实新测试日志（R7-09） |
| FP07 | freeze/diagnose代码已有 | 防替换inputs、递归hash、先验诊断清单、真实结果与双中心化（R7-10） |
| WBX | 官方组件真实复用，公开函数已有init年份门 | valid_time/真实坐标/生产override；原312项及job（R7-11/14） |
| 2022 | 不应假定优先年份已可用 | 先只读原log/metadata；公共处理bug可能回溯旧年，不读skill（R7-14） |
| 发布 | core可安装声明存在 | 不等于fixedGPU和WBX可复现；补环境分层锁和构建记录（R7-04） |

## 是否继续
建议继续一轮有限的证据闭合与机制诊断，不建议直接扩大当前固定K4库的同类路由实验。
这不是永久否定动态编辑，也不要求“必须先证明有效才允许测试”。
新的科学实验可以针对可证伪机制重新设计，但必须由人批准新协议、预算和数据角色，旧失败保持。
原方案中“先收尾/诊断再战略决定”保留；把2022元数据调查提前并行；公开benchmark表不作为必须等待的研究战略前置。
