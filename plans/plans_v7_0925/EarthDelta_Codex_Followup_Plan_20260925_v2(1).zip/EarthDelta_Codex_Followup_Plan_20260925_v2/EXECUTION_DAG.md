# 执行DAG

```text
FP-06a-R2 版本/原件/overlay封存
  ├─ FP-06b-R2 legacy/H32谱系与质量门回放
  ├─ FP-06c-R2 FP06/erratum/OOF严格入口修复
  ├─ FP-08c 2022现有log/metadata（独立支线）
  └─ WBX-02d valid-time/provenance + Tier原件
FP-06a-R2 + FP-06b-R2 + FP-06c-R2
  └─ FP-06d-R2 冻结标量复算/追加勘误/正式FP06
FP-06d-R2 + FP-06c-R2
  └─ FP-07d 只读机制诊断
FP-06b-R2 + FP-06d-R2 + FP-07d
  └─ FP-09-HUMAN 战略建议（人决定；WBX/2022支线缺件不强制拖延建议）
所有分支完成或带MISSING关闭 → FP-10-CLOSE
```

完整GPU/数据gate缺失时，不准许新scientific run；但可继续不依赖缺件的纯CPU修复及结构测试。
FP-06a可分别记录code_snapshot_complete与raw_receipts_complete，不能因一个已完成抹去另一个MISSING。
FP06预期负面PIVOT_STATIC不阻止合法只读FP07；若原矩阵本身invalid/泄漏则不能解释其科学效用，先取证修复。
2022支线不是旧cache CPU复算前提；公开baseline表也不是研究战略必须等待的前提。
`status=DONE`是具体任务范围完成；scientific verdict及new_run_authorization是独立字段。
历史FP-00～FP-05b/WBX代码DONE仅保留原范围，不当作本次最新GPU/novelty PASS。
禁止 FP-07d→旧FP05b 的任何回写箭头；禁止 FP-09-HUMAN→自动执行Stage4 的箭头。

## 非循环依赖的具体分流
FP-06a-R2先产code_snapshot_complete、historical_cache_chain_complete、latest_s0_receipts_complete三个独立字段。
仅最新S0回执缺失时，仍可修CPU入口和复算旧标量；它锁的是新release/新运行，不追溯抹去旧FP05。
正式旧FP06需要原C-J生产链和冻结数据有效性，不要求为旧实验重做一次最新S0。
任何任务的部分输出可供明确不依赖缺件的CPU检查使用，不能把部分输出合成一个总PASS。
FP-10-CLOSE可在各分支DONE或带MISSING/STOP终结后收尾，绝不把终结记录解释成子gate通过。
