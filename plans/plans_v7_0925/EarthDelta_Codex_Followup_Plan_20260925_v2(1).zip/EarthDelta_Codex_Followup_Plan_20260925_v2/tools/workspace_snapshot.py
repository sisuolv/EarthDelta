#!/usr/bin/env python3
"""Read-only Git/worktree snapshot and protected-file guard; never a science gate."""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,subprocess,sys
from pathlib import Path

CORE17=(
 'earthdelta/bank_training.py','earthdelta/registry.py','earthdelta/static_adapter.py',
 'earthdelta/fs_protocol.py','earthdelta/metrics_contract.py','earthdelta/pilot_contract.py',
 'earthdelta/data/make_splits.py','scripts/r2_fs_bank_train.py','scripts/r4_bank_decide.py',
 'tests/test_fitted_fs_bank_roundtrip.py','tests/test_bank_quality_gate.py','tests/test_profile_immutability.py',
 'tests/test_plan_gate_chain.py','earthdelta/contracts.py','earthdelta/bridge/stormer_bridge.py',
 'earthdelta/bridge/stormer_arch.py','earthdelta/lowrank.py')

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()

def is_protected(rel:str)->bool:
 return rel in CORE17 or rel.startswith('plans/plan_v4_0923/run_') or (rel.startswith('plans/plan_v6_0925/') and rel.endswith('.zip'))

def run(repo:Path,*args:str):
 cmd=['git','-C',str(repo),*args]
 try:
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
  return {'argv':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 except (OSError,subprocess.TimeoutExpired) as e:
  return {'argv':cmd,'returncode':None,'stdout':'','stderr':str(e),'status':'MISSING'}

def all_protected_names(repo:Path):
 names=set()
 base=repo/'plans/plan_v4_0923'
 if base.is_dir():
  for p in base.glob('run_*'):
   if p.is_dir():
    for f in p.rglob('*'):
     if f.is_file() or f.is_symlink():names.add(f.relative_to(repo).as_posix())
 return sorted(names)

def capture(a):
 repo=a.repo.resolve();out=a.out.resolve()
 if not repo.is_dir():raise ValueError('Repository does not exist')
 if out.is_relative_to(repo) or repo.is_relative_to(out):raise ValueError('Output must be separate from repository')
 if out.exists():raise FileExistsError('Refusing overwrite: '+str(out))
 out.mkdir(parents=True)
 records={k:run(repo,*args)for k,args in {
  'head':('rev-parse','HEAD'),'branch':('branch','--show-current'),
  'status':('status','--porcelain=v1'),'worktree_diff':('diff','--name-status'),
  'index_diff':('diff','--cached','--name-status'),
  'remote_ref':('ls-remote','origin','refs/heads/audit/round2-review-20260921')}.items()}
 head=records['head']['stdout'].strip()
 result={'schema':'ed-review-workspace/1','created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
  'repo':str(repo),'expected_head':a.expected_head,'actual_head':head,'commands':records,
  'head_matches':head==a.expected_head,'new_stage4_authorized':False,
  'scope':'Git state and tracked-byte snapshot only, not raw GPU/stability/scientific validation'}
 ls=run(repo,'ls-files','-z')
 if ls['returncode']!=0:raise ValueError('Cannot enumerate tracked files: '+ls['stderr'])
 hashes=[];errors=[]
 for rel in filter(None,ls['stdout'].split('\0')):
  p=repo/rel
  try:
   if p.is_symlink():
    errors.append({'path':rel,'error':'SYMLINK_REQUIRES_EXPLICIT_ASSET_MAPPING'});continue
   if not p.resolve().is_relative_to(repo):raise ValueError('path outside repository')
   if not p.is_file():raise FileNotFoundError(rel)
   hashes.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'protected':is_protected(rel)})
  except (OSError,ValueError) as e:errors.append({'path':rel,'error':str(e)})
 snapshot={'schema':'ed-review-tracked-snapshot/1','repo':str(repo),'source_head':head,'files':hashes,
  'protected_names_including_untracked':all_protected_names(repo),'errors':errors,
  'ignored_file_bytes_checked':False,'note':'Ignored asset contents need separate fresh hashes; names and tracked bytes are protected here.'}
 result['snapshot_complete']=not errors
 result['remote_state']='OBSERVED' if records['remote_ref']['returncode']==0 else 'MISSING'
 result['remote_equals_local']=None
 if result['remote_state']=='OBSERVED':
  lines=records['remote_ref']['stdout'].strip().splitlines()
  result['remote_equals_local']=len(lines)==1 and lines[0].split()[0]==head
 for p,x in [(out/'workspace.json',result),(out/'tracked_hashes.json',snapshot)]:
  with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
 print(json.dumps({'head_matches':result['head_matches'],'snapshot_complete':not errors,'remote_state':result['remote_state'],'out':str(out)}))
 return 0 if result['head_matches'] and not errors else 2

def verify(a):
 repo=a.repo.resolve();s=json.loads(a.snapshot.read_text());bad=[]
 if str(repo)!=s['repo']:raise ValueError('Snapshot belongs to another repository path')
 for r in s['files']:
  if not r['protected']:continue
  p=repo/r['path']
  if not p.is_file() or p.is_symlink() or sha(p)!=r['sha256']:bad.append(r['path'])
 names=all_protected_names(repo)
 old=s.get('protected_names_including_untracked',[])
 added=sorted(set(names)-set(old));missing=sorted(set(old)-set(names))
 result={'status':'PROTECTED_BYTES_AND_NAMES_UNCHANGED' if not(bad or added or missing) else 'STOP',
  'changed':bad,'added':added,'missing':missing,'new_stage4_authorized':False,
  'scope':'Tracked protected byte hashes and all protected filenames; not ignored weight/tensor content.'}
 print(json.dumps(result,indent=2));return 2 if bad or added or missing else 0

def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
 c=sub.add_parser('capture');c.add_argument('--repo',type=Path,required=True);c.add_argument('--out',type=Path,required=True);c.add_argument('--expected-head',required=True)
 v=sub.add_parser('verify-protected');v.add_argument('--repo',type=Path,required=True);v.add_argument('--snapshot',type=Path,required=True)
 a=p.parse_args()
 try:return capture(a) if a.command=='capture' else verify(a)
 except (ValueError,OSError,KeyError)as e:print('STOP: '+str(e),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
