#!/usr/bin/env python3
"""Read-only, independently implemented FP05b scalar-cache re-evaluation.
Uses only stdlib + numpy; never imports EarthDelta, fits a policy, opens zarr,
loads torch weights, submits a job, or writes into the old run. No endpoint
parity claim: the native endpoint -> scalar step is a separate evidence gate.
The real run was NOT executed by the report author. Run --self-test for a
synthetic check; real execution requires the exact pinned repository files.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, math, sys
from pathlib import Path
from typing import Any
import numpy as np

HEAD='45edd51b563a626e01b31af24e0d95afa6d56d7b'
REL='plans/plan_v4_0923/run_20260924T104725Z_fp05b'
PROTOCOL_SHA='a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8'
BLOB_PINS={
 'cache/dev/candidate_results.json':'c23c73d9819ffc3a9acb2dbcf231455d1cce8948',
 'cache/dev/background_f0.json':'a625cfc03fc9e36fc83a7bba19b6eec46b6346b9',
 'cache/dev/cache_manifest.json':'6ca5c41449a9192a1ffb3b23c1e70b08f19b47bd',
 'policies/folds.json':'75382f11a6f75c4e42437471b7e42d88e22ab155',
 'policies/oof_predictions.json':'0384c5e09303890f17cb56088b53f44ae226c662',
 'policies/prediction_freeze.json':'38e76e61394c940d2c70e7ce6c29a0247b2a1133',
 'evaluation/paired_block_bootstrap.json':'947be4070c65a14d127e2f5bfcb230da43821a70'}
CANDIDATES=['reference','expert_0','expert_1','expert_2','expert_3']
METHODS=['F0','M0','M1','M2','M3','M4','M5']
LEADS=[6,24,72]

class EvidenceError(ValueError): pass

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def blob(b:bytes)->str:return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
def require(ok:bool,message:str)->None:
    if not ok: raise EvidenceError(message)
def read_json(p:Path)->Any:return json.loads(p.read_text(encoding='utf-8'))
def resolve_repo_path(raw:str,repo:Path)->Path:
    prefix='/mnt/afs/260010168/EarthDelta/'
    p=repo/raw[len(prefix):] if raw.startswith(prefix) else Path(raw)
    if not p.is_absolute():p=repo/p
    p=p.resolve()
    require(p.is_relative_to(repo),'Asset escapes repository; provide a reviewed asset-map amendment')
    return p

def check_ref(ref:dict,repo:Path,seen:dict)->Path:
    require(isinstance(ref,dict) and 'path' in ref and 'sha256' in ref,'Missing path/hash in reference')
    p=resolve_repo_path(ref['path'],repo);h=sha(p.read_bytes())
    require(h==ref['sha256'],f'Hash mismatch: {p}')
    seen[str(p)]=h;return p

def unpack(rows:list,actions:dict,bg:dict):
    ids=sorted(actions); require(len(ids)==112,'Expected frozen N=112')
    L={}; times={}; nonfinite=0
    for r in rows:
        key=(r['issue_id'],r['candidate_id'],int(r['lead_hours']))
        require(key not in L,f'Duplicate scalar cell: {key}')
        require(r['status'] in ('PASS','FAIL_NONFINITE'),'Unknown status')
        val=r['cpu_loss']
        if r['status']=='PASS':require(val is not None and math.isfinite(float(val)) and val>=0,'Invalid PASS loss')
        else:nonfinite+=1
        L[key]=(r['status'],val)
        if 'issue_time' in r:
            t=int(r['issue_time']);require(key[0] not in times or times[key[0]]==t,'Inconsistent issue time')
            times[key[0]]=t
    expected={(i,c,h) for i in ids for c in CANDIDATES for h in LEADS}
    require(set(L)==expected,'Matrix is not EXACTLY N x 5 x 3')
    require(nonfinite/len(L)<=.02,'Nonfinite fraction exceeds frozen limit')
    require(set(bg)==set(ids),'F0 issue set not identical')
    require(all(L[(i,'reference',h)][0]=='PASS' for i in ids for h in LEADS),'Invalid Fs reference')
    def value(i,c,h):
        s,v=L[(i,c,h)]
        return float(v) if s=='PASS' else float(L[(i,'reference',h)][1])
    m5=min(CANDIDATES,key=lambda c:(sum(value(i,c,24) for i in ids),CANDIDATES.index(c)))
    array=np.empty((len(ids),len(METHODS),len(LEADS)),dtype=np.float64)
    selected={}
    for n,i in enumerate(ids):
        require(all(actions[i][m] in CANDIDATES for m in ['M0','M1','M2','M3']),'Unknown action')
        require(actions[i]['M0']=='reference','M0 must be no-edit')
        oracle=min(CANDIDATES,key=lambda c:(value(i,c,24),CANDIDATES.index(c)))
        a={m:actions[i][m] for m in ['M0','M1','M2','M3']};a.update(M4=oracle,M5=m5)
        selected[i]=a
        for j,h in enumerate(LEADS):
            f0=bg[i]['f0_cpu'][str(h)]
            require(f0 is not None and math.isfinite(float(f0)) and f0>=0,'Invalid F0 scalar')
            array[n,0,j]=float(f0)
            for m,c in a.items():array[n,METHODS.index(m),j]=value(i,c,h)
    return ids,array,times,selected,m5

def resample(ids,array,times,block_factor=1,draws=10000):
    origin=int(dt.datetime(2019,7,6,12,tzinfo=dt.timezone.utc).timestamp())
    require(set(ids)<=set(times),'No exact issue times; supply the pinned admission manifest')
    blocks={i:((times[i]-origin)//(7*86400))//block_factor for i in ids}
    u=sorted(set(blocks.values()))
    S=np.array([np.sum(array[[n for n,i in enumerate(ids) if blocks[i]==b]],axis=0) for b in u])
    # Same declared resampling design and seed, independent implementation.
    idx=np.random.default_rng(20260924).integers(len(u),size=(draws,len(u)))
    sums=S[idx].sum(axis=1);point=S.sum(axis=0)
    results={};harm={}
    for j,h in enumerate(LEADS):
        denominator=sums[:,1,j]
        require(np.all(denominator>0),'Zero Fs bootstrap denominator')
        hd=(sums[:,1,j]-sums[:,0,j])/denominator
        hp=(point[1,j]-point[0,j])/point[1,j]
        harm[str(h)]={'point':float(hp),'ci':[float(v) for v in np.percentile(hd,[2.5,97.5])]}
        for m in METHODS:
            for base in ['M0','M1','F0']:
                mi,bi=METHODS.index(m),METHODS.index(base)
                d=(sums[:,bi,j]-sums[:,mi,j])/denominator
                g=(point[bi,j]-point[mi,j])/point[1,j]
                lo,hi=np.percentile(d,[2.5,97.5])
                results[f'{m}_vs_{base}_{h}h']={'point':float(g),'ci_low':float(lo),'ci_high':float(hi),
                    'status_vs_delta_min':'ABOVE' if lo>=.0034 else ('BELOW' if hi<.0034 else 'STRADDLE'),
                    'note':'Classification at 6h is diagnostic; 72h safety uses lower CI >= -0.0034, NOT superiority.'}
    return {'n_blocks':len(u),'block_ids':u,'draws':draws,'seed':20260924,
            'H_Fs_by_lead':harm,'effects':results}

def real_run(repo:Path):
    root=repo/REL;seen={};loaded={}
    for rel,want in BLOB_PINS.items():
        p=root/rel;b=p.read_bytes();require(blob(b)==want,f'Pinned git blob mismatch: {p}')
        seen[str(p)]=sha(b);loaded[rel]=json.loads(b)
    protocol_path=root/'protocol/cache_protocol_v1.json'
    pb=protocol_path.read_bytes();require(sha(pb)==PROTOCOL_SHA,'Protocol hash mismatch')
    seen[str(protocol_path)]=sha(pb);protocol=json.loads(pb)
    manifest=loaded['cache/dev/cache_manifest.json'];freeze=loaded['policies/prediction_freeze.json']
    require(manifest['passed'] is True and manifest['protocol_sha256']==PROTOCOL_SHA,'Bad cache certificate')
    require(freeze['cache_manifest_sha256']==seen[str(root/'cache/dev/cache_manifest.json')],'Freeze/cache mismatch')
    for key in ['candidate_results','background_f0','dev_protocol']:
        check_ref(manifest[key],repo,seen)
    for key in ['folds','oof_predictions','label_access_log']:
        check_ref(freeze[key],repo,seen)
    for ref in freeze['per_fold_files'].values():check_ref(ref,repo,seen)
    # Admission needed only as a timestamp manifest, never as a data loader.
    admissions=[]
    def scan(obj):
        if isinstance(obj,dict):
            if 'path' in obj and 'sha256' in obj and 'admission' in str(obj['path']) and str(obj['path']).endswith('.json'):
                admissions.append(obj)
            for val in obj.values():scan(val)
        elif isinstance(obj,list):
            for val in obj:scan(val)
    scan(protocol)
    pred=loaded['policies/oof_predictions.json'];require(pred.get('poisoned') is None,'Poisoned prediction file')
    ids,array,times,acts,m5=unpack(loaded['cache/dev/candidate_results.json']['rows'],pred['predictions'],
                                loaded['cache/dev/background_f0.json']['issues'])
    for ref in admissions:
        p=check_ref(ref,repo,seen);doc=read_json(p)
        if isinstance(doc,dict):
            for r in (doc.get('admission') or {}).get('admitted',[]):
                if r['issue_id'] in ids:
                    t=int(r['issue_time']);require(r['issue_id'] not in times or times[r['issue_id']]==t,'Admission time conflict')
                    times[r['issue_id']]=t
    require(set(times)>=set(ids),'Cannot recover exact pinned issue times')
    require(set(ids)==set(manifest['issue_ids']),'Action/cache issue mismatch')
    folds=loaded['policies/folds.json']['folds'];all_eval=[]
    for f in folds:
        all_eval+=f['eval_ids'];require(not (set(f['train_ids'])&set(f['eval_ids'])),'Fold id overlap')
        for t in f['train_ids']:
            require(all(abs(times[t]-times[e])>108*3600 for e in f['eval_ids']),'Support+buffer overlap')
    require(sorted(all_eval)==ids,'OOF coverage not exactly once')
    main=resample(ids,array,times);sensitivity=resample(ids,array,times,2)
    published=loaded['evaluation/paired_block_bootstrap.json']['primary_7day_blocks']['comparisons']
    diffs={}
    for name,r in published.items():
        key=f"{r['method']}_vs_{r['baseline']}_{r['lead_hours']}h"
        got=main['effects'][key]
        diffs[name]={k:float(got[k]-r[k]) for k in ['point','ci_low','ci_high']}
    # Different summation order can change last bits; this bound is an auditor scalar-reduction check,
    # NOT a change to a scientific acceptance threshold, and never used for S0 or anchor certification.
    require(all(abs(v)<1e-10 for d in diffs.values() for v in d.values()),'Published primary scalar/CI mismatch')
    require(all(sha(Path(p).read_bytes())==h for p,h in seen.items()),'Input changed during read-only audit')
    return {'status':'OBSERVED_LOCAL_RECOMPUTE','schema':'ed-auditor-native-recompute/1','commit':HEAD,
            'scope':'Scalar cache -> actions -> paired effects only; native endpoint recomputation and GPU provenance are separate gates.',
            'input_sha256':seen,'N':len(ids),'M5_static_action':m5,
            'primary':main,'sensitivity_14day_report_only':sensitivity,
            'published_primary_differences':diffs,'frozen_24h_conclusions_not_relabelled':True,
            'selection_counts':{m:{c:sum(a[m]==c for a in acts.values()) for c in CANDIDATES} for m in ['M1','M2','M3','M4']}}

def self_test():
    # Same data-independent ratios for all blocks makes the expected result exact.
    ids=[f'i{k}' for k in range(24)]
    origin=int(dt.datetime(2019,7,6,12,tzinfo=dt.timezone.utc).timestamp())
    times={i:origin+n*7*86400 for n,i in enumerate(ids)}
    a=np.ones((len(ids),len(METHODS),3));a[:,0,:]=[.99,.98,.97];a[:,METHODS.index('M3'),:]=.96
    result=resample(ids,a,times,draws=200)
    for h,want in zip(LEADS,[.03,.02,.01]):
        require(abs(result['effects'][f'M3_vs_F0_{h}h']['point']-want)<1e-12,'Lead-specific F0 test failed')
    return {'status':'SYNTHETIC_SELF_TEST_PASS','real_repository_data_read':False,'gpu_executed':False,
            'checks':['lead_specific_H','paired_F0_gain','Fs_denominator','block_resampling'],'n_checks':4}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path)
    ap.add_argument('--out',type=Path,required=True);ap.add_argument('--self-test',action='store_true');a=ap.parse_args()
    try:
        if a.self_test:result=self_test()
        else:
            require(a.repo is not None,'--repo required');repo=a.repo.resolve()
            require(not a.out.resolve().is_relative_to(repo),'Output must be outside source repo; do not overwrite old evidence')
            result=real_run(repo)
        a.out.parent.mkdir(parents=True,exist_ok=True)
        with a.out.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,ensure_ascii=False,allow_nan=False)
        print(json.dumps({'status':result['status'],'out':str(a.out)}))
    except (EvidenceError,OSError,KeyError,ValueError,TypeError) as exc:
        print(f'BLOCKED_OR_INVALID: {type(exc).__name__}: {exc}',file=sys.stderr);return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
