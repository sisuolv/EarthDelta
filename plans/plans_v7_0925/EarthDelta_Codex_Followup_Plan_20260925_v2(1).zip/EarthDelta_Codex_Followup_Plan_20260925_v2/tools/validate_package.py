#!/usr/bin/env python3
"""Validate package bytes, JSON and task DAG. No scientific authorization is produced."""
from __future__ import annotations
import argparse,hashlib,json,sys
from pathlib import Path
REQUIRED=['START_HERE_FOR_CODEX.md','FOLLOWUP_PLAN.md','EXECUTION_DAG.md','STOP_CONDITIONS.md','CODEX_TASKS.json','ARTIFACT_CONTRACT.md','TEST_PLAN.md','REPRODUCIBILITY.md','CURRENT_GAP_ANALYSIS.md','evidence/PLAN_AUDIT_RESULT.json','evidence/EVIDENCE_MANIFEST.json','evidence/REQUIRED_INPUTS.md','prompts/CODEX_EXECUTION_PROMPT.md']
FIELDS={'id','priority','depends_on','scope','commands','acceptance_criteria','evidence_outputs','stop_if','status','estimated_minutes'}
def validate(root):
 errors=[]
 for rel in REQUIRED:
  if not(root/rel).is_file():errors.append('Missing '+rel)
 for p in root.rglob('*.json'):
  try:json.loads(p.read_text())
  except (ValueError,UnicodeError)as e:errors.append('InvalidJSON '+str(p)+': '+str(e))
 if errors:return errors
 tasks=json.loads((root/'CODEX_TASKS.json').read_text())['tasks'];ids=[t['id']for t in tasks]
 if len(set(ids))!=len(ids):errors.append('Duplicate task IDs')
 graph={}
 for t in tasks:
  if not FIELDS<=t.keys():errors.append('Missing task fields '+t.get('id','?'))
  if not set(t['depends_on'])<=set(ids):errors.append('Unknown dependency '+t['id'])
  if t['status']=='DONE' and not t['evidence_outputs']:errors.append('DONE without evidence '+t['id'])
  if t.get('new_stage4_authorized')is True:errors.append('Unauthorized Stage4 flag '+t['id'])
  graph[t['id']]=t['depends_on']
 active=set();seen=set()
 def visit(i):
  if i in active:raise ValueError('DAG cycle '+i)
  if i in seen:return
  active.add(i)
  for d in graph.get(i,[]):visit(d)
  active.remove(i);seen.add(i)
 try:
  for i in graph:visit(i)
 except ValueError as e:errors.append(str(e))
 mp=root/'PACKAGE_MANIFEST.json'
 if not mp.is_file():errors.append('Missing PACKAGE_MANIFEST.json')
 else:
  m=json.loads(mp.read_text())
  expected={r['path']for r in m['files']}
  present={p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file() and p.name!='PACKAGE_MANIFEST.json' and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix!='.pyc'}
  if present!=expected:errors.append('Packagefile set differs from manifest')
  for r in m['files']:
   p=root/r['path']
   if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:errors.append('Hash mismatch '+r['path'])
 return errors

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',type=Path,required=True);a=p.parse_args()
 try:errors=validate(a.package.resolve())
 except (OSError,KeyError,TypeError,ValueError)as e:errors=[str(e)]
 print(json.dumps({'status':'PACKAGE_STRUCTURE_PASS'if not errors else 'STOP','errors':errors,'scientific_verification':False,'new_stage4_authorized':False},indent=2));return 2 if errors else 0
if __name__=='__main__':raise SystemExit(main())
