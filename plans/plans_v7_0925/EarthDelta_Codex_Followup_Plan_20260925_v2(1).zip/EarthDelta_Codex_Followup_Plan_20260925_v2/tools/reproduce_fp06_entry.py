#!/usr/bin/env python3
"""Reproduce four SYNTHETIC cases on the exact audited snapshots, not the user's live code."""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
PINS={'earthdelta/fp06_decision.py':'906d8b8ce56022eccf1039dfb23941cf1e3a80e0',
 'scripts/r5_audit_runner.py':'2742bf307b06818f2a7728fbb8b22386a2bf1116',
 'tests/test_fp06_decision.py':'ee1c11251bcb6e34cdd2143207f4724308e99a74'}
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 package=a.package.resolve();out=a.out.resolve()
 if out.is_relative_to(package):raise ValueError('Output must be outside package')
 out.mkdir(parents=True,exist_ok=False);snap=out/'isolated_snapshot'
 for rel,want in PINS.items():
  b=(package/'evidence/audited_sources'/rel).read_bytes()
  if blob(b)!=want:raise ValueError('Audited source changed: '+rel)
  dest=snap/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 for name in ('earthdelta','scripts'):(snap/name/'__init__.py').write_text('')
 env={**os.environ,'PYTHONPATH':str(snap),'PYTHONDONTWRITEBYTECODE':'1','CUDA_VISIBLE_DEVICES':''}
 base={k:{'status_vs_delta_min':'ABOVE'}for k in ('oracle_vs_Fs','oracle_vs_M1','M1_vs_Fs','M3_vs_Fs','M3_vs_M1')}
 base['M3_vs_Fs_72h']={'status_vs_delta_min':'ABOVE','harm72_guard_pass':True};rows=[]
 for name,val,want in [('missing',None,'CONTINUE_NEXT_ITERATION'),('string_false','false','CONTINUE_NEXT_ITERATION'),('boolean_false',False,'INVALID'),('recorded_status_fixture',True,'PIVOT_STATIC')]:
  data={'comparisons':json.loads(json.dumps(base))}
  if val is not None:data['evidence_valid']=val
  if name=='recorded_status_fixture':
   data['comparisons']['oracle_vs_Fs']['status_vs_delta_min']='STRADDLE'
   for k in ('oracle_vs_M1','M1_vs_Fs','M3_vs_Fs','M3_vs_M1'):data['comparisons'][k]['status_vs_delta_min']='BELOW'
  ip=out/(name+'.json');ip.write_text(json.dumps(data));op=out/(name+'_out')
  cmd=[sys.executable,str(snap/'scripts/r5_audit_runner.py'),'fp06-decision','--inputs',str(ip),'--out',str(op)]
  start=time.perf_counter();r=subprocess.run(cmd,cwd=snap,env=env,capture_output=True,text=True,timeout=30)
  (out/(name+'.log')).write_text(r.stdout+r.stderr)
  obj=json.loads((op/'decision.json').read_text())
  rows.append({'case':name,'input_evidence_valid':'ABSENT' if val is None else val,'verdict':obj['verdict'],'expected_snapshot_behavior':want,'matches':obj['verdict']==want,'returncode':r.returncode,'elapsed_seconds':time.perf_counter()-start,'argv':cmd})
 result={'status':'AUDITED_SNAPSHOT_BUG_REPRODUCED' if all(r['matches'] for r in rows) else 'PROBE_MISMATCH','cases':rows,'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'new_stage4_authorized':False,'weather_data_read':False,'GPU_executed':False,'scope':'Synthetic snapshot demonstration only. A fixed live repository must instead reject the first two cases.'}
 (out/'probe_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
 return 0 if all(r['matches']for r in rows) else 2
if __name__=='__main__':raise SystemExit(main())
