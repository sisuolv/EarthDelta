# 8–10 小时后续执行计划

**目标不是“把所有表变绿”，而是用最少成本改变研究决策。**
安排540分钟串行时间盒，预留至600分钟处理环境/缺件；可并行的2022元数据/WBX取证会缩短关键路径。
`estimated_minutes`为资源分配上限，不是未运行工作的耗时预测。真实elapsed必须另记。
本轮**不分配新Stage4、bank训练或confirm作业**；最多准备一份人工待批的GPU诊断/单因素实验协议。

已知baseline：remote `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`；规范计划ZIP Gitblob e904950e5ac85db9c48c7c6b48a417e0898aa9e1。
所有输出在 `$RUN`（仓库外），历史 `$REPO/plans/plan_v4_0923/run_20260924T104725Z_fp05b` 不可写。
`NEW_AFTER_IMPLEMENTATION`是要求Codex实现的接口，不是声称仓库已有该CLI；
`NEW_AFTER_GATE_REPAIR`是现有CLI必须先修复/验收后才能用；工具脚本已随本包提供。

## 执行顺序及每项合同

## FP-06a-R2 — 固定实际工作区、规范ZIP、source/overlay合同与AFS原件

优先级：P0；依赖：无；预算：45分钟时间盒。
资源：CPU / metadata and bounded file hashing。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
python "$PKG/tools/workspace_snapshot.py" capture --repo "$REPO" --out "$RUN/entry" --expected-head 8ab914b877fcf2ace8c0e8da28cd8b0c47f22714
python "$PKG/tools/validate_package.py" --package "$PKG"
```

输出：`entry/workspace.json`；`entry/tracked_hashes.json`；`entry/receipts_index.json`；`entry/overlay_contract_observed.json`。

成功标准：git HEAD/branch/status and origin comparison independently recorded; missing not default clean；S0 raw/result/source/reference/overlay manifest copied or explicitly MISSING; no GPU rerun just to replace old receipts；Canonical ZIP blob matches e904950e5ac85db9c48c7c6b48a417e0898aa9e1。

STOP：HEAD or protected asset mismatch without reviewed version amendment；A missing receipt is replaced by a narrative。
失败后pivot：缺原件先写精确索取清单；可继续不依赖它的CPU修复，不启动Stage4。

## FP-06b-R2 — 旧500发散与v2/H32资产分离，回放质量门及全部消费边界

优先级：P0；依赖：FP-06a-R2；预算：75分钟时间盒。
资源：CPU first; optional GPU replay requires separate explicit approval。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
python -m pytest -q tests/test_fs_quality_gate.py tests/test_fs_static_adapter.py tests/test_plan_gate_chain.py
NEW_AFTER_IMPLEMENTATION: python scripts/r7_fs_lineage_audit.py --inputs "$RUN/entry/receipts_index.json" --out "$RUN/fs_lineage"
```

输出：`fs_lineage/assets.json`；`fs_lineage/quality_replay.json`；`fs_lineage/negative_entry_tests.json`；`fs_lineage/stage4_readiness.json`。

成功标准：Legacy bad Fs rejected through real consumer CLI; no surviving-expert cherry-pick；Complete FsFitRecord length/count/finiteness/last-update/fixed-final-panel checks, exact asset and formal protocol binding；Current H32 Q1-Q6 and four replicas/selected asset verified or BLOCKED; unique old kernel cause remains distinct。

STOP：Legacy500 asset accepted；Missing quality trace or final checkpoint panel is treated as pass；Any real Stage4 launched。
失败后pivot：H32不合法则当前bank停用；不以merge等价或剔除坏副本挽救旧库。新训练仅提出新协议。

## FP-06c-R2 — 修FP06入口、erratum/OOF gate闭合及错误退出传播

优先级：P0；依赖：FP-06a-R2；预算：105分钟时间盒。
资源：CPU; patch new audit entrypoints, preserve old artifacts and core17。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
python "$PKG/tools/reproduce_fp06_entry.py" --package "$PKG" --out "$RUN/entry_bug_reference"
python -m pytest -q tests/test_fp06_decision.py tests/test_fp05_consumption_chain.py tests/test_policy_oof_isolation.py
NEW_AFTER_IMPLEMENTATION: python -m pytest -q tests/test_r7_release_gate.py tests/test_r7_erratum_contract.py
```

输出：`consumer/tests.log`；`consumer/junit.xml`；`consumer/source_amendment.json`；`consumer/mutation_cases.json`。

成功标准：missing/stringfalse/self-declaredstatus/changedthreshold cannot get scientific authorization；Consume trusted raw-bound gate bundle; recompute CI classification; exactV1-V8+matrix+dev semantics；Erratum source includes self; all old24h comparisons/point/CI preserved; invalid gates nonzero; no old overwrite。

STOP：Oldprotocol/oldoutcome overwritten；rc0 alone counted as acceptance；Frozen d or sample/lead set changed。
失败后pivot：仍有口子则只做修复与schema/logic测试，正式FP06和下游scientific run保持锁定。

## FP-06d-R2 — 独立冻结标量重算、分lead配对F0勘误和FP06正式收尾

优先级：P0；依赖：FP-06a-R2, FP-06b-R2, FP-06c-R2；预算：60分钟时间盒。
资源：CPU, NumPy; no zarr/weights/model。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
python "$PKG/tools/recompute_frozen_fp05b.py" --repo "$REPO" --out "$RUN/scalar_recompute.json"
NEW_AFTER_GATE_REPAIR: python scripts/r5_score_erratum.py --protocol "$REPO/plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/cache_protocol_v1.json" --protocol-sha256 a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8 --cache-manifest "$REPO/plans/plan_v4_0923/run_20260924T104725Z_fp05b/cache/dev/cache_manifest.json" --prediction-freeze "$REPO/plans/plan_v4_0923/run_20260924T104725Z_fp05b/policies/prediction_freeze.json" --old-evaluation "$REPO/plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/paired_block_bootstrap.json" --out "$RUN/erratum"
NEW_AFTER_GATE_REPAIR: python scripts/r5_audit_runner.py fp06-decision --inputs "$RUN/verified_fp06_inputs.json" --out "$RUN/fp06"
```

输出：`scalar_recompute.json`；`erratum/effects_by_lead.json`；`erratum/paired_F0_intervals.json`；`fp06/decision.json`；`fp06/gate.json`。

成功标准：Exact frozen112×5×3 complete; oldCI independently regenerated with declared draw unit/seed；All methods direct pairedF0 CI at eachlead; no subtraction of marginalCI endpoints；Rule3 PIVOT_STATIC only after integrity/admission check; explicitly not M1 barPASS or Stage4 approval。

STOP：Original24h discrepancy beyond auditor scalar tolerance；Missingreceipt or matrix invalid upgraded to formalPASS；ChangedN/seed/d/leadset。
失败后pivot：标量不一致先定位聚合/输入；不改冻结结果，不做择优重采样。

## WBX-02d — 修WBX有效时间/来源权限，恢复TierA/B原件并全量对账

优先级：P0；依赖：FP-06a-R2；预算：60分钟时间盒。
资源：CPU; reuse existing arrays/receipts only。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
python -m pytest -q tests/test_wbx_evaluate.py tests/test_wbx_export.py tests/test_wbx_regrid.py
NEW_AFTER_IMPLEMENTATION: python -m pytest -q tests/test_r7_wbx_capability.py
NEW_AFTER_IMPLEMENTATION: python scripts/r7_wbx_receipt_audit.py --inputs "$RUN/entry/receipts_index.json" --out "$RUN/wbx"
```

输出：`wbx/capability_tests.json`；`wbx/full312_comparison.csv`；`wbx/upstream_provenance.json`；`wbx/decision.json`。

成功标准：2020init+72h2021valid refused before real read; fakearraycoords/authorizedoverride refused；Actual upstream modules and commits verified; native bitwise vs officialmetric tolerance separated；Expected312 keys enumerated beforecompare; allmissing/mismatches retained; >=2 rawmanualpairs。

STOP：Forbiddenyearactualread；Onlymatchingrows kept；TierB missingtable calledPASS。
失败后pivot：缺原件标MISSING，不新跑benchmark填空；不把WBX2c作为战略建议前提。

## FP-07d — 修只读绑定后解释固定收益/专家互补/路由遗憾

优先级：P1；依赖：FP-06c-R2, FP-06d-R2；预算：75分钟时间盒。
资源：CPU, existingcache only; nonewmodel fitting。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
NEW_AFTER_IMPLEMENTATION: python -m pytest -q tests/test_r7_diagnostic_isolation.py
NEW_AFTER_BINDING_REPAIR: python scripts/r5_diagnose.py freeze-diagnostics --inputs "$RUN/diagnostic_inputs.json" --out "$RUN/diagnostic_protocol"
NEW_AFTER_BINDING_REPAIR: python scripts/r5_diagnose.py diagnose --inputs "$RUN/diagnostic_inputs.json" --protocol "$RUN/diagnostic_protocol/protocol.json" --out "$RUN/diagnostics"
python "$PKG/tools/workspace_snapshot.py" verify-protected --repo "$REPO" --snapshot "$RUN/entry/tracked_hashes.json"
```

输出：`diagnostics/headroom_decomposition.json`；`diagnostics/routing_regret.json`；`diagnostics/centering_sensitivity.json`；`diagnostics/REPORT.md`；`diagnostics/old_hashes_after.json`。

成功标准：Protocolhash pinned externally and inputpaths exactlybound; recursivechild hashes checked before/after；Switchrate/regret/centeredadvantage/near-ties/fold/monthsupport reported; no label/tuning feedback tooldresult；PCAcoefficients compared onlyaftermapping back commonfeaturebasis; MDE fromoldpanel notposthocpower proof。

STOP：Swappedinputs accepted；Oldchildfile change undetected；Newregime/subgroup promoted to confirm oroldpass。
失败后pivot：库无额外空间→先候选构造或静态路线；库有空间但路由差→仅提出一个特征/utility模型对照。

## FP-08c — 2022既有日志/元数据根因分流，暂不读模型效果

优先级：P1_PARALLEL；依赖：FP-06a-R2；预算：30分钟时间盒。
资源：CPUmetadata; noforecast/inference, noyearselectionbyskill。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
NEW_AFTER_IMPLEMENTATION: python scripts/r7_data_metadata_audit.py --log "$REPO/checkpoints/pull_2022.log" --metadata-only --out "$RUN/year2022"
```

输出：`year2022/findings.json`；`year2022/required_integrity_reads.json`；`year2022/access_ledger.json`。

成功标准：Failureclass network/object/manifest/schema/decoder separated with actualevidence；Sharedparser defect triggers scopedlegacyrecheck；2021/2022 accessledger updated; localmissinglognotcalleddataabsent。

STOP：Forecastskillread；Automatic2021fallback basedon performance；Freshdata download withoutapproval。
失败后pivot：缺日志保留BLOCKED，不阻塞旧cacheCPU诊断；数值验数另提最小授权。

## FP-09-HUMAN — 整理有限重构、当前库收尾或未来confirm的人工决策框架

优先级：P1；依赖：FP-06b-R2, FP-06d-R2, FP-07d；预算：60分钟时间盒。
资源：CPU/documentation; noGPU。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
MANUAL_ANALYSIS: write "$RUN/strategy/DECISION_FRAMEWORK.md" and "$RUN/strategy/NEXT_EXPERIMENT_PROTOCOL.DRAFT.json" from verifiedevidence
```

输出：`strategy/DECISION_FRAMEWORK.md`；`strategy/NEXT_EXPERIMENT_PROTOCOL.DRAFT.json`；`strategy/claims.json`。

成功标准：One falsifiablemechanism perproposed experiment with directgain/strongstatic/responsecontrols；Originalnegative remains; noclaim all dynamiceditinginvalid；Human_decision remainsMISSING until actual userauthorization; noexecutor-signed approval。

STOP：AutomaticStage4 approval；Novelty attributed to testcount/S0identity；Changedoldthreshold labeled preregistered。
失败后pivot：无法提出高信息可证伪修正则建议停止当前配置；不把一次小样本负结果包装成完整负结果论文。

## FP-10-CLOSE — 收集实际完成/阻塞证据，形成可重放handoff

优先级：P1；依赖：FP-06a-R2, FP-06b-R2, FP-06c-R2, FP-06d-R2, WBX-02d, FP-07d, FP-08c, FP-09-HUMAN；预算：30分钟时间盒。
资源：CPU。

输入：按 evidence/REQUIRED_INPUTS.md 和前驱 evidence_outputs 读取真实原件，另参考对应 R7 finding；缺输入不得自行构造PASS。

命令／实施接口：
```bash
python "$PKG/tools/workspace_snapshot.py" verify-protected --repo "$REPO" --snapshot "$RUN/entry/tracked_hashes.json"
python "$PKG/tools/validate_package.py" --package "$PKG"
```

输出：`HANDOFF.md`；`TASK_RESULTS.json`；`FINAL_MANIFEST.json`；`CLAIMS.md`。

成功标准：Everytask has actualcommands/rc/time/hash and scopedstatus；Blockedbranches closedwithMISSING and noautomaticretry；Finalarchivehashandfilelist saved; nooldoutput overwritten。

STOP：DONE without evidence；Background/future work falsely stated ascomplete。
失败后pivot：时间盒到即保存部分完成，不以无限认证或追加样本延长。


## 预先公开的战略框架（框架，不是决定）

**继续受限重构**：明确有某个可检验瓶颈，而不只是“样本不够”。先量化 oracle−M1，而非只看oracle−Fs。
若当前库额外空间很小，改善route本身最多回收有限剩余；优先讨论候选构造/固定适配，而非增加复杂路由。
若有互补空间却选不好，再比较同特征/预算的direct-gain与error/response分解，严格测决策regret。

**保留最强研究问题**：能否仅用起报时可用历史，预测候选参数编辑对未来预报的响应与收益，
并在错误预测下通过拒绝编辑控制伤害？这比“动态LoRA用于天气”更具体；它目前是待证假设，不是已建立贡献。
须证明优于强固定PEFT、简单条件路由和代价相同的直接utility预测；跨未见state/edit泛化比增加模块数量更有说服力。

**当前配置收尾**：若工程正确而oracle额外空间、实际utility或安全性仍不足，又没有一个单因素高信息修正，
建议停止当前K4配置。不能据此宣判整个动态编辑路线无效；单配置负结果也不足以直接声称一篇完整负结果论文。

**未来confirm**：必须独立数据资格、候选/规则/预算冻结、人工批准。现有2019H2已开发使用，
2020H2已曝光；2021/2022完整性PASS不等于科学未曝光。不能在两年看完skill后选择一年。
如果目标是确认负结果，也需单独预注册estimand与功效设计。

## 不形成循环前提
现有负结果阻止自动扩样和成功宣称，但不禁止为解释负结果设计新实验。
新实验不要求“先证明自己有效”，只要求工程安全、数据合规、可证伪目标和明确人工授权。

## 入口实现补充
FP06 wrapper错误是证据决策误升级，不是已观测的自动GPU提交；修复后依然保留“决策不授予GPU”原则。
INVALID/缺证据应非零或由统一runner强制检查typedgate；正常负面科学判定可返回0，但new_stage4_authorized必须false。
最新S0原件缺失不阻止旧标量CPU复算；正式旧FP06绑定原生产链；新Stage4才必须核最新release的S0/质量合同。
