"""Synthetic package tests only; these do not use real weather data."""
import copy,importlib.util,json,sys,unittest
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('nativeaudit',ROOT/'tools/recompute_frozen_fp05b.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
t=importlib.util.spec_from_file_location('snapshot',ROOT/'tools/workspace_snapshot.py');w=importlib.util.module_from_spec(t);t.loader.exec_module(w)

def fixture():
 ids=[f'i{k:03}' for k in range(112)];rows=[];acts={};bg={}
 for n,i in enumerate(ids):
  acts[i]={'M0':'reference','M1':'expert_0','M2':'expert_0','M3':'expert_1'}
  bg[i]={'f0_cpu':{'6':.99,'24':.98,'72':.97}}
  for c in m.CANDIDATES:
   for h in m.LEADS:rows.append({'issue_id':i,'candidate_id':c,'lead_hours':h,'status':'PASS','cpu_loss':1.0 if c=='reference' else .96,'issue_time':1562414400+n*21600})
 return rows,acts,bg

class Contracts(unittest.TestCase):
 def test_lead_specific_selftest(self):self.assertEqual(m.self_test()['status'],'SYNTHETIC_SELF_TEST_PASS')
 def test_exact_matrix(self):
  rows,a,b=fixture();ids,x,_,_,_=m.unpack(rows,a,b);self.assertEqual(x.shape,(112,7,3))
 def test_duplicate_rejected(self):
  r,a,b=fixture();r.append(r[0].copy())
  with self.assertRaises(m.EvidenceError):m.unpack(r,a,b)
 def test_missing_cell_rejected(self):
  r,a,b=fixture();r.pop()
  with self.assertRaises(m.EvidenceError):m.unpack(r,a,b)
 def test_unknown_candidate_rejected(self):
  r,a,b=fixture();r[0]['candidate_id']='oracle'
  with self.assertRaises(m.EvidenceError):m.unpack(r,a,b)
 def test_nan_pass_rejected(self):
  r,a,b=fixture();r[1]['cpu_loss']=float('nan')
  with self.assertRaises(m.EvidenceError):m.unpack(r,a,b)
 def test_reference_failure_rejected(self):
  r,a,b=fixture();r[0]['status']='FAIL_NONFINITE';r[0]['cpu_loss']=None
  with self.assertRaises(m.EvidenceError):m.unpack(r,a,b)
 def test_missing_f0_rejected(self):
  r,a,b=fixture();b.pop('i000')
  with self.assertRaises(m.EvidenceError):m.unpack(r,a,b)
 def test_wrong_noedit_rejected(self):
  r,a,b=fixture();a['i000']['M0']='expert_0'
  with self.assertRaises(m.EvidenceError):m.unpack(r,a,b)
 def test_registered_fallback(self):
  r,a,b=fixture()
  for row in r:
   if row['issue_id']=='i000' and row['candidate_id']=='expert_1' and row['lead_hours']==24:row.update(status='FAIL_NONFINITE',cpu_loss=None)
  ids,x,*_=m.unpack(r,a,b);self.assertEqual(x[0,m.METHODS.index('M3'),1],1.)
 def test_protected_prefixes(self):
  self.assertTrue(w.is_protected('earthdelta/static_adapter.py'))
  self.assertTrue(w.is_protected('plans/plan_v4_0923/run_X/evaluation/z.json'))
  self.assertFalse(w.is_protected('scripts/r5_audit_runner.py'))
 def test_frozen_threshold_artifact(self):
  c=json.loads((ROOT/'evidence/S0_OVERLAY_CONTRACT.json').read_text());self.assertEqual(c['frozen_parity_tolerance'],1e-5);self.assertEqual(c['required_steps'],[1,4,12]);self.assertFalse(c['raw_s0_file_obtained'])
 def test_conditional_claims(self):
  a=json.loads((ROOT/'evidence/SUMMARY_ARITHMETIC.json').read_text());self.assertFalse(a['bootstrap_CIs_regenerated']);self.assertLess(abs(a['M3_minus_M1']+3.0192762416195793e-6),1e-16)
 def test_future_tasks_not_completed(self):
  ts=json.loads((ROOT/'CODEX_TASKS.json').read_text())['tasks']
  for t in ts:
   if t.get('execution_role')!='HISTORY_ONLY_NOT_DAG_GATE':self.assertEqual(t['status'],'TO_BE_RUN');self.assertFalse(t['new_stage4_authorized'])
if __name__=='__main__':unittest.main()
