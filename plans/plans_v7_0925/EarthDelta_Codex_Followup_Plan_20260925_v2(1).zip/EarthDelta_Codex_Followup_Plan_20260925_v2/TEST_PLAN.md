# 测试层级

## A. 已在本审查执行
精确Gitblob匹配的 fp06_decision.py、r5_audit_runner.py、test_fp06_decision.py；
5个原test本轮通过。另4个入口探针：missing、stringfalse、false、原记录status路径。
见evidence/FP06_ENTRY_PROBE.json。这是CPU隔离小子集，不是最新48项或全仓库测试。
独立摘要算术与CSV blob核对见SUMMARY_ARITHMETIC；没有重跑实际1680cell/bootstrap。

## B. Codex需新增并实际运行的回归
1. FP06：missing/null/字符串false/整数/自填true、缺gate引用、错hash、伪status、改delta、缺CI、boundary equality；INVALID和缺证据禁止后继。
2. Fs：旧坏trace、少样本重复、zip长度错位、最后optimizer.step后非有限、缺同finalpanel、缺副本、wrongFs/hash、differentnormalization；从真实consumer检查拒绝，不只helper。
3. OOF/cache：缺V2或任一V1–V8、重复/漏/extra1680cells、错误dev链、F0读取hash变、mixedrole、train/val/support越界。
4. Poison：eval+purged两种NaN/1e9，逐fold完整参数/预测hash；禁止缓存命中代替重新拟合。训练标签正对照区分“模型没用任何label”与真正隔离。
5. Erratum：逐leadH/F0不同的合成反例；24h均值或CI改变但status相同必须失败；缺一个comparison失败；gate=false CLI非零；pairedF0CI与H_CI不同。
6. FP07：args.inputs替换、protocolhash更改、子文件修改、读取后才建before、输出覆盖旧目录；所有情况I/O前拒绝或非零失败。
7. WBX：2020init+72h跨2021、2021实际coords伪2020参数、authorized测试override生产使用、singlechunk缺provenance、climatology/history年份；禁越权读取。
8. 新environment：core安装与officialGPU/WBX安装分开；精确module-origin与source/wheelhash；native缺xformers是预期dependencyFAIL，非hardwareFAIL。

## C. GPU gate（未来，仅获授权且确有缺口才跑）
先恢复已有原件，不能靠重跑补造历史冻结时序。
若需独立fresh S0/加载验证，先冻结overlay/callgraph/data/权重/预算；保留原失败与每次attempt。
S0未过、质量门未过，绝不Stage4。仅分配GPU不算模型执行，模型执行不算science。

## D. 科学核验
原冻结OOF/区块/样本数/threshold不变；直接与M1/F0对照，oracle与可部署策略分开。
M3≈M1不是等价性证明，positivevsFs也不是动态必要性。样本级row数量不是独立天气过程数量。
任何新增特征/模型实验必须另有新protocol；当前FP07只描述现有输出。

## E. 包自测
运行 `python -m unittest discover -s tests -v` 与 tools/validate_package.py。
这些测试只验证包内工具、合成标量处理和DAG，不认证真实天气结果或Stage4授权。
