# EarthDelta v2：先修可信证据链，再决定研究投入

**审查基线：`8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`；分支 `audit/round2-review-20260921`。**
验收基准是仓库 `plans/plan_v6_0925/` 内的88663字节计划ZIP，不是此前聊天的同名ZIP。
本包审查已实际读取代码和跟踪产物，并在隔离CPU副本重跑5个原测试及4个入口反例；不是“所有证据不可读”。
最新 AFS GPU 原件仍缺，因此不把文档登记的S0成功等同于已独立验收。

## 第一件事
依次读 FULL_REVIEW.md、evidence/PLAN_AUDIT_RESULT.json、CURRENT_GAP_ANALYSIS.md、
STOP_CONDITIONS.md、FOLLOWUP_PLAN.md、EXECUTION_DAG.md、CODEX_TASKS.json。
本包的SOURCE/ASSET/PROTOCOL常量用于取证，不能替代执行机fresh hash。

```bash
export REPO=/mnt/afs/260010168/EarthDelta
export PKG=/absolute/path/to/EarthDelta_Codex_Followup_Plan_20260925_v2
export RUN=/mnt/afs/260010168/earthdelta_audit_v2/$(date -u +%Y%m%dT%H%M%SZ)
python "$PKG/tools/workspace_snapshot.py" capture --repo "$REPO" --out "$RUN/entry" --expected-head 8ab914b877fcf2ace8c0e8da28cd8b0c47f22714
python "$PKG/tools/validate_package.py" --package "$PKG"
```
`RUN`必须在仓库外。不同HEAD/dirty不是自动reset许可；记录diff，先解释版本变化再继续。
不要为了聊天缺附件重跑已有训练；先在AFS定位 REQUIRED_INPUTS.md 原路径。

## 本包授权边界
默认只做现有证据读取、CPU独立复算、消费入口修复、只读诊断和方案准备。
**不自动启动新的Stage4、训练、外部模型API或confirm效果评估。**
旧Stage4缓存已有真实历史产物；允许读取它，不把“禁止新运行”说成“历史没执行”。
若原件无法取得，继续能独立完成的CPU任务并输出MISSING；不能用自填true通过 gate。

## 高优先级实质问题
`r5_audit_runner.py:28`把缺失或字符串false变成true（本轮已复现）。
旧500-step坏Fs必须拒绝；当前H32有真实质量门，必须按asset lineage核验，不混成一个问题。
FP05b仍BELOW/STRADDLE；不是零正效应，但路由没有证明胜过固定专家。
所有代码修正要有新source manifest；不得改原evaluation、协议、split或17个认证core pin后沿用旧资格。

## 交付
按DAG写evidence；命令/时间/退出码/真实job/哈希必须实存。
区分 ENGINEERING_PASS、EXPERIMENT_EXECUTED、SCIENTIFIC_SUPPORT、NOVELTY_SUPPORT。
策略最终由人决定，不由Codex根据“测试全绿”自动批准。
