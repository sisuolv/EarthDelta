```json
{
  "overall_verdict": "PARTIALLY_EXECUTED",
  "actual_remote_head": "8ab914b877fcf2ace8c0e8da28cd8b0c47f22714",
  "branch": "audit/round2-review-20260921",
  "local_head": null,
  "local_worktree_status": "MISSING",
  "local_remote_sync_status": "MISSING",
  "s0_verdict": "REPORTED_OVERLAY_PASS_NEW_RAW_RECEIPTS_MISSING",
  "fs_divergence_verdict": "LEGACY_500_STEP_FAILURE_REAL; CURRENT_H32_HAS_QUALITY_GATE; CURRENT_RELEASE_CHAIN_NOT_CLOSED",
  "fp05b_value_verdict": "POSITIVE_SMALL_CONDITIONAL_DEV_EFFECT_VS_FS_BUT_BELOW_0.0034; DYNAMIC_INCREMENT_VS_M1_NOT_DEMONSTRATED",
  "novelty_verdict": "PLAUSIBLE_RESEARCH_HYPOTHESIS_NOT_ESTABLISHED",
  "stage4_authorization": "BLOCKED_NEW_RUN; EXISTING_FROZEN_CACHE_READ_ONLY_ALLOWED",
  "fp06_expected_rule_path_if_evidence_valid": "RULE_3_PIVOT_STATIC",
  "fp06_formal_validated_execution": "MISSING",
  "independent_review_execution": {
    "repository_test_subset": 5,
    "repository_test_subset_passed": 5,
    "entry_probe_cases": 4,
    "full_repository_pytest": false,
    "new_gpu_jobs": 0,
    "full_1680_scalar_recompute": false,
    "summary_arithmetic_and_source_blob_checks": true
  },
  "labels": {
    "ENGINEERING_PASS": "PARTIAL; known entry failures remain",
    "EXPERIMENT_EXECUTED": "HISTORICAL_ARTIFACTS_OBSERVED; latest_AFS_GPU_receipts_missing",
    "SCIENTIFIC_SUPPORT": "LIMITED_RECORDED_DEV_RESULT; no dynamic-over-static or confirm success",
    "NOVELTY_SUPPORT": "INCONCLUSIVE"
  },
  "blocking_items": [
    "R7-03: latest S0 raw/source/environment chain",
    "R7-05/R7-06: asset-specific Fs stability replay and current consumer gate",
    "R7-07: FP06 CLI fail-open reproduced",
    "R7-08/R7-09: erratum numerical and scalar consumption contract",
    "R7-10: FP07 input/child-hash binding",
    "R7-11: WBX valid-time/provenance gate",
    "R7-12: frozen dynamic route did not clear bar; no automatic expansion",
    "R7-14: raw TierB and2022 inputs absent"
  ],
  "next_plan_priority": [
    "FP-06a-R2: freeze source/overlay/receipts",
    "FP-06b-R2: legacy-vs-H32 lineage and fail-closed replay",
    "FP-06c-R2: fix FP06 and erratum/OOF entry contracts",
    "FP-06d-R2: independent frozen scalar recompute, append-only erratum",
    "WBX-02d: exact valid-time/provenance capability",
    "FP-07d: bound read-only mechanism diagnostics",
    "FP-08c: existing2022 logs/metadata, parallel",
    "FP-09-HUMAN: bounded redesign/closure/confirm framework",
    "FP-10-CLOSE: reproducible handoff and no implicit Stage4"
  ],
  "v6_task_status_file": "evidence/TASK_STATUS_V6.json",
  "finding_file": "evidence/FINDINGS.json",
  "limitations": [
    "Not all long raw trace numeric cells were inspected or re-evaluated.",
    "No latest AFS result files or full weights were obtained.",
    "Five exact repository tests are not the full suite or the MD-reported48 tests.",
    "No raw weather tensor/1680-row scalar re-bootstrap was executed by the reviewer.",
    "No absence-of-related-work or empirical novelty proof is claimed."
  ]
}
```

# EarthDelta 独立研究与工程审查（2026-09-25，v2）

## 1. 总判断、版本与证据边界

**总体 PARTIALLY_EXECUTED；新Stage4 BLOCKED。值得继续一轮有限的取证与机制诊断，不值得直接扩大当前K4路由实验。**
远端HEAD `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`，上一实现提交 `85ed929f565191cf428ba8d491000542e55fe49e`；旧FP05冻结基线 `45edd51b563a626e01b31af24e0d95afa6d56d7b`。
已真实读取远端、规范ZIP和代码，不采用此前对话中“完全无法读取证据”的错误总述。
本地连接404，所以实际AFS工作区、dirty及与origin同步没有被确认。远端ahead2不是本地同步证明。[R7-01]

规范ZIP为88663字节，SHA a3adbf8c5e93d0e44a4a5dd1976754c9af113c8451a14a7875cc9d6a98b318b5，
Gitblob e904950e5ac85db9c48c7c6b48a417e0898aa9e1，已恢复解压并核对；不要与上一条消息同名77433字节包混用。[R7-02]

本轮实测5个原FP06测试通过，但4个入口探针揭示fail-open。最新48测试属于MD摘要，没有被本轮完整重跑。
旧raw GPU JSON有嵌入job记录，最新pt-lujnmfhg仅取得文档索引。没有新的GPU、权重/端点freshhash、完整1680cell重bootstrap。
长raw trace和diff只读相关区间，不能将此报告称“全仓库逐字全覆盖认证”。具体见READ_SCOPE和EVIDENCE_MANIFEST。

## 2. 规范v6任务四层状态

| 任务 | 状态 | 代码 / CPU | GPU或真实执行 | 科学目标 / 限定 |
|---|---|---|---|---|
| FP-00 | DONE | 历史只读盘点记录 | 不要求GPU | 不代表当前本地状态 |
| FP-01 | DONE（原范围） | 指定配置S0逻辑 | 旧认证；最新原件缺 | 仅数值管线 |
| FP-03 | DONE（H32资格） | Q1–Q6与历史测试 | V2认证记录 | 非样本外有益/普遍稳定 |
| FP-04 | DONE（资格） | 共同Fs/组装逻辑 | B-J认证记录 | 训练组与probe范围 |
| FP-05a | DONE | 曝光/证书重建产物 | 只读CPU，无新GPU | D1纠正已记录 |
| FP-05b | DONE（产物生成） | cache/OOF/score记录 | C-J计算记录；raw链待补 | 小正DEV效应，未达bar |
| WBX-01A-code | DONE（代码） | 官方组件复用 | 原TierA receipt缺 | 非天气效用 |
| WBX-01B-code | DONE（代码） | TierB对账实现 | 原312表/job缺 | 不升级真运行PASS |
| FP-02 | PARTIALLY_DONE | 多入口已有门 | 全链未闭合 | 仍有绕过风险 |
| FP-06a | BLOCKED | 全证据封存待补 | AFS receipt/endpoints缺 | 原始数字独立链未闭合 |
| FP-06b | PARTIALLY_DONE | lead修复及erratum已有 | 真实新勘误产物缺 | 验收不应只比status |
| FP-06c | PARTIALLY_DONE | 本轮5原test过；入口bug复现 | 无需GPU；可信正式receipt缺 | 规则路径不等于正式决定 |
| FP-07a | PARTIALLY_DONE | freeze已有，绑定不足 | 真实隔离验收缺 | 不能自称不可回写 |
| FP-07b | PARTIALLY_DONE | diagnose已有 | 实际诊断产物缺 | 机制诊断未完成 |
| FP-07c | NOT_STARTED* | 占位不算决策包 | 未见人工决策材料 | 战略未决定 |
| FP-08a | BLOCKED | metadata/log可先读 | 原2022 log缺 | 数据资格未确认 |
| FP-08b | NOT_STARTED* | 可选完整性修复 | 未见授权/执行 | 不能自动读skill |
| WBX-02a | PARTIALLY_DONE | init年份门已有 | raw表及有效时间gate未闭合 | 不等于confirm安全 |
| WBX-02b | NOT_STARTED* | 未见完整runner/protocol | 无公开比较原件 | 未建立公开排名 |
| WBX-02c | NOT_STARTED* | 可选任务 | 无新baseline作业原件 | 非未来confirm |

DONE仅限原任务交付范围。例如WBX-code DONE不代表TierB真GPU数值已由本审查重新证明。
NOT_STARTED表示在已查清单中无实证完成项；有AFS未上传结果时应补原件再更新，不武断断言历史未运行。[R7-15]

## 3. S0可信性

最新文档报告pt-lujnmfhg用固定Torch2.3.1+cu121/xformers0.0.27 overlay完成1/4/12步，diff均0、阈值仍1e-5。
原始S0路径、报告SHA、原生四job和overlayprobe见S0_OVERLAY_CONTRACT。
S0脚本显式关闭TF32，保留checkpoint/normalization/upstream/config/coordinate绑定；桥接源码blob与45edd51一致。
这些支持“修复路径合理、无静态放宽tol迹象”，不能替代新原JSON及source/参考hash实核。[R7-03/04]

原生标准镜像能获得H100但ModuleNotFoundError:xformers，说明调度与硬件可用，不说明官方环境可用。
overlay补足依赖，其可复现性需要wheel/module-origin/container/driver/ABI记录；一次4卡allocation不代表4独立parityreplica。
S0证明限定配置的数值一致，不能推出训练backward长期稳定、任意backend/5090等价或动态收益。[R7-03/04]

发布也未闭合：pyproject仅numpy/scipy/torch和pytest；fixedGPU与WBX的依赖/引用代码需单独安装锁及验证。
这不是必须把所有依赖装进core，而是文档与实际可复现范围要一致。[R7-04]

## 4. Fs发散、Stage3b和Stage4

### 4.1 旧finding是真的，但其对象是旧资产
round4审的是9月22日d749a1c附近的500-step、LR.01、8样本、seed20260921流程。
两个formaljob分别出现2/4 Fs退化，记录的final-panel ratio严重者约4.644734和4.066871；不能归咎于简单的跨样本首末loss比较。
其同样本方向、grad异常与最终面板相互支持，但完整原trace重放及唯一根因仍需独立证据。
四worker实际有四个Fs reference digest；旧bank不能“排掉发散专家”后变成同一Fs下的公平候选库。[R7-05]

Fs训练在专家月份分组之前，因此该分组不能解释先发生的Fs replica divergence。
Adam、固定LR、梯度clip与seed相同也不保证CUDA训练路径严格确定；LR/步数、backend/precision、数据/代码漂移应分别用证据检查，
不能凭新overlay成功就宣称旧失败唯一原因是xformers/TF32。32-step好、500-step差是观察，不是控制完备的单因素因果实验。[R7-05]

### 4.2 当前代码已经比旧审计结论前进
formal方向质量门现在进入eligible判定；另有Q1-Q6全horizon/clip/per-visit/epoch、固定L0/L1 panel及holdout门。
Fs选择固定四副本与指定adapter，禁止替换；post-Fs消费者按文件hash、manifest、协议、checkpoint/norm与merged digest绑定共同参考。
所以“当前只有日志而没有质量门”是不准确的。[R7-06]

但per_sample第一/最后访问不是所有样本在相同最终权重的比较。helper用zip需完整长度核验，最后optimizer.step后参数有限性和固定final-panel不可省。
当前强资格门能覆盖相当部分风险，仍需将旧坏record、缺字段、缺副本和错资产放进实际consumer入口，证明其fail-closed，而非只测helper。[R7-06]

### 4.3 明确verdict
**旧Stage3b/500-step资产：FAIL_UNQUALIFIED_REFERENCE，禁止进入新Stage4。**
**后继FP03-v2/H32与FP04：已观察到受限工程资格，不应被旧500finding一概推翻；当前发布/消费链仍待闭合。**
不是“可随意排除坏专家后继续”；也不需要无限追究旧kernel唯一根因才能做安全的CPU取证。
只要质量门、实际资产身份和消费边界能被可审计地证明，就可完成工程资格；是否投资新cache还需考虑既有负面科学结果。

**本包不批准新的Stage4。** 原FP05b cache已经存在，可以只读复算；S0过了也不能自动重跑/扩样。
若下一轮科学实验针对新可证伪问题，应人工批准新source/asset/data/protocol/预算，而不是回改旧FP05。[R7-06/07/12]

## 5. FP05b数字、原规则和统计解释

下表来自最新HEAD实际返回的原CSV，副本2257字节Gitblob验证相符。
本轮独立核算代数/阈值逻辑，但**没有重新从1680cell或原预测端点生成这些置信区间**。
百分数均为Fs分母的相对loss变化，不是RMSE百分比，也不是“百分点的天气命中率”。[R7-12]

| 24h比较 | 点估计(%) | 原95%CI(%) | 对d=.34%的关系 |
|---|---:|---|---|
| M3−Fs | +0.261143 | [0.238927,0.284374] | BELOW |
| M1−Fs | +0.261445 | [0.225650,0.300814] | BELOW |
| oracle−Fs | +0.315005 | [0.282400,0.350734] | STRADDLE |
| oracle−M1 | +0.053560 | [0.041341,0.066693] | BELOW |
| M3−M1 | −0.000302 | [−0.020659,0.018101] | BELOW；对0跨越 |
| H_Fs (Fs相对F0伤害) | +0.191348 | [0.149753,0.234196] | 正的记录伤害 |

M3对Fs不是“完全没有正收益”；正确说法是条件于该冻结OOF、23块可用开发样本，有小正记录效应，但未达预注册实用线。
M3对M1没有证明增量，也不等于统计等价。记录显示M3确实切换：73次expert_0、39次expert_1；M1则112次expert_0，所以不能说它退化成常量。M1约取得oracle点增益的83%，而oracle−M1剩余空间只有.05356%，
故即使改善路由，当前候选库内可回收的平均空间受限。优先增加路由复杂性不是高信息选择。[R7-12]

M3的+0.069796%对F0点差是G_Fs−H_Fs；它没有这里已经独立生成的pairedCI，不得相减两个边际CI端点。
72h M3−Fs约+.438948%，原安全guard通过，但原6/72的G_F0列错用了H24；不得据它宣称对F0长时距改善已验证。
新逐lead修复脚本存在，却仍需全量数值验收及方法对F0的直接pairedCI。[R7-08/12]

既有112行不是112个独立天气过程；主bootstrap23周块，14日敏感性13块，均条件于已拟合OOF策略，
不含整个候选训练/策略设计过程的全部不确定性。2019开发年、2020训练到2019评估是回顾性转移，不是历史部署/最终confirm。

### STOP与FP06
原128目标剔除16超过cap8；接受112是结果前availability修订，需要保留原STOP/例外。
两个空层解释10个drop，不是全部16个。完整半年总体不能从仅23层结果直接推出。[R7-13]
按照冻结first-match，若证据有效，oracle−Fs不是BELOW，而oracle−M1是BELOW，所以先命中rule3 **PIVOT_STATIC**。
oracle−Fs STRADDLE不能作为“任何STRADDLE优先”的全局否决。
但这只是预期规则路径；当前CLI缺省true漏洞尚在，且rawgatechain未闭合，所以不能宣称正式可信FP06已完成。

### 新发现的执行漏洞
r5入口missing/stringfalse→CONTINUE已实际复现；该CLI本身不提交GPU，这不是已经观察到Stage4越权运行。purefunction本身会拒missing，说明问题在wrapper，不是把整个实现一票否定。
erratum只核status交集而不核point/CI完整性、gatefalse仍rc0；FP07核A读B；WBX核init不核valid。
这些都是源代码可定位的问题，并不等于证据表明历史FP05已经被它们污染；修复与历史结论限定必须同时保留。[R7-07～11]

## 6. WeatherBench-X

代码实际使用官方deterministic metrics、GridAreaWeighting、Aggregator和WB2 regrid等组件，不应称为自写一遍RMSE。
但源码调用只能证明实现依赖，不能证明某次实际job导入路径/版本与原表都通过。
native旧panel bitwise与官方指标归约容差是不同合同；104×3是family×issue×lead记录，不是104独立天气起报。
原TierB全表和job不在本次可用材料，仍MISSING；新的公开benchmark runner也未在所查scripts清单得到。
修年份gate应看真实input/valid/history坐标与manifest，而不是信任调用者给的年份或authorized列表。[R7-11/14]

## 7. novelty与最强可辩护贡献

### 文献对照（不是“完全不重叠”要求）
- **WeatherPEFT: Task-Adaptive Parameter-Efficient Fine-Tuning for Weather Foundation Models（ICLR 2026; arXiv v2 2026-06-17）**：动态prompt上下文重校准和Fisher指导选择；不能称已有天气PEFT全是静态。 天气任务适配不是forecast-specific counterfactual utility验证。 [L01]
- **A foundation model for the Earth system (Aurora)（Nature 2025-05-21）**：预训练地球系统模型可适配多个预报任务。 证明一个新增动态控制器优于强固定适配仍需自己的对照。 [L02]
- **Mixture of LoRA Experts（ICLR 2024）**：LoRA专家组合与门控已有先例。 天气因果时序、收益/伤害和counterfactual response是另需实证的维度。 [L03]
- **LoRA-Mixer: Coordinate Modular LoRA Experts Through Serial Attention Routing（ICLR 2026）**：注意力投影中的细粒度routing及frozen LoRA复用已有。 不能把bank+router或attn.proj插入位置当作独立新颖性。 [L04]
- **LD-MoLE: Learnable Dynamic Routing for Mixture of LoRA Experts（ICLR 2026）**：token/layer自适应专家数量与稀疏控制。 单纯增加动态容量不是EarthDelta核心贡献证据。 [L05]
- **Tent: Fully Test-time Adaptation by Entropy Minimization（ICLR 2021; arXiv 2006.10726）**：每测试batch使用熵目标更新归一化/仿射参数。 EarthDelta冻结bank选择若无在线梯度，不等同该TTA设置；图像熵不直接移植连续天气回归。 [L06]
- **Estimation of observation impact using the NRL atmospheric variational data assimilation adjoint system（Tellus A 2004）**：FSO研究观测同化对短期预报误差的影响。 参数编辑不是观测影响；二次损失差恒等式本身是代数而非新算法。 [L07]
- **Online Learning with Optimism and Delay（ICML 2021）**：DORM/DORM+/AdaHedgeD面向延迟反馈、并有天气气候任务验证。 双向OOF不能替代真实label-availability约束的online选择对照。 [L08]
- **WeatherBench-X（Official repository/documentation, accessed 2026-09-25）**：模块化loader/interpolation/metrics/aggregation；WB2 benchmark仍活跃并由WBX驱动。 评测实现不是新数据集或预测能力；本轮未查到须引用的独立WBX论文，不编造论文。 [L09]


补充的近期TTA对照：**PETSA（2025 workshop）**已经结合小型输入/输出校准、低秩适配和动态门控；**Towards Principled Test-Time Adaptation for Time Series Forecasting（2026-05预印本）**明确以已成熟真值限制适配，并提出轻量FAC校准。这两项是通用时序预测来源，不冒称已经验证全球天气任务。它们进一步要求EarthDelta说明：不是仅仅轻量适配、守住标签时间或加入谱模块，而是可预测的编辑响应是否带来超越同成本直接校准/收益预测的增量。[L10–L11]

以上优先用论文作者/官方proceedings/官方框架文档，不从检索不到邻居推出“全球首创”。
WeatherPEFT已有动态prompt，所以旧“已有天气PEFT全是静态”的动机要改；MoLE/LoRA-Mixer/LD-MoLE使
bank+router、低秩模块复用和动态capacity本身不足以作为核心新颖性。[L01,L03-L05]

**最可信的研究表述（待证，不是已实现主张）**：
> 在固定天气基础模型上，仅凭起报时可用的历史，预测候选参数编辑对未来预报的响应与效用；用校准的效用不确定性决定何时编辑或拒绝编辑，并检验它能否超越强固定适配及同成本的直接收益预测。

已实现的小候选库+ridge直接gain并未等于该error/response分解方法。其失败不直接证伪整个构想，
但说明当前bank作为研究载体的额外headroom弱，下一轮不能只换一个更大router。

若 e=y−Fs，d=Fc−Fs，则二次loss下
`L(Fs)−L(Fc)=2<e,d>_Q−||d||_Q²` 是代数恒等式，不是本工作的数学novelty。
用预测的e和d替代真值后不再保证收益估计精确；将不同编辑响应线性组合也不意味着非线性rollout的真实响应线性。
因此“exact objective”应限定于已知真实response/固定线性summary的恒等式，不可扩大为任意forecast编辑选择精确。[L07；代数推导]

有价值的方向是校准“选择是否正确”而不仅预测MSE：若每个候选gain误差≤epsilon，argmax的真实regret≤2epsilon；
这也是基础推论，不单独作为novelty。真正需要的新证据是对未见状态/编辑仍有效的响应预测、可用的拒绝门和真实成本/伤害收益。

### 最小有区分力的对照
1. **F0、合法强静态M1、同预算固定PEFT/静态残差校正、direct-gain路由**：分清一般适配收益与状态路由增量。M5/hindsight是诊断不作部署baseline。
2. **同输入/容量/训练数据/推理预算的direct-gain vs error+response分解**：看utility calibration、chosen-action regret及真实forecastloss，而非只看head拟合误差。
3. **真实e+预测d、预测e+真实d、真实e+真实d**：只作oracle诊断，定位误差来源；不能进主榜。跨未见edit/state检验分解是否真有泛化价值。
4. **状态/候选错配与calendar-only控制**：在不破坏fold/时间可用性的前提下打乱状态，检验是否只是季节或固定专家效应。
5. **一次真正冻结的确认评估和安全/成本报告**：approvedholdout、同一可用真值、逐lead及tail伤害、realizedlatency；无这个就不称可部署收益。

如果动态bank长期不能超越强静态，可保留“编辑响应/收益可预测性与失败模式”的研究问题和可靠对照基座。
但一套可靠工具或单个K4负结果本身尚不足以证明科研贡献；需要系统性现象、解释和可推广对照。
NOVELTY_SUPPORT保持INCONCLUSIVE，不能从S0/pytest数量跳级。

## 8. 下一步与禁止宣称

8–10小时细化计划见FOLLOWUP_PLAN，按540分钟预算加60分钟缓冲；环境与数据成本现场记录而非虚构profile。
优先修能改变结论的入口错误、旧/新资产边界和标量复算；2022只读metadata并行；不让公开baseline表拖住研究决策。
当前不授权新的Stage4/confirm；旧cache只读允许；新科学协议可由人考虑，而非被工程检查无限阻塞。

不能宣称：新S0原件已独立核实；原生镜像与overlay同合同；4卡就是4重复；merge证明训练稳定；H32资格就是普遍无害；
动态路由已证明有实用/confirm收益；BELOW等于没有任何正收益；M3≈M1证明所有路由等价；
312项官方metrics全bitwise或104独立sample；2022已ready；正式FP06/FP07/WBX2已执行；novelty已实验证明。

---
## Findings位置与处置（完整）

### R7-01 远端版本已核实；不能从远端推断本地 clean/synced
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`GitHub branch audit/round2-review-20260921 at 8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`；`plans/plan_v6_0925/EXECUTION_STATUS_20260925.md`。

远端 HEAD 8ab914b；45edd51→85ed929→8ab914b。CodexPro 本地工作区连接实际返回404，故本地HEAD、分支、dirty及相对origin的ahead/behind仍MISSING。

行动：执行机只读 git rev-parse/status/ls-remote；不要reset、清理或覆盖工作区。

### R7-02 仓库规范计划ZIP与上一轮对话同名ZIP不同
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`plans/plan_v6_0925/EarthDelta_Codex_Followup_Plan_20260925.zip`。

恢复的88663字节ZIP，SHA256 a3adbf8c5e93d0e44a4a5dd1976754c9af113c8451a14a7875cc9d6a98b318b5，Git blob e904950e5ac85db9c48c7c6b48a417e0898aa9e1，与仓库目录返回一致。六份核心计划及任务JSON已解压读取。

行动：按仓库ZIP验收，不把此前77433字节对话包替代规范合同。

### R7-03 最新S0仅有可核的跟踪记录索引，原始AFS链未取到
证据：**PLAUSIBLE_UNVERIFIED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`plans/plan_v6_0925/GPU_RECHECK_EVIDENCE_20260925.md`；`/mnt/afs/260010168/acp_runs/ed-r6-s0-overlay-recheck-20260925T115020Z/s0/gate_output/s0-gate-20260925t115202730947z/s0_gate_result.json`。

文档登记 pt-lujnmfhg、Torch2.3.1+cu121/xformers0.0.27、1/4/12误差0、1e-5及原JSON SHA；本轮没有原JSON、scheduler完成回执、source manifest、checkpoint/norm/upstream原件，不能称最新GPU独立验收。4卡分配不等于4次独立parity重复。

行动：先恢复原件与hash，绑定实际job源码、参考manifest、容器/overlay和设备；缺项停在MISSING，不为补历史时序而重跑。

### R7-04 原生H100可分配不等于官方依赖合同可用
证据：**STATIC_CONFIRMED**；优先级P1；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`plans/plan_v6_0925/GPU_RECHECK_EVIDENCE_20260925.md`；`pyproject.toml:12-22`；`earthdelta/wbx/_vendor.py`。

4个原生单卡任务的文档登记为已获H100但缺xformers；overlay probe与S0另列。pyproject只声明numpy/scipy/torch，dev仅pytest，不能复现固定GPU或WBX环境。新48passed只有MD摘要，非本次重跑。

行动：分别发布core/official-GPU/WBX环境锁；保存wheel/container/module-origin哈希，禁止把本地可导入视为发布安装完成。

### R7-05 旧500-step Fs确有灾难性退化；该审查不是最新H32资产
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`codex_audit_round4/fs_fit_divergence_assessment.json`；`codex_audit_round4/evidence/gpu_records_recomputed.json`；`codex_audit_round4/evidence/artifact_crosschecks.json`；`earthdelta/static_adapter.py:929-1008`。

round4针对9月22日/d749a1c旧工作区。两组formal作业各2/4参考Fs的同样本最后损失变差；旧报告final-panel ratio包括4.644734、4.066871。8样本/同seed与轮转顺序先训练Fs，之后才分专家组，因此专家月份分组不能解释之前的Fs副本分歧。旧4个不同Fs的bank不能剔除坏专家后冒充共同参考实验。

行动：按asset digest区分legacy500、v1 H256、v2 H32；将坏record喂给当前质量门并证明消费链拒绝；不强求唯一根因才允许安全取证。

### R7-06 当前已存在真实质量门，不能沿用旧“只有日志”的判词
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`earthdelta/static_adapter.py:982-1008,1060-1158,1350-1635`；`scripts/r2_fs_bank_train.py:420-570,619-660,800-1030`；`plans/plan_v4_0923/run_20260924T013959Z_fp03_v2/certify/V2_certify_decision.json`。

当前formal方向门会令eligible=false；Q1-Q6另核完整horizon、clip、per-visit、epoch、同最终panel与holdout；certify决定固定资产且禁替换；post-Fs消费者按文件/协议digest绑定唯一Fs。H32资格是受限工程资格，不是样本外无害或普遍训练稳定性。per_sample首末不是同一最终检查点，最后optimizer.step后仍需固定panel。

行动：保留既有门，补完整链坏record回放、缺字段/最后一步非有限/少样本/错资产拒绝；证明当前消费的就是H32资产。不得改旧17核心pin以假装证书沿用。

### R7-07 FP06 CLI将缺失或字符串false有效性升级为true
证据：**EXECUTION_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`scripts/r5_audit_runner.py:17-32,35-75`；`earthdelta/fp06_decision.py:15-57`；`tests/test_fp06_decision.py:1-51`；`evidence/FP06_ENTRY_PROBE.json`。

在与远端Git blob一致的两个生产模块及5个原测试的隔离CPU副本上重跑：5passed；missing及字符串false均归一为true并输出CONTINUE_NEXT_ITERATION/rc0。明确false产生INVALID但仍rc0。没有读取任何天气数据或运行GPU。

行动：入口消费受信gate bundle，禁止bool(...)和缺省true；从CI/原规则重算status；缺hash/schema/identity拒绝；INVALID非零，负面科学结论可rc0但authorization永远独立。

### R7-08 逐lead勘误存在，但结果验收和证据闭合不足
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`scripts/r5_score_erratum.py:67-114,137-210`；`scripts/r4_policy_oof.py:240-285`。

已修H24误用于6/72的问题且有独立append-only脚本，不能再说未实现。erratum只比较24h status而非全部point/CI，仅检查交集；gate=false时main仍rc0；paired_F0_intervals仅放H_Fs区间，未给各方法对F0的配对区间；source_record未含erratum脚本自身。真实新erratum产物未获得。

行动：用独立冻结标量工具重算；全部注册24h比较逐值保持，按lead给直接配对F0 CI；失败退出非零；旧evaluation只读，新输出带脚本/依赖hash。

### R7-09 新OOF消费检查仍未闭合所有验证键
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`scripts/r4_policy_oof.py:40-120`；`scripts/r4_candidate_cache.py:process_issue,stage_merge`。

精确allowlist、source pins、background hash等已增加；但V-check只检查已提供values为true，不强制V1..V8全集；dev文件hash校验不等于消费其完整语义；下游仍需1680唯一键与状态/denominator完整校验。现存历史矩阵是否受影响需原数据复算，不能从潜在入口漏洞推断实际泄漏。

行动：补缺V键、subset/duplicate rows、错dev链、F0/identity/source漂移的真实入口负测试；预测Poison重跑同时检查eval与purged，保留旧13mutant历史，不冒充新执行。

### R7-10 FP07只读隔离可被替换inputs绕开
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`scripts/r5_diagnose.py:freeze,diagnose`。

diagnose验证args.protocol中的refs，却从独立args.inputs指定的路径读取数据，未要求两者相等；也未消费子文件hash或外部固定protocol hash。before快照在读取后且只含四个顶层文件；返回值不阻断after mismatch。中心化仅逐专家减列均值，不能单凭SVD证明去掉了样本共同误差。

行动：只从hash固定协议取输入；递归ref并在I/O前校验；只读挂载；旧树前后hash不变；诊断名单冻结，保留row/column/double-centered区别，不用新结果改旧FP05。

### R7-11 WBX检查起报年份而不检查有效时间/真实数据来源
证据：**STATIC_CONFIRMED**；优先级P0；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`earthdelta/wbx/evaluate.py:39-87,evaluate,evaluate_single_chunk`。

新增两个公开入口年份检查是真实改进，但requested_years仅来自init_times；2020-12-31+72h会跨2021。authorized可由生产调用者覆盖；single_chunk接受调用者给的init_times未核数组坐标。没有证据显示本次历史实验已越权，但新confirm读取存在路径。

行动：用dataset manifest与实际坐标核init/valid/history支持；跨年、伪标签、内存数组与测试override生产拒绝；年份不代替精确issue/role capability。

### R7-12 当前FP05b不是“零正收益”，而是未达实用阈值且路由未胜静态
证据：**STATIC_CONFIRMED**；优先级P1；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/dev_results.csv`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/paired_block_bootstrap.json`。

M3-Fs点0.00261143及CI均>0但上界<0.0034；M3-M1点约-3.019e-6、CI跨0；oracle-M1上界0.000666927<0.0034。独立摘要算术得到静态约占oracle点增益83%。本轮没有重新从1680标量/原端点生成CI。

行动：保留条件于冻结OOF的正小效应与未达标结论；先看增量headroom和收益/遗憾而非raw-loss相关；正式first-match在证据有效前提下预期rule3 PIVOT_STATIC，不是已发正式FP06。

### R7-13 接受N112是结果前公开例外，不等于原STOP通过
证据：**STATIC_CONFIRMED**；优先级P1；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`plans/plan_v4_0923/run_20260924T104725Z_fp05b/admission/policy_dev_selection_STOP.json`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/admission/policy_dev_selection_coordinator_resolution.json`；`plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/PREREGISTRATION.md`。

cap8实际16；两空层造成10个drop，另6个并非空层。记录时序为10:55STOP、11:00resolution、12:09协议，支持result前availability例外的叙事但不是防篡改时序认证。保留23/25strata支持域，不声称完整半年。

行动：不用补齐样本或改门槛重报；保留原STOP/例外/精确采样名单及其正式准入解释。

### R7-14 WBX历史312项和2022根因尚未独立验收
证据：**MISSING**；优先级P1；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json`；`checkpoints/pull_2022.log`；`plans/plan_v6_0925/EXECUTION_STATUS_20260925.md`。

官方metric/regrid真实import可在源码确认，但TierB原对账表/原作业未取得，不能把官方metrics称所有bitwise；2022失败只见旧文档引用，最新validator结果未知。数据完整性与未用于选型是不同资格。

行动：从AFS优先恢复精确小文件；2022日志/元数据与主线并行，不先读新年份模型效果；若公共解析器有误回查旧年。

### R7-15 本轮计划执行部分完成，文档与脚本存在不等于任务验收
证据：**STATIC_CONFIRMED**；优先级P1；commit `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

位置：`plans/plan_v6_0925/EXECUTION_STATUS_20260925.md`；`scripts/r5_audit_runner.py`；`scripts/r5_diagnose.py`；`scripts/r5_score_erratum.py`；`scripts/ directory at 8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。

新增代码与部分测试存在；未发现跟踪的完整FP06/FP07/2022/WBX02执行产物。public benchmark runner不在当前scripts清单，真实运行可在AFS但未取得，不能认定全DONE或认定从未在本地执行。

行动：按TASK_STATUS_V6逐任务补最小缺口；不要为了完成目录清单重训历史Fs/bank。

## 外部论文与来源
[L01] WeatherPEFT: Task-Adaptive Parameter-Efficient Fine-Tuning for Weather Foundation Models. ICLR 2026; arXiv v2 2026-06-17. https://proceedings.iclr.cc/paper_files/paper/2026/hash/4e6219cc3913fd508dbd7f3f6d90cd4e-Abstract-Conference.html
[L02] A foundation model for the Earth system (Aurora). Nature 2025-05-21. https://www.nature.com/articles/s41586-025-09005-y
[L03] Mixture of LoRA Experts. ICLR 2024. https://proceedings.iclr.cc/paper_files/paper/2024/hash/ce806d8b4bf38cd92d483e5a0490d983-Abstract-Conference.html
[L04] LoRA-Mixer: Coordinate Modular LoRA Experts Through Serial Attention Routing. ICLR 2026. https://proceedings.iclr.cc/paper_files/paper/2026/hash/18610cbcd1da57854aa05ebdc5cd3168-Abstract-Conference.html
[L05] LD-MoLE: Learnable Dynamic Routing for Mixture of LoRA Experts. ICLR 2026. https://proceedings.iclr.cc/paper_files/paper/2026/hash/6a39cf3b666f8bdb2223f253981f3869-Abstract-Conference.html
[L06] Tent: Fully Test-time Adaptation by Entropy Minimization. ICLR 2021; arXiv 2006.10726. https://arxiv.org/abs/2006.10726
[L07] Estimation of observation impact using the NRL atmospheric variational data assimilation adjoint system. Tellus A 2004. https://onlinelibrary.wiley.com/doi/full/10.1111/j.1600-0870.2004.00056.x
[L08] Online Learning with Optimism and Delay. ICML 2021. https://proceedings.mlr.press/v139/flaspohler21a.html
[L09] WeatherBench-X. Official repository/documentation, accessed 2026-09-25. https://github.com/google-research/weatherbenchX

仓库精确文件/版本/已读范围见evidence/EVIDENCE_MANIFEST.json；未取得原件见evidence/REQUIRED_INPUTS.md。
