# 复现边界与版本

审查remote `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`；最新GPU文档登记 `85ed929f565191cf428ba8d491000542e55fe49e`；旧FP05资产 `45edd51b563a626e01b31af24e0d95afa6d56d7b`。
三个版本不能混写为同一实验；本地actualHEAD/dirty/sync必须在执行机重新读取。
规范ZIPSHA a3adbf8c5e93d0e44a4a5dd1976754c9af113c8451a14a7875cc9d6a98b318b5。

1. source snapshot、dirtydiff、code/数据/权重/normalization/overlay/import origin逐层固定；保留旧sourcepins，不回填旧protocol。
2. 新结果仅写仓库外RUN。workspace_snapshot.py保护既有历史run文件；它是hash保全，不是训练/科学验收。
3. tools/recompute_frozen_fp05b.py独立实现“已保存标量→actions→pairedbootstrap”，继承规范包的精确旧blob pins。
   HEAD常量标识原实验45edd51，不声称它等于当前workspace。该脚本不读zarr/weights、无GPU、无策略拟合。
   归约误差检查1e-10只是审计浮点运算上限，不用于S0/anchor或修改科学门槛。
4. 原始端点→标量CPU复算、原job真执行、预注册时序、全标签访问隔离仍是不同gate。
5. SHA sidecar/mtime不是独立防篡改时间认证；核scheduler收到的argv/hash、源snapshot与外部既存记录。
6. 只复制被授权的原件，不分享第三方权重/整年数据；优先hash和精确小样本。
7. latest48passed属于跟踪MD所报，本轮独立执行为5个确切原测试；不能合并成53个已独立完成。
8. CPU补丁回归结果、synthetic probes、原天气科学结果分别放目录并用label区分。
9. 输出中的 MISSING 不表示历史没运行；缺回执不能通过重训变为“历史原件已齐”。
10. 需要继续新研究时，以新候选/数据/协议/预算和人工授权另开run；当前包从不隐式授权Stage4。
