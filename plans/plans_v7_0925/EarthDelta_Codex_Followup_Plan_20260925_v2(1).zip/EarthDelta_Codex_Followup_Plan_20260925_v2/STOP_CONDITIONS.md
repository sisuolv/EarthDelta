# v2 STOP合同

以下“原冻结合同”逐字保留规范v6计划包中的 STOP_CONDITIONS.md。
本包新增的是证据门和版本边界，不更改原实用阈值/统计规则，也不授权原计划可选GPU。

---
## 原冻结合同（原文）

# 硬门、原阈值、勘误和数据隔离
## 历史数值门（不得放宽）
- S0：ps4；official_zero_diff_mean；torch2.3.1+cu121/xformers0.0.27；有效TF32关闭；6h×1/4/12全部max_abs≤1e-5。与WBX或Fs merge容差不同。
- Fs v2：Ntrain8、H32、lr.0025；原v1 H256失败保留；Q1有限、Q2 clip0/visit≤1.25/epochfactor1.02、Q3训练8/8方向、Q4train最大ratio<1且均值≤.99、Q5train72h≤1.01、Q6qualification24h≤1.02。Fs merge atol=max(1e-5,1.5e-3*delta_max_abs),rtol1e-5；不是逐位合并。
- Bank：唯一Fs；K4/rank4、blocks18–23、singleton a0=rho=.25、max_active1、hold4×6h再从编辑态续Fs；32updates；E3自组24h均ratio严格<1。A1–A5 exact0，expert0..3、step1/4/12、hold后8步完整。
- FP04的17个core pins不得修改。修FP05/WBX新代码另建版本身份，不回写原protocol中源码hash。

## 本轮FP05已冻协议（以原文件复核为准，不重新解释数值）
协议 `plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/cache_protocol_v1.json` SHA256 `a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8`。
- 完整N112，5candidate×3lead（6/24/72），4外折，23个7日块；16/19层缺数据；不补样、不换窗口、不事后选N。原128→112的cap修订保留真实标签，不称完全未改规则。
- support闭区间[t−12h,t+72h]，purge额外24h，端点接触也冲突。对授权精确UTC与store实际time/内容复核，不仅看标签。
- policy_dev=当前被冻结的2019H2可用issue集合；2020H2 EXPOSED_NOT_CONFIRM；2021/22无模型读取许可；confirm=UNASSIGNED_NO_ACCESS。完整性读取与模型/标签使用分开记录。
- 候选no-edit/Fs+4singleton，F0只背景，M4 oracle只诊断，M5全DEV最优静态只hindsight对照；M1必须outer-train选。
- 原数值一致性：V5 CPU/GPU loss差≤1e-12×L；V6解析gain atol1e-11、rtol1e-8；debug anchor严格bitwise，≤1e-6但不exact只可升级协调者，不能自动通过。
- 原DEV-SCALE-v1只在结果揭示前选过一次：候选112/56/30；load+ceil(N/4)×p95(t_issue)×1.5≤45min，N×bytes×1.2≤60GB且≤free disk，peak≤64GiB。当前实际N112已冻结，本包不重新执行规模选择。
- 全矩阵与F0同分母；nonfinite按原协议惩罚/回退，不删行；nonfinite>2%原规则拒绝；Fs无效直接INVALID。
- 主效用d=0.0034，正号指loss减少，Fs总loss为所有比较分母。95% paired whole-block percentile CI、10000draws、seed20260924；7日主，14日报告，不用更有利敏感性取代主CI。
- ABOVE iff lowerCI≥.0034；BELOW iff upperCI<.0034；其余STRADDLE。72h safety lowerCI≥−.0034，不能把6/72h旁表ABOVE当24h主试验达标。
- scaler/PCA/kmeans/ridge/HPO按原outer/inner训练侧；只可复演已冻结参数，不能借勘误调模型。scaler std floor1e-12，PCA d8，ridge λ(0.1, 1, 10, 100, 1000.0, 10000.0) ties更大λ；regime k(2, 3, 4) ties更小k，n_init10、seed20260924、Lloyd≤300，cluster<5回退M1；ridge四个absolute gain，预测最大≤0选no-edit。不得重新选。
- 所有lead同面板换算：H_h=(ΣFs_h−ΣF0_h)/ΣFs_h；G_F0,h=G_Fs,h−H_h。只纠正错误字段；不是换目标或数值效用界。

## 禁止事项
**FP-05b 的 BELOW/STRADDLE 结论不得因为 FP-07 诊断结果而被重新解读为达标。**
旧evaluation/protocol/policies/certificates只读；允许可追踪errata，但严禁替换原文件。诊断必须新run、独立源码、全部分组展示与前后hash。不得因为某月正效应转改全年主结论，不把同一DEV的调参当独立confirm。

## 原FP06顺序，先验证真值表
1 INVALID证据→INVALID。
2 oracle−Fs BELOW→STOP_CURRENT_BANK。
3 oracle−M1 BELOW→PIVOT_STATIC（另报M1−Fs是否ABOVE）。
4 M3−M1 BELOW而oracle对应headroom未BELOW→STOP_CURRENT_SELECTOR。
5 M3−M1及M3−Fs ABOVE且72hguard通过→仅CONTINUE_NEXT_ITERATION资格。
6 未在前面终止且判决路径STRADDLE→INCONCLUSIVE at cap。
第6条的“未在前面终止”落实原文In order，不另加全局STRADDLE否决。当前规则3可机械执行；未被原规则覆盖的组合（如收益均ABOVE但72hguard失败）须fail-closed并升级协调者，不能擅自制造通过。无论机械标签为何，24h原BELOW/STRADDLE不能改。

## WBX
官方metric reconciliation≤1e-6 relative与in-job原panel bitwise是不同合同，不互换。TierB PASS无原表不算独立审过；generic evaluate必须在loader前审精确支持许可与所有valid_time年份。baseline共同case/变量/网格/units/初始化不得按skill挑。

## 权限
本包未批准任何新GPU/天气训练/new-year value读取。receipt或数据缺失先列精确MISSING；不能无限重新跑认证。2022仅已有logs/metadata开放；完整性数值读取/修复、新year下载、未来confirm另审批。人工的收尾/重设计/确认选择不得交给机械runner代办。


---
## 本轮额外硬门

1. 最新S0需要原`/mnt/afs/260010168/acp_runs/ed-r6-s0-overlay-recheck-20260925T115020Z/s0/gate_output/s0-gate-20260925t115202730947z/s0_gate_result.json`、报告SHA `4aab593d3326f754b866815e9a5d0a15ff1336a1f51079ba38689d4251949670`、真实scheduler完成字段及source/overlay/参考数据绑定；MD摘要不能代替原件。S0容差固定`1e-5`，步长1/4/12不减。
2. 旧500-step发散Fs及其不同参考下的专家不得进入Stage4。当前H32只能在完整asset/quality/consumer链验收后被视为工程合格；merge通过不能代替稳定性。
3. `evidence_valid`缺失、null、字符串、0/1或仅自行提交true都不是可信gate；必须消费受信原始证据及其绑定。INVALID/缺证据阻止后继，不靠rc0猜PASS。
4. FP05b **BELOW/STRADDLE不得因FP07诊断重新解读为达标**。首匹配rule3 PIVOT_STATIC也不等于M1通过delta_min；不改变“先买信息，再由人决定”的战略边界。
5. 旧evaluation/OOF/actions/protocol/split全部只读；勘误追加到新目录，24h注册比较全量point/CI/status不变，浮点归约差只用已说明的审计算术容差，不可拿它放宽S0。
6. WBX必须核实所有init/valid/history时间及真实数据manifest，不能仅检查init年；生产authorized参数或single_chunk伪日期不能自授权。
7. canonical matrix必须是精确112×5×3，V1–V8完整；原fallback规则保留，不删除坏行、空层或失败重试来制造成功。
8. FP07从固定protocol引用加载，不能另给inputs换文件；读取前/后递归hash及只读挂载；发现旧文件变化立即STOP。
9. `paired_F0_intervals.json`必须给各方法对F0的配对区间，不能只放H_Fs；不从两个边际CI端点相减。
10. 2022完整性FAIL仅阻塞其使用；若公共解析器缺陷，则回查受影响历史数据。2021不是看skill后的备选。技术验数不等于最终confirm资格。
11. 本8–10小时时间盒不授予新的Stage4或confirm。可提出下一轮单因素实验，但必须另有人工同意、新预算和新协议；不能因本包测试通过自动启动。
12. 原17核心pin改变则旧证书不能自动沿用；保留历史源码快照，在新版本重新证明实际受影响合同。禁止为了让旧protocol source check过关而回填原pin。

## STOP输出
写独立STOP.json：task、UTC、具体规则、文件/commit/hash、实际与期望、退出码、是否已读标签/运行模型、允许的修复取证。
缺原件是BLOCKED/MISSING；有效输入下计算错误是INVALID；科学不足是INCONCLUSIVE/负结果。三者不能混用。
