# 当前差距与最小行动

审查提交 `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`。旧指标不可倒写。



## R26-01 · P0 · MISSING · 最新本地状态与新 S0 原件未取得

`CodexPro.open_current_workspace: connection failed`
`plans/plan_v6_0925/GPU_RECHECK_EVIDENCE_20260925.md`
`/mnt/afs/260010168/acp_runs/ed-r6-s0-overlay-recheck-20260925T115020Z/s0/gate_output/s0-gate-20260925t115202730947z/s0_gate_result.json`

远端 HEAD 已获取；本地 worktree、ahead/behind、AFS 与 pt-lujnmfhg 的实际 source/asset/job 三联绑定未现场核实。文档 PASS 不升级为新作业独立认证；这也不是证明作业失败。

**最小行动：**先读取既有原件、重算 hash、保存 git status 与 remote-sync 回执；不因聊天缺件而重跑训练。



## R26-02 · P1 · STATIC_CONFIRMED · 硬件、依赖与官方路径是不同门

`plans/plan_v6_0925/GPU_RECHECK_EVIDENCE_20260925.md`
`scripts/r6_5090_bridge_smoke.py:1-98`

文档记录四个 native H100 作业因缺 xformers 失败；新 5090 脚本明示 SDPA engineering-only、official_xformers_parity=False。它们不能替代 Torch2.3.1+cu121/xformers0.0.27 的官方合同。

**最小行动：**隔离环境、记录有效 TF32 和导入路径；native/SDPA smoke 与 S0 分栏，不自动换 attention 后端。



## R26-03 · P0 · EXECUTION_CONFIRMED · 历史正式 Fs 存在真实有限值失稳，但不能外推到全部新 Fs

`codex_audit_round4/fs_fit_divergence_assessment.json`
`codex_audit_round4/ROUND4_REPORT.md`
`earthdelta/static_adapter.py:917-1128`
`plans/plan_v4_0923/run_20260923T192759Z_fp03_fs/forensics/j2_findings.json`

旧 500 步、lr=0.01 运行的同样本方向及固定面板均退化，非单纯 mixed-sample 日志错觉。认证后端的高 lr 正控制仍失稳，不能把所有原因唯一归于 TF32。Adam/重复访问/训练时长均须区分；精确 merge 可精确执行坏模型。

**最小行动：**旧失败产物全程禁止进入 cache；按权重身份把历史 H500、v1 H256、v2 H32 分成三条 lineage，不挑较好的历史 worker 混成新 bank。



## R26-04 · P0 · STATIC_CONFIRMED · 强资格门及实际 cache 消费链已经存在，不能再只评价低层 eligible

`earthdelta/static_adapter.py:1280-1490`
`earthdelta/static_adapter.py:1590-1618`
`scripts/r2_fs_bank_train.py:810-915`
`scripts/r4_candidate_cache.py:200-305`
`plans/plan_v4_0923/run_20260924T013959Z_fp03_v2/certify/V2_certify_decision.json`
`plans/plan_v4_0923/run_20260924T013959Z_fp03_v2/decisions/V2_J3_formal_decision.json`
`plans/plan_v4_0923/run_20260924T033627Z_fp04_bank/certify/bank/bank_verify.json`

Q1-Q6 包括轨迹稳定性、固定面板和指定候选；cache 实际消费 pinned S0、Fs certificate、bank bundle 和 loaded digest。H32 Fs 与 K4 的有限资格证据保留；不是所有 horizon/recipe 的稳定性证明，更不是天气效用证明。

**最小行动：**重新核验原始 trace 到 certificate 再到 cache 的 hash 链，并做真实入口拒绝坏 Fs 的负向测试；无需为了复盘旧唯一机制而自动重训合格 H32。



## R26-05 · P1 · STATIC_CONFIRMED · 训练稳定性记录有冗余字段一致性缺口

`earthdelta/static_adapter.py:1280-1370`

training_stability 同时计算 clip_events_from_trace，却在 clip_events 存在时用其决定 clip_ok，未强制二者相同。当前合格记录未显示因此错判；该缺口不能被描述成已证明当前 Fs 发散。

**最小行动：**新增外层只读 verifier 重算 clip/update/issue/grad 长度与计数，矛盾即 INVALID；保留被 FP04 pin 的原核心文件，需改核心时走显式新版本合同。



## R26-06 · P0 · EXECUTION_CONFIRMED · FP05b 已有样本外实验：收益为正但不达效用门，动态增量未被支持

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/dev_results.csv:1-17`
`plans/plan_v4_0923/run_20260924T104725Z_fp05b/analysis/phasec_independent_recompute.json`
`plans/plan_v4_0923/run_20260924T104725Z_fp05b/analysis/cj2_independent_verify_noloss.json`
`plans/plan_v4_0923/run_20260924T104725Z_fp05b/protocol/PREREGISTRATION.md`

N112/23blocks；M3/Fs 点0.00261143189908、CI上界0.00284374299472<0.0034；M3/M1点-3.019276e-6且CI跨0；oracle/M1上界0.000666927041656<0.0034。因此“不达门槛/无有用动态增量”成立，“完全没有正效应/完全未跑OOS”不成立。

**最小行动：**旧数值、fold、roster、阈值保持不可变；只读复算并按第一匹配规则收尾，不扩样、不用 S0 翻案。



## R26-07 · P0 · EXECUTION_CONFIRMED · FP06 CLI fail-open 已独立复现

`scripts/r5_audit_runner.py:17-31`
`earthdelta/fp06_decision.py:16-22`
`evidence/CPU_PROBE_RESULT.json`

两份源码按 Git blob 重建校验一致后运行真实 CLI：missing evidence_valid 和字符串 false 均被 bool(...default True) 转为 True，产出 PIVOT_STATIC/rc0；核心函数原本拒绝这两种输入。显式布尔 False 返回 INVALID，但 CLI 仍 exit0。此漏洞在新后处理，不证明历史 FP05b 曾被该入口污染。

**最小行动：**入口必须严格 is True 且消费可信 gate artifact/hash，不信 caller bool；冻结 delta 与结果阈值一致；INVALID 返回非零。补齐 receipt/endpoint 子命令或明确采用经测等价工具。



## R26-08 · P1 · STATIC_CONFIRMED · 逐 lead 勘误仅部分实现，未形成已执行的严密闭环

`scripts/r5_score_erratum.py`
`earthdelta/policy_oof.py:420-493`
`scripts/r4_policy_oof.py:40-125`
`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/dev_results.csv`

已改为逐 lead 的 H_Fs，正常 scorer 增加 source/F0/hash/全覆盖绑定是进展。但 erratum 只对比旧24h status，不比较点估计/CI；paired_F0_intervals 实际只保存 H_Fs 区间；driver 未在 source_record 中自绑定；gate false 时 main 仍可能 rc0。未取得新 erratum 运行产物。

**最小行动：**用本包独立标量工具产生所有 lead 的 M-F0 配对区间；正式 append-only erratum 必须锁旧输入、新 scorer+driver 与白名单 diff，24h数值/CI/动作全核对，原文件前后 hash 不变，失败非零退出。



## R26-09 · P0 · STATIC_CONFIRMED · WeatherBench-X 年份门已接入口但遗漏 valid-time/support

`earthdelta/wbx/evaluate.py::assert_years_authorized`
`earthdelta/wbx/evaluate.py::evaluate`
`earthdelta/wbx/evaluate.py::evaluate_single_chunk`

evaluate 在 loader 前检查 init_times 年份是实质进展；然而 2020-12-31 + 72h 会读取2021 truth，init-year-only 不会拒绝。single_chunk 信任 caller 提供 init_times，不绑定已载数组时间坐标；任意 authorized 集合和自签 hash 不是外部数据授权。

**最小行动：**按实际 init+lead/valid_time/history/support 及受批 allowlist 绑定所有真实读取，跨年、伪造 coords、扩大 authorized 的负例在 loader 前拒绝。



## R26-10 · P1 · MISSING · 新缓存与 WBX 原始 GPU 回执尚未闭合

`plans/plan_v4_0923/run_20260924T104725Z_fp05b/jobs/`
`plans/plan_v4_0923/run_20260924T104725Z_fp05b/analysis/cj2_independent_verify_noloss.json`
`artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/job_result.json`
`artifacts/round2_cci/ed-r4cachecj2-0924125702-926f58/job_result.json`
`artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json`

CJ2有四分片产物/显存/模型加载记录，统计计算也有产物，但 jobs 树仅 argv/dry-run，没有完整平台job_id+原始returncode+elapsed联结。TierB原件读取404。不能把FP05a恢复的旧20job回执算作这些新job。

**最小行动：**恢复原 receipt/invocation/source/shard logs/TierB表，不为补发票而重跑天气训练。



## R26-11 · P1 · STATIC_CONFIRMED · FP07 诊断入口与功能分解仍需修订

`scripts/r5_diagnose.py::freeze`
`scripts/r5_diagnose.py::diagnose`

函数校验 protocol.inputs 中的路径，却随后从独立 --inputs 路径读 cache/freeze，未强制两者同一对象；叶节点哈希未全部消费，前后只检查四个上层文件。中心化仅减列均值，仍包含所有专家共享的样本难度方向，不能单凭其rank宣称状态依赖专家互补。

**最小行动：**唯一解析根、逐叶hash/原件禁止写；输出 common component、双向中心化 interaction、加权switch贡献与oracle/M1 headroom。issue_time从已pin admission读取；matrix里字段存在性待真实输入验证，不猜。



## R26-12 · P1 · STATIC_CONFIRMED · 源码与命令交付不等于 v6 全计划执行

`plans/plan_v6_0925/EXECUTION_STATUS_20260925.md`
`scripts/r5_audit_runner.py::build_parser`
`scripts/r5_diagnose.py::main`
`earthdelta/policy_oof.py:330-364`
`plans/plan_v6_0925/EarthDelta_Codex_Followup_Plan_20260925.zip::CODEX_TASKS.json`

v6要求的 receipt-audit/endpoint-audit/strategy-packet 等没有当前runner接口；诊断另有实际子命令。新48测试只有状态文档，未得原log；最新已读取真实历史全套log为917passed/19skipped。OOF只保参数digest，不等于可部署selector。

**最小行动：**命令冒烟与缺口表统一；未实现命令标NEW_AFTER_IMPLEMENTATION。正式回执完成才升级DONE，公开WBX动态比较先有完整可加载策略。



## R26-13 · P1 · PLAUSIBLE_UNVERIFIED · 最值得保留的是状态依赖有限参数干预的效用预测，而非现成K4路由性能

`README.md`
`plans/plan_v4_0923/run_20260924T104725Z_fp05b/evaluation/dev_results.csv`
`evidence/LITERATURE_REVIEW.md`

LoRA、adapter routing、误差影响、在线专家选择均有近邻。误差与有限响应分解可形成组合性方法贡献，但须证明超出直接gain预测的迁移/成本/拒绝有害编辑价值。当前没有该证明。

**最小行动：**先用已有缓存识别头部问题是候选互补性还是selector；新实验最少保留F0/Fs/static/direct/factorized/oracle及状态置换对照，按新协议另立身份。
