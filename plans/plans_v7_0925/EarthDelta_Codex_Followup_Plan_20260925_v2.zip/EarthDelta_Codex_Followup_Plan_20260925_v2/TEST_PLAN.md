# 测试层次与真实执行要求

## A. 交付工具／本轮独立审计
本包的 source_copy 两个小Python文件与远端git blob相同。`reproduce_runner_probe.py` 复现缺validity/string-false默认许可漏洞；它运行的是**有已知缺陷的历史源码拷贝**，不是修复验收。`recompute_native_evidence.py --self-test`只有合成4项检查，不是112-case真实复算。

## B. CPU／真实入口修复
1. FP06缺missing/null/string/数值flag、wronggate/source/protocol/threshold全拒绝；显式INVALID不能return0。枚举729语法状态之外还测missing和identity，不能把规则枚举当事实validity认证。
2. Fs trace length/issue/time、clip计数与preclip范数一致；中期爆炸后恢复不能只看first-last；历史坏证书/weights/不同Fs混合拒绝；预期在模型构造前，spy后继为0。
3. scorer full roster、F0、fold、prediction/source/driver任一hash变动拒绝；不同lead构造不同H确保只改6/72时不污染24；F0配对差CI直接共同draw计算。24hstatus相同但点值变化应失败。
4. WBX valid_time跨年、history越界、伪造init coords、任意authorized扩大、unsigned/未批准permit、singlechunk元数据不一致，全部在loader/aggregate前拒绝。
5. 诊断--inputs另指文件即使冻结ref未变也拒绝；叶子替换拒绝；a_i+b_k矩阵双向interaction应0；真实issue_time从admission重建；全部旧树hash不变。
6. poison outer eval+purged labels，只比较被毒化fold自己的OOF；不要要求其它合法以其为train的fold不变。negative测试必须走正确拒绝原因，import失败不算。

## C. GPU gate
本轮不默认提交GPU。验证既有ACP原件，独立计算source/assets，保留original failures。原4卡S0不自动外推native镜像、SDPA、其他torch；任何backend改变需新的限定gate，不改旧FP05身份。

## D. 科学结果
只读原112case。重算N×5×3与同draw CI，核对7天主／14天敏感性。小正effect与0.34%bar分开，M3/M1方向CI跨0与BELOW bar分开，oracle headroom与可部署策略分开。新erratum不改24h被冻结主数字。

## E. 回归与发布
在真正工作区运行现有全部tests并保存命令、junit、skip reasons、walltime、source与环境；已读917/19历史日志不能当最新HEAD新执行。提交不含权重/密钥/私人环境变量；前后SHA、DAG与task字段完整。
