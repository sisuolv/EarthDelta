# 可复现性与版本边界

远端阅读锚点：`8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`；实现为`85ed929f565191cf428ba8d491000542e55fe49e`；v6基线`45edd51b563a626e01b31af24e0d95afa6d56d7b`。本次没有本地工作区认证，也没有改远端。运行前重新读取HEAD/status/ahead-behind；不要reset用户工作。

固定核心17文件取自FP04 protocol/source manifest，逐一rehash。bridge/s0/Fs/bank与新后处理脚本分清；被pin核心更改必须有新版本合同，不能只把旧protocol里的hash替换为新值。修正clip一致性可用新增独立validator，不必改冻结核心。

模型环境以原执行overlay和有效导入路径为准，不靠pip包版本字符串或GPU型号猜测。sm_120/5090 engineering probe和官方H100路径隔离；所有日志保留PYTHONPATH的非秘密路径、CUDA/driver/torch/xf/version/precision和source_root。记录包清单和wheel/imagehash，禁止自动在执行中pip升级。

所有旧数据文件与源结果hash先封存。尽量使用repo外只读snapshot或copy+read-only权限；以最终hash验证，而不声称chmod可抵抗任意恶意同权限写入。路径可重定位，但必须提供显式asset-map，验证相同内容，不修改原manifest。case/task/seed/hold/lead/Q/scale/损失分母与训练时间支持全部记录。

本包 `tools/recompute_native_evidence.py` 来自上一v6包，经metadata字段修订标明旧输入基线与本地实际HEAD；数值计算与原blob pins保留。输出必须在repo外且exclusive-create。它不加载torch/天气zarr、不会fit或新GPU、仅检查原标量矩阵与配对统计；端点→标量与原job真实性另有gate。

源码spawns command、returncode、elapsed同时写日志；任何失败不得只凭file存在升格PASS。最终SHA256对所有交付文件逐个计算，不包括SHA表本身以避免自引用；ZIP另算SHA并存旁路`.sha256`。

Remote URL与环境日志需移除URL用户信息、PAT/API key等认证部分，仅保存允许的非秘密路径、版本、hash；不要复制整个环境变量或凭证文件。
