#!/usr/bin/env python3
"""Reproduce the OBSERVED BUG on bundled hash-identical historical source.
This detects an existing defect; a pass is NOT a test that the repository is fixed.
No GPU, credentials, weather data, network, or write to the real repository.
"""
from __future__ import annotations
import argparse, hashlib, itertools, collections, json, os, subprocess, sys, time
from pathlib import Path
sys.dont_write_bytecode = True
PINS={'earthdelta/fp06_decision.py':'906d8b8ce56022eccf1039dfb23941cf1e3a80e0',
      'scripts/r5_audit_runner.py':'2742bf307b06818f2a7728fbb8b22386a2bf1116'}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    pkg=Path(__file__).resolve().parents[1];src=pkg/'evidence/source_copy';out=a.out.resolve()
    if out.is_relative_to(pkg):raise ValueError('Output must be outside the package')
    out.mkdir(parents=True,exist_ok=False);ident=[]
    for rel,want in PINS.items():
        b=(src/rel).read_bytes();got=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
        if got!=want:raise ValueError(f'Historical source blob differs: {rel}')
        ident.append({'path':rel,'git_blob':got,'sha256':hashlib.sha256(b).hexdigest()})
    sys.path.insert(0,str(src))
    from earthdelta.fp06_decision import decide_fp06
    names=('oracle_vs_Fs','oracle_vs_M1','M1_vs_Fs','M3_vs_Fs','M3_vs_M1')
    comp={n:{'status_vs_delta_min':v} for n,v in zip(names,('STRADDLE','BELOW','BELOW','BELOW','BELOW'))}
    comp['M3_vs_Fs_72h']={'harm72_guard_pass':True};results=[]
    for label,value in [('missing',None),('string_false','false'),('boolean_false',False)]:
        obj={'comparisons':comp}
        if label!='missing':obj['evidence_valid']=value
        ip=out/(label+'.json');ip.write_text(json.dumps(obj));op=out/(label+'_cli')
        cmd=[sys.executable,'-m','scripts.r5_audit_runner','fp06-decision','--inputs',str(ip),'--out',str(op)]
        t=time.monotonic();r=subprocess.run(cmd,cwd=src,env={**os.environ,'PYTHONPATH':str(src),'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True)
        parsed=json.loads((op/'decision.json').read_text())
        want='INVALID' if label=='boolean_false' else 'PIVOT_STATIC'
        if r.returncode!=0 or parsed['verdict']!=want or decide_fp06(obj)['verdict']!='INVALID':
            raise AssertionError('Historical defect no longer reproduced on purported same bytes')
        results.append({'case':label,'returncode':r.returncode,'elapsed_seconds':time.monotonic()-t,
                        'command':cmd,'core_verdict':'INVALID','cli_verdict':parsed['verdict'],
                        'stdout':r.stdout,'stderr':r.stderr})
    count=collections.Counter()
    for vals in itertools.product(('ABOVE','BELOW','STRADDLE'),repeat=5):
        for guard in (True,False,None):
            c={n:{'status_vs_delta_min':v} for n,v in zip(names,vals)};c['M3_vs_Fs_72h']={'harm72_guard_pass':guard}
            count[decide_fp06({'evidence_valid':True,'comparisons':c})['verdict']]+=1
    doc={'status':'OBSERVED_DEFECT_REPRODUCED','scope':'CPU_SYNTHETIC_ONLY_NOT_A_FIXED_REPO_TEST',
         'sources':ident,'cases':results,'syntactic_states':729,'outcomes':dict(count),'gpu_executed':False,'real_weather_read':False}
    (out/'probe_result.json').write_text(json.dumps(doc,indent=2)+'\n')
    print(json.dumps({'status':doc['status'],'out':str(out)}));return 0
if __name__=='__main__':raise SystemExit(main())
