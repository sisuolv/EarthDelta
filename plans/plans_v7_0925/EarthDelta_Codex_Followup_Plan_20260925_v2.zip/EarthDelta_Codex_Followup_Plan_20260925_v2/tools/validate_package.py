#!/usr/bin/env python3
"""Validate package structure, JSON, DAG and frozen constants; not project science."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
ROOT_FILES=['START_HERE_FOR_CODEX.md','FOLLOWUP_PLAN.md','EXECUTION_DAG.md','STOP_CONDITIONS.md','CODEX_TASKS.json','ARTIFACT_CONTRACT.md','TEST_PLAN.md','REPRODUCIBILITY.md','CURRENT_GAP_ANALYSIS.md','evidence/PLAN_AUDIT_RESULT.json','evidence/EVIDENCE_MANIFEST.json','evidence/REQUIRED_INPUTS.md','prompts/CODEX_EXECUTION_PROMPT.md']
FIELDS={'id','priority','depends_on','scope','commands','acceptance_criteria','evidence_outputs','stop_if','status','estimated_minutes'}
def validate(p:Path):
    checks=[]
    def need(ok,name):
        checks.append({'name':name,'passed':bool(ok)})
        if not ok:raise ValueError(name)
    need(p.name=='EarthDelta_Codex_Followup_Plan_20260925_v2','archive root name')
    need(all((p/x).is_file() and (p/x).stat().st_size for x in ROOT_FILES),'all required nonempty files')
    docs={str(f.relative_to(p)):json.loads(f.read_text()) for f in p.rglob('*.json')}
    need(bool(docs),'all json parses')
    tasks=docs['CODEX_TASKS.json'];need(len(tasks)==7,'seven new bounded tasks')
    ids=[x['id'] for x in tasks];need(len(ids)==len(set(ids)),'unique task ids')
    need(all(FIELDS<=set(t) for t in tasks),'required fields')
    need(all(t['status']=='TO_BE_RUN' for t in tasks),'future results not forged')
    need(sum(t['estimated_minutes'] for t in tasks)==540,'timeboxes total 540min')
    seen=set();remaining={t['id']:set(t['depends_on']) for t in tasks}
    need(all(d<=set(ids) for d in remaining.values()),'dependencies exist')
    while remaining:
        ready={i for i,d in remaining.items() if d<=seen}
        need(bool(ready),'acyclic topological wave')
        seen|=ready
        for i in ready:remaining.pop(i)
    need(len(docs['evidence/V6_TASK_DISPOSITION.json'])==20,'all original 20 tasks covered')
    a=docs['evidence/PLAN_AUDIT_RESULT.json'];need(a['stage4_authorization'].startswith('DENIED'),'new Stage4 denied')
    need(a['audit_execution']['gpu_jobs_submitted']==0,'no auditor GPU fabrication')
    c=docs['evidence/S0_AND_ASSET_CONTRACT.json'];need(c['official_parity']['tolerance_max_abs']==1e-5,'S0 frozen tolerance')
    need(c['official_parity']['new_job_id']=='pt-lujnmfhg' and c['official_parity']['new_raw_certificate_status']=='MISSING','new S0 raw status honest')
    n=docs['evidence/FROZEN_FP05B_RESULTS.json'];need(n['delta_min']==.0034 and n['N']==112,'frozen bar and N')
    need(n['comparisons']['M3_vs_Fs']['status_vs_delta_min']=='BELOW' and n['comparisons']['oracle_vs_Fs']['status_vs_delta_min']=='STRADDLE','frozen results retained')
    sp=docs['evidence/CPU_PROBE_RESULT.json'];need(sp['findings']['missing_validity_accepted'],'CPU counterexample included')
    sf=p/'SHA256SUMS.json'
    if sf.exists():
        hashes=docs['SHA256SUMS.json']['files'];actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f!=sf}
        need(set(hashes)==actual,'hash table complete')
        for rel,want in hashes.items():
            need(hashlib.sha256((p/rel).read_bytes()).hexdigest()==want,'sha256 '+rel)
    return {'status':'PASS','scope':'PACKAGE_ONLY_NOT_EARTHDELTA_GPU_OR_SCIENTIFIC_VALIDATION','checks':checks,'n_checks':len(checks),'json_files':len(docs)}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--package',type=Path,required=True);ap.add_argument('--out',type=Path);a=ap.parse_args()
    try:
        r=validate(a.package.resolve())
        if a.out:
            a.out.parent.mkdir(parents=True,exist_ok=True)
            with a.out.open('x') as f:json.dump(r,f,indent=2)
        print(json.dumps({'status':r['status'],'n_checks':r['n_checks'],'scope':r['scope']}));return 0
    except Exception as e:
        print(json.dumps({'status':'FAIL','error':str(e)}));return 2
if __name__=='__main__':raise SystemExit(main())
