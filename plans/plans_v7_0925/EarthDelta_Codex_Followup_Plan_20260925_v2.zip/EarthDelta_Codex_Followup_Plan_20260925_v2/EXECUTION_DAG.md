# 执行DAG与状态门

```text
FP-09a (read-only identity + sealed sources + G0 S0)
  └── FP-09b (raw trace → Q1-Q6 → certified Fs/bank → G1)
FP-09c (independent CPU synthetic entry repairs → G2)
09a + 09b + 09c
  └── FP-09d (sealed original cache only → exact recompute + erratum → G3)
        └── FP-09e (frozen exploratory diagnostics, no new model)
               └── FP-09f (validated first-match decision + proposed pivot)
                      └── FP-09g (independent regression and evidence delivery)
```

G0/G1/G2/G3 必须有真实artifact与hash，不能靠CLI returncode、caller bool或任务名通过。source/instrumentation更新与旧协议必须可区分。

**没有通往新Stage4/GPU训练/扩样/confirm的授权边。** 旧FP05b缓存已存在，本DAG只读复算，不重新生产数据。最新S0与旧S0合同不能静默替换。G0/G1失败禁止下游科学模型run；纯合成09c可以独立继续。缺原件时任务可产出inventory+BLOCKED，但不能产出冒名G0/G1 PASS。

FP06仅在G3完整后执行。其正面或负面返回都不自动授权GPU；预计PIVOT_STATIC是可复核推导，不是写死的验收结果。语义上不把A1-A5或S0作为scientific-support父节点。


## 历史合同与最新复验分开
G0必须分成 `G0_OLD_FROZEN_CONTRACT` 与 `G0_NEW_RECHECK`。前者绑定原FP05b实际消费的S0、source与资产，是复算原结果的身份前提；后者绑定新pt-lujnmfhg，仅用于认证“最新环境复验已通过”的声明。若原合同可完整核验而新原件缺失，最新复验保持MISSING/INCONCLUSIVE，不替换旧证书，也不阻止已封存旧缓存的只读复算。任何新模型科学作业仍没有本包授权；原合同或Fs gate本身失败则不得将旧缓存复算升级为经过认证的科学结论。不要因为后来的一张回执未上传，就倒推旧试验一定失效。
