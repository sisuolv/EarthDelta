# 每项实验／审计的artifact合同

每任务保存 `task_result.json`（schema, task_id, status=OBSERVED或TO_BE_RUN/MISSING/BLOCKED, started_utc, finished_utc, command/argv数组, returncode, elapsed_seconds, stdout/stderr文件hash, git_head, branch, dirty_diff_hash, source_manifest_sha256, input_hashes, output_hashes, gate_reasons）。
结果分四轴，不能相互推导：
`ENGINEERING_PASS`（具体门名与范围）；`EXPERIMENT_EXECUTED`（CPU/GPU及实际回执）；`SCIENTIFIC_SUPPORT`（支持/不支持哪一固定假设）；`NOVELTY_SUPPORT`（相关对照是否执行，未知则INCONCLUSIVE）。

## S0附加必填
采用 `evidence/S0_AND_ASSET_CONTRACT.json`，其中区分旧已登记pin与新仅报告pin。最新job_id必须是 `pt-lujnmfhg` 的真实原件映射；Torch2.3.1+cu121/xformers0.0.27，image digest/overlay wheelhash/import路径/有效TF32/设备；bridge、contracts、lowrank、s0 gate、official reference实现的executed source SHA-256；checkpoint `7fde884ec85f4999d4bcb02d55ed72c142912071956083ebee08d3d86311b695`；normalization identity `ed-norm-identity/1:3e0b216bfbf34ab0` 与完整NPZ内容hash、变量/坐标。
必须绑定official manifest、input、reference1/4/12、actual1/4/12（shape/dtype/maxdiff/meandiff/finite、固定tol1e-5）。原文件摘要与自己重hash分别记 expected/actual。four allocated GPUs只说明配置，不填四份不存在的独立parity。

原生四single job与overlay smoke单独保存hardware_available/dependency_available/official_backend_ready，不能用总PASS隐藏缺xformers。

## Fs/bank附加必填
完整loss、grad_total/A/B、parameter/update norm、clip阈值与事件、issue_id/time顺序、初/末adapter及backbone digest、optimizer超参/scheduler/seed/rank/blocks；L0/F0/L1固定面板及Q0-Q6逐项；指定candidate与replica证据；training eligibility和外部qualification不能混为一项。
quality_gate artifact必须绑定对应weights/rawtrace/protocol/source；实际消费者在load前重hash所有引用。counter重算与原record不符即INVALID。Bank另存四expert共同Fs、所有E0–E6、assembly/reload A1–A5、registry输入、probe作用范围。

## Cache/OOF/science附加必填
精确issue/support/role/分片/合法read-set、112×5×3、F0同集合、官方变量顺序与raw/normalized定义；loss及非有限fallback计数、endpoint/target/hash。Frozen folds/inner folds/purge、train-only preprocess/HPO、候选tie规则、每issue一次OOF、prediction freeze与label-access。
Bootstrap存block映射、draw index或可重现seed/算法、ratio denominator、point/CI/ABOVE-BELOW-STRADDLE、72h safety、同draw的H_h和policy-F0区间；F0背景不是候选。24h旧结果不变必须比较**数值/CI/动作**，不是仅比较status。Erratum保存old_input_manifest、new_source_manifest（包括driver）及approved_diff；绝不编辑原文件。

## 授权gate
`gate.json`: schema, gate_name, passed(boolean), reasons, verified_input_manifest_sha256, source_manifest_sha256, allowed_capabilities, parent_gate_sha256s。布尔True本身不是证据；CLI需重hash其输入与父证据。独立验证者不得只读被检者summary。
默认allowed_capabilities仅read_sealed_artifacts/cpu_synthetic_tests；新Stage4/new_weather_reads/confirm/new_gpu_training永远False，除非新的单独授权文件与新协议明确允许。


## 历史合同与最新复验分开
G0必须分成 `G0_OLD_FROZEN_CONTRACT` 与 `G0_NEW_RECHECK`。前者绑定原FP05b实际消费的S0、source与资产，是复算原结果的身份前提；后者绑定新pt-lujnmfhg，仅用于认证“最新环境复验已通过”的声明。若原合同可完整核验而新原件缺失，最新复验保持MISSING/INCONCLUSIVE，不替换旧证书，也不阻止已封存旧缓存的只读复算。任何新模型科学作业仍没有本包授权；原合同或Fs gate本身失败则不得将旧缓存复算升级为经过认证的科学结论。不要因为后来的一张回执未上传，就倒推旧试验一定失效。
