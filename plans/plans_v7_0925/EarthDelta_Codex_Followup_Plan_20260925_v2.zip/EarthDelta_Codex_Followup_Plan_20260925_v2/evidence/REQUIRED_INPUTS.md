# 必要外部输入：优先提供小回执，勿无谓上传大权重

这里的 MISSING 表示审计环境没有原件，不表示AFS上不存在。Codex在原机器先读取；原件可本地访问且可hash时不需上传聊天。

## 1. 最新S0与环境（FP-09a）
- `/mnt/afs/260010168/acp_runs/ed-r6-s0-overlay-recheck-20260925T115020Z/s0/gate_output/s0-gate-20260925t115202730947z/s0_gate_result.json`，预期文档SHA `4aab593d3326f754b866815e9a5d0a15ff1336a1f51079ba38689d4251949670`。
- 同一run的 `request.json`、实际source manifest/快照或diff、ACP `pt-lujnmfhg` 提交与完成回执、原 `job_result.json` 或等价完成记录（job_id、returncode、elapsed_seconds、start/end、stdout/stderr hash）。文件名不同须用实际枚举映射，禁止伪造固定文件名。
- `/mnt/afs/260010168/acp_runs/ed-r6-h100-overlay-20260925T114520Z/result.json`，预期文档SHA `a274a272393cfc616f436092dc7b797d8f9b1c490a44bf08677721da5ddb315e`，对应`pt-ctdnreud`。
- `/mnt/afs/260010168/acp_runs/ed-r6-h100-4single-20260925T113532Z/shard*/result.json` 与四个真实job映射：`pt-qg3ebil5`、`pt-wqhw710g`、`pt-edomquse`、`pt-sr6n07b3`。
- 实际overlay根、wheel/镜像摘要、pip freeze/import path/有效TF32；official reference manifest、原输入与1/4/12 reference张量的hash；checkpoint/NPZ/坐标顺序hash。大文件只需本地可读+实际重算hash，不要求聊天上传。

## 2. Fs与bank lineage（FP-09b）
- `plans/plan_v4_0923/run_20260924T013959Z_fp03_v2/certify/fs/` 的adapter/merged权重及原始V2-J3四replica `fs_fit_record.json`、`fs_panels.json`、`provenance.json`、`run_record.json`；V2-J4 freeze/reload原件。
- `plans/plan_v4_0923/run_20260924T033627Z_fp04_bank/certify/bank/` 的 `bank.pt`、四expert与probe、manifest/registry；对应训练、组装、verify原回执。
- 至少一份历史坏Fs真实trace作为只读负控制。Q1/Q2必须从raw trace重算，不只相信summary的eligible。坏Fs无需进入GPU即可在入口拒绝。
- 原始路径：`artifacts/round2_cci/ed-r4fs03v2p-0924020931-71716b/`、`ed-r4fs03v2j4-0924021935-be0786/`、`ed-r4bankbj2-0924052624-dde08d/`、`ed-r4bankbj3r-0924054117-185e82/`。

## 3. 现有FP05b与WBX（FP-09d）
- `plans/plan_v4_0923/run_20260924T104725Z_fp05b/cache/dev/candidate_results.json`、`background_f0.json`、cache manifest；完整policies目录的fold、OOF、prediction freeze、label access/per-fold文件；原paired bootstrap与dev_results.csv；已pin admission只用于issue time元数据。
- `artifacts/round2_cci/ed-r4cachecj1-0924123848-4457b0/` 与 `ed-r4cachecj2-0924125702-926f58/` 的真实job completion、invocation、source manifest和shard日志。旧20-job账本不能代替这两个新job。
- 3个预先按hash选定debug及3个dev issue的**现有**原端点/targets，以同dtype/变量/Q/scale独立复算loss；无端点则记MISSING，不启动新cache补造历史证据。
- `artifacts/wbx_smoke/20260924T135007Z_tierB/tierb_summary.json`、原metric表、GPU记录、forecast/truth支持窗、官方代码pin及Tier-A原回执。若实际目录名不同，请提供metadata映射。

## 4. 非默认必要项
2022下载原日志仅用于FP08a后续metadata根因诊断；本次不默认读取2022 weather values。新confirm/new benchmark/新训练都不由本包自动授权。缺上列必要原件时冻结相应gate并继续允许纯合成修复测试，不伪造PASS、不用重跑掩盖旧缺件。
