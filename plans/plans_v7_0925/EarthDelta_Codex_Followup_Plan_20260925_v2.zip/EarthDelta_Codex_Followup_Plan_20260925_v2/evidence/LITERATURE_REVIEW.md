# 相关工作与最强可辩护贡献（检索日期 2026-09-25）

以下基于论文作者摘要/正式出版页和官方仓库文档，不声称穷尽检索、复现论文结果或取得“首个”的优先权证明。

| 工作 | 已有内容与重叠 | EarthDelta仍需要证明什么 |
|---|---|---|
| Aurora, Nature 2025, DOI 10.1038/s41586-025-09005-y | Earth-system foundation model、多任务适配；roll-out fine-tuning 使用LoRA | “天气模型上使用LoRA”不是新贡献。需证明逐起报有限编辑的效用预测与选择价值。 |
| WeatherPEFT, ICLR 2026, arXiv:2509.22020 | task-adaptive动态prompt和Fisher-guided参数选择 | 参数效率/天气任务适配已存在；候选干预对未来误差的样本依赖效用须独立证实。 |
| PETSA, ICML 2025 TTA workshop, arXiv:2506.23424 | 时序预测中的轻量校准、低秩模块和dynamic gating | 不是同一全球天气实验；EarthDelta冻结bank+OOF不自动成为在线TTA，须说明标签到达与更新时序。 |
| CoMoL, arXiv:2603.00573v2, 2026-06-04 | 低秩expert/core-space routing/动态合并 | “LoRA专家+路由”非独占；参数不同不保证天气响应或最优动作不同。 |
| VI-MoLE, arXiv:2608.02528v1, 2026-08-03 | 预测counterfactual remaining risk，按risk reduction/cost路由，允许abstain | 不能声称首个utility而非uncertainty路由。对比应落在天气动力学有限参数响应、误差几何和跨候选/目标迁移。 |
| MergeProbe, arXiv:2606.19549v1, 2026-06-17 | 从早期更新/梯度/表征预测adapter合并后utility retention并决策 | 它的mergeability是效用保留，不是EarthDelta的数值merge-equivalence；两者不可混为同一成功指标。 |
| Langland & Baker 2004, DOI 10.1111/j.1600-0870.2004.00056.x | adjoint-based observation impact/短期预报误差影响 | 误差敏感度和impact不是新思想；新对象可为冻结神经预报器上的有限参数干预，而非观测/初始状态扰动。 |
| Gonzalez & Brayshaw 2021, DOI 10.1002/qj.4177 | sequential expert weighting/online multimodel weather-sensitive forecasting | 在线选择专家并非新命题；EarthDelta当前回顾性OOF不可当历史部署回测。 |
| WeatherBench-X 官方 google-research/weatherbenchX 文档；WB2 JAMES 2024 DOI10.1029/2023MS004019 | WBX是评价框架，继任WB2评价代码；WB2 benchmark仍在使用 | 调通官方metrics或一个TierB smoke不是公开benchmark排名或动态编辑性能证据。 |

## 当前最强表述
“研究能否从当前可获得的天气状态预测有限参数干预的后续响应，并将响应与基线预测误差对齐，在共享代价下选择或拒绝编辑；通过冻结的配对回放、静态/直接gain预测和oracle对照，检验动态性是否真正必要。”

设 `e = truth - forecast_Fs`，`d = forecast_edit - forecast_Fs`，Q为冻结权重，则精确恒等式
`gain = ||e||_Q^2 - ||e-d||_Q^2 = 2<e,d>_Q - ||d||_Q^2`。
这只是平方损失代数，不是新定理，也不需要把有限d误写为线性Jacobian近似。研究增量在于：不看未来truth、不逐候选完整rollout的情况下，能否学到可迁移的e/d效用并降低有害编辑/计算成本。当前未完成此验证。

## 最小对照而非堆模块
保留 F0、固定Fs、train-only选择的static/M1、direct-gain/M3、拟议factorized响应法、score-only oracle；尽可能同信息、同数据、同候选与匹配部署成本。响应法至少对比常量/全局响应、合法状态依赖响应、打乱状态-响应对应。新贡献还需在未用于训练响应头的候选或冻结的新Q/lead上显示迁移，不能仅在同一K4 gain标签上打赢一次回归。

## 当前投入判断
已有K4的oracle相对M1上界低于原0.34%工程效用界，优先诊断候选互补性而非扩大selector或追加相同评估样本。负结果不是整个研究方向被证伪；可保留“识别何时动态编辑没有价值”的可重放评价工具，但单一小型负试验还不足以声称通用benchmark或方法novelty。
