# 范围与可复核边界

远端审查锚点：`8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`，实现提交 `85ed929f565191cf428ba8d491000542e55fe49e`；本地工作区连接失败，不能认证 clean/synced。
Canonical v6 ZIP 从 Library materialize，完整字节 SHA-256 为 `a3adbf8c5e93d0e44a4a5dd1976754c9af113c8451a14a7875cc9d6a98b318b5`；Git blob `e904950e5ac85db9c48c7c6b48a417e0898aa9e1` 与远端一致。
已完整读取根与v6三个指定状态文档、v6六个指定合同与全部20任务，以及旧331行 ROUND4_REPORT 和 divergence assessment。大型重复 trace、完整1.7MB candidate矩阵、完整AFS原件未在本次环境取得；辅助审计JSON只读取关键范围，不能声称“所有原始证据全文独立复现”。

原始ACP结果、权重和完整数据不在聊天容器中；文件路径/哈希陈述不是实际文件存在性证明。最新S0只有状态索引，不升级为原件认证。私有GitHub可以读，AFS不能读；不把两种限制混为一谈。

独立运行：仅两份源码经git blob一致性验证后的三个合成CLI反例、729个纯规则输入状态，以及本包自检。没有训练模型、没有新GPU作业、没有重跑完整仓库测试、没有复算真实112-case全部bootstrap。记录自带的独立复算为其作者执行，不冒充本轮执行。
