# EarthDelta · 2026-09-25 v2 执行入口

**审查锚点 `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`；当前是 PARTIALLY_EXECUTED，不是动态编辑价值或novelty成立。**

默认授权：本包FP-09a～g的有界CPU/原件只读审计与后处理修复；新GPU=0，Stage4新cache/训练/扩样不授权，confirm=NULL。只有原始回执与实际gate有效才能做正式判决。CPU合成入口修复FP-09c可在缺件调查期间独立做。

先读：`evidence/PLAN_AUDIT_RESULT.json` → `CURRENT_GAP_ANALYSIS.md` → `FOLLOWUP_PLAN.md` → `EXECUTION_DAG.md` → `STOP_CONDITIONS.md` → `ARTIFACT_CONTRACT.md` → `TEST_PLAN.md` → `REPRODUCIBILITY.md` → `CODEX_TASKS.json`。`evidence/V6_TASK_DISPOSITION.json`是原20任务逐项验收，不重新排队训练历史DONE部分。

初始化环境变量（REPO必须用实际工作区；RUN位于repo外，禁止写旧run）：
```bash
export REPO=/mnt/afs/260010168/EarthDelta
export PKG=/absolute/path/to/EarthDelta_Codex_Followup_Plan_20260925_v2
export RUN=/mnt/afs/260010168/acp_runs/ed-r6-audit-v2-$(date -u +%Y%m%dT%H%M%SZ)
export OLD="$REPO/plans/plan_v4_0923/run_20260924T104725Z_fp05b"
test ! -e "$RUN" && mkdir -p "$RUN"
cd "$REPO"
python "$PKG/tools/validate_package.py" --package "$PKG"
```
不要覆盖已有RUN；绑定真实HEAD、分支、工作区diff、remote ahead/behind。HEAD已推进时只审查差异，不强制reset丢失工作。

最重要的修订：FP06 CLI `bool(obj.get('evidence_valid', True))` 已被独立CPU反例击穿；WBX还漏valid-time跨年；erratum与诊断入口尚未形成完整真实执行。H32 Fs已有较强限定资格，不能与旧H500混同；但任何坏Fs不得通过merging或eligible被偷渡。

估时是规划timebox而非运行事实：核心540分钟，最多600分钟；卡住时记录精确缺件。缺AFS原件先读本机，不要求把大权重上传聊天；禁止为补旧回执重跑模型。

所有结果必须分轴：ENGINEERING_PASS、EXPERIMENT_EXECUTED、SCIENTIFIC_SUPPORT、NOVELTY_SUPPORT。FP05b主24h的BELOW/STRADDLE和0.0034不动；FP07永远不能倒写原评价。


## 历史合同与最新复验分开
G0必须分成 `G0_OLD_FROZEN_CONTRACT` 与 `G0_NEW_RECHECK`。前者绑定原FP05b实际消费的S0、source与资产，是复算原结果的身份前提；后者绑定新pt-lujnmfhg，仅用于认证“最新环境复验已通过”的声明。若原合同可完整核验而新原件缺失，最新复验保持MISSING/INCONCLUSIVE，不替换旧证书，也不阻止已封存旧缓存的只读复算。任何新模型科学作业仍没有本包授权；原合同或Fs gate本身失败则不得将旧缓存复算升级为经过认证的科学结论。不要因为后来的一张回执未上传，就倒推旧试验一定失效。
