# 不可静默放宽的合同

## 数值与模型身份
S0：Torch `2.3.1+cu121`、xformers `0.0.27`、官方模型；实际有效matmul/cuDNN TF32均False。1/4/12个6h步的官方参考 max_abs_diff <= `1e-5`，不可删除rollout、换reference、放大tol或以SDPA/bridge-vs-bridge代替。新job `pt-lujnmfhg` raw仍MISSING；报告sha `4aab593d3326f754b866815e9a5d0a15ff1336a1f51079ba38689d4251949670` 是待核验pin，不是PASS。

Fs-v2保持H32、lr0.0025、同8训练issues、seed20260921、Adam原defaults、clip1、blocks18–23/rank4。Q1 finite/exact32；Q2 clip_events0、per-visit L/L0<=1.25、每完整8步epoch <=历史最小epoch均值×1.02；Q3重复8/8下降；Q4 max r_i<1且mean ratio<=0.99为PASS，mean>1或max>1.02为FAIL，其余INCONCLUSIVE；Q5训练72h ratio<=1.01；Q6原16例资格面板24h ratio<=1.02。计数与trace矛盾一律INVALID，不以summary为准。旧H500/H256坏产物不许升格，不能挑worker。

Fs数值merge专用容差维持 `atol=max(1e-5,1.5e-3*delta_max_abs), rtol=1e-5`；它不是S0容差。zero-edit与hold后Fs continuation必须精确。FP04银行A1–A5 `max|diff|=0`，K4/rank4、rho0.25、hold4、共同Fs、四专家all-or-nothing；own-group E3严格ratio<1.00。不事后按OOS gain剔除专家，不跨不同Fs混合。

## 冻结数据与科学结果
原protocol SHA `a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8`；N=112、23个7天strata、缺16/19、原四outer/三inner折、支持窗[t−12h,t+72h]+24h缓冲不变。2019H2是回顾性dev；2020H2含X1曝光，不是clean confirm；confirm=NULL/UNASSIGNED_NO_ACCESS。2022真实weather reads和任何新年份均不默认批准。

目标为原native area-weighted standardized squared loss，主24h；6h报告，72h safety不可替换主目标。所有对比用同lead的sum Fs denominator。delta_min=`0.0034`；95%配对7天block bootstrap、10000draws、seed20260924；14天仅敏感性报告。ABOVE:lo>=d；BELOW:hi<d；否则STRADDLE。72h guard:lo>=−0.0034。

保留：M3/Fs BELOW；M3/M1 BELOW且CI跨0；oracle/Fs STRADDLE；oracle/M1 BELOW。正式first-match是条件PIVOT_STATIC，不是static已过门槛。不能改阈值补救失败，不按中间skill扩样，不用诊断重新选择原OOF超参。

Cache native CPU/GPU scalar对账维持原V5相对1e-12、原解析gainV6 atol1e-11/rtol1e-8；原历史anchor与crossworker精确要求不放宽。独立不同求和次序scalar复算的1e-10界仅作审计工具一致性，既不改变以上门，也不改变科学效用界。WBX自身对账尺度按原协议另核，不套S0或把rel1e-6误称bitwise。

## 入口和写入
缺gate必须拒绝，`bool('false')`/默认True禁止；正式CLI INVALID非零。WBX必须验证实际valid_time/support，2020起报但2021真值不能通过year-only。错误有效性不能靠status字符串推导。

所有FP07输出标EXPLORATORY_DIAGNOSTIC；旧protocol/cache/OOF/evaluation以只读manifest前后hash保护。勘误仅新目录、完整source+driverhash、同输入，24h数值和CI不动。叶节点变化、caller路径替换、坐标替换、秘密扩年均立即STOP。

达到600分钟cap即停止，保存部分结果/MISSING，不删失败、不补造回执。所有unknown用INCONCLUSIVE/MISSING，不把不确定写成负事实，也不把小正点估计写成有用dynamic novelty。


## 历史合同与最新复验分开
G0必须分成 `G0_OLD_FROZEN_CONTRACT` 与 `G0_NEW_RECHECK`。前者绑定原FP05b实际消费的S0、source与资产，是复算原结果的身份前提；后者绑定新pt-lujnmfhg，仅用于认证“最新环境复验已通过”的声明。若原合同可完整核验而新原件缺失，最新复验保持MISSING/INCONCLUSIVE，不替换旧证书，也不阻止已封存旧缓存的只读复算。任何新模型科学作业仍没有本包授权；原合同或Fs gate本身失败则不得将旧缓存复算升级为经过认证的科学结论。不要因为后来的一张回执未上传，就倒推旧试验一定失效。
