# 后续8–10小时：先改变研究判断，再考虑新实验

执行优先级：环境/身份 → Fs谱系与拒绝门 → 后处理真实入口 → 冻结缓存复算/配对F0 → 互补性诊断 → 正式first-match → 回归交付。默认不新增GPU。总timebox540min，最多600min，非已测吞吐承诺。

输入核心为evidence/REQUIRED_INPUTS.md；已有原ZIP/旧结果不重复生成。所有NEW_AFTER_IMPLEMENTATION命令是拟实现接口，先实现与测试/--help再运行，不能当作已存在或已执行命令。可使用功能等价薄封装，但必须写command mapping与相同成功门。

## FP-09a · 60分钟timebox · 封存原证据，恢复最新S0/环境原件并明确身份；新S0不覆盖旧FP05协议

**依赖：**无；先遵守只读与身份边界

**输入：**当前工作区、v6包、原件清单与已保存gate；各依赖任务的evidence_outputs。

**资源：**CPU、metadata/file hashing；新GPU=0

```bash
python "$PKG/tools/validate_package.py" --package "$PKG"
git -C "$REPO" rev-parse HEAD; git -C "$REPO" branch --show-current; git -C "$REPO" status --porcelain=v1; git -C "$REPO" remote -v
git -C "$REPO" fetch --prune origin; git -C "$REPO" rev-list --left-right --count HEAD...origin/audit/round2-review-20260921
NEW_AFTER_IMPLEMENTATION: python -m scripts.r5_audit_runner receipt-audit --repo "$REPO" --inputs "$RUN/inputs.json" --out "$RUN/09a"
```

**预期输出：**`09a/entry.json`；`09a/sealed_inputs_manifest.json`；`09a/receipt_audit.json`；`09a/s0_binding.json`；`09a/G0.json`

**成功标准：**记录真实HEAD/dirty diff/ahead-behind，dirty不是自动清空或reset理由；sealed_inputs_manifest前后hash保持；实际raw新S0与job/source/ckpt/norm/official-ref/effectiveTF32闭合才G0_PASS；缺件必须G0_BLOCKED且给exact path；不升级状态文档为execution

**STOP：**本地HEAD不同但未保存差异审查；任何原件hash矛盾；缺关键raw receipt仅允许inventory/合成测试，不做新模型运行

**失败后的pivot：**原件无法恢复：BLOCKED_PUBLIC_CERTIFICATION；继续纯CPU合成入口修复。禁止凭rerun重新生成所谓旧回执。

## FP-09b · 90分钟timebox · 把旧H500/v1H256/newH32分离，重算稳定性并证明真实cache入口拒绝坏Fs

**依赖：**FP-09a

**输入：**当前工作区、v6包、原件清单与已保存gate；各依赖任务的evidence_outputs。

**资源：**CPU重算/weight hash；不进行天气训练；固定核心17文件不改

```bash
NEW_AFTER_IMPLEMENTATION: python -m scripts.r5_fs_lineage audit --inputs "$RUN/inputs.json" --out "$RUN/09b"
NEW_AFTER_IMPLEMENTATION: python -m pytest -q tests/test_fs_lineage_gate.py tests/test_stage4_rejects_bad_fs.py --junitxml="$RUN/09b/junit.xml"
```

**预期输出：**`09b/fs_lineage.json`；`09b/qualification_recomputed.json`；`09b/rejected_historical_artifacts.json`；`09b/consumer_negative_controls.json`；`09b/G1.json`

**成功标准：**锁adapter/merged/reference/cert/protocol/source及实际cache输入，不能以merge替代Q1-Q6；从trace重算所有计数、same-issue方向、常量lr/optimizer、clip events与记录一致；历史坏Fs、恢复后first-last下降但中期失稳、缺trace、wrongFs/S0/role等在模型构造前拒绝；新H32仅维持原H32资格；不得自动外推到500步；FP04全四专家共同Fs、all-or-nothing保留

**STOP：**原trace/权重身份缺失或矛盾；Q1/Q2/Q4-Q6失败；任何坏Fs可越过真实消费者

**失败后的pivot：**禁止所有新Stage4；仍可审阅sealed历史数值。若要新recipe，用新protocol另行提案，不换掉已冻结Fs。

## FP-09c · 90分钟timebox · 修复FP06、erratum、diagnose、WBX入口，纯合成测试可与缺件调查并行

**依赖：**无；先遵守只读与身份边界

**输入：**当前工作区、v6包、原件清单与已保存gate；各依赖任务的evidence_outputs。

**资源：**CPU合成fixtures；无外部weather读取；可并行

```bash
python "$PKG/tools/reproduce_runner_probe.py" --out "$RUN/09c/observed_old_bug"
NEW_AFTER_IMPLEMENTATION: python -m pytest -q tests/test_fp06_validity_cli.py tests/test_fp06_threshold_binding.py tests/test_fp06_erratum_gate.py tests/test_fp07_input_binding.py tests/test_wbx_actual_support_gate.py --junitxml="$RUN/09c/junit.xml"
```

**预期输出：**`09c/junit.xml`；`09c/negative_controls.json`；`09c/source_diff.patch`；`09c/entry_guard_matrix.json`；`09c/G2.json`

**成功标准：**FP06必须gate原件hash通过且evidence_valid严格True；缺失/字符串/0/错误证据拒绝；CLI delta_min须匹配冻结协议，不能只改报告label；INVALID非零；erratum必须raw数值/CI/动作保持、source driver自hash、逐lead配对F0CI、失败非零；diagnose从同一pinned root读所有叶子并全程只读，时刻从admission恢复；WBX跨年valid_times、history/support、singlechunk坐标与允许列表匹配；真实loader调用前拒绝；不把catch/import失败当negative-control成功

**STOP：**任何绕过可造成未批准数据读取/错误正式判决；修复需要改被冻结核心而没有新合同；测试只有helper没有实际CLI/loader-spy

**失败后的pivot：**有缺口的入口保持disabled；不删除旧结果或偷偷降低guard。

## FP-09d · 90分钟timebox · 读取既有sealed cache独立复算并追加逐lead勘误，补endpoint/WBX对账

**依赖：**FP-09a, FP-09b, FP-09c

**输入：**当前工作区、v6包、原件清单与已保存gate；各依赖任务的evidence_outputs。

**资源：**CPU+NumPy，原端点文件只读；新GPU=0

```bash
python "$PKG/tools/recompute_native_evidence.py" --repo "$REPO" --out "$RUN/09d/native_recompute.json"
NEW_AFTER_IMPLEMENTATION_AND_TEST: python -m scripts.r5_score_erratum --protocol "$OLD/protocol/cache_protocol_v1.json" --protocol-sha256 a42c11dc68d9ede158370a6ba77c4ef8b54cb5cecde30358ee2424fc18ae96d8 --cache-manifest "$OLD/cache/dev/cache_manifest.json" --prediction-freeze "$OLD/policies/prediction_freeze.json" --old-evaluation "$OLD/evaluation/paired_block_bootstrap.json" --out "$RUN/09d/errata"
NEW_AFTER_IMPLEMENTATION: python -m scripts.r5_audit_runner endpoint-audit --inputs "$RUN/inputs.json" --out "$RUN/09d/endpoints"
```

**预期输出：**`09d/native_recompute.json`；`09d/errata/effects_by_lead.json`；`09d/paired_policy_F0_intervals.json`；`09d/endpoint_audit.json`；`09d/wbx_receipt_audit.json`；`09d/old_hashes_unchanged.json`；`09d/G3.json`

**成功标准：**精确112×5×3、F0相同112、OOF每issue一次、23blocks及两空strata完全对应；同seed/block/draw/权重定义复现主24h点值和CI、全部旧status与动作不变；逐lead直接用共同抽样计算M3-F0/M1-F0区间；不做独立CI端点相减；核验旧端点到scalar及WBX原metric表，缺原件只能MISSING，不声称成功；所有勘误写新目录并pin driver/core/原cache/新source；旧evaluation、protocol、predictions前后hash不变

**STOP：**任何未经解释24h点值/CI/动作改变；发现非批准support/数据替换；匹配靠放宽S0/anchor/效用阈值；缺旧端点禁止补跑伪装历史复算

**失败后的pivot：**INVALID证据链先定位计分或身份，保留旧数值及问题说明；不得用新诊断改成正面结论。

## FP-09e · 90分钟timebox · 冻结FP07诊断问题并检验共同修正与真实互补性，不重新HPO原OOF

**依赖：**FP-09d

**输入：**当前工作区、v6包、原件清单与已保存gate；各依赖任务的evidence_outputs。

**资源：**CPU，已有scalar/feature/response文件；缺响应文件不生成新cache

```bash
AFTER_BINDING_FIX: python -m scripts.r5_diagnose freeze-diagnostics --inputs "$RUN/inputs.json" --out "$RUN/09e/protocol"
AFTER_BINDING_AND_DIAGNOSTIC_FIX: python -m scripts.r5_diagnose diagnose --inputs "$RUN/inputs.json" --protocol "$RUN/09e/protocol/protocol.json" --out "$RUN/09e/results"
```

**预期输出：**`09e/protocol/protocol.json`；`09e/results/headroom_decomposition.json`；`09e/results/interaction_decomposition.json`；`09e/results/routing_regret.json`；`09e/results/hypotheses_ranked.json`；`09e/old_hashes_unchanged.json`

**成功标准：**诊断前pin问题/输入/子组/计算规则/新source，不冒称重新confirm；输出common gain和双向中心化expert×issue interaction，constant a_i+b_k toy的interaction为零；M3≠M1的每次switch收益/损失用全部112的Fs分母加权汇总；不能把39切换当有效性；比较calendar/强弱误差/lead的现象仅诊断；不得posthoc换主目标或扩大K；识别候选headroom不足与selector不足的不同证据，给可证伪下一实验而非唯一根因宣称

**STOP：**输入叶子hash或path与冻结协议不同；诊断写回旧目录/标签；把SVD/common-response相关性当因果证明或把posthoc结果升级SCIENCE_PASS

**失败后的pivot：**无有用oracle动态headroom：保留静态/测量工具；若state依赖有限但selector差，提新合法selector对照；不自动启动。

## FP-09f · 60分钟timebox · 正式执行修复后的冻结first-match规则，并提交有限再设计/停止决定

**依赖：**FP-09d, FP-09e

**输入：**当前工作区、v6包、原件清单与已保存gate；各依赖任务的evidence_outputs。

**资源：**CPU；新实验只是设计，不执行

```bash
AFTER_FP06_FIX_AND_G3_PASS: python -m scripts.r5_audit_runner fp06-decision --inputs "$RUN/09f/validated_fp06_inputs.json" --out "$RUN/09f/decision"
NEW_AFTER_IMPLEMENTATION: python -m scripts.r5_strategy_packet --audit "$RUN/09d/native_recompute.json" --diagnostics "$RUN/09e/results" --out "$RUN/09f/strategy"
```

**预期输出：**`09f/decision/decision.json`；`09f/decision/claims.json`；`09f/strategy/MINIMAL_NEXT_EXPERIMENT.md`；`09f/strategy/RESOURCE_DECISION.json`

**成功标准：**只在实际gate有效时正式first-match；预期PIVOT_STATIC但不硬编码结果；保留oracle/Fs STRADDLE和M1/Fs BELOW，PIVOT_STATIC不等于static过门槛；决策包最少F0/Fs/M1/M3/factorized/oracle与状态置换、匹配输入成本；无头部空间先不造复杂selector；无新数据/新year/确认集自动授权；新研究必须新的候选/协议/暴露身份；结果分别ENGINEERING_PASS/EXPERIMENT_EXECUTED/SCIENTIFIC_SUPPORT/NOVELTY_SUPPORT

**STOP：**被R26-07默认bool绕过；threshold不等旧0.0034；claim把小正差值夸成有用dynamic increment、公开WBX胜出或novelty已证

**失败后的pivot：**PIVOT_STATIC或STOP_CURRENT_BANK是合法结论；仅留bounded新假设提案，不自动拨更多GPU。

## FP-09g · 60分钟timebox · 独立回归、发布可重复材料和最终claims审计

**依赖：**FP-09a, FP-09b, FP-09c, FP-09d, FP-09e, FP-09f

**输入：**当前工作区、v6包、原件清单与已保存gate；各依赖任务的evidence_outputs。

**资源：**CPU；全套耗时需要本地实测

```bash
python -m pytest -q tests --junitxml="$RUN/09g/full_suite.xml"
python "$PKG/tools/validate_package.py" --package "$PKG"
NEW_AFTER_IMPLEMENTATION: python -m scripts.r5_audit_runner validate-delivery --run "$RUN" --out "$RUN/09g/final_validation.json"
```

**预期输出：**`09g/full_suite.xml`；`09g/full_suite.log`；`09g/final_validation.json`；`09g/HANDOFF.md`；`09g/claims_matrix.json`

**成功标准：**记录command/rc/runtime/source/env，分清skip vs pass，不相加历史测试数；dry diff和source pins清楚，旧原件树hash不变；所有命令help/schema/输出契约能用；计划工具selftest不包装仓库测试；完整缺件表、20原任务disposition与新任务结果、分轴claims、最终zip hash齐全

**STOP：**任何关键新回归失败或旧文件被改；剩余时间达到600min cap；交付把未运行标DONE或漏报MISSING

**失败后的pivot：**到cap停止并记录部分交付，不靠删测试/吞失败完成；保留可继续复现的最小缺口。

## 新GPU边界

本轮使用原有GPU回执，不新增训练/正式cache。确需诊断环境差异时，应先提出与已知证据区分的具体假设、固定已曝光probe与输出，再单独申请至多1 H100、30分钟的数值诊断；其结果标ENGINEERING_ONLY且不是补造历史回执。该建议不是本包自动授权。

## 新研究设计不等于执行许可

若重新构建bank或更换目标，必须另立new run identity/recipe/准入/效用阈值；不得从已知112个dev结果中挑“好区间”宣称确认。完整候选对照见evidence/LITERATURE_REVIEW.md。


## 历史合同与最新复验分开
G0必须分成 `G0_OLD_FROZEN_CONTRACT` 与 `G0_NEW_RECHECK`。前者绑定原FP05b实际消费的S0、source与资产，是复算原结果的身份前提；后者绑定新pt-lujnmfhg，仅用于认证“最新环境复验已通过”的声明。若原合同可完整核验而新原件缺失，最新复验保持MISSING/INCONCLUSIVE，不替换旧证书，也不阻止已封存旧缓存的只读复算。任何新模型科学作业仍没有本包授权；原合同或Fs gate本身失败则不得将旧缓存复算升级为经过认证的科学结论。不要因为后来的一张回执未上传，就倒推旧试验一定失效。
