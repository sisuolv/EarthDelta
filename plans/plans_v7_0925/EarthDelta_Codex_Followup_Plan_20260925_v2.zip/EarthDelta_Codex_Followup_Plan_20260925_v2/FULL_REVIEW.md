# EarthDelta 独立研究与工程审查 · 2026-09-25 v2

## 结论
**PARTIALLY_EXECUTED。建议继续一轮有界CPU取证/修复/诊断，不支持直接扩大当前动态bank实验。**
关键不是“S0是否绿了”，而是分清：旧发散Fs、新H32认证Fs、当前有限K4的样本外结果、新后处理代码的真实性与入口漏洞。已有FP05b不是“完全没跑样本外”，也不是“完全没有正效果”：M3对Fs小幅为正，但没有达到原0.34%效用门；相对合法静态M1没有可辨认增量。正式冻结规则的**条件推导**是PIVOT_STATIC，不是科学方向已经失败，也不是static已经达标。

### 1. HEAD与证据边界 [R26-01]
远端分支`audit/round2-review-20260921` HEAD `8ab914b877fcf2ace8c0e8da28cd8b0c47f22714`，实现提交`85ed929f565191cf428ba8d491000542e55fe49e`；从v6审查基线45edd51向前两个commit。最新diff没有改变bridge/s0/Fs/bank核心，而是后处理、WBX门、兼容smoke及文档。
本地CodexPro工作区连接失败，无法认证dirty/clean或ahead-behind；不把远端可访问当AFS可访问。v6 ZIP完整字节与Git blob一致，已读六个指定合同和全部20任务。旧331行ROUND4_REPORT、divergence assessment与关键源码/实际JSON已核查；大型raw trace辅助JSON仅关键范围，完整1.7MB矩阵读取返回空内容；AFS/大权重/新S0原件未取得。没有依据本prompt摘要补出原始数值。
本轮独立执行仅两份hash一致源码的三例CPU反证、729语法规约输入枚举及交付工具自检；没有新GPU、没有完整仓库重测，也没有复算全112case真实bootstrap。原record作者的独立复算不能称为本次运行。[E01–E19]

## 2. v6全部任务四层验收
|任务|判定|代码|CPU证据|GPU证据|科学目标|
|---|---|---|---|---|---|
|FP-00|DONE|历史盘点已交付|历史entry回执|不需要GPU|无科学主张|
|FP-01|DONE|旧官方S0已认证|旧回归证据|旧证书1/4/12差0；新pt-lujnmfhg原件MISSING|仅官方数值等价|
|FP-03|DONE|H32强资格/冻结链存在|历史Q1-Q6与测试|指定Fs真实产物；权重本轮未重hash|资格面板+0.3393%损害，非有益|
|FP-04|DONE|共同Fs/K4/registry/精确组装|历史门与测试|原probe A1-A5精确|训练方向资格；OOS价值见FP05b|
|FP-05a|DONE|全曝光ledger、旧回执核对已交付|CPU只读核查产物|原20旧job核查，非新cache receipt|confirm未分配|
|FP-05b|DONE|缓存、legal OOF、score产物已生成|917passed/19skipped历史log|四分片输出已读；原平台receipt未闭合|M3主效用BELOW；动态增量无支持|
|WBX-01A-code|DONE|官方组件复用实现|代码级测试存在；本轮未重跑|TierA原始回执未取得|工程测试不证明性能|
|WBX-01B-code|DONE|TierB代码已实现|旧对账工具代码存在|TierB summary原件404|未核实真实metric表，非公开benchmark|
|FP-02|PARTIALLY_DONE|Fs/cache链进步；后处理/WBX有缺口|部分新guard测试；本轮揭示runner反例|未形成全入口认证|不能升级整条消费链DONE|
|FP-06a|PARTIALLY_DONE|标量复算工具已有；receipt/endpoint命令缺失|原包合成测试；真实重新执行未取得|CJ1/CJ2/新S0/TierB缺原件|端点到标量与job绑定未关|
|FP-06b|PARTIALLY_DONE|source/bg/poison修复及erratum部分实现|新48pass为文档陈述；无原log|本项不需GPU|新逐lead勘误/直接F0CI未执行证实|
|FP-06c|PARTIALLY_DONE|纯规则+CLI存在；CLI fail-open|独立三例CPU反证；729语法状态枚举|本项不需GPU|条件计算PIVOT_STATIC，正式决策未认证|
|FP-07a|PARTIALLY_DONE|freeze-diagnostics函数存在|未取得冻结协议/执行回执|禁止新GPU|仅方法壳，不是问题预注册已完成|
|FP-07b|PARTIALLY_DONE|SVD/regret诊断部分实现|未取得真实运行；路径/分解需修订|禁止新GPU|共同响应/互补不足仍是假说|
|FP-07c|NOT_STARTED|无完整可证伪战略包产物|MISSING|未授权|NOT_STARTED|
|FP-08a|NOT_STARTED|未取得data_forensics实现与2022原日志|MISSING|不需要GPU|数据失败根因未知|
|FP-08b|BLOCKED|未获独立数据读取/修复许可|MISSING|未授权|不得打开未批准新年份|
|WBX-02a|PARTIALLY_DONE|实际入口已有年份门；valid-time缺口|部分新测试；跨年入口未覆盖|Tier原回执MISSING|未完成精确支持窗授权|
|WBX-02b|NOT_STARTED|公开benchmark runner/动态模型序列化缺失|MISSING|未启动|协议与部署角色未准备好|
|WBX-02c|BLOCKED|前置任务未闭合|MISSING|未获新benchmark授权|不能公开性能排名|

`DONE`严格限定原任务范围；WBX-01A/B-code本来就是code-only。旧测试不抵消新入口bug；最新status里的48pass未有原log，本次读到的真实完整历史log是FP05b prefreeze的917passed、19skipped、772.14秒，不是8ab914b重测。[R26-12；plans/plan_v4_0923/run_20260924T104725Z_fp05b/tests/pytest_full_suite_fp05b_prefreeze.log]

## 3. S0可信性与环境 [R26-01/02]
过去指定H100配置的官方1/4/12步原证书已记录零差，容差1e-5保留。最新文档登记pt-lujnmfhg在Torch2.3.1+cu121/xformers0.0.27上也为零差；该信息与未改动的核心源路径相容，但最新raw source/asset/job绑定仍MISSING。本轮结论是**REPORTED_PASS_PENDING_RAW_BINDING**，不是宣布失败，也不是独立PASS。
需核对新raw certificate SHA `4aab593d3326f754b866815e9a5d0a15ff1336a1f51079ba38689d4251949670`、actual source snapshot、effective TF32、checkpoint/normalization内容、official reference manifest/input/output。完整expected pins见S0_AND_ASSET_CONTRACT，不把旧证书的hash自动套到新job上。四卡资源分配也不等于四块卡分别都跑过parity。
四个原生single作业声称拿到H100但缺xformers，属于hardware/scheduler可用、official dependency不可用；其raw receipts未取得。5090 SDPA脚本明确engineering-only，不能替代上游official路径。依赖修复应该固定overlay/importpaths和wheel/image摘要，而不是运行途中升级Torch或静默fallback。

## 4. Fs divergence、Stage3b与Stage4 [R26-03/04/05]
### 4.1 旧问题是真的
`per_sample_loss_direction`按相同issue分组再比较first/last，避免了raw首末loss对应不同样本的错误；FsFitRecord真实记录loss与issue/time，当前训练循环round-robin、constant Adam、仅adapter更新，记录preclip total/A/B梯度、实际parameter/update norms。旧严重记录同样本0/8改善且固定Fs/F0面板约4.64或4.07，并非纯日志误解。`clip_grad_norm_`返回preclip范数；有限且经过clip不等于轨迹稳定，Adam参数位移也不由梯度clip直接固定。
旧同时四个worker各拟合不同Fs，使专家共参考前提失效；不能挑“没发散的”跨Fs混合。merge-equivalence只证明坏模型两种执行等价，不能证明训练正确。
### 4.2 新H32不能被旧H500一票否决
后续v1在认证后端仍能用lr0.01重现失稳；H256较小lr稳定却资格holdout退化，说明后端/TF32不是唯一机制。新v2 H32/lr0.0025的Q1-Q6真实资格记录存在：32updates、clip0、per-visit max1、8/8方向、train24 ratio0.9740597、train72 ratio0.9923692、资格holdout24 ratio1.0033926。后者仍是14/16略差、平均+0.3393%，但处于预注册2%容忍内。是有限资格，不是总体无害或样本外有益。
实际cache不是裸load任意Fs：`r4_candidate_cache.py:200–305`调用S0 consumption、authorize_certified_fs、deep bank verification、load_certified_fs和loaded digest。强资格到指定产物的链存在，值得保留，不应误写“仍只有merge门”。但要用raw traces/hash负控制重新验证消费者，尤其clip_events冗余字段未强制一致的问题。该代码缺口没有证据已经污染当前H32，不应夸大。
### 4.3 明确判断
Stage3b/FP04：**CERTIFIED_H32_REFERENCE_AND_K4_SCOPED_QUALIFICATION**；不是通用formal training全部稳定，也不是可以随意排除发散专家后使用任何bank。
Stage4：历史FP05b cache已经生成；本轮**不授权新Stage4缓存、重训、扩样**。只读原缓存取证可继续。新S0 PASS不能推翻已经冻结的负面/不足效用结论；若G0/Q1-Q6/真实消费链失败，禁止任何新的模型科学run。原件缺失先补原件，不用重跑伪装历史。

## 5. FP05b数值与WeatherBench-X [R26-06/08/10]
|对比|点值（%）|95% CI（%）|相对0.34%|
|---|---:|---:|---|
|oracle_vs_Fs|0.315005413|[0.282400210, 0.350733607]|STRADDLE|
|oracle_vs_M1|0.053560296|[0.041340622, 0.066692704]|BELOW|
|M1_vs_Fs|0.261445118|[0.225650290, 0.300814091]|BELOW|
|M3_vs_Fs|0.261143190|[0.238926547, 0.284374299]|BELOW|
|M3_vs_M1|-0.000301928|[-0.020659133, 0.018101311]|BELOW|
|H_Fs_24h|0.191347602|[0.149752684, 0.234196060]|BELOW|
|M3_vs_Fs_72h|0.438947600|[0.380958632, 0.495152855]|ABOVE|

以上为冻结结果文件记录，不是本次全矩阵重算。另有`phasec_independent_recompute.json`记录旧作者用不同bootstrap RNG复核全部状态一致、点值最大差3.8901e-16，支持其原统计产物的内部一致性；不把这个自带记录冒充本轮CPU执行。

**BELOW不等于负收益。** M3/Fs 95%区间全在零以上，却上界仍低于0.34%，所以是“小正效果但未达效用门”。M3/M1点约−0.000302个百分点，CI跨零；不是统计证明完全相等，却没有增量路由支持。oracle相对M1的CI也全正但上界约0.06669个百分点，远小于原0.34%，当前候选库即使hindsight路由也没有足够增量空间满足旧门槛。
`H_Fs=(ΣL_Fs−ΣL_F0)/ΣL_Fs`，24h约+0.19135%，表示Fs比F0差。M3对F0的Fs分母点增益为0.26114−0.19135=0.06980%；这是点值，不是已认证有益或F0分母百分比。须从相同bootstrap draw直接计算paired difference CI，不能把两个CI上下界各自相减。
72h M3/Fs约+0.43895%可支持该已登记guard方向，但不能替换预注册主24h，也不能用旧CSV错误复用H24的GF0_72列宣称对F0改善。新scorer源码已改lead-specific，真实append-only erratum产物还缺。[R26-08]
样本覆盖只有23/25周strata，2019H2有两段完整性缺口；dropcap8→16是事先于模型结果的完整性修订，不等同协议从没变。2020训练→2019评估是回顾性dev而非时间因果部署；上游2019checkpoint选择年也不等于从未被任何模型选择过程见过。旧0.0034不根据诊断结果修改。

**冻结规则顺序**先看oracle/Fs是否BELOW，再看oracle/M1。第一项STRADDLE不立即终止整套规则；第二项BELOW命中PIVOT_STATIC。该判断不是“所有STRADDLE都一律INCONCLUSIVE”，也不是statics已过门槛。正式gate目前不能交给有fail-open漏洞的CLI。

WeatherBench-X已真正复用official metric/aggregation/loaders及region配置，框架集成有工程价值。它是评价框架而非一种使预报更准的方法；TierA/B smoke不是公开benchmark。原TierB summary路径404、raw metric表/GPU联结未取得，故本轮不报未核实的RMSE/ACC胜负。若旧材料写104×3，它是metric条目维度，不能冒充312独立天气样本。

## 6. 新代码问题，按重要性
### R26-07 · EXECUTION_CONFIRMED：FP06默认许可
两份源码Git blob完全相同后运行CLI：missing validity→PIVOT_STATIC/rc0；字符串false→PIVOT_STATIC/rc0；显式False→INVALID但仍rc0。根因`bool(obj.get('evidence_valid',True))`，核心函数却是严格is True。新代码的错不能推断旧FP05b被这个后来入口污染，但它会让本轮“正式收尾”不可靠。须消费真实gate artifact+hash，而不只是修成默认False后仍信caller随意True。

### R26-09 · STATIC_CONFIRMED：WBX跨年真值绕过
真实入口已接入year门是进展；requested_years只由init_times导出，2020-12-31+72h的2021truth没有被此门阻挡。single_chunk的caller times未和真实arrays绑定，default2020/任意authorized并非全支持窗许可。补真实valid_time/history/allowlist校验与loader-before-spy负例。

### R26-08 · STATIC_CONFIRMED：erratum不是完整修复
旧24h只比较分类字符串，未比对point/CI/actions；输出名paired_F0_intervals实际只有H的区间；没有包括driver自己的sourcehash；gate失败却可能rc0。普通scorer已增加source/bg/manifest guards值得认可，但不能因此打勾全部FP06b。

### R26-11 · STATIC_CONFIRMED：诊断绑定与分解
校验protocol路径后转而从另一个inputs文件读取是入口漏洞。只做列中心化的gain矩阵仍含全专家共享的样本难度方向，SVD不直接代表状态依赖互补；需同时给common component与double-centered interaction。没有真实运行产物就保持PARTIALLY_DONE，metadata前后四文件不变不能证明所有叶子只读。

### R26-12 · STATIC_CONFIRMED：命令和发布缺口
runner当前只有fp06-decision，而原v6计划要求receipt-audit、endpoint-audit等；实际诊断子命令与原伪命令有差异。需命令mapping和end-to-end证据，不因接口文字变更自动判计划违约，也不因代码存在升格完成。只保存参数digest的OOF不是可加载部署模型；公开WBX动态比较仍需完整serialization。

## 7. novelty与是否继续投入 [R26-13]
相关工作的详细对照和出处见`evidence/LITERATURE_REVIEW.md`。Aurora/WeatherPEFT覆盖天气基础模型适配；PETSA覆盖时序TTA的低秩/门控；CoMoL覆盖LoRA专家与动态路由；VI-MoLE已提出counterfactual risk/utility routing；MergeProbe预测adapter合并utility；经典observation-impact和sequential learning也已存在。
最强可辩护方向不是“第一次组合这些模块”，而是**在冻结天气动力学中预测有限参数干预的状态依赖后续响应，将其与基线误差对齐，以同预算选择或拒绝编辑，并检验该预测跨候选、lead/Q或天气状态的迁移**。平方误差的`2<e,d>−||d||²`是精确代数，不是novelty证明。
当前可支持：有限官方数值一致、有限资格/组装、合法OOF小正但subthreshold/无路由增量的实验记录。当前不能支持：动态编辑有实际天气效用、因果根因已完整定位、factorization胜过direct-gain、跨候选迁移或发表级novelty。
建议继续一轮9小时闭环，但不支持重复同bank扩样。优先用现有缓存回答“专家是否只有共同修正、是否有可被状态选择利用的差异”。如果oracle空间不足，先重设计候选生成或保留静态路线；如果有充足差异但selector失败，再考虑更好的状态表示。此判断不等于整个EarthDelta方向终止。

## 8. 8–10小时计划与STOP
本包FP-09a60min环境/receipt；09b90minFs lineage+拒绝门；09c90min真实入口修复；09d90min原标量/端点/逐lead配对勘误；09e90min只读功能诊断；09f60min正式first-match+最小提案；09g60min独立回归和交接。总540min是规划timebox，不是声称已测runtime。默认0新GPU，恢复原GPU证据。09c可独立并行，任何G0/G1失败都没有新Stage4授权边。详尽输入、命令/伪命令、资源、输出、成功、STOP和pivot见FOLLOWUP_PLAN及CODEX_TASKS。
到600min或缺关键原件即停相关gate并保存BLOCKED，不能靠减测试/改门槛按时完成。不得FP07倒写FP05b；不得为补原票据重跑模型；不得将2020H2改称clean confirm；不得根据已见结果扩样或换主lead。新实验只输出提案，最少F0/Fs/static/direct/factorized/oracle和state-shuffle、同输入成本对照，不堆JEPA/memory/dynamic rank。

## 9. 不能对外宣称
不能说最新pt-lujnmfhg原件已经被本轮独立认证；不能说所有H100原生镜像依赖可用；不能说旧500步Fs发散是假问题或新32步认证覆盖500步；不能说merge/861或917测试/四卡启动证明科学价值；不能说FP05b完全没跑样本外或没有任何正效果；不能说M3已过0.34%或显著优于M1；不能说GF0点值证明天气实用增益；不能说TierB就是完整公开benchmark；不能说诊断SVD证明因果互补；不能说novelty已经实验证明。

本报告每条finding的标签、精确路径和最小后续动作见CURRENT_GAP_ANALYSIS及PLAN_AUDIT_RESULT。实际原件不足处为MISSING，推导与建议单独标明，不用摘要填补证据。


## 历史合同与最新复验分开
G0必须分成 `G0_OLD_FROZEN_CONTRACT` 与 `G0_NEW_RECHECK`。前者绑定原FP05b实际消费的S0、source与资产，是复算原结果的身份前提；后者绑定新pt-lujnmfhg，仅用于认证“最新环境复验已通过”的声明。若原合同可完整核验而新原件缺失，最新复验保持MISSING/INCONCLUSIVE，不替换旧证书，也不阻止已封存旧缓存的只读复算。任何新模型科学作业仍没有本包授权；原合同或Fs gate本身失败则不得将旧缓存复算升级为经过认证的科学结论。不要因为后来的一张回执未上传，就倒推旧试验一定失效。
