# EarthDelta round-two independent review

Read codex_audit_round2/README.md for navigation, and use codex_audit_round2/CHATGPT_PRO_PROMPT.md as the review request.

The Markdown reading packet is in codex_audit_round2/delivery/. Source outside the audit directory is fixed at fb767f7f6efbc428be39c9ad84f5905331d6e40f. Official Stormer excerpts and their MIT license are under codex_audit_round2/context/upstream_stormer/.

This is an evidence package, not a complete runtime environment. It contains no model checkpoints, weather data, or normalization binaries.
